<style>
  .option-dialog-pro .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'添加账户':'修改账户'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pro">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="账户：" prop="cUserName">
        <el-input v-model.trim="dataInfoForm.cUserName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="真实姓名：" prop="cRealName">
        <el-input v-model.trim="dataInfoForm.cRealName" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="登陆密码：" v-if="optionData.type == 'add'" prop="cPassword" :rules="{required: true, validator: validatePsw, trigger: 'blur'}">
        <el-input v-model="dataInfoForm.cPassword" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="登陆密码：" v-if="optionData.type == 'update'" prop="cPassword" :rules="{validator: validatePsw, trigger: 'blur'}">
        <el-input v-model="dataInfoForm.cPassword" auto-complete="off"  placeholder="输入密码将覆盖原密码"></el-input>
      </el-form-item>
      <el-form-item label="选择角色：" prop="cRoleName">
        <el-select v-model="dataInfoForm.cRoleName" clearable placeholder="请选择" auto-complete="off">
          <el-option
            v-for="item in roleList"
            :key="item.iRoleId"
            :label="item.cRoleName"
            :value="item.cRoleName">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="手机号：" prop="cMobile">
        <el-input v-model="dataInfoForm.cMobile" auto-complete="off"></el-input>
      </el-form-item>
      <el-form-item label="状态：" >
        <el-radio-group v-model="dataInfoForm.cStatus">
          <el-radio class="radio" :label="1">启用</el-radio>
          <el-radio class="radio" :label="0">禁用</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import userAccountApi from '../../apis/user-account-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        roleList: null,
        rules: {
          cUserName: [
            {required: true, message: '请输入用户名', trigger: 'blur'}
//            {validator: this.validateUserName, trigger: 'blur'}
          ],
          cRealName: [
            {required: true, message: '请输入真实姓名', trigger: 'blur'}
//            {validator: this.validateRealName, trigger: 'blur'}
          ],
          cRoleName: [
            {required: true, message: '请选择角色', trigger: 'blur'}
          ],
          cMobile: [
            {required: true, message: '请输入手机号', trigger: 'blur'},
            {validator: this.validatePho, trigger: 'blur'}
          ],
          cStatus: [
            {required: true, message: '请选择状态', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.selectRoleList()
      if (this.optionData.type === 'update') {
        this.dataInfoForm.cPassword = null
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      // 获取角色列表
      selectRoleList () {
        const params = {'currentPage': 1, 'number': 100}
        userAccountApi.getRoleDataList(params).then((data) => {
          if (data.code === 1) {
            this.roleList = data.data.list
          }
        }, (error) => {
          console.log(error)
          this.roleList = null
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              userAccountApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              userAccountApi.updateDataInfo(_this.dataInfoForm.iUserId, _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      },
      validateUserName (rule, value, callback) {
        let regExp = /^[a-zA-Z][a-zA-Z0-9]{4,14}$/
        if (value === undefined || value === '') {
          callback(new Error('请输入用户名'))
        } else if (regExp.test(value) === false) {
          callback(new Error('5-15位以字母开头，包含字母和数字'))
        } else {
          callback()
        }
      },
      validateRealName (rule, value, callback) {
        let regExp = /^[\u4e00-\u9fa5]{2,4}$/
        if (value === undefined || value === '') {
          callback(new Error('请输入真实姓名'))
        } else if (regExp.test(value) === false) {
          callback(new Error('2-4位汉字'))
        } else {
          callback()
        }
      },
      validatePsw (rule, value, callback) {
        let regExp = /^[a-zA-Z][a-zA-Z0-9_]{5,11}$/
        if (this.optionData.type === 'add') {
          if (value === undefined || value === '') {
            callback(new Error('请输入密码'))
          } else if (regExp.test(value) === false) {
            callback(new Error('6-12位以字母开头,包含字母、数字、下划线'))
          } else {
            callback()
          }
        } else if (this.optionData.type === 'update') {
          if (value) {
            if (regExp.test(value) === false) {
              callback(new Error('6-12位以字母开头,包含字母、数字、下划线'))
            } else {
              callback()
            }
          } else {
            callback()
          }
        }
      },
      validatePho (rule, value, callback) {
        let regExp = /^1[34578]\d{9}$/
        if (value === undefined || value === '') {
          callback(new Error('请输入手机号'))
        } else if (regExp.test(value) === false) {
          callback(new Error('11位手机号码'))
        } else {
          callback()
        }
      }

    }
  }
</script>
