<style>
  .option-dialog-pro .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?(optionData.optionType=='menuList'?'添加菜单':'添加功能'):(optionData.optionType=='menuList'?'修改菜单':'修改功能')"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pro">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item :label="optionData.optionType=='menuList'?'菜单名称：':'功能名称：'" prop="cMenuName">
        <el-input v-model="dataInfoForm.cMenuName"></el-input>
      </el-form-item>
      <el-form-item label="功能标识：" prop="cIdentifier" v-if="optionData.optionType=='menuOperation'">
        <el-select v-model="dataInfoForm.cIdentifier" filterable placeholder="请选择">
          <el-option
            v-for="item in roleAuthorityList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="菜单类型：" prop="cMenuType">
        <el-radio-group v-model="dataInfoForm.cMenuType">
          <el-radio v-for="item in [{name:'菜单',value:0,enabled:optionData.optionType=='menuList'},{name:'页面',value:1,enabled:true},{name:'按钮',value:2,enabled:optionData.optionType=='menuOperation'},{name:'分类',value:3,enabled:true}]"
                    class="radio" :label="item.value" :disabled="!item.enabled">{{item.name}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="菜单类型：" prop="cMenuType">-->
        <!--<el-select v-model="dataInfoForm.cMenuType" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in [{name:'菜单',value:0,enabled:optionData.optionType=='menuList'},{name:'页面',value:1,enabled:true},{name:'按钮',value:2,enabled:optionData.optionType=='menuOperation'},{name:'分类',value:3,enabled:true}]"-->
            <!--:key="item.value"-->
            <!--:label="item.name"-->
            <!--:value="item.value"-->
            <!--:disabled="!item.enabled">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="排序：" prop="iOrderNum">
        <el-input v-model.number.trim="dataInfoForm.iOrderNum"></el-input>
      </el-form-item>
      <el-form-item label="菜单图标：" prop="cIcon" v-if="optionData.optionType=='menuList'">
        <el-input v-model.number.trim="dataInfoForm.cIcon"></el-input>
      </el-form-item>
      <el-form-item :label="optionData.optionType=='menuList'?'菜单路径：':(dataInfoForm.cMenuType == 3?'分类值：':'功能路径：')" prop="cUrl" v-if="dataInfoForm.cMenuType == 1 || dataInfoForm.cMenuType == 3">
        <el-input v-model="dataInfoForm.cUrl"></el-input>
      </el-form-item>
      <el-form-item label="访问地址：" prop="cBackUrl" v-if="optionData.optionType=='menuOperation'&& dataInfoForm.cMenuType == 2">
        <el-input v-model="dataInfoForm.cBackUrl "></el-input>
      </el-form-item>
      <el-form-item label="提交方式：" prop="cBackMethod" v-if="optionData.optionType=='menuOperation'&& dataInfoForm.cMenuType == 2">
        <el-radio-group v-model="dataInfoForm.cBackMethod">
          <el-radio v-for="item in methodTypeList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="提交方式：" prop="cBackMethod" v-if="optionData.optionType=='menuOperation'&& dataInfoForm.cMenuType == 2">-->
        <!--<el-select v-model="dataInfoForm.cBackMethod" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in methodTypeList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('gameInfoForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import menuApi from '../../apis/menu-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
          cMenuName: [
            {required: true, message: '请输入名称', trigger: 'blur'}
          ],
          cIdentifier: [
            {required: true, message: '请选择功能标识', trigger: 'change'}
          ],
          cMenuType: [
            {type: 'number', required: true, message: '请选择服务器版本号', trigger: 'change'}
          ],
          cUrl: [
            {required: true, message: '请输入路径', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'roleAuthorityList', 'methodTypeList'
      ])
    },
    created: function () {

    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              menuApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              // 数据修改
              menuApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
