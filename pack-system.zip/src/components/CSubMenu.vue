<style scoped>
</style>
<template>
  <el-submenu :index="menu.iMenuId+''">
    <template slot="title"><i class="menu-parent-icon icon iconfont" :class="menu.cIcon|| 'icon-caidan'"></i>{{menu.label}}</template>
    <template v-for="item in menu.children">
      <template v-if="item.children && item.children.length>0">
        <c-sub-menu :menu="item"></c-sub-menu>
      </template>
      <template v-else>
        <el-menu-item :index="item.iMenuId+''" @click="menuItemSelect(item)">
          <i class="menu-icon icon iconfont" :class="'icon-dian'" style="margin-left: 6px;"></i>{{item.label}}
          <!--<span style="margin-left: 2px;">{{item.label}}</span>-->
        </el-menu-item>
      </template>
    </template>

  </el-submenu>
</template>
<script>
  export default {
    name: 'cSubMenu',
    props: ['menu'],
    methods: {
      menuItemSelect (menu) {
        this.$router.push(menu.cUrl)
      }
    }
  }
</script>
