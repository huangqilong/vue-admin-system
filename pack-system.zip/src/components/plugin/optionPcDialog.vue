<style>
  .option-dialog-cha .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增渠道':'修改渠道'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-cha">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="120px">
      <el-form-item label="地区：" prop="iAreaId">
        <el-select v-model="dataInfoForm.iAreaId" placeholder="请选择" @change="changeDataList()">
          <el-option
            v-for="item in areaList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="语言：" prop="iLanguageId">
        <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择" @change="changeDataList()">
          <el-option
            v-for="item in languageList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="平台：" prop="iPlatformId">
        <el-radio-group v-model="dataInfoForm.iPlatformId" @change="changePlatformDataList()">
          <el-radio v-for="item in platformList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="平台：" prop="iPlatformId">-->
        <!--<el-select v-model="dataInfoForm.iPlatformId" placeholder="请选择" @change="changePlatformDataList()">-->
          <!--<el-option-->
            <!--v-for="item in platformList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="游戏名称：" prop="gameId">
        <el-select v-model="dataInfoForm.gameId" placeholder="请选择">
          <el-option
            v-for="item in gameList"
            :key="item.gameId"
            :label="item.gameName"
            :value="item.gameId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="渠道名称：">
        <el-select v-model="dataInfoForm.iChannelId" placeholder="请选择">
          <el-option
            v-for="item in channelList"
            :key="item.iChannelId"
            :label="item.channelName"
            :value="item.iChannelId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="插件类型：" prop="pluginType">
        <el-radio-group v-model="dataInfoForm.pluginType" @change="getPluginList()">
          <el-radio class="radio" :label="'1'">功能</el-radio>
          <el-radio class="radio" :label="'2'">广告</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="插件名称：" prop="pluginDictId">
        <el-select v-model="dataInfoForm.pluginDictId" placeholder="请选择" @change="selectPluginDic()">
          <el-option
            v-for="item in pluginList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="参数配置：">
        <el-table :data="paramsDataList" stripe>
          <el-table-column prop="paramsKey" label="参数名"></el-table-column>
          <el-table-column prop="paramsValue" label="参数值">
            <template scope="scope">
              <el-input v-model="scope.row.paramsValue" placeholder="请输入参数值"></el-input>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import pluginApi from '../../apis/plugin-api'
  import gameApi from '../../apis/game-api'
  import channelApi from '../../apis/channel-api'
  import dictionaryApi from '../../apis/dictionary-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        gameList: [],
        channelList: [],
        pluginList: [],
        paramsDataList: [],
        platformType: 'android',
        isUpdateOption: false,
        isFirstUpdateGameOption: false,
        isFirstUpdateChannelOption: false,
        isFirstUpdatePluginOption: false,
        rules: {
          iAreaId: [
            {type: 'number', required: true, message: '请选择地区', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择语言', trigger: 'change'}
          ],
          iPlatformId: [
            {type: 'number', required: true, message: '请选择平台', trigger: 'change'}
          ],
          gameId: [
            {type: 'number', required: true, message: '请选择游戏', trigger: 'change'}
          ],
          iChannelId: [
            {type: 'number', required: true, message: '请选择渠道', trigger: 'change'}
          ],
          pluginDictId: [
            {type: 'number', required: true, message: '请选择插件', trigger: 'change'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'buttonLoading', 'pluginTypeList'
      ])
    },
    created: function () {
      if (this.optionData.type === 'update') {
        this.isUpdateOption = true
        this.isFirstUpdateGameOption = true
        this.isFirstUpdateChannelOption = true
        this.isFirstUpdatePluginOption = true
      }
      this.getGameList()
      this.getChannelList()
      this.getPluginList()
    },
    methods: {
      changeDataList () {
        this.getGameList()
        this.getChannelList()
      },
      changePlatformDataList () {
        this.getGameList()
        this.getChannelList()
        this.getPluginList()
      },
      // 判断平台类型
      judgePlatformType () {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === this.dataInfoForm.iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
      },
      // 获取游戏列表
      getGameList () {
        let _this = this
        let optionParams = {
          areaId: this.dataInfoForm.iAreaId,
          languageId: this.dataInfoForm.iLanguageId,
          platformId: this.dataInfoForm.iPlatformId
        }
        // 获得打包游戏项目表
        gameApi.getAllDataList(optionParams).then((data) => {
          if (data.code === 1) {
            _this.gameList = data.data
            if (!this.isUpdateOption) {
              this.dataInfoForm.gameId = ''
            } else {
              this.isFirstUpdateGameOption = false
              if (!this.isFirstUpdateGameOption && !this.isFirstUpdateChannelOption && !this.isFirstUpdatePluginOption) {
                this.isUpdateOption = false
              }
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      getChannelList () {
        let _this = this
        let optionParams = {
          areaId: this.dataInfoForm.iAreaId,
          languageId: this.dataInfoForm.iLanguageId,
          platformId: this.dataInfoForm.iPlatformId
        }
        const params = {'currentPage': 1, 'number': 9999, ...optionParams}
        // 获取数据列表
        channelApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.channelList = data.data.list
            if (!this.isUpdateOption) {
              this.dataInfoForm.iChannelId = ''
            } else {
              this.isFirstUpdateChannelOption = false
              if (!this.isFirstUpdateGameOption && !this.isFirstUpdateChannelOption && !this.isFirstUpdatePluginOption) {
                this.isUpdateOption = false
              }
            }
          }
        }, (error) => {
          this.channelList = null
        })
      },
      getPluginList () {
        let typeArray = ['func_plugin', 'Android_ad_plugin', 'IOS_ad_plugin']
        let type = ''
        if (this.dataInfoForm.pluginType === '1') {
          type = typeArray[0]
        } else {
          this.judgePlatformType()
          if (this.platformType === 'ios') {
            type = typeArray[2]
          } else {
            type = typeArray[1]
          }
        }
        dictionaryApi.getDictsByType(type).then((data) => {
          if (data.code === 1) {
            this.pluginList = data.data
            if (!this.isUpdateOption) {
              this.dataInfoForm.pluginDictId = ''
            } else {
              this.selectPluginDic()
            }
          }
        }, (error) => {
          console.log(error)
          this.pluginList = []
        })
      },
      selectPluginDic () {
        this.paramsDataList = []
        if (this.isUpdateOption) {
          let resKey = this.dataInfoForm.paramsKey.split(',')
          let resValue = this.dataInfoForm.paramsValue ? this.dataInfoForm.paramsValue.split(',') : []
          for (let rIndex in resKey) {
            this.paramsDataList.push({
              paramsKey: resKey[rIndex],
              paramsValue: resValue.length > 0 ? resValue[rIndex] : ''
            })
          }
          this.isFirstUpdatePluginOption = false
          if (!this.isFirstUpdateGameOption && !this.isFirstUpdateChannelOption && !this.isFirstUpdatePluginOption) {
            this.isUpdateOption = false
          }
        } else {
          this.dataInfoForm.paramsKey = ''
          if (this.dataInfoForm.pluginDictId) {
            dictionaryApi.getPluginDictIdList(this.dataInfoForm.pluginDictId).then((data) => {
              if (data.code === 1) {
                this.dataInfoForm.paramsKey = data.val
                let resData = data.val.split(',')
                for (let resItem of resData) {
                  this.paramsDataList.push({
                    paramsKey: resItem,
                    paramsValue: ''
                  })
                }
              }
            }, (error) => {
              console.log(error)
            })
          }
        }
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let paramsAry = []
            for (let param of this.paramsDataList) {
//              if (param.paramsValue === '') {
//                this.$alert('参数配置不可为空', '提醒', {
//                  confirmButtonText: '确定'
//                })
//                return false
//              }
              paramsAry.push(param.paramsValue)
            }
            this.dataInfoForm.paramsValue = paramsAry.join(',')
            pluginApi.addGcConfigDataInfo(_this.dataInfoForm).then((data) => {
              if (data.code === 1) {
                this.optionData.dialogFormVisible = false
                _this.optionCallBack()
              } else {
                this.$alert(data.msg, '操作失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              console.log(error)
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
