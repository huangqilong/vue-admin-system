<style>
  .option-dialog-version .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog .upload-demo-table{
    width: 80px;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增插件版本':'修改插件版本'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-version">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="版本号：" prop="channelVersion">
        <el-input v-model.trim="dataInfoForm.channelVersion"></el-input>
      </el-form-item>
      <el-form-item label="cocoapods：" prop="cCocoapods" v-if="this.$route.params.type=='ios'">
        <el-input v-model.trim="dataInfoForm.cCocoapods"></el-input>
      </el-form-item>
      <el-form-item label="版本描述：" prop="cDesc">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.cDesc"></el-input>
      </el-form-item>
      <el-form-item label="资源路径：" prop="cResPath" v-if="false">
        <el-input v-model.trim="dataInfoForm.cResPath"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import channelApi from '../../apis/channel-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        rules: {
          channelVersion: [
            {required: true, message: '请输入版本号', trigger: 'blur'}
          ],
          cCocoapods: [
            {required: true, message: '请输入cocoapods', trigger: 'blur'}
          ],
          cResPath: [
            {required: true, message: '请输入资源路径', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              if (this.$route.params.type !== 'ios') {
                _this.dataInfoForm.channelVersionValue = _this.dataInfoForm.channelVersion
              }
              // 数据新增
              channelApi.addVersionDataInfo(_this.$route.params.type, _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm)) {
                this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              if (this.$route.params.type !== 'ios') {
                _this.dataInfoForm.channelVersionValue = _this.dataInfoForm.channelVersion
              }
              // 数据修改
              channelApi.updateVersionDataInfo(_this.$route.params.type, _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
