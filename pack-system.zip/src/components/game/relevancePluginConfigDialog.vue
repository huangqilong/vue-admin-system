<style>
  .option-dialog-config .el-dialog{
    min-width: 800px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog .upload-demo-table{
    width: 80px;
  }
  .option-dialog .pre-config-option{
    position: absolute;
    top: 19px;
    left: 140px;
  }
</style>
<template>
  <el-dialog :title="optionData.title"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-config">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="230px">
      <el-form-item  label="最小系统版本：" prop="minSdkVersion">
        <el-input v-model.number.trim="dataInfoForm.minSdkVersion"></el-input>
      </el-form-item>
      <el-form-item  label="指定系统版本：" prop="targetSdkVersion">
        <el-input v-model.number.trim="dataInfoForm.targetSdkVersion"></el-input>
      </el-form-item>
      <el-form-item  label="渠道版本值：" prop="channelVersionValue">
        <el-input v-model.trim="dataInfoForm.channelVersionValue" :disabled="true"></el-input>
      </el-form-item>
      <el-form-item  label="版本额外字段：" prop="channelVersionExtra">
        <el-input v-model.trim="dataInfoForm.channelVersionExtra"></el-input>
      </el-form-item>
      <el-form-item  label="maven的名称：" prop="mavenChannelName">
        <el-input v-model.trim="dataInfoForm.mavenChannelName"></el-input>
      </el-form-item>
      <el-form-item  label="maven的group：" prop="mavenChannelGroup">
        <el-input v-model.trim="dataInfoForm.mavenChannelGroup"></el-input>
      </el-form-item>
      <el-form-item  label="applicationName：" prop="applicationName">
        <el-input v-model.trim="dataInfoForm.applicationName"></el-input>
      </el-form-item>
      <el-form-item  label="特殊处理的渠道配置ID：" prop="specChannelConfig">
        <el-input v-model.number.trim="dataInfoForm.specChannelConfig"></el-input>
      </el-form-item>
      <el-form-item label="是否分包：" prop="cDex">
        <el-radio class="radio" v-model="dataInfoForm.cDex" label="1">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cDex" label="0">否</el-radio>
      </el-form-item>
      <el-form-item label="是否需要生成微信jar：" prop="cWxjar">
        <el-radio class="radio" v-model="dataInfoForm.cWxjar" label="1">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cWxjar" label="0">否</el-radio>
      </el-form-item>
      <el-form-item label="是否需要填写metadata：" prop="cMetadata">
        <el-radio class="radio" v-model="dataInfoForm.cMetadata" label="1">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cMetadata" label="0">否</el-radio>
      </el-form-item>
      <el-form-item label="渠道自定义参数：" prop="metaData" v-if="dataInfoForm.cMetadata==1">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.metaData"></el-input>
      </el-form-item>
      <el-form-item label="是否需要特殊处理：" prop="cSpeHand">
        <el-radio class="radio" v-model="dataInfoForm.cSpeHand" label="1">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cSpeHand" label="0">否</el-radio>
      </el-form-item>
      <el-form-item  label="特殊处理路径：" prop="spePath" v-if="dataInfoForm.cSpeHand==1">
        <el-input v-model.trim="dataInfoForm.spePath"></el-input>
      </el-form-item>
      <el-form-item  label="特殊处理文件名称：" prop="speFileName" v-if="dataInfoForm.cSpeHand==1">
        <el-input v-model.trim="dataInfoForm.speFileName"></el-input>
      </el-form-item>
      <el-form-item  label="特殊处理文件内容：" prop="speContent" v-if="dataInfoForm.cSpeHand==1">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.speContent"></el-input>
      </el-form-item>
      <el-form-item label="启动配置：" prop="cLauncher">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.cLauncher"></el-input>
      </el-form-item>
      <el-form-item label="客户端是否请求接口初始化接口：" prop="cRequestParams">
        <el-radio class="radio" v-model="dataInfoForm.cRequestParams" label="1">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cRequestParams" label="0">否</el-radio>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'

  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        preConfigCheck: false,
        rules: {
          minSdkVersion: [
            { pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur' }
          ],
          targetSdkVersion: [
            { pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur' }
          ],
          specChannelConfig: [
            { pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur' }
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          // 数据修改
          gameApi.putGameChannelRelevancePluginConfigData(_this.dataInfoForm).then((data) => {
            if (data.code === 1) {
              this.optionData.dialogFormVisible = false
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            console.log(error)
          })
        })
      }
    }
  }
</script>
