<style>
  .option-dialog-config-ios-config .el-dialog{
    width: 900px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .tabs-content{
    padding-left: 10px;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增游戏配置':'修改游戏配置'" :visible.sync="optionData.dialogFormVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-config-ios-config">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="130px">
      <el-row>
        <el-col :span="8">
          <el-form-item label="渠道名称：" prop="iChannelId">
            <el-select v-model="dataInfoForm.iChannelId" placeholder="请选择" @change="channelSelectChange(true)">
              <el-option
                v-for="item in channelList"
                :key="item.iChannelId"
                :label="item.channelName"
                :value="item.iChannelId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="渠道版本：" prop="iChannelConfigId">
            <el-select v-model="dataInfoForm.iChannelConfigId" placeholder="请选择">
              <el-option
                v-for="item in channelVersionList"
                :key="item.iIosChannelId"
                :label="item.channelVersion"
                :value="item.iIosChannelId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item :label="(optionData.gameInfo.cAssertType == '1'&&dataInfoForm.iUseImessage==1)?'游戏appstore描述文件：':'描述文件：'" prop="keystorePath">
            <el-upload
              class="upload-demo"
              :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
              :show-file-list="true"
              :multiple="false"
              :headers="headersFile"
              :file-list="fileStoreUploadList"
              :before-upload="beforeFileUpload"
              :on-success="handleStoreFileSuccess"
              :on-remove="handleStoreFileRemove"
              :on-error="handleStoreFileError"
              :on-progress="handleFileProgress">
              <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
            </el-upload>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="证书签名：" prop="cCertType">
            <el-select v-model="dataInfoForm.cCertType" placeholder="请选择" @change="getIOSCertList(true)">
              <el-option
                v-for="item in signatureTypeList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="证书名称：" prop="iCertId">
            <el-select v-model="dataInfoForm.iCertId" placeholder="请选择">
              <el-option
                v-for="item in certList"
                :key="item.iCertId"
                :label="item.cCertName"
                :value="item.iCertId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="包名：" prop="bundleId">
            <el-input v-model.trim="dataInfoForm.bundleId"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="bugly ID：">
            <el-input v-model.trim="dataInfoForm.buglyId"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="bugly KEY：">
            <el-input v-model.trim="dataInfoForm.buglyKey"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="最小版本：" prop="minIosVersion">
            <el-select v-model="dataInfoForm.minIosVersion" placeholder="请选择">
              <el-option
                v-for="item in iosSystemVersionList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="代理版本：" prop="iMiddleareId">
            <el-select v-model="dataInfoForm.iMiddleareId" placeholder="请选择">
              <el-option
                v-for="item in agencyList"
                :key="item.iMiddleareId"
                :label="item.cMiddleareVersion +'（'+(item.cAssertType == agencyTypeList[0].iDicId ? agencyTypeList[0].sDicName:(item.cAssertType == agencyTypeList[1].iDicId ? agencyTypeList[1].sDicName: agencyTypeList[2].sDicName))+'）'"
                :value="item.iMiddleareId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="项目名称：" prop="cProjectName">
            <el-input v-model.trim="dataInfoForm.cProjectName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="构建版本：" prop="buildVersion">
            <el-input v-model.trim="dataInfoForm.buildVersion"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <el-form-item label="渠道额外资源：" prop="extraResPath">
            <el-row>
              <el-col :span="21">
                <el-upload
                  class="upload-demo"
                  :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
                  :show-file-list="true"
                  :multiple="false"
                  :headers="headersFile"
                  :file-list="extraResUploadList"
                  :before-upload="beforeExtraResUpload"
                  :on-success="handleExtraResSuccess"
                  :on-remove="handleExtraResRemove"
                  :on-error="handleExtraResError"
                  :on-progress="handleExtraResProgress">
                  <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
                </el-upload>
              </el-col>
              <el-col :span="3" style="text-align: right;">
                <el-button size="mini" type="text" @click="extraResDemoUpload">实 例</el-button>
                <el-button size="mini" type="text" @click="extraResUpload" v-if="dataInfoForm.extraResPath">下载</el-button>
              </el-col>
            </el-row>
          </el-form-item>
        </el-col>
      </el-row>
      <!--
      <el-row v-if="optionData.gameInfo.cAssertType == '1'">
        <el-col :span="8">
          <el-form-item label="是否启用iMessage：">
            <el-radio class="radio" v-model="dataInfoForm.iUseImessage" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.iUseImessage" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="optionData.gameInfo.cAssertType == '1'&& dataInfoForm.iUseImessage==1">
        <el-col :span="8">
          <el-form-item label="证书签名：" prop="imessageCertType">
            <el-select v-model="imessageCertType" placeholder="请选择" @change="getImessageCertList(true)">
              <el-option
                v-for="item in signatureTypeList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId"
                :disabled="item.iDicId!='0'">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="iMessage证书名称：" prop="imessageCertId">
            <el-select v-model="dataInfoForm.imessageCertId" placeholder="请选择">
              <el-option
                v-for="item in imessageCertList"
                :key="item.iCertId"
                :label="item.cCertName"
                :value="item.iCertId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="iMessage包名：" prop="imessageBundleId">
            <el-input v-model.trim="dataInfoForm.imessageBundleId"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="optionData.gameInfo.cAssertType == '1'&& dataInfoForm.iUseImessage==1">
        <el-col :span="8">
          <el-form-item label="游戏adhoc描述文件：" prop="imessagePathPp1">
            <el-upload
              class="upload-demo"
              :action="proxyDevApi + '/uploadFile/' +messageFileUploadDirId+'/name/pp1/suffix/mobileprovision'"
              :show-file-list="true"
              :multiple="false"
              :headers="headersFile"
              :file-list="filePp1UploadList"
              :before-upload="beforeFileUpload"
              :on-success="handlePp1FileSuccess"
              :on-remove="handlePp1FileRemove"
              :on-error="handlePp1FileError"
              :on-progress="handleFileProgress">
              <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
            </el-upload>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="iMessage appstore描述文件：" prop="imessagePathPpim">
            <el-upload
              class="upload-demo"
              :action="proxyDevApi + '/uploadFile/' +messageFileUploadDirId+'/name/ppim/suffix/mobileprovision'"
              :show-file-list="true"
              :multiple="false"
              :headers="headersFile"
              :file-list="filePpimUploadList"
              :before-upload="beforeFileUpload"
              :on-success="handlePpimFileSuccess"
              :on-remove="handlePpimFileRemove"
              :on-error="handlePpimFileError"
              :on-progress="handleFileProgress">
              <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
            </el-upload>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="iMessage adhoc描述文件：" prop="imessagePathPpim1">
            <el-upload
              class="upload-demo"
              :action="proxyDevApi + '/uploadFile/' +messageFileUploadDirId+'/name/ppim1/suffix/mobileprovision'"
              :show-file-list="true"
              :multiple="false"
              :headers="headersFile"
              :file-list="filePpim1UploadList"
              :before-upload="beforeFileUpload"
              :on-success="handlePpim1FileSuccess"
              :on-remove="handlePpim1FileRemove"
              :on-error="handlePpim1FileError"
              :on-progress="handleFileProgress">
              <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
            </el-upload>
          </el-form-item>
        </el-col>
      </el-row> -->

      <el-row>
        <el-col :span="8">
          <el-form-item label="是否开启AppStore包：">
            <el-radio class="radio" v-model="dataInfoForm.iUseAppstore" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.iUseAppstore" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="dataInfoForm.iUseAppstore==1">
        <el-col :span="24">
          <el-form-item label="AppStore描述文件：" prop="imessagePathPp1">
            <el-upload
              class="upload-demo"
              :action="proxyDevApi + '/uploadFile/' +messageFileUploadDirId+'/name/pp1/suffix/mobileprovision'"
              :show-file-list="true"
              :multiple="false"
              :headers="headersFile"
              :file-list="filePp1UploadList"
              :before-upload="beforeFileUpload"
              :on-success="handlePp1FileSuccess"
              :on-remove="handlePp1FileRemove"
              :on-error="handlePp1FileError"
              :on-progress="handleFileProgress">
              <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
            </el-upload>
          </el-form-item>
        </el-col>
        <el-col :span="24">
          <el-row>
            <el-col :span="8">
              <el-form-item label="是否启用iMessage：">
                <el-radio class="radio" v-model="dataInfoForm.iUseImessage" :label="1">是</el-radio>
                <el-radio class="radio" v-model="dataInfoForm.iUseImessage" :label="0">否</el-radio>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-if="dataInfoForm.iUseImessage==1">
            <el-col :span="8">
              <el-form-item label="iMessage包名：" prop="imessageBundleId">
                <el-input v-model.trim="dataInfoForm.imessageBundleId"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="iMessage appstore描述文件：" prop="imessagePathPpim">
                <el-upload
                  class="upload-demo"
                  :action="proxyDevApi + '/uploadFile/' +messageFileUploadDirId+'/name/ppim/suffix/mobileprovision'"
                  :show-file-list="true"
                  :multiple="false"
                  :headers="headersFile"
                  :file-list="filePpimUploadList"
                  :before-upload="beforeFileUpload"
                  :on-success="handlePpimFileSuccess"
                  :on-remove="handlePpimFileRemove"
                  :on-error="handlePpimFileError"
                  :on-progress="handleFileProgress">
                  <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
                </el-upload>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="iMessage adhoc描述文件：" prop="imessagePathPpim1">
                <el-upload
                  class="upload-demo"
                  :action="proxyDevApi + '/uploadFile/' +messageFileUploadDirId+'/name/ppim1/suffix/mobileprovision'"
                  :show-file-list="true"
                  :multiple="false"
                  :headers="headersFile"
                  :file-list="filePpim1UploadList"
                  :before-upload="beforeFileUpload"
                  :on-success="handlePpim1FileSuccess"
                  :on-remove="handlePpim1FileRemove"
                  :on-error="handlePpim1FileError"
                  :on-progress="handleFileProgress">
                  <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
                </el-upload>
              </el-form-item>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </el-form>
    <el-tabs v-model="tabValue" type="card" class="tabs-content">
      <el-tab-pane label="白名单列表" name="first">
        <configSingleForm :configSingleForm="whiteListForm"></configSingleForm>
      </el-tab-pane>
      <el-tab-pane label="url映射列表" name="second">
        <configDoubleForm :configDoubleForm="urlMapListForm"></configDoubleForm>
      </el-tab-pane>
      <el-tab-pane label="info额外配置列表" name="third">
        <configDoubleForm :configDoubleForm="infoConfigForm"></configDoubleForm>
      </el-tab-pane>
      <el-tab-pane label="entitments配置列表" name="fourth">
        <configDoubleForm :configDoubleForm="entitmentsConfigForm"></configDoubleForm>
      </el-tab-pane>
      <el-tab-pane label="闪屏" name="fourth1">
        <splashConfigTableV2 :fileConfig="splashFileConfig"></splashConfigTableV2>
      </el-tab-pane>
      <el-tab-pane label="游戏ICON" name="fourth2">
        <iconConfigTableV2 :fileConfig="iconFileConfig"></iconConfigTableV2>
      </el-tab-pane>
    </el-tabs>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='update' && optionData.gameInfo.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'
  import ioscertApi from '../../apis/ioscert-api'
  import agencyApi from '../../apis/agency-api'
  import channelApi from '../../apis/channel-api'
  import configSingleForm from '../manager/configFormSingle'
  import configDoubleForm from '../manager/configFormDouble'
  import iconConfigTableV2 from '../manager/iconConfigTableV2'
  import splashConfigTableV2 from '../manager/splashConfigTableV2'
  export default{
    components: {
      configSingleForm,
      configDoubleForm,
      iconConfigTableV2,
      splashConfigTableV2
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        oldProjectSplashDataList: null,
        oldProjectIconDataList: null,
        oldWhiteListForm: null,
        oldUrlMapListForm: null,
        oldInfoConfigForm: null,
        oldEntitmentsConfigForm: null,
        extraResUploadList: [],
        fileStoreUploadList: [],
        filePp1UploadList: [],
        filePpimUploadList: [],
        filePpim1UploadList: [],
        preConfigCheck: '',
        preConfigCheckShow: false,
        imessageCertType: '0',
        channelTypeList: [
          {
            'name': '已打包渠道',
            'value': '1'
          }, {
            'name': '未接入渠道',
            'value': '0'
          }
        ],
        channelType: '',
        channelList: null,
        channelVersionList: null,
        certList: [],
        imessageCertList: [],
        agencyList: null,
        certDesc: '',
        certPackName: '',
        tabValue: 'first',
        iconFileConfig: {
          platformType: 1,
          sourceType: 1,
          picType: 0
        },
        splashFileConfig: {
          platformType: 1,
          sourceType: 1,
          picType: 1
        },
        // 白名单列表
        whiteListForm: {
          dataIds: [],
          dataList: []
        },
        // Url映射列表
        urlMapListForm: {
          dataIds: [],
          dataList: []
        },
        // info额外配置列表
        infoConfigForm: {
          dataIds: [],
          dataList: []
        },
        // entitments配置列表
        entitmentsConfigForm: {
          dataIds: [],
          dataList: []
        },
        rules: {
          iChannelId: [
            {type: 'number', required: true, message: '请选择渠道', trigger: 'change'}
          ],
          iChannelConfigId: [
            {type: 'number', required: true, message: '请选择渠道版本', trigger: 'change'}
          ],
          iCertId: [
            {type: 'number', required: true, message: '请选择证书', trigger: 'change'}
          ],
          bundleId: [
            {required: true, message: '请输入证书包名', trigger: 'blur'}
          ],
          minIosVersion: [
            {type: 'number', required: true, message: '请选择最小系统版本', trigger: 'change'}
          ],
          keystorePath: [
            {required: true, message: '请上传描述文件', trigger: 'change'}
          ],
          iMiddleareId: [
            {type: 'number', required: true, message: '请选择代理版本', trigger: 'change'}
          ],
          cProjectName: [
            {required: true, message: '请输入项目名称', trigger: 'blur'}
          ],
          imessageCertId: [
            {type: 'number', required: true, message: '请选择imessage证书', trigger: 'change'}
          ],
          imessageBundleId: [
            {required: true, message: '请输入imessage包名', trigger: 'blur'}
          ],
          imessagePathPp1: [
            {required: true, message: '请上传游戏adhoc描述文件', trigger: 'change'}
          ],
          imessagePathPpim: [
            {required: true, message: '请上传appstore描述文件', trigger: 'change'}
          ],
          imessagePathPpim1: [
            {required: true, message: '请上传adhoc描述文件', trigger: 'change'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'projectSplashDataList', 'projectIconDataList', 'deleteGamePicIds', 'fileUploadDirId', 'buttonLoading', 'iosExtraResPath',
        'signatureTypeList', 'iosSystemVersionList', 'proxyDevApi', 'headersFile', 'messageFileUploadDirId', 'agencyTypeList'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      whiteListForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      urlMapListForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      infoConfigForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      entitmentsConfigForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      projectSplashDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      projectIconDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldWhiteListForm, this.whiteListForm) &&
            equalsExtend.objectEqual(this.oldUrlMapListForm, this.urlMapListForm) &&
            equalsExtend.objectEqual(this.oldInfoConfigForm, this.infoConfigForm) &&
            equalsExtend.objectEqual(this.oldEntitmentsConfigForm, this.entitmentsConfigForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.optionData.type === 'update') {
        this.fileStoreUploadList = []
        if (this.dataInfoForm.keystorePath) {
          this.fileStoreUploadList.push({
            name: this.dataInfoForm.keystorePath
          })
        }
        if (this.dataInfoForm.imessageResDirId && this.dataInfoForm.keyPaths) {
          if (this.dataInfoForm.keyPaths['0']) {
            this.filePp1UploadList.push({
              name: this.dataInfoForm.keyPaths['0']
            })
          }
          if (this.dataInfoForm.keyPaths['1']) {
            this.filePpimUploadList.push({
              name: this.dataInfoForm.keyPaths['1']
            })
          }
          if (this.dataInfoForm.keyPaths['2']) {
            this.filePpim1UploadList.push({
              name: this.dataInfoForm.keyPaths['2']
            })
          }
          this.dataInfoForm.imessagePathPp1 = this.dataInfoForm.keyPaths['0'] || ''
          this.dataInfoForm.imessagePathPpim = this.dataInfoForm.keyPaths['1'] || ''
          this.dataInfoForm.imessagePathPpim1 = this.dataInfoForm.keyPaths['2'] || ''
        }
        if (this.dataInfoForm.extraResPath) {
          this.extraResUploadList = []
          this.extraResUploadList.push({
            name: this.dataInfoForm.extraResPath,
            resId: this.dataInfoForm.extraResId
          })
        }
      }
      if (this.dataInfoForm.resDirId) {
        this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
      } else {
        this.$store.dispatch('getFileUploadDir', null)
      }
      if (this.dataInfoForm.imessageResDirId) {
        this.$store.dispatch('getMessageFileUploadDir', this.dataInfoForm.imessageResDirId)
      } else {
        this.$store.dispatch('getMessageFileUploadDir', null)
      }
      for (const dItem of this.dataInfoForm.iosWhiteVOList) {
        this.whiteListForm.dataList.push({
          id: dItem.iWhitelistId,
          iProjectChannelId: dItem.iProjectChannelId,
          value: dItem.cQueriesScheme
        })
      }
      for (const dItem of this.dataInfoForm.iosUrlSchemeVOList) {
        this.urlMapListForm.dataList.push({
          id: dItem.iUrlSchemeId,
          iProjectChannelId: dItem.iProjectChannelId,
          value1: dItem.urlSchemeName,
          value2: dItem.urlSchemeIdentifer
        })
      }
      for (const dItem of this.dataInfoForm.iosPlistVOList) {
        this.infoConfigForm.dataList.push({
          id: dItem.iPlistId,
          iProjectChannelId: dItem.iProjectChannelId,
          value2: dItem.infoValue,
          value1: dItem.infoKey
        })
      }
      for (const dItem of this.dataInfoForm.entitlementsVOList) {
        this.entitmentsConfigForm.dataList.push({
          id: dItem.iEntitlementsId,
          iProjectChannelId: dItem.iProjectChannelId,
          value2: dItem.entitlementsValue,
          value1: dItem.entitlementsKey
        })
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
      this.oldProjectSplashDataList = JSON.parse(JSON.stringify(this.projectSplashDataList))
      this.oldProjectIconDataList = JSON.parse(JSON.stringify(this.projectIconDataList))
      this.oldWhiteListForm = JSON.parse(JSON.stringify(this.whiteListForm))
      this.oldUrlMapListForm = JSON.parse(JSON.stringify(this.urlMapListForm))
      this.oldInfoConfigForm = JSON.parse(JSON.stringify(this.infoConfigForm))
      this.oldEntitmentsConfigForm = JSON.parse(JSON.stringify(this.entitmentsConfigForm))
      // 获取证书列表
      this.getIOSCertList()
      this.getImessageCertList()
      // 获取渠道列表
      this.getChannelList()
      // 获取代理列表
      this.getAgencyList()
    },
    methods: {
      handleFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      beforeFileUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let iosRegCert = /.mobileprovision/
        let isUpload = iosRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('描述文件格式只能为mobileprovision', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleStoreFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.fileStoreUploadList.length > 0 && this.fileStoreUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.fileStoreUploadList[0].resId)
          }
          this.fileStoreUploadList = []
          let fileName = response.data.url
          this.fileStoreUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.keystorePath = fileName
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.fileStoreUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleStoreFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.keystorePath = ''
        this.dataInfoForm.resId = ''
      },
      handleStoreFileError (error, file, fileList) {
        this.fileStoreUploadList = []
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      handlePp1FileSuccess (response, file, fileList) {
        if (response.code === 1) {
          this.filePp1UploadList = []
          let fileName = response.data.url.substring(response.data.url.lastIndexOf('/') + 1)
          this.filePp1UploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.imessagePathPp1 = fileName
          this.dataInfoForm.imessageResId_pp1 = response.data.resId
          this.dataInfoForm.imessageResDirId = this.messageFileUploadDirId
        } else {
          this.filePp1UploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handlePp1FileRemove (file, fileList) {
        this.dataInfoForm.imessagePathPp1 = ''
        this.dataInfoForm.imessageResId_pp1 = ''
      },
      handlePp1FileError (error, file, fileList) {
        this.filePp1UploadList = []
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      handlePpimFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          this.filePpimUploadList = []
          let fileName = response.data.url.substring(response.data.url.lastIndexOf('/') + 1)
          this.filePpimUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.imessagePathPpim = fileName
          this.dataInfoForm.imessageResId_ppim = response.data.resId
          this.dataInfoForm.imessageResDirId = this.messageFileUploadDirId
        } else {
          this.filePpimUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handlePpimFileRemove (file, fileList) {
        this.dataInfoForm.imessagePathPpim = ''
        this.dataInfoForm.imessageResId_ppim = ''
      },
      handlePpimFileError (error, file, fileList) {
        this.filePpimUploadList = []
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      handlePpim1FileSuccess (response, file, fileList) {
        if (response.code === 1) {
          this.filePpim1UploadList = []
          let fileName = response.data.url.substring(response.data.url.lastIndexOf('/') + 1)
          this.filePpim1UploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.imessagePathPpim1 = fileName
          this.dataInfoForm.imessageResId_ppim1 = response.data.resId
          this.dataInfoForm.imessageResDirId = this.messageFileUploadDirId
        } else {
          this.filePpim1UploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handlePpim1FileRemove (file, fileList) {
        this.dataInfoForm.imessagePathPpim1 = ''
        this.dataInfoForm.imessageResId_ppim1 = ''
      },
      handlePpim1FileError (error, file, fileList) {
        this.filePpim1UploadList = []
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      beforeExtraResUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegCert = /.(zip)/
        let isUpload = androidRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('渠道额外资源格式只能为zip', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleExtraResProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleExtraResSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.extraResUploadList.length > 0 && this.extraResUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.extraResUploadList[0].resId)
          }
          this.extraResUploadList = []
          let fileName = response.data.url
          this.extraResUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.extraResPath = fileName
          this.dataInfoForm.extraResId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.extraResUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleExtraResRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.extraResPath = ''
        this.dataInfoForm.extraResId = ''
      },
      handleExtraResError (error, file, fileList) {
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      extraResDemoUpload () {
        window.location.href = this.iosExtraResPath
      },
      extraResUpload () {
        let realPath = window.location.href
        let extraRP = this.dataInfoForm.extraResPath.substring(this.dataInfoForm.extraResPath.indexOf('/upload/'))
        let extraDownloadPath = ''
        if (realPath.indexOf('192.168.0.147') >= 0) {
          extraDownloadPath = 'http://192.168.0.147/cms' + extraRP
        } else {
          extraDownloadPath = 'http://192.168.0.148/cms' + extraRP
        }
        window.location.href = extraDownloadPath
      },
      getIOSCertList (flag) {
        let _this = this
        ioscertApi.getTypeDropDownDataList(this.dataInfoForm.cCertType).then((data) => {
          if (data.code === 1) {
            _this.certList = data.data
            if (flag && _this.certList.length > 0) {
              _this.dataInfoForm.iCertId = _this.certList[0].iCertId
            }
          }
        }, (error) => {
          console.log(error)
          _this.certList = null
        })
      },
      getImessageCertList (flag) {
        let _this = this
        ioscertApi.getTypeDropDownDataList(this.imessageCertType).then((data) => {
          if (data.code === 1) {
            _this.imessageCertList = data.data
            if (flag && _this.imessageCertList.length > 0) {
              _this.dataInfoForm.imessageCertId = _this.imessageCertList[0].iCertId
            }
          }
        }, (error) => {
          console.log(error)
          _this.imessageCertList = null
        })
      },
      getChannelList () {
        let _this = this
        channelApi.getDropDownDataList(this.optionData.gameInfo.iPlatformId).then((data) => {
          if (data.code === 1) {
            _this.channelList = data.data
            _this.channelSelectChange()
          }
        }, (error) => {
          console.log(error)
          _this.channelList = null
        })
      },
      getAgencyList () {
        let _this = this
        agencyApi.getPlatDataList('ios', this.optionData.gameInfo.iPlatformId, this.optionData.gameInfo.cAssertType).then((data) => {
          if (data.code === 1) {
            _this.agencyList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.agencyList = null
        })
      },
      channelSelectChange (flag) {
        let _this = this
//        for (const cItem of this.channelList) {
//          if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
//            this.dataInfoForm.buglyId = cItem.buglyId || ''
//            this.dataInfoForm.buglyKey = cItem.buglyKey || ''
//            break
//          }
//        }
        if (_this.dataInfoForm.iChannelId) {
          channelApi.getDropDownVersionDataList(_this.$route.params.type, _this.dataInfoForm.iChannelId).then((data) => {
            if (data.code === 1) {
              _this.channelVersionList = data.data.list
              if (flag && _this.channelVersionList.length > 0) {
                _this.dataInfoForm.iChannelConfigId = _this.channelVersionList[0].iIosChannelId
              }
            }
          }, (error) => {
            console.log(error)
            _this.channelVersionList = null
          })
        }
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (_this.optionData.type === 'add') {
//              _this.dataInfoForm.resDirId = this.fileUploadDirId
              _this.dataInfoForm.splashList = []
              _this.dataInfoForm.iconList = []
              _this.dataInfoForm.iosWhiteVOList = []
              _this.dataInfoForm.iosUrlSchemeVOList = []
              _this.dataInfoForm.iosPlistVOList = []
              _this.dataInfoForm.entitlementsVOList = []
              for (const dItem of _this.whiteListForm.dataList) {
                if (dItem.value) {
                  _this.dataInfoForm.iosWhiteVOList.push({
                    cQueriesScheme: dItem.value
                  })
                }
              }
              for (const dItem of _this.urlMapListForm.dataList) {
                if (dItem.value1 || dItem.value2) {
                  _this.dataInfoForm.iosUrlSchemeVOList.push({
                    urlSchemeName: dItem.value1,
                    urlSchemeIdentifer: dItem.value2
                  })
                }
              }
              for (const dItem of _this.infoConfigForm.dataList) {
                if (dItem.value1 && dItem.value2) {
                  _this.dataInfoForm.iosPlistVOList.push({
                    infoValue: dItem.value2,
                    infoKey: dItem.value1
                  })
                }
              }
              for (const dItem of _this.entitmentsConfigForm.dataList) {
                if (dItem.value1 && dItem.value2) {
                  _this.dataInfoForm.entitlementsVOList.push({
                    entitlementsValue: dItem.value2,
                    entitlementsKey: dItem.value1
                  })
                }
              }
              for (let iItem of _this.projectIconDataList) {
                if (iItem.picUrl) {
                  _this.dataInfoForm.iconList.push({
                    cDictIds: iItem.iDicId,
                    sDictNames: iItem.sDicName,
                    cPicType: iItem.cPicType,
                    cSource: iItem.cSource,
                    iPlatformId: iItem.iPlatformId,
                    resIds: iItem.resId,
                    picUrl: iItem.picUrl
                  })
                }
              }
              for (let sItem of _this.projectSplashDataList) {
                let isNull = true
                let tempRes = {
                  resId: [],
                  picUrl: []
                }
                let tempItem = {
                  cDictIds: sItem.splashId + ',' + sItem.orientationId,
                  sDictNames: sItem.splashName + ',' + sItem.orientationName,
                  cPicType: sItem.cPicType,
                  cSource: sItem.cSource,
                  iPlatformId: sItem.iPlatformId,
                  resIds: '',
                  picUrl: ''
                }
                for (let picItem of sItem.picList) {
                  if (picItem.picUrl) {
                    isNull = false
                    tempRes.resId.push(picItem.resId)
                    tempRes.picUrl.push(picItem.picUrl)
                  }
                }
                if (!isNull) {
                  tempItem.resIds = tempRes.resId.join(',')
                  tempItem.picUrl = tempRes.picUrl.join(',')
                  _this.dataInfoForm.splashList.push(tempItem)
                }
              }
              let submitData = JSON.parse(JSON.stringify(_this.dataInfoForm))
              delete submitData.imessagePathPp1
              delete submitData.imessagePathPpim
              delete submitData.imessagePathPpim1
              // 数据新增
              gameApi.addConfigDataInfoV2('ios', submitData).then((data) => {
                if (data.code === 1) {
                  _this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  _this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, this.dataInfoForm) &&
                equalsExtend.objectEqual(_this.oldWhiteListForm, _this.whiteListForm) &&
                equalsExtend.objectEqual(_this.oldUrlMapListForm, _this.urlMapListForm) &&
                equalsExtend.objectEqual(_this.oldInfoConfigForm, _this.infoConfigForm) &&
                equalsExtend.objectEqual(_this.oldEntitmentsConfigForm, _this.entitmentsConfigForm) &&
                equalsExtend.objectEqual(_this.oldProjectSplashDataList, _this.projectSplashDataList) &&
                equalsExtend.objectEqual(_this.oldProjectIconDataList, _this.projectIconDataList)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              _this.dataInfoForm.iosWhiteVOList = []
              _this.dataInfoForm.iosUrlSchemeVOList = []
              _this.dataInfoForm.iosPlistVOList = []
              _this.dataInfoForm.entitlementsVOList = []
              _this.dataInfoForm.iconList = []
              _this.dataInfoForm.splashList = []
              for (const dItem of _this.whiteListForm.dataList) {
                if (dItem.value) {
                  _this.dataInfoForm.iosWhiteVOList.push({
                    iWhitelistId: dItem.id || '',
                    iProjectChannelId: dItem.iProjectChannelId || '',
                    cQueriesScheme: dItem.value
                  })
                }
              }
              for (const dItem of _this.urlMapListForm.dataList) {
                if (dItem.value1 || dItem.value2) {
                  _this.dataInfoForm.iosUrlSchemeVOList.push({
                    iUrlSchemeId: dItem.id || '',
                    iProjectChannelId: dItem.iProjectChannelId || '',
                    urlSchemeName: dItem.value1,
                    urlSchemeIdentifer: dItem.value2
                  })
                }
              }
              for (const dItem of _this.infoConfigForm.dataList) {
                if (dItem.value1 && dItem.value2) {
                  _this.dataInfoForm.iosPlistVOList.push({
                    iPlistId: dItem.id || '',
                    iProjectChannelId: dItem.iProjectChannelId || '',
                    infoValue: dItem.value2,
                    infoKey: dItem.value1
                  })
                }
              }
              for (const dItem of _this.entitmentsConfigForm.dataList) {
                if (dItem.value1 && dItem.value2) {
                  _this.dataInfoForm.entitlementsVOList.push({
                    iEntitlementsId: dItem.id || '',
                    iProjectChannelId: dItem.iProjectChannelId || '',
                    entitlementsValue: dItem.value2,
                    entitlementsKey: dItem.value1
                  })
                }
              }
              if (_this.whiteListForm.dataIds.length > 0) {
                _this.dataInfoForm.whiteIds = _this.whiteListForm.dataIds.join(',')
              }
              if (_this.urlMapListForm.dataIds.length > 0) {
                _this.dataInfoForm.urlSchemeIds = _this.urlMapListForm.dataIds.join(',')
              }
              if (_this.infoConfigForm.dataIds.length > 0) {
                _this.dataInfoForm.iosPlistIds = _this.infoConfigForm.dataIds.join(',')
              }
              if (_this.entitmentsConfigForm.dataIds.length > 0) {
                _this.dataInfoForm.entitlementIds = _this.entitmentsConfigForm.dataIds.join(',')
              }
              for (let iItem of _this.projectIconDataList) {
                if (iItem.picUrl) {
                  _this.dataInfoForm.iconList.push({
                    cDictIds: iItem.iDicId,
                    sDictNames: iItem.sDicName,
                    cPicType: iItem.cPicType,
                    cSource: iItem.cSource,
                    iPlatformId: iItem.iPlatformId,
                    iRefId: iItem.iRefId,
                    iPicId: iItem.iPicId,
                    resIds: iItem.resId,
                    picIds: iItem.picId,
                    picUrl: iItem.picUrl
                  })
                }
              }
              for (let sItem of _this.projectSplashDataList) {
                let isNull = true
                let tempRes = {
                  resId: [],
                  picId: [],
                  picUrl: []
                }
                let tempItem = {
                  cDictIds: sItem.splashId + ',' + sItem.orientationId,
                  sDictNames: sItem.splashName + ',' + sItem.orientationName,
                  cPicType: sItem.cPicType,
                  cSource: sItem.cSource,
                  iPlatformId: sItem.iPlatformId,
                  iRefId: sItem.iRefId,
                  iPicId: sItem.iPicId,
                  picIds: '',
                  resIds: '',
                  picUrl: ''
                }
                for (let picItem of sItem.picList) {
                  if (picItem.picUrl) {
                    isNull = false
                    if (picItem.resId) {
                      tempRes.resId.push(picItem.resId)
                    }
                    if (picItem.picId) {
                      tempRes.picId.push(picItem.picId)
                    }
                    tempRes.picUrl.push(picItem.picUrl)
                  }
                }
                if (!isNull) {
                  tempItem.resIds = tempRes.resId.join(',')
                  tempItem.picIds = tempRes.picId.join(',')
                  tempItem.picUrl = tempRes.picUrl.join(',')
                  _this.dataInfoForm.splashList.push(tempItem)
                }
              }
              let submitData = JSON.parse(JSON.stringify(_this.dataInfoForm))
              delete submitData.imessagePathPp1
              delete submitData.imessagePathPpim
              delete submitData.imessagePathPpim1
              // 数据修改
              gameApi.updateConfigDataInfoV2('ios', submitData).then((data) => {
                if (data.code === 1) {
                  _this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  _this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
