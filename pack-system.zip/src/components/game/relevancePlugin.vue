<style>
  .option-dialog-relevance-2 .el-dialog{
    width: 800px;
  }
  .option-dialog-relevance-2 .plugin-item .plugin-item-checkbox .el-checkbox__input{
    line-height: 42px;
  }
  .option-dialog-relevance-2 .plugin-item .plugin-item-checkbox .el-checkbox__label>span{
    overflow: hidden;
    text-overflow: ellipsis;
    display: block;
    width: 118px;
    line-height: 12px;
  }
</style>
<style scoped>
  .option-dialog-relevance-2 .plugin-item{
    padding-left: 10px;
    padding-right: 10px;
    line-height: 36px;
    margin-bottom: 5px;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogFormVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-relevance-2">
    <div style="margin: 0 0 15px 0;" v-if="functionPlugin.pluginList.length > 0">
      <el-checkbox style="width: 100%" :indeterminate="functionPlugin.isIndeterminate" v-model="functionPlugin.checkAll" @change="handleCheckAllChange($event, functionPlugin)"><strong style="font-size: 16px;">功能插件</strong></el-checkbox>
      <el-checkbox-group v-model="functionPlugin.pluginCheckList" @change="handleCheckedChange(functionPlugin)" style="margin-top: 5px">
        <el-row :gutter="20">
          <el-col :span="8" v-for="plugin in functionPlugin.pluginList" class="plugin-item">
            <el-row>
              <el-col :span="14">
                <el-checkbox :label="plugin" :key="plugin.iPluginId" @change="handleCheckChange($event, plugin, functionPlugin)" class="plugin-item-checkbox">
                  <span v-if="plugin.pluginName.replace(/[\u0391-\uFFE5]/g,'aa').length<=18">{{plugin.pluginName}}</span>
                  <el-tooltip :content="plugin.pluginName" placement="bottom" effect="light" v-if="plugin.pluginName.replace(/[\u0391-\uFFE5]/g,'aa').length>18">
                    <span>{{plugin.pluginName}}</span>
                  </el-tooltip>
                </el-checkbox>
              </el-col>
              <el-col :span="10">
                <el-select v-model="plugin.iPluginConfigId" placeholder="请选择" style="width: 80%;" @change="pluginVersionChange(plugin, functionPlugin)">
                  <el-option
                    v-for="item in plugin.pluginVersionList"
                    :key="item.iPluginConfigId"
                    :label="item.pluginVersion"
                    :value="item.iPluginConfigId">
                  </el-option>
                </el-select>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </el-checkbox-group>
    </div>
    <div style="margin: 0 0 15px 0;" v-if="normalPlugin.pluginList.length > 0">
      <el-checkbox style="width: 100%" :indeterminate="normalPlugin.isIndeterminate" v-model="normalPlugin.checkAll" @change="handleCheckAllChange($event, normalPlugin)"><strong style="font-size: 16px;">渠道插件</strong></el-checkbox>
      <el-checkbox-group v-model="normalPlugin.pluginCheckList" @change="handleCheckedChange(normalPlugin)" style="margin-top: 5px">
        <el-row :gutter="20">
          <el-col :span="8" v-for="plugin in normalPlugin.pluginList" class="plugin-item">
            <el-row>
              <el-col :span="14">
                <el-checkbox :label="plugin" :key="plugin.iPluginId" @change="handleCheckChange($event, plugin, normalPlugin)" class="plugin-item-checkbox">
                  <span v-if="plugin.pluginName.replace(/[\u0391-\uFFE5]/g,'aa').length<=18">{{plugin.pluginName}}</span>
                  <el-tooltip :content="plugin.pluginName" placement="bottom" effect="light" v-if="plugin.pluginName.replace(/[\u0391-\uFFE5]/g,'aa').length>18">
                    <span>{{plugin.pluginName}}</span>
                  </el-tooltip>
                </el-checkbox>
              </el-col>
              <el-col :span="10">
                <el-select v-model="plugin.iPluginConfigId" placeholder="请选择" style="width: 80%;" @change="pluginVersionChange(plugin, normalPlugin)">
                  <el-option
                    v-for="item in plugin.pluginVersionList"
                    :key="item.iPluginConfigId"
                    :label="item.pluginVersion"
                    :value="item.iPluginConfigId">
                  </el-option>
                </el-select>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </el-checkbox-group>
    </div>
    <div style="margin: 0 0 0 0;" v-if="advertPlugin.pluginList.length > 0">
      <el-checkbox style="width: 100%" :indeterminate="advertPlugin.isIndeterminate" v-model="advertPlugin.checkAll" @change="handleCheckAllChange($event, advertPlugin)"><strong style="font-size: 16px;">广告插件</strong></el-checkbox>
      <el-checkbox-group v-model="advertPlugin.pluginCheckList" @change="handleCheckedChange(advertPlugin)" style="margin-top: 5px">
        <el-row :gutter="20">
          <el-col :span="8" v-for="plugin in advertPlugin.pluginList" class="plugin-item">
            <el-row>
              <el-col :span="14">
                <el-checkbox :label="plugin" :key="plugin.iPluginId" @change="handleCheckChange($event, plugin, advertPlugin)" class="plugin-item-checkbox">
                  <span v-if="plugin.pluginName.replace(/[\u0391-\uFFE5]/g,'aa').length<=18">{{plugin.pluginName}}</span>
                  <el-tooltip :content="plugin.pluginName" placement="bottom" effect="light" v-if="plugin.pluginName.replace(/[\u0391-\uFFE5]/g,'aa').length>18">
                    <span>{{plugin.pluginName}}</span>
                  </el-tooltip>
                </el-checkbox>
              </el-col>
              <el-col :span="10">
                <el-select v-model="plugin.iPluginConfigId" placeholder="请选择" style="width: 80%;" @change="pluginVersionChange(plugin, advertPlugin)">
                  <el-option
                    v-for="item in plugin.pluginVersionList"
                    :key="item.iPluginConfigId"
                    :label="item.pluginVersion"
                    :value="item.iPluginConfigId">
                  </el-option>
                </el-select>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </el-checkbox-group>
    </div>

    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.gameInfo.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm()" :loading="buttonLoading" v-if="optionData.gameInfo.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.gameInfo.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import pluginApi from '../../apis/plugin-api'
  export default{
    components: {},
    props: ['optionData'],
    data () {
      return {
        pluginVersionList: [],
        pluginVersionId: '',
        isEqualsOption: true,
        oldFunctionPlugin: null,
        oldNormalPlugin: null,
        oldAdvertPlugin: null,
        functionPlugin: {
          checkAll: true,
          pluginList: [],
          pluginCheckList: [],
          isIndeterminate: true,
          dataParams: {
            iGamePluginIds: [],
            gamePluginVersionConfigList: []
          }
        },
        normalPlugin: {
          checkAll: true,
          pluginList: [],
          pluginCheckList: [],
          isIndeterminate: true,
          dataParams: {
            iGamePluginIds: [],
            gamePluginVersionConfigList: []
          }
        },
        advertPlugin: {
          checkAll: true,
          pluginList: [],
          pluginCheckList: [],
          isIndeterminate: true,
          dataParams: {
            iGamePluginIds: [],
            gamePluginVersionConfigList: []
          }
        }
      }
    },
    watch: {
      functionPlugin: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldFunctionPlugin, this.functionPlugin) &&
            equalsExtend.objectEqual(this.oldNormalPlugin, this.normalPlugin) &&
            equalsExtend.objectEqual(this.oldAdvertPlugin, this.advertPlugin)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      normalPlugin: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldFunctionPlugin, this.functionPlugin) &&
            equalsExtend.objectEqual(this.oldNormalPlugin, this.normalPlugin) &&
            equalsExtend.objectEqual(this.oldAdvertPlugin, this.advertPlugin)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      advertPlugin: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldFunctionPlugin, this.functionPlugin) &&
            equalsExtend.objectEqual(this.oldNormalPlugin, this.normalPlugin) &&
            equalsExtend.objectEqual(this.oldAdvertPlugin, this.advertPlugin)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created () {
      // 获取当前渠道的插件列表
      this.getChannelPlugins()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      getChannelPlugins () {
        let _this = this
        pluginApi.getChannelPluginList('game', this.optionData.gameInfo.iProjectId, this.optionData.gameInfo.iPlatformId).then((data) => {
          if (data.code === 1) {
            for (let dItem of data.data) {
              dItem.iPluginConfigId = (dItem.iPluginConfigId && dItem.iPluginConfigId > 0) ? dItem.iPluginConfigId :
                (dItem.pluginVersionList.length > 0 ? dItem.pluginVersionList[0].iPluginConfigId : '')
              if (dItem.pluginType === '3') {
                _this.normalPlugin.pluginList.push(dItem)
                _this.normalPlugin.pluginCheckList = _this.normalPlugin.pluginList.filter((item) => {
                  return item.iGamePluginId && item.iGamePluginId > 0
                })
                _this.normalPlugin.isIndeterminate = !(_this.normalPlugin.pluginList.length === _this.normalPlugin.pluginCheckList.length)
                _this.normalPlugin.dataParams = {
                  iGamePluginIds: [],
                  gamePluginVersionConfigList: []
                }
              } else if (dItem.pluginType === '2') {
                _this.advertPlugin.pluginList.push(dItem)
                _this.advertPlugin.pluginCheckList = _this.advertPlugin.pluginList.filter((item) => {
                  return item.iGamePluginId && item.iGamePluginId > 0
                })
                _this.advertPlugin.isIndeterminate = !(_this.advertPlugin.pluginList.length === _this.advertPlugin.pluginCheckList.length)
                _this.advertPlugin.dataParams = {
                  iGamePluginIds: [],
                  gamePluginVersionConfigList: []
                }
              } else {
                _this.functionPlugin.pluginList.push(dItem)
                _this.functionPlugin.pluginCheckList = _this.functionPlugin.pluginList.filter((item) => {
                  return item.iGamePluginId && item.iGamePluginId > 0
                })
                _this.functionPlugin.isIndeterminate = !(_this.functionPlugin.pluginList.length === _this.functionPlugin.pluginCheckList.length)
                _this.functionPlugin.dataParams = {
                  iGamePluginIds: [],
                  gamePluginVersionConfigList: []
                }
              }
            }
            this.handleCheckedChange(this.functionPlugin)
            this.handleCheckedChange(this.normalPlugin)
            this.handleCheckedChange(this.advertPlugin)
            this.oldFunctionPlugin = JSON.parse(JSON.stringify(this.functionPlugin))
            this.oldNormalPlugin = JSON.parse(JSON.stringify(this.normalPlugin))
            this.oldAdvertPlugin = JSON.parse(JSON.stringify(this.advertPlugin))
          }
        }, (error) => {
          _this.functionPlugin = {
            checkAll: true,
            pluginList: null,
            pluginCheckList: null,
            isIndeterminate: true,
            dataParams: null
          }
          _this.normalPlugin = {
            checkAll: true,
            pluginList: null,
            pluginCheckList: null,
            isIndeterminate: true,
            dataParams: null
          }
          _this.advertPlugin = {
            checkAll: true,
            pluginList: null,
            pluginCheckList: null,
            isIndeterminate: true,
            dataParams: null
          }
        })
      },
      handleCheckChange (event, item, pluginTypeList) {
        // 插件选中
        if (event) {
          if (item.iGamePluginId > 0) {
            // 之前选中的插件
            let dpIndex = pluginTypeList.dataParams.iGamePluginIds.indexOf(item.iGamePluginId)
            if (dpIndex >= 0) {
              pluginTypeList.dataParams.iGamePluginIds.splice(dpIndex, 1)
            }
          }
//          else {
//            // 新增加选中的插件
//            pluginTypeList.dataParams.gamePluginVersionConfigList.push({
//              'iChannelId': this.channelInfo.iChannelId,
//              'iPluginId': item.iPluginId,
//              'pluginName': item.pluginName,
//              'isRequired': item.isRequired,
//              'typeId': item.typeId
//            })
//          }
        } else {
          if (item.iGamePluginId > 0) {
            // 之前选中的插件
            if (pluginTypeList.dataParams.iGamePluginIds.indexOf(item.iGamePluginId) === -1) {
              pluginTypeList.dataParams.iGamePluginIds.push(item.iGamePluginId)
            }
          }
//          else {
//            // 去掉选中的插件
//            for (let i = 0; i < pluginTypeList.dataParams.gamePluginVersionConfigList.length; i++) {
//              let tempItem = pluginTypeList.dataParams.gamePluginVersionConfigList[i]
//              if (tempItem.iPluginId === item.iPluginId) {
//                pluginTypeList.dataParams.gamePluginVersionConfigList.splice(i, 1)
//                break
//              }
//            }
//          }
        }
      },
      handleCheckAllChange (event, pluginTypeList) {
        pluginTypeList.pluginCheckList = event ? pluginTypeList.pluginList : []
        pluginTypeList.isIndeterminate = false
        pluginTypeList.dataParams = {
          iGamePluginIds: [],
          gamePluginVersionConfigList: []
        }
        if (event) {
//          for (let i = 0; i < pluginTypeList.pluginList.length; i++) {
//            let tempItem = pluginTypeList.pluginList[i]
//            if (tempItem.iChannelPluginId === 0) {
//              pluginTypeList.dataParams.gamePluginVersionConfigList.push({
//                'iChannelId': this.channelInfo.iChannelId,
//                'iPluginId': tempItem.iPluginId,
//                'pluginName': tempItem.pluginName,
//                'isRequired': tempItem.isRequired,
//                'typeId': tempItem.typeId
//              })
//            }
//          }
          console.log('TODO 全选中操作')
        } else {
          for (let i = 0; i < pluginTypeList.pluginList.length; i++) {
            let tempItem = pluginTypeList.pluginList[i]
            if (tempItem.iGamePluginId && tempItem.iGamePluginId > 0) {
              pluginTypeList.dataParams.iGamePluginIds.push(tempItem.iGamePluginId)
            }
          }
        }
      },
      handleCheckedChange (pluginTypeList) {
        let checkedCount = pluginTypeList.pluginCheckList.length
        pluginTypeList.checkAll = checkedCount === pluginTypeList.pluginList.length
        pluginTypeList.isIndeterminate = checkedCount > 0 && checkedCount < pluginTypeList.pluginList.length
      },
      pluginVersionChange (plugin, pluginTypeList) {
        for (let sItem of pluginTypeList.pluginCheckList) {
          if (sItem.iPluginId === plugin.iPluginId) {
            console.log(sItem.iPluginConfigId)
            console.log(plugin.iPluginConfigId)
//            sItem.iPluginConfigId = plguin.iPluginConfigId
          }
        }
      },
      submitForm () {
        if (equalsExtend.objectEqual(this.oldFunctionPlugin, this.functionPlugin) &&
          equalsExtend.objectEqual(this.oldNormalPlugin, this.normalPlugin) &&
          equalsExtend.objectEqual(this.oldAdvertPlugin, this.advertPlugin)) {
          this.optionData.dialogFormVisible = false
          return
        }
        let dataParams = {
          ids: '',
          gamePluginVersionConfigList: []
        }
        let iGamePluginIdsAll = this.functionPlugin.dataParams.iGamePluginIds.concat(this.normalPlugin.dataParams.iGamePluginIds).concat(this.advertPlugin.dataParams.iGamePluginIds)
        let pluginCheckListAll = this.functionPlugin.pluginCheckList.concat(this.normalPlugin.pluginCheckList).concat(this.advertPlugin.pluginCheckList)
        dataParams.ids = iGamePluginIdsAll.join(',')
        for (let cItem of pluginCheckListAll) {
          dataParams.gamePluginVersionConfigList.push({
            'iGamePluginId': cItem.iGamePluginId === 0 ? '' : cItem.iGamePluginId,
            'iProjectId': this.optionData.gameInfo.iProjectId,
            'iPluginId': cItem.iPluginId,
            'pluginName': cItem.pluginName,
            'iPluginConfigId': cItem.iPluginConfigId,
            'isRequired': cItem.isRequired
          })
        }
        pluginApi.addChannelPlugin('game', dataParams).then((data) => {
          if (data.code === 1) {
            this.optionData.dialogFormVisible = false
          } else {
            this.$alert(data.msg, '关联插件失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '关联插件失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
