<style>
  .option-dialog-game-asset .el-dialog{
    width: 500px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog .upload-demo-table{
    width: 80px;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增游戏资源':'修改游戏资源'"
             :visible.sync="optionData.dialogFormVisible"
             :close-on-click-modal="false"
             class="option-dialog option-dialog-game-asset">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="资源名称：" prop="gameAssetsName">
        <el-input v-model.trim="dataInfoForm.gameAssetsName"></el-input>
      </el-form-item>
      <el-form-item label="资源类型：" prop="cVersionType">
        <el-radio-group v-model="dataInfoForm.cVersionType">
          <el-radio v-for="item in gameAssetsTypeList" class="radio" :label="item.value">{{item.name}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="资源类型：" prop="cVersionType">-->
        <!--<el-select v-model="dataInfoForm.cVersionType" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in gameAssetsTypeList"-->
            <!--:key="item.value"-->
            <!--:label="item.name"-->
            <!--:value="item.value">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="上传方式：" v-if="false">
        <el-radio class="radio" v-model="dataInfoForm.uploadType" label="0">http上传</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.uploadType" label="1">ftp上传</el-radio>
      </el-form-item>
      <el-form-item label="资源路径：" v-if="false && dataInfoForm.uploadType == '1'">
        <el-input v-model.trim="dataInfoForm.gameAssetPath"></el-input>
      </el-form-item>
      <el-form-item label="游戏资源：" v-if="false && dataInfoForm.uploadType == '0'">
        <el-upload
          class="upload-demo"
          :action="proxyDevApi+'/uploadFile/' +fileUploadDirId"
          :show-file-list="true"
          :multiple="false"
          :headers="headersFile"
          :file-list="fileAssetUploadList"
          :before-upload="beforeAvatarUpload"
          :on-success="handleAssetFileSuccess"
          :on-remove="handleAssetFileRemove"
          :on-error="handleAssetFileError"
          :on-progress="handleAssetFileProgress">
          <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
        </el-upload>
        <!--<input type="file" name="file" @change="getFile($event)">-->
      </el-form-item>
      <el-form-item label="文件名称：" prop="assetsName" v-if="false && dataInfoForm.gameAssetPath">
        <el-input v-model.trim="dataInfoForm.assetsName"></el-input>
      </el-form-item>
      <div style="color: #ef5350;">提示：非运营人员添加时，请选择其他资源！</div>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading || startFileUpload" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='update' && optionData.gameInfo.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'

  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      let checkAssetsName = (rule, value, callback) => {
        if (this.dataInfoForm.gameAssetPath && this.dataInfoForm.assetsName) {
          let pFile = this.dataInfoForm.gameAssetPath.substring(this.dataInfoForm.gameAssetPath.lastIndexOf('.'))
          let aFile = this.dataInfoForm.assetsName.substring(this.dataInfoForm.assetsName.lastIndexOf('.'))
          return pFile !== aFile ? callback(new Error('文件名称后缀需要与上传文件后缀保持一致')) : callback()
        }
        callback()
      }
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        startFileUpload: false,
        platformType: 0,
        fileAssetUploadList: [],
        preFile: {
          cMd5: '',
          resId: ''
        },
        rules: {
          gameAssetsName: [
            {required: true, message: '请输入资源名称', trigger: 'blur'}
          ],
          gameAssetPath: [
            {required: true, message: '请输入游戏资源', trigger: 'blur'}
          ],
          assetsName: [
            {validator: checkAssetsName, trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'headersFile', 'gameAssetsTypeList', 'fileUploadDirId', 'buttonLoading', 'proxyDevApi'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.platformType = this.$route.params.type === 'ios' ? 1 : 0
      if (this.optionData.type === 'update' && this.dataInfoForm.uploadType === '0' && this.dataInfoForm.gameAssetPath) {
        this.fileAssetUploadList = []
        this.fileAssetUploadList.push({
          name: this.dataInfoForm.gameAssetPath,
          resId: this.dataInfoForm.resId
        })
        this.preFile.cMd5 = this.dataInfoForm.cMd5
      }
      if (this.dataInfoForm.resDirId) {
        this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
      } else {
        this.$store.dispatch('getFileUploadDir', null)
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegAsset = /.(pkg|apk)/
        let iosRegAsset = /.pkg/
        let isUpload = false
        if (this.platformType === 1) {
          isUpload = iosRegAsset.test(fileType)
          if (!isUpload) {
            this.$alert('资源类型只能为pkg', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        } else {
          isUpload = androidRegAsset.test(fileType)
          if (!isUpload) {
            this.$alert('资源类型只能为pkg或apk', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        }
        if (isUpload) {
          this.startFileUpload = true
        }
        return isUpload
      },
      handleAssetFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleAssetFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          // 判断文件是否上传过
          if (this.preFile.cMd5 === response.data.md5) {
            this.$alert('您上传的游戏资源已存在，请更新后提交！', '友情提醒', {
              confirmButtonText: '确定'
            })
            this.$store.dispatch('deleteGameConfigImage', response.data.resId)
            fileList.splice(1, 1)
            this.startFileUpload = false
            return
          } else {
            // 判断全局资源文件是否已上传
            gameApi.isAssetsExist(response.data.md5).then((data) => {
              if (data.val === '1') {
                this.$alert('您上传的游戏资源已存在，请更新后提交！', '友情提醒', {
                  confirmButtonText: '确定'
                })
                this.$store.dispatch('deleteGameConfigImage', response.data.resId)
                fileList.splice(0, 1)
              } else {
                if (this.fileAssetUploadList.length > 0 && this.fileAssetUploadList[0].resId) {
                  this.$store.dispatch('deleteGameConfigImage', this.fileAssetUploadList[0].resId)
                }
                this.fileAssetUploadList = []
                let fileName = response.data.url
                this.fileAssetUploadList.push({
                  name: fileName,
                  resId: response.data.resId
                })
                this.dataInfoForm.gameAssetPath = fileName
                this.dataInfoForm.resId = response.data.resId
                this.dataInfoForm.cMd5 = response.data.md5
              }
              this.startFileUpload = false
            }, (error) => {
              this.startFileUpload = false
              console.log(error)
            })
          }
        } else {
          this.fileAssetUploadList = []
          this.startFileUpload = false
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleAssetFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.gameAssetPath = ''
        this.dataInfoForm.resId = ''
        this.dataInfoForm.cMd5 = ''
        this.startFileUpload = false
      },
      handleAssetFileError (error, file, fileList) {
        this.fileAssetUploadList = []
        this.startFileUpload = false
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      submitForm (formName) {
        let _this = this
        if (this.optionData.isAddRealAsset && this.dataInfoForm.cVersionType === '1') {
          this.$alert('每一个游戏版本资源只能有一个正式资源', '友情提醒', {
            confirmButtonText: '确定'
          })
          return
        }
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              this.dataInfoForm.resDirId = this.fileUploadDirId
              // 数据新增
              gameApi.addAssetsDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              gameApi.updateAssetsDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
