<style>
  .option-dialog-ios-permission .el-dialog{
    width: 600px;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogFormVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-ios-permission">
    <el-form :model="dataInfoForm" ref="dataInfoForm">
      <el-row v-for="(item,index) in dataInfoForm.iOSPermissionDataList">
        <el-col :span="10">
          <el-form-item
            :prop="'iOSPermissionDataList.' + index + '.isChecked'">
            <el-checkbox v-model="item.isChecked">{{item.sDicName}}</el-checkbox>
          </el-form-item>
        </el-col>
        <el-col :span="14">
          <el-form-item
            :prop="'iOSPermissionDataList.' + index + '.sDesc'"
            :rules="item.isChecked ? [{required: true, message: '请输入权限描述语句', trigger: 'blur'}] : []">
            <el-input v-model="item.sDesc" placeholder="这里填写权限描述语句" :disabled="!item.isChecked"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'
  import dictionaryApi from '../../apis/dictionary-api'

  export default{
    components: {
    },
    props: ['optionData'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        iOSPermissionCheck: [],
        dataInfoForm: {
          iOSPermissionDataList: []
        }
      }
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    created: function () {
      // 获取权限配置列表
      this.getGameIOSPermissionList()
    },
    methods: {
      getGameIOSPermissionList () {
        let id = ''
        if (this.optionData.type === 'game') {
          id = this.optionData.iProjectId
        } else {
          id = this.optionData.iProjectAssetId
        }
        gameApi.getIOSPermissionDataInfo(id, this.optionData.type).then((data) => {
          if (data.code === 1) {
            this.iOSPermissionCheck = []
            for (let item of data.data) {
              this.iOSPermissionCheck.push({
                iDicId: item.iDictId,
                sDesc: item.sDesc
              })
            }
            this.getIOSPermissionList()
          } else {
            this.iOSPermissionCheck = []
          }
        }, (error) => {
          console.log(error)
          this.iOSPermissionCheck = []
        })
      },
      getIOSPermissionList () {
        dictionaryApi.getDictsByType('iOSPermission').then((data) => {
          if (data.code === 1) {
            this.dataInfoForm.iOSPermissionDataList = []
            for (let item of data.data) {
              let param = {
                isChecked: false,
                iDicId: item.iDicId,
                sDicName: item.sDicName,
                sDesc: ''
              }
              for (let cItem of this.iOSPermissionCheck) {
                if (cItem.iDicId === item.iDicId) {
                  param.sDesc = cItem.sDesc
                  param.isChecked = true
                }
              }
              this.dataInfoForm.iOSPermissionDataList.push(param)
            }
            this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
          } else {
            this.dataInfoForm.iOSPermissionDataList = []
          }
        }, (error) => {
          this.dataInfoForm.iOSPermissionDataList = []
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let id = ''
            if (this.optionData.type === 'game') {
              id = this.optionData.iProjectId
            } else {
              id = this.optionData.iProjectAssetId
            }
            let submitParam = []
            for (let item of _this.dataInfoForm.iOSPermissionDataList) {
              if (item.isChecked) {
                if (this.optionData.type === 'game') {
                  submitParam.push({
                    iDictId: item.iDicId,
                    sDesc: item.sDesc,
                    iProjectId: this.optionData.iProjectId
                  })
                } else {
                  submitParam.push({
                    iDictId: item.iDicId,
                    sDesc: item.sDesc,
                    iProjectAssetId: this.optionData.iProjectAssetId
                  })
                }
              }
            }
            gameApi.putIOSPermissionDataInfo(id, submitParam, this.optionData.type).then((data) => {
              if (data.code === 1) {
                _this.optionData.dialogFormVisible = false
              } else {
                _this.$alert(data.msg, '操作失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              _this.$alert(error, '操作失败', {
                confirmButtonText: '确定'
              })
            })
          }
        })
      }
    }
  }
</script>
