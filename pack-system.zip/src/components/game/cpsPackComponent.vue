<style>
  .content-list-pack{
  }
  .content-list-pack .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .content-list-pack .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
    max-height: 450px;
    overflow-y: auto;
    overflow-x: hidden;
  }
  .content-list .path{
    margin-top: 10px;
  }
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <div class="content-list-pack">
    <div class="content-list" id="myData">
      <el-form :model="dataInfoForm" ref="dataInfoForm">
        <el-row v-if="0 == dataInfoForm.gamePackCPSorADModelList.length">
          <el-col :span="2">&nbsp;</el-col>
          <el-col :span="20">
            <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('dataInfoForm')">添&nbsp;&nbsp;加</el-button>
          </el-col>
          <el-col :span="2">&nbsp;</el-col>
        </el-row>
        <el-row v-if="dataInfoForm.gamePackCPSorADModelList.length > 0">
          <el-col :span="9" class="table-head">广告码</el-col>
          <el-col :span="9" class="table-head">备注</el-col>
          <el-col :span="3" class="table-head">选择官方码</el-col>
          <el-col :span="3" class="table-head">&nbsp;</el-col>
        </el-row>
        <el-row v-for="(domain,index) in dataInfoForm.gamePackCPSorADModelList" :gutter="10">
          <el-col :span="9">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.cAdcpsCode'"
              :rules="[{required: true, message: '请输入渠道码', trigger: 'blur'},{validator: checkChannelCode, trigger: 'blur'}]">
              <el-input v-model.trim="domain.cAdcpsCode" placeholder="请输入渠道码"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="9">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.sDemo'"
              :rules="[{required: true, message: '请输入备注', trigger: 'blur'}]">
              <el-input v-model.trim="domain.sDemo" placeholder="请输入备注"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="3">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.cOfficial'">
              <el-checkbox v-model="domain.cOfficial" :true-label="'1'" :false-label="'0'">&nbsp;</el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="3" style="text-align: left;">
            <el-button type="text" class="table-option-button" @click.prevent="removeItem(index)">删除</el-button>
            <el-button type="text" class="table-option-button" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.gamePackCPSorADModelList.length-1">添加</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {},
    props: ['dataInfoForm'],
    data () {
      return {
        gamePackDataLength: 0
      }
    },
    created: function () {
    },
    computed: {
      ...mapGetters([
      ])
    },
    watch: {
      gamePackDataLength () {
        this.$nextTick(() => {
          var container = this.$el.querySelector('#myData')
          container.scrollTop = container.scrollHeight
        })
      }
    },
    methods: {
      checkChannelCode (rule, value, callback) {
        if (!value) {
          return callback(new Error('请输入渠道码'))
        }
        setTimeout(() => {
          let infoItemsStr = JSON.stringify(this.dataInfoForm.gamePackCPSorADModelList)
          let valStr = JSON.stringify({cAdcpsCode: value})
          if (infoItemsStr.split(valStr.substring(1, valStr.length - 1)).length <= 2) {
            callback()
          } else {
            callback(new Error('渠道码已存在'))
          }
        }, 1000)
      },
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.gamePackCPSorADModelList.push({
              cAdcpsCode: '',
              sDemo: '',
              cOfficial: '0'
            })
            this.gamePackDataLength = this.dataInfoForm.gamePackCPSorADModelList.length
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        let iCpsAdId = this.dataInfoForm.gamePackCPSorADModelList[$index].iAdcodeId
        if (iCpsAdId) {
          this.dataInfoForm.deletePackedIds.push(iCpsAdId)
        }
        this.dataInfoForm.gamePackCPSorADModelList.splice($index, 1)
      },
      submitForm () {
        return this
      }
    }
  }
</script>
