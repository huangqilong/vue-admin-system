<style>
  .option-dialog-game-config-zy .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select,.option-dialog .el-input-number{
    width: 100%;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-game-config-zy">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="130px">
      <template v-if="optionData.type=='bugly'">
        <el-form-item label="bugly ID：" label-width="120px" prop="buglyId">
          <el-input v-model.trim="dataInfoForm.buglyId"></el-input>
        </el-form-item>
        <el-form-item label="bugly KEY：" label-width="120px" prop="buglyKey">
          <el-input v-model.trim="dataInfoForm.buglyKey"></el-input>
        </el-form-item>
      </template>
      <template v-if="optionData.type=='keystore'">
        <el-form-item label="签名文件：" prop="keystorePath">
          <el-upload
            class="upload-demo"
            :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
            :show-file-list="true"
            :multiple="false"
            :headers="headersFile"
            :file-list="fileStoreUploadList"
            :before-upload="beforeAvatarUpload"
            :on-success="handleStoreFileSuccess"
            :on-remove="handleStoreFileRemove"
            :on-error="handleStoreFileError"
            :on-progress="handleStoreFileProgress">
            <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="签名密码：" prop="keyPassword">
          <el-input v-model.trim="dataInfoForm.keyPassword"></el-input>
        </el-form-item>
        <el-form-item label="注意事项：">
          <el-input type="textarea" :rows="3" v-model.trim="dataInfoForm.sDemo" placeholder="如果更换签名文件和密码请在这里填写一下更换签名所影响的范围。"></el-input>
        </el-form-item>
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import equalsExtend from '../../utils/equals-extend'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        fileStoreUploadList: [],
        extraResUploadList: [],
        rules: {
          buglyId: [
            {required: true, message: '请输入buglyId', trigger: 'blur'}
          ],
          buglyKey: [
            {required: true, message: '请输入buglyKey', trigger: 'blur'}
          ],
          keystorePath: [
            {required: true, message: '请上传签名文件', trigger: 'change'}
          ],
          keyPassword: [
            {required: true, message: '请输入签名密码', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading', 'proxyDevApi', 'fileUploadDirId', 'headersFile'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.optionData.type === 'keystore' && this.dataInfoForm.keystorePath) {
        this.fileStoreUploadList = []
        this.fileStoreUploadList.push({
          name: this.dataInfoForm.keystorePath
        })
      }
      if (this.optionData.type === 'keystore') {
        if (this.dataInfoForm.resDirId) {
          this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
        } else {
          this.$store.dispatch('getFileUploadDir', null)
        }
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegCert = /.(jks|keystore)/
        let isUpload = androidRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('签名文件格式只能为jks|keystore', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleStoreFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleStoreFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.fileStoreUploadList.length > 0 && this.fileStoreUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.fileStoreUploadList[0].resId)
          }
          this.fileStoreUploadList = []
          let fileName = response.data.url
          this.fileStoreUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.keystorePath = fileName
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.fileStoreUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleStoreFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.keystorePath = ''
        this.dataInfoForm.resId = ''
      },
      handleStoreFileError (error, file, fileList) {
        this.fileStoreUploadList = []
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'bugly') {
              gameApi.updateAssetsDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogVisible = false
                  if (_this.optionCallBack) {
                    _this.optionCallBack()
                  }
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              // 数据修改
              gameApi.postKeystoreConfigV2DataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogVisible = false
                  if (_this.optionCallBack) {
                    _this.optionCallBack()
                  }
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
