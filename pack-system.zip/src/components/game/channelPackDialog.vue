<style>
  .option-dialog-cps-pack-1 .el-dialog{
    width: 900px;
  }
  .option-dialog-cps-pack-1 .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .option-dialog-cps-pack-1 .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
  }
</style>
<template>
  <el-dialog :title="optionData.title"
             :visible.sync="optionData.dialogVisible"
             :close-on-click-modal="false"
             class="option-dialog option-dialog-cps-pack-1">
    <div class="content-list">
      <el-tabs v-model="tabValue" type="card" class="tabs-content">
        <el-tab-pane label="广告码包" name="firstTab">
          <adv-pack-component ref="advChildMethod" :dataInfoForm="advPackDataInfo" :pluginList="pluginList"></adv-pack-component>
        </el-tab-pane>
        <el-tab-pane label="cps包" name="secondTab">
          <cps-pack-component ref="cpsChildMethod" :dataInfoForm="cpsPackDataInfo"></cps-pack-component>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import advPackComponent from './advPackComponent'
  import cpsPackComponent from './cpsPackComponent'
  import gameApi from '../../apis/game-api'
  import pluginApi from '../../apis/plugin-api'
  export default{
    components: {
      advPackComponent,
      cpsPackComponent
    },
    props: ['optionData'],
    data () {
      return {
        packType: 1,
        tabValue: 'firstTab',
        isEqualsOption: true,
        oldAdvPackDataInfo: null,
        oldCpsPackDataInfo: null,
        advPackDataInfo: {
          deletePackedIds: [],
          gamePackCPSorADModelList: []
        },
        cpsPackDataInfo: {
          deletePackedIds: [],
          gamePackCPSorADModelList: []
        },
        pluginList: []
      }
    },
    watch: {
      advPackDataInfo: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldAdvPackDataInfo, this.advPackDataInfo) &&
            equalsExtend.objectEqual(this.oldCpsPackDataInfo, this.cpsPackDataInfo)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      cpsPackDataInfo: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldAdvPackDataInfo, this.advPackDataInfo) &&
            equalsExtend.objectEqual(this.oldCpsPackDataInfo, this.cpsPackDataInfo)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.getPluginList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      getPluginInfo (plugins, pluginConfigIds) {
        let spList = []
        for (let pItem of this.pluginList) {
          if (plugins.indexOf(pItem.iPluginId) >= 0) {
            for (let spItem of pItem.pluginVersionList) {
              if (pluginConfigIds.indexOf(spItem.iPluginConfigId) >= 0) {
                pItem.iPluginConfigId = spItem.iPluginConfigId
                spList.push(pItem.pluginName + '--' + spItem.pluginVersion)
              }
            }
          }
        }
        return spList
      },
      checkCpsAdvDataInfo () {
        for (let pItem of this.optionData.packCpsAdvInfo) {
          if (pItem.cPackType === '0') {
            this.advPackDataInfo.gamePackCPSorADModelList.push({
              iAdcodeId: pItem.iAdcodeId,
              cAdcpsCode: pItem.cAdcpsCode,
              sDemo: pItem.sDemo,
              cOfficial: pItem.cOfficial,
              cAdPluginIds: pItem.cAdPluginIds,
              cAdPluginConfigIds: pItem.cAdPluginConfigIds,
              popoverVisible: false,
              adpluginList: pItem.cAdPluginIds.split(','),
              adpluginConfigList: pItem.cAdPluginConfigIds.split(','),
              selectPluginList: this.getPluginInfo(pItem.cAdPluginIds, pItem.cAdPluginConfigIds)
            })
          } else {
            this.cpsPackDataInfo.gamePackCPSorADModelList.push({
              iAdcodeId: pItem.iAdcodeId,
              cAdcpsCode: pItem.cAdcpsCode,
              sDemo: pItem.sDemo,
              cOfficial: pItem.cOfficial
            })
          }
        }
        this.oldAdvPackDataInfo = JSON.parse(JSON.stringify(this.advPackDataInfo))
        this.oldCpsPackDataInfo = JSON.parse(JSON.stringify(this.cpsPackDataInfo))
      },
      getPluginList () {
        let _this = this
        let params = {
          platformId: this.optionData.gameInfo.iPlatformId,
          languageId: this.optionData.gameInfo.iLanguageId,
          areaId: this.optionData.gameInfo.iAreaId
        }
        pluginApi.getPluginDataList(2, params).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
            for (let pItem of _this.pluginList) {
              if (pItem.pluginVersionList.length > 0) {
                pItem.iPluginConfigId = pItem.pluginVersionList[0].iPluginConfigId
              } else {
                pItem.iPluginConfigId = null
              }
            }
            _this.pluginList = JSON.parse(JSON.stringify(_this.pluginList))
            this.checkCpsAdvDataInfo()
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      hideDialog () {
        let dPackIds = this.advPackDataInfo.deletePackedIds.concat(this.cpsPackDataInfo.deletePackedIds)
        let dataInfo = {
          adCodeIds: dPackIds.join(','),
          gameAdcodeConfigList: []
        }
        for (let aItem of this.advPackDataInfo.gamePackCPSorADModelList) {
          dataInfo.gameAdcodeConfigList.push({
            projectId: this.optionData.gameInfo.iProjectId,
            iAdcodeId: aItem.iAdcodeId,
            cPackType: '0',
            cAdcpsCode: aItem.cAdcpsCode,
            sDemo: aItem.sDemo,
            cOfficial: aItem.cOfficial,
            cAdPluginIds: aItem.adpluginList.join(','),
            cAdPluginConfigIds: aItem.adpluginConfigList.join(',')
          })
        }
        for (let cItem of this.cpsPackDataInfo.gamePackCPSorADModelList) {
          dataInfo.gameAdcodeConfigList.push({
            projectId: this.optionData.gameInfo.iProjectId,
            iAdcodeId: cItem.iAdcodeId,
            cPackType: '1',
            sDemo: cItem.sDemo,
            cAdcpsCode: cItem.cAdcpsCode,
            cOfficial: cItem.cOfficial
          })
        }
        if (dataInfo.gameAdcodeConfigList.length === 0) {
          return false
        }
        gameApi.postCpsAdvPackInfo(dataInfo).then((data) => {
          if (data.code === 1) {
            this.optionData.dialogVisible = false
          } else {
            this.$alert(data.msg, '广告码配置失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
        })
      },
      submitForm () {
        if (equalsExtend.objectEqual(this.oldAdvPackDataInfo, this.advPackDataInfo) &&
          equalsExtend.objectEqual(this.oldCpsPackDataInfo, this.cpsPackDataInfo)) {
          this.optionData.dialogVisible = false
          return
        }
        let _this = this
        let advThis = this.$refs.advChildMethod.submitForm()
        let cpsThis = this.$refs.cpsChildMethod.submitForm()
        advThis.$refs['dataInfoForm'].validate((valid) => {
          if (valid) {
            cpsThis.$refs['dataInfoForm'].validate((validCps) => {
              if (validCps) {
                _this.hideDialog()
              } else {
                return false
              }
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
