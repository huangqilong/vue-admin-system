<style>
  .option-dialog-config .el-dialog{
    width: 700px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog .upload-demo-table{
    width: 80px;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增游戏配置':'修改游戏配置'"
             :visible.sync="optionData.dialogFormVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-config">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="120px">
      <el-form-item label="渠道名称：" prop="iChannelId">
        <el-select v-model="dataInfoForm.iChannelId" placeholder="请选择" @change="channelSelectChange(true)">
          <el-option
            v-for="item in channelList"
            :key="item.iChannelId"
            :label="item.channelName"
            :value="item.iChannelId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="渠道版本：" prop="iChannelConfigId">
        <el-select v-model="dataInfoForm.iChannelConfigId" placeholder="请选择">
          <el-option
            v-for="item in channelVersionList"
            :key="item.iAndrChannelId"
            :label="item.channelVersion"
            :value="item.iAndrChannelId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="代理版本：" prop="iMiddleareId">
        <el-select v-model="dataInfoForm.iMiddleareId" placeholder="请选择">
          <el-option
            v-for="item in agencyList"
            :key="item.iMiddleareId"
            :label="item.cMiddleareVersion"
            :value="item.iMiddleareId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="版本号：" prop="versionCode">
        <el-input v-model.number.trim="dataInfoForm.versionCode"></el-input>
      </el-form-item>
      <el-form-item label="版本名字：" prop="versionName">
        <el-input v-model.trim="dataInfoForm.versionName"></el-input>
      </el-form-item>
      <el-form-item label="渠道包名：" prop="packageName">
        <el-input v-model.trim="dataInfoForm.packageName"></el-input>
      </el-form-item>
      <el-form-item label="签名文件：" prop="keystorePath">
        <el-upload
          class="upload-demo"
          :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
          :show-file-list="true"
          :multiple="false"
          :headers="headersFile"
          :file-list="fileStoreUploadList"
          :before-upload="beforeAvatarUpload"
          :on-success="handleStoreFileSuccess"
          :on-remove="handleStoreFileRemove"
          :on-error="handleStoreFileError"
          :on-progress="handleStoreFileProgress">
          <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item label="签名密码：" prop="keyPassword">
        <el-input v-model.trim="dataInfoForm.keyPassword"></el-input>
      </el-form-item>
      <el-form-item label="渠道额外资源：" prop="extraResPath">
        <el-row>
          <el-col :span="20">
            <el-upload
              class="upload-demo"
              :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
              :show-file-list="true"
              :multiple="false"
              :headers="headersFile"
              :file-list="extraResUploadList"
              :before-upload="beforeExtraResUpload"
              :on-success="handleExtraResSuccess"
              :on-remove="handleExtraResRemove"
              :on-error="handleExtraResError"
              :on-progress="handleExtraResProgress">
              <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
            </el-upload>
          </el-col>
          <el-col :span="4" style="text-align: center;">
            <el-button size="mini" type="text" @click="extraResDemoUpload">实 例</el-button>
            <el-button size="mini" type="text" @click="extraResUpload" v-if="dataInfoForm.extraResPath">下载</el-button>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="最小sdk版本：" prop="minVersion">
        <el-input v-model.number.trim="dataInfoForm.minVersion"></el-input>
      </el-form-item>
      <el-form-item label="指定sdk版本：" prop="targetVersion">
        <el-input v-model.number.trim="dataInfoForm.targetVersion"></el-input>
      </el-form-item>
      <el-form-item label="是否使用obb：">
        <el-radio class="radio" v-model="cObb" :label="1">是</el-radio>
        <el-radio class="radio" v-model="cObb" :label="0">否</el-radio>
      </el-form-item>
      <el-form-item label="crc值：" prop="crcValue" v-if="cObb==1">
        <el-input v-model.trim="dataInfoForm.crcValue" placeholder="请填写crc值"></el-input>
      </el-form-item>
      <el-form-item label="谷歌密钥：" prop="publicKey">
        <el-input v-model.trim="dataInfoForm.publicKey" placeholder="请填写谷歌密钥"></el-input>
      </el-form-item>
      <el-form-item label="是否分包：" prop="cDex">
        <el-radio class="radio" v-model="dataInfoForm.cDex" :label="'1'">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cDex" :label="'0'">否</el-radio>
      </el-form-item>
      <el-form-item label="bugly ID：">
        <el-input v-model.trim="dataInfoForm.buglyId"></el-input>
      </el-form-item>
      <el-form-item label="bugly KEY：">
        <el-input v-model.trim="dataInfoForm.buglyKey"></el-input>
      </el-form-item>
      <el-form-item label="游戏比例：" prop="iRate">
        <el-input v-model.number.trim="dataInfoForm.iRate"></el-input>
      </el-form-item>
      <el-form-item label="是否要填写metadata：">
        <el-radio class="radio" v-model="dataInfoForm.cMetadata" label="1">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cMetadata" label="0">否</el-radio>
      </el-form-item>
      <el-form-item label="metadata：" v-if="dataInfoForm.cMetadata == '1'">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.metaData"></el-input>
      </el-form-item>
      <el-form-item label="游戏ICON：">
        <iconConfigTable :fileConfig="iconFileConfig"></iconConfigTable>
      </el-form-item>
      <el-form-item label="渠道闪屏：">
        <splashConfigTable :fileConfig="splashFileConfig"></splashConfigTable>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='update' && optionData.gameInfo.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'
  import agencyApi from '../../apis/agency-api'
  import channelApi from '../../apis/channel-api'
  import iconConfigTable from '../manager/iconConfigTable'
  import splashConfigTable from '../manager/splashConfigTable'

  export default{
    components: {
      iconConfigTable,
      splashConfigTable
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        oldProjectSplashDataList: null,
        oldProjectIconDataList: null,
        isMetadata: 1,
        channelList: null,
        channelVersionList: null,
        agencyList: null,
        fileStoreUploadList: [],
        extraResUploadList: [],
        iconFileConfig: {
          platformType: 0,
          sourceType: 1,
          picType: 0
        },
        splashFileConfig: {
          platformType: 0,
          sourceType: 1,
          picType: 1
        },
        cObb: 0,
        rules: {
          iChannelId: [
            {type: 'number', required: true, message: '请选择渠道', trigger: 'change'}
          ],
          iChannelConfigId: [
            {type: 'number', required: true, message: '请选择渠道版本', trigger: 'change'}
          ],
          iMiddleareId: [
            {type: 'number', required: true, message: '请选择代理版本', trigger: 'change'}
          ],
          versionCode: [
            { pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur' }
          ],
          minVersion: [
            { pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur' }
          ],
          targetVersion: [
            { pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur' }
          ],
          iRate: [
            {pattern: /^[0-9]*$/, message: '请输入数字', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'headersFile', 'projectSplashDataList', 'projectIconDataList', 'deleteGamePicIds',
        'fileUploadDirId', 'buttonLoading', 'proxyDevApi', 'extraResPath'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      projectSplashDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      projectIconDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.optionData.type === 'update') {
        this.cObb = this.dataInfoForm.crcValue ? 1 : 0
//        this.isMetadata = this.dataInfoForm.cMetadata ? 1 : 0
      }
      if (this.optionData.type === 'update' && this.dataInfoForm.keystorePath) {
        this.fileStoreUploadList = []
        this.fileStoreUploadList.push({
          name: this.dataInfoForm.keystorePath,
          resId: this.dataInfoForm.resId
        })
      }

      if (this.optionData.type === 'update' && this.dataInfoForm.extraResPath) {
        this.extraResUploadList = []
        this.extraResUploadList.push({
          name: this.dataInfoForm.extraResPath,
          resId: this.dataInfoForm.extraResId
        })
      }

      if (this.dataInfoForm.resDirId) {
        this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
      } else {
        this.$store.dispatch('getFileUploadDir', null)
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
      this.oldProjectSplashDataList = JSON.parse(JSON.stringify(this.projectSplashDataList))
      this.oldProjectIconDataList = JSON.parse(JSON.stringify(this.projectIconDataList))
      // 获取渠道列表
      this.getChannelList()
      // 获取代理列表
      this.getAgencyList()
    },
    methods: {
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegCert = /.(jks|keystore)/
        let isUpload = androidRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('签名文件格式只能为jks|keystore', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleStoreFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleStoreFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.fileStoreUploadList.length > 0 && this.fileStoreUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.fileStoreUploadList[0].resId)
          }
          this.fileStoreUploadList = []
          let fileName = response.data.url
          this.fileStoreUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.keystorePath = fileName
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.fileStoreUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleStoreFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.keystorePath = ''
        this.dataInfoForm.resId = ''
      },
      handleStoreFileError (error, file, fileList) {
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      beforeExtraResUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegCert = /.(zip)/
        let isUpload = androidRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('渠道额外资源格式只能为zip', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleExtraResProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleExtraResSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.extraResUploadList.length > 0 && this.extraResUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.extraResUploadList[0].resId)
          }
          this.extraResUploadList = []
          let fileName = response.data.url
          this.extraResUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.extraResPath = fileName
          this.dataInfoForm.extraResId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.extraResUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleExtraResRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.extraResPath = ''
        this.dataInfoForm.extraResId = ''
      },
      handleExtraResError (error, file, fileList) {
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      getChannelList () {
        let _this = this
        channelApi.getDropDownDataList(this.optionData.gameInfo.iPlatformId).then((data) => {
          if (data.code === 1) {
            _this.channelList = data.data
            _this.channelSelectChange()
          }
        }, (error) => {
          console.log(error)
          _this.channelList = null
        })
      },
      getAgencyList () {
        let _this = this
        let cAssertType = this.optionData.gameInfo.cAssertType === '2' ? '1' : this.optionData.gameInfo.cAssertType
        agencyApi.getPlatDataList('android', this.optionData.gameInfo.iPlatformId, cAssertType).then((data) => {
          if (data.code === 1) {
            _this.agencyList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.agencyList = null
        })
      },
      channelSelectChange (flag) {
        let _this = this
        for (const cItem in this.channelList) {
          if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
            this.dataInfoForm.buglyId = cItem.buglyId || ''
            this.dataInfoForm.buglyKey = cItem.buglyKey || ''
            break
          }
        }
        if (_this.dataInfoForm.iChannelId) {
          channelApi.getDropDownVersionDataList(_this.$route.params.type, _this.dataInfoForm.iChannelId).then((data) => {
            if (data.code === 1) {
              _this.channelVersionList = data.data
              if (flag && _this.channelVersionList.length > 0) {
                _this.dataInfoForm.iChannelConfigId = _this.channelVersionList[0].iAndrChannelId
              }
            }
          }, (error) => {
            console.log(error)
            _this.channelVersionList = null
          })
        }
      },
      extraResUpload () {
        let realPath = window.location.href
        let extraRP = this.dataInfoForm.extraResPath.substring(this.dataInfoForm.extraResPath.indexOf('/upload/'))
        let extraDownloadPath = ''
        if (realPath.indexOf('192.168.0.147') >= 0) {
          extraDownloadPath = 'http://192.168.0.147/cms' + extraRP
        } else {
          extraDownloadPath = 'http://192.168.0.148/cms' + extraRP
        }
        window.location.href = extraDownloadPath
      },
      extraResDemoUpload () {
        window.location.href = this.extraResPath
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              this.dataInfoForm.resDirId = this.fileUploadDirId
              _this.dataInfoForm.splashList = []
              _this.dataInfoForm.iconList = []
              for (let iItem of _this.projectIconDataList) {
                if (iItem.picUrl) {
                  _this.dataInfoForm.iconList.push({
                    cDictIds: iItem.iDicId,
                    sDictNames: iItem.sDicName,
                    cPicType: iItem.cPicType,
                    cSource: iItem.cSource,
                    iPlatformId: iItem.iPlatformId,
                    resIds: iItem.resId,
                    picUrl: iItem.picUrl
                  })
                }
              }
              for (let sItem of _this.projectSplashDataList) {
                let isNull = true
                let tempRes = {
                  resId: [],
                  picUrl: []
                }
                let tempItem = {
                  cDictIds: sItem.splashId + ',' + sItem.orientationId,
                  sDictNames: sItem.splashName + ',' + sItem.orientationName,
                  cPicType: sItem.cPicType,
                  cSource: sItem.cSource,
                  iPlatformId: sItem.iPlatformId,
                  resIds: '',
                  picUrl: ''
                }
                for (let picItem of sItem.picList) {
                  if (picItem.picUrl) {
                    isNull = false
                    tempRes.resId.push(picItem.resId)
                    tempRes.picUrl.push(picItem.picUrl)
                  }
                }
                if (!isNull) {
                  tempItem.resIds = tempRes.resId.join(',')
                  tempItem.picUrl = tempRes.picUrl.join(',')
                  _this.dataInfoForm.splashList.push(tempItem)
                }
              }
              // 数据新增
              gameApi.addConfigDataInfo('android', _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  _this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  _this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, this.dataInfoForm) &&
                equalsExtend.objectEqual(_this.oldProjectSplashDataList, _this.projectSplashDataList) &&
                equalsExtend.objectEqual(_this.oldProjectIconDataList, _this.projectIconDataList)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              if (this.cObb === 0) {
                this.dataInfoForm.crcValue = ''
              }
              _this.dataInfoForm.iconList = []
              _this.dataInfoForm.splashList = []
              for (let iItem of _this.projectIconDataList) {
                if (iItem.picUrl) {
                  _this.dataInfoForm.iconList.push({
                    cDictIds: iItem.iDicId,
                    sDictNames: iItem.sDicName,
                    cPicType: iItem.cPicType,
                    cSource: iItem.cSource,
                    iPlatformId: iItem.iPlatformId,
                    iRefId: iItem.iRefId,
                    iPicId: iItem.iPicId,
                    resIds: iItem.resId,
                    picIds: iItem.picId,
                    picUrl: iItem.picUrl
                  })
                }
              }
              for (let sItem of _this.projectSplashDataList) {
                let isNull = true
                let tempRes = {
                  resId: [],
                  picId: [],
                  picUrl: []
                }
                let tempItem = {
                  cDictIds: sItem.splashId + ',' + sItem.orientationId,
                  sDictNames: sItem.splashName + ',' + sItem.orientationName,
                  cPicType: sItem.cPicType,
                  cSource: sItem.cSource,
                  iPlatformId: sItem.iPlatformId,
                  iRefId: sItem.iRefId,
                  iPicId: sItem.iPicId,
                  picIds: '',
                  resIds: '',
                  picUrl: ''
                }
                for (let picItem of sItem.picList) {
                  if (picItem.picUrl) {
                    isNull = false
                    if (picItem.resId) {
                      tempRes.resId.push(picItem.resId)
                    }
                    if (picItem.picId) {
                      tempRes.picId.push(picItem.picId)
                    }
                    tempRes.picUrl.push(picItem.picUrl)
                  }
                }
                if (!isNull) {
                  tempItem.resIds = tempRes.resId.join(',')
                  tempItem.picIds = tempRes.picId.join(',')
                  tempItem.picUrl = tempRes.picUrl.join(',')
                  _this.dataInfoForm.splashList.push(tempItem)
                }
              }
              // 数据修改
              gameApi.updateConfigDataInfo('android', _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  _this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  _this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
