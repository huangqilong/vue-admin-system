<style>
  .option-dialog-join-up .el-dialog{
    min-width: 900px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
</style>
<template>
  <el-dialog title="接入游戏列表"
             :visible.sync="optionConfigData.dialogFormVisible"
             class="option-dialog option-dialog-join-up">
    <div class="content-list">
      <el-table :data="dataInfoForm" stripe>
        <el-table-column prop="areaName" label="地区" width="50"></el-table-column>
        <el-table-column prop="platformName" label="平台" width="50"></el-table-column>
        <el-table-column prop="languageName" label="语言" width="100"></el-table-column>
        <el-table-column prop="gameName" label="游戏名称" width="150"></el-table-column>
        <el-table-column prop="iGameAssetVersion" label="游戏版本" width="100"></el-table-column>
        <el-table-column label="资源类型" width="100">
          <template scope="scope">
            {{scope.row.cversionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}
          </template>
        </el-table-column>
        <el-table-column prop="iGameAssetName" label="资源名称" ></el-table-column>
        <el-table-column prop="cDisplay" label="状态" :width="80">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionConfigData.dialogFormVisible = false">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'

  export default{
    components: {},
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {}
    },
    computed: {
      ...mapGetters([
        'gameAssetsTypeList'
      ])
    },
    created: function () {},
    methods: {}
  }
</script>
