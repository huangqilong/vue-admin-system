<style>
  .content-list-pack{
  }
  .content-list-pack .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .content-list-pack .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
    max-height: 450px;
    overflow-y: auto;
    overflow-x: hidden;
  }
  .content-list .path{
    margin-top: 10px;
  }
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <div class="content-list-pack">
    <div class="content-list" id="myData">
      <el-form :model="dataInfoForm" ref="dataInfoForm">
        <el-row v-if="0 == dataInfoForm.gamePackCPSorADModelList.length">
          <el-col :span="2">&nbsp;</el-col>
          <el-col :span="20">
            <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('dataInfoForm')">添&nbsp;&nbsp;加</el-button>
          </el-col>
          <el-col :span="2">&nbsp;</el-col>
        </el-row>
        <el-row v-if="dataInfoForm.gamePackCPSorADModelList.length > 0">
          <el-col :span="5" class="table-head">广告码</el-col>
          <el-col :span="5" class="table-head">备注</el-col>
          <el-col :span="6" class="table-head">广告插件</el-col>
          <el-col :span="2" class="table-head">选择官方码</el-col>
          <el-col :span="3" class="table-head">操作</el-col>
          <el-col :span="3" class="table-head">&nbsp;</el-col>
        </el-row>
        <el-row v-for="(domain,index) in dataInfoForm.gamePackCPSorADModelList" :gutter="10">
          <el-col :span="5">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.cAdcpsCode'"
              :rules="[{required: true, message: '请输入渠道码', trigger: 'blur'},{validator: checkChannelCode, trigger: 'blur'}]">
              <el-input v-model.trim="domain.cAdcpsCode" placeholder="请输入渠道码"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.sDemo'"
              :rules="[{required: true, message: '请输入备注', trigger: 'blur'}]">
              <el-input v-model.trim="domain.sDemo" placeholder="请输入备注"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6">
            &nbsp;{{domain.selectPluginList.join(',')}}
          </el-col>
          <el-col :span="2">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.cOfficial'">
              <el-checkbox v-model="domain.cOfficial" :true-label="'1'" :false-label="'0'" @change="gamePackAdvOfficial(domain, dataInfoForm.gamePackCPSorADModelList)">&nbsp;</el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="3">
            <el-popover
              placement="bottom"
              title="插件配置信息"
              width="400"
              trigger="click"
              v-model="domain.popoverVisible">
              <div class="popover-content">
                <el-table :data="pluginList" stripe ref="pluginMultipleTable" @selection-change="handleSelectionChange" style="width: 400px;">
                  <el-table-column
                    type="selection"
                    width="50"
                    label="操作">
                  </el-table-column>
                  <el-table-column prop="pluginName" label="插件名称"></el-table-column>
                  <el-table-column prop="pluginVersion" label="版本号" width="150">
                    <template scope="scope">
                      <el-select v-model="scope.row.iPluginConfigId" placeholder="请选择">
                        <el-option
                          v-for="item in scope.row.pluginVersionList"
                          :key="item.iPluginConfigId"
                          :label="item.pluginVersion"
                          :value="item.iPluginConfigId">
                        </el-option>
                      </el-select>
                    </template>
                  </el-table-column>
                </el-table>
                <div style="text-align: right;margin-top: 5px;">
                  <el-button size="small" @click="domain.popoverVisible = false">关 闭</el-button>
                </div>
              </div>
              <el-button slot="reference" type="text" class="table-option-button" @click="popoverPluginClick(index)">选择插件</el-button>
            </el-popover>
          </el-col>
          <el-col :span="3" style="text-align: left;">
            <el-button type="text" class="table-option-button" @click.prevent="removeItem(index)">删除</el-button>
            <el-button type="text" class="table-option-button" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.gamePackCPSorADModelList.length-1">添加</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {
    },
    props: ['dataInfoForm', 'pluginList'],
    data () {
      return {
        selectIndex: 0,
        gamePackDataLength: 0
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    watch: {
      gamePackDataLength () {
        this.$nextTick(() => {
          var container = this.$el.querySelector('#myData')
          container.scrollTop = container.scrollHeight
        })
      }
    },
    created: function () {
    },
    methods: {
      gamePackAdvOfficial (domain, dataList) {
        for (let item of dataList) {
          item.cOfficial = '0'
        }
        domain.cOfficial = '1'
      },
      checkChannelCode (rule, value, callback) {
        if (!value) {
          return callback(new Error('请输入渠道码'))
        }
        setTimeout(() => {
          let infoItemsStr = JSON.stringify(this.dataInfoForm.gamePackCPSorADModelList)
          let valStr = JSON.stringify({cAdcpsCode: value})
          if (infoItemsStr.split(valStr.substring(1, valStr.length - 1)).length <= 2) {
            callback()
          } else {
            callback(new Error('渠道码已存在'))
          }
        }, 1000)
      },
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.gamePackCPSorADModelList.push({
              cAdcpsCode: '',
              sDemo: '',
              cOfficial: '0',
              cAdPluginIds: '',
              cAdPluginConfigIds: '',
              popoverVisible: false,
              adpluginList: [],
              adpluginConfigList: [],
              selectPluginList: []
            })
            this.gamePackDataLength = this.dataInfoForm.gamePackCPSorADModelList.length
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        let iCpsAdId = this.dataInfoForm.gamePackCPSorADModelList[$index].iAdcodeId
        if (iCpsAdId) {
          this.dataInfoForm.deletePackedIds.push(iCpsAdId)
        }
        this.dataInfoForm.gamePackCPSorADModelList.splice($index, 1)
      },
      handleSelectionChange (selectDataList) {
        this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].selectPluginList = []
        this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginList = []
        this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginConfigList = []
        for (let sItem of selectDataList) {
          for (let pvItem of sItem.pluginVersionList) {
            if (sItem.iPluginConfigId === pvItem.iPluginConfigId) {
              this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].selectPluginList.push(sItem.pluginName + '--' + pvItem.pluginVersion)
            }
          }
          this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginList.push(sItem.iPluginId)
          this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginConfigList.push(sItem.iPluginConfigId)
        }
      },
      popoverPluginClick (index) {
        this.selectIndex = index
        let adpluginList = this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginList
        for (let pItem of this.pluginList) {
          if (adpluginList.indexOf(pItem.iPluginId + '') >= 0) {
            this.$refs['pluginMultipleTable'][this.selectIndex].toggleRowSelection(pItem, true)
          }
        }
      },
      submitForm () {
        return this
      }
    }
  }
</script>
