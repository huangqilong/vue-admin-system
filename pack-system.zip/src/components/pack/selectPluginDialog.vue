<style>
  .option-dialog-pack .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
</style>
<template>
  <el-dialog title="选择插件"
             :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-pack">
    <div class="content-list">
      <el-table :data="pluginList" stripe ref="pluginMultipleTable" @select-all="handleSelectionAll" @select="handleSelection" @selection-change="handleSelectionChange">
        <el-table-column
          type="selection"
          width="80"
          label="操作">
        </el-table-column>
        <el-table-column prop="pluginName" label="插件名称"></el-table-column>
        <el-table-column label="版本号">
          <template scope="scope">
            <el-select v-model="scope.row.iPluginConfigId" placeholder="请选择">
              <el-option
                v-for="item in scope.row.gamePackPluginVersionVOList"
                :key="item.iPluginConfigId"
                :label="item.pluginVersion"
                :value="item.iPluginConfigId">
              </el-option>
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="pluginType" label="插件类型">
          <template scope="scope">
            {{scope.row.pluginType=='1'?'功能插件':(scope.row.pluginType=='2'?'广告插件':'渠道插件')}}
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import packToolApi from '../../apis/pack-tool-api'

  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm'],
    data () {
      return {
        pluginList: [],
        pluginSelectList: [],
        selectDataList: []
      }
    },
    computed: {
    },
    created: function () {
      // 选择默认选中的值
      for (let item of this.dataInfoForm.selectPluginList) {
        this.pluginSelectList.push(item.iPluginId)
      }
      // 获取插件列表
      this.searchDataList()
    },
    methods: {
      searchDataList () {
        let _this = this
        packToolApi.getPackGamePluginDataList(this.dataInfoForm.iChannelId, this.optionData.platformType).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
            for (let pItem of _this.pluginList) {
              if (pItem.gamePackPluginVersionVOList.length > 0) {
                pItem.iPluginConfigId = pItem.gamePackPluginVersionVOList[0].iPluginConfigId
              } else {
                pItem.iPluginConfigId = ''
              }
            }
            _this.pluginList = JSON.parse(JSON.stringify(_this.pluginList))
            this.$nextTick(function () {
              _this.checkSelectList()
            })
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      checkSelectList () {
        for (let pItem of this.pluginList) {
          if (pItem.pluginType === '3' || (pItem.pluginType !== '3' && pItem.isRequired === 1) || this.pluginSelectList.indexOf(pItem.iPluginId) >= 0) {
            this.$refs.pluginMultipleTable.toggleRowSelection(pItem, true)
          }
          if ((pItem.pluginType === '3' || (pItem.pluginType !== '3' && pItem.isRequired === 1)) && this.pluginSelectList.indexOf(pItem.iPluginId) < 0) {
            this.dataInfoForm.selectPluginList.push({
              iPluginId: pItem.iPluginId,
              pluginName: pItem.pluginName,
              iPluginConfigId: pItem.gamePackPluginVersionVOList[0].iPluginConfigId,
              pluginVersion: pItem.gamePackPluginVersionVOList[0].pluginVersion,
              iChannelPluginId: pItem.gamePackPluginVersionVOList[0].iChannelPluginId
            })
          }
        }
      },
      handleSelectionAll (selection) {
        if (selection.length === 0) {
          for (let pItem of this.pluginList) {
            if (pItem.pluginType === '3' || (pItem.pluginType !== '3' && pItem.isRequired === 1)) {
              this.$refs.pluginMultipleTable.toggleRowSelection(pItem, true)
            }
          }
        }
      },
      handleSelection (selection, row) {
        if (row.pluginType === '3' || (row.pluginType !== '3' && row.isRequired === 1)) {
          this.$refs.pluginMultipleTable.toggleRowSelection(row, true)
        }
      },
      handleSelectionChange (selectDataList) {
        this.selectDataList = selectDataList
      },
      submitForm () {
        this.dataInfoForm.selectPluginList = []
        for (let sItem of this.selectDataList) {
          for (let spItem of sItem.gamePackPluginVersionVOList) {
            if (sItem.iPluginConfigId === spItem.iPluginConfigId) {
              this.dataInfoForm.selectPluginList.push({
                iPluginId: sItem.iPluginId,
                pluginName: sItem.pluginName,
                iPluginConfigId: spItem.iPluginConfigId,
                pluginVersion: spItem.pluginVersion,
                iChannelPluginId: spItem.iChannelPluginId
              })
              break
            }
          }
        }
        this.optionData.dialogVisible = false
      }
    }
  }
</script>
