<style scoped>
  .main-sidebar {
    position: absolute;
    top: 60px;
    width: 230px;
    background-color: #324157;
    overflow-y: auto;
    bottom: 0;
  }
  .main-sidebar .el-menu {
    border-right: 1px solid #545c64;
  }
</style>
<style>
  .el-menu-vertical-demo .el-menu-item{
    border-left:2px solid #324157;
  }
  .el-menu-vertical-demo .el-menu-item.is-active{
    border-left:2px solid #ffd04b;
    background-color: rgb(40 52 70) !important;
  }
  .el-menu-vertical-demo .el-menu-item:hover{
    background-color:#48576a !important;
  }
  .el-menu-vertical-demo .el-menu-item, .el-menu-vertical-demo .el-submenu__title{
    height: 50px;
    line-height: 50px;
  }
  .el-menu-vertical-demo .el-menu-item .menu-parent-icon,
  .el-menu-vertical-demo .el-submenu .menu-parent-icon{
    color: #f1f1f1;
    margin-right: 10px;
    font-size: 20px;
  }
  .el-menu-vertical-demo .el-submenu .menu-icon{
    color: #f1f1f1;
    margin-right: 10px;
    font-size: 10px;
  }
  .el-menu-vertical-demo .el-menu-item.is-active i{
    color:#20a0ff;
  }
</style>
<template>
  <nav class="main-sidebar">
    <el-menu class="el-menu-vertical-demo"
             :unique-opened="true"
             :default-active="activeMenuIndex"
             background-color="#324157"
             text-color="#f1f1f1"
             active-text-color="#20a0ff">
      <template v-for="menu in menuConfig">
        <template v-if="menu.children && menu.children.length>0">
          <c-sub-menu :menu="menu"></c-sub-menu>
        </template>
        <template v-else>
          <el-menu-item :index="menu.iMenuId+''" @click="menuItemSelect(menu)"><i class="menu-parent-icon icon iconfont" :class="menu.cIcon || 'icon-caidan'"></i>{{menu.label}}</el-menu-item>
        </template>
      </template>
    </el-menu>
  </nav>
</template>
<script>
  import {mapGetters} from 'vuex'
  import menuConfigData from '../config/menu'
  import CSubMenu from '../components/CSubMenu'

  export default {
    name: 'cMenu',
    components: {
      CSubMenu
    },
    data () {
      return {
        activeIndex: '31',
        menuConfig: []
      }
    },
    computed: mapGetters([
      'activeMenuIndex'
    ]),
    created: function () {
      this.menuConfig = menuConfigData
      this.intervalTime = setInterval(() => {
        if (this.menuConfig.length > 0) {
          this.$store.dispatch('getMenuActiveIndex', {menus: this.menuConfig, path: this.$route.path})
          clearInterval(this.intervalTime)
        }
      }, 1000)
      this.getActiveIndex(this.menuConfig)
    },
    methods: {
      menuItemSelect (menu) {
        this.$router.push(menu.cUrl)
      },
      getActiveIndex (menus) {
        for (var i = 0; i < menus.length; i++) {
          let menu = menus[i]
          if (menu.children && menu.children.length > 0) {
            this.getActiveIndex(menu.children)
          } else {
            if (this.$route.path.indexOf(menu.cUrl) > -1) {
              this.activeIndex = menu.iMenuId + ''
            }
          }
        }
      }
    }
  }
</script>
