<style>
  .option-dialog-pro .el-dialog--tiny{
    min-width: 400px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增游戏工程':'修改游戏工程'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pro">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="工程code：" prop="projectCode">
        <el-input v-model="dataInfoForm.projectCode"></el-input>
      </el-form-item>
      <el-form-item label="服务器版本号：" prop="serverVersion">
        <el-input v-model="dataInfoForm.serverVersion"></el-input>
      </el-form-item>
      <el-form-item label="资源key：" prop="appKey">
        <el-input v-model="dataInfoForm.appKey"></el-input>
      </el-form-item>
      <el-form-item label="游戏ID：" prop="gameId">
        <el-input v-model="dataInfoForm.gameId"></el-input>
      </el-form-item>
      <el-form-item label="额外拼接：" prop="extraSign">
        <el-input v-model="dataInfoForm.extraSign"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import projectApi from '../../apis/project-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
          projectCode: [
            {required: true, message: '请输入工程code', trigger: 'blur'}
          ],
          serverVersion: [
            {required: true, message: '请输入服务器版本号', trigger: 'blur'}
          ],
          appKey: [
            {required: true, message: '请输入资源key', trigger: 'blur'}
          ],
          gameId: [
            {required: true, message: '请输入游戏ID', trigger: 'blur'}
          ],
          extraSign: [
            {required: true, message: '请输入额外拼接', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'buttonLoading'
      ])
    },
    created: function () {

    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              projectApi.addDataInfo(_this.dataInfoForm).then((data) => {
                console.log(data)
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              // 数据修改
              projectApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
