<style>
  .option-dialog-pro .el-dialog--tiny{
    min-width: 400px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增渠道':'修改渠道'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pro">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="渠道名称：" prop="channelId">
        <el-select v-model="dataInfoForm.channelId" placeholder="请选择">
          <el-option
            v-for="item in channelList"
            :key="item.iChannelId"
            :label="item.channelName"
            :value="item.iChannelId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="语言：" prop="iLanguageId">
        <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择">
          <el-option
            v-for="item in languageList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="包名：" prop="packageName">
        <el-input v-model="dataInfoForm.packageName"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import projectApi from '../../apis/project-api'
  import channelApi from '../../apis/channel-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
          channelId: [
            {type: 'number', required: true, message: '请选择渠道名称', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择语言', trigger: 'change'}
          ],
          packageName: [
            {required: true, message: '请输入包名', trigger: 'blur'}
          ]
        },
        channelList: null
      }
    },
    computed: {
      ...mapGetters([
        'languageList', 'buttonLoading'
      ])
    },
    created: function () {
      // 获取渠道列表
      const params = {'currentPage': 1, 'number': 99999}
      channelApi.getDataList(params).then((data) => {
        if (data.code === 1) {
          this.channelList = data.data.list
        }
      }, (error) => {
        console.log(error)
        this.channelList = null
      })
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              projectApi.addChannelDataInfo(_this.dataInfoForm).then((data) => {
                console.log(data)
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              // 数据修改
              projectApi.updateChannelDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
