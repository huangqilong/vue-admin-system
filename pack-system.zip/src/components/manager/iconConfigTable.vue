<style scoped>
  .img-content{
  }
  .img-content .img-item{
    width: 100px;
    height: 100px;
    margin: 0 auto;
    position: relative;
  }
  .img-content .img-item .img-item-icon{
    position: absolute;
    right: 2px;
    top: 2px;
    cursor: pointer;
    font-size: 14px;
    color: #999;
    background-color: #fff;
    border-radius: 50%;
  }
  .img-content .img-item img{
    width: 100%;
    height: 100%;
  }
  .previewImages{
    width: 32px;
    height: 32px;
  }
  .previewImages img{
    width: 32px;
    height: 32px;
  }
</style>
<template>
  <div>
    <el-table :data="projectIconDataList" stripe>
      <el-table-column prop="sDicName" label="分辨率"></el-table-column>
      <el-table-column label="图片资源">
        <template scope="scope">
          <el-popover v-if="scope.row.picUrl"
            placement="bottom"
            title="预览图片"
            width="200"
            trigger="hover">
            <div class="img-content">
              <div class="img-item">
                <div class="el-icon-close img-item-icon" @click="handleFileRemove(scope.$index)"></div>
                <img :src="scope.row.picUrl + '?o_O='+ (scope.row.resId ?scope.row.resId:new Date().getTime()) ">
              </div>
            </div>
            <div slot="reference" class="previewImages">
              <img :src="scope.row.picUrl + '?o_O='+ (scope.row.resId ?scope.row.resId:new Date().getTime()) ">
            </div>
            <!--<el-button slot="reference" type="text" class="table-option-button">预览</el-button>-->
          </el-popover>
          <span v-if="!scope.row.picUrl">----</span>
        </template>
      </el-table-column>
      <el-table-column
        label="操作" width="100">
        <template scope="scope">
          <el-upload
            class="upload-demo upload-demo-table"
            :action="proxyDevApi+'/uploadFile/' + fileUploadDirId + '/' + scope.row.iDicId + '/platform/' + fileConfig.platformType + '/pic/' + fileConfig.picType"
            :show-file-list="false"
            :headers="headersFile"
            :before-upload="beforeAvatarUpload"
            :on-success="handleFileSuccess">
            <el-button type="text" @click="selectFileUpload(scope.$index)">上传</el-button>
          </el-upload>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    props: ['fileConfig'],
    components: {
    },
    computed: {
      ...mapGetters([
        'headersFile', 'projectIconDataList', 'deleteGamePicIds', 'fileUploadDirId', 'proxyDevApi'
      ])
    },
    data () {
      return {
        optionIndex: -1
      }
    },
    methods: {
      selectFileUpload ($index) {
        this.optionIndex = $index
      },
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegImg = /.(png|jpg|bmp|gif)/
        let iosRegImg = /.png/
        let isUpload = false
        if (this.fileConfig.platformType === 1) {
          isUpload = iosRegImg.test(fileType)
          if (!isUpload) {
            this.$alert('图片类型只能为png', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        } else {
          isUpload = androidRegImg.test(fileType)
          if (!isUpload) {
            this.$alert('图片类型只能为png|jpg|bmp|gif', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        }
        return isUpload
      },
      handleFileSuccess (response, file, fileList) {
        if (response.code === 1) {
//          if (this.projectIconDataList[this.optionIndex].picPath) {
//            let iPicId = this.projectIconDataList[this.optionIndex].iPicId
//            if (iPicId && this.deleteGamePicIds.indexOf(iPicId) < 0) {
//              // 判断为修改，先保存iPicId，在删除
//              this.$store.dispatch('deleteGamePicIds', iPicId)
//            } else {
//              this.$store.dispatch('deleteGameConfigImage', this.projectIconDataList[this.optionIndex].picId)
//            }
//          }
          this.$store.dispatch('updateProjectIconPath', {index: this.optionIndex, fileData: response.data[0]})
        } else {
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleFileRemove ($index) {
//        let iPicId = this.projectIconDataList[$index].iPicId
//        if (iPicId && this.deleteGamePicIds.indexOf(iPicId) < 0) {
//          // 判断为修改，先保存iPicId，在删除
//          this.$store.dispatch('deleteGamePicIds', iPicId)
//        } else {
//          this.$store.dispatch('deleteGameConfigImage', this.projectIconDataList[$index].picId)
//        }
        this.$store.dispatch('deleteProjectIconPath', {index: $index})
      }
    }
  }
</script>
