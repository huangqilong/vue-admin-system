<style scoped>
  .img-content{
    max-width: 100%;
  }
  .img-content .img-item{
    width: 100px;
    height: 100px;
    position: relative;
    float: left;
    margin: 5px;
  }
  .img-content .img-item .img-item-icon{
    position: absolute;
    right: 2px;
    top: 2px;
    cursor: pointer;
    font-size: 14px;
    color: #999;
    background-color: #fff;
    border-radius: 50%;
  }
  .img-content .img-item img{
    width: 100%;
    height: 100%;
  }
  .previewImages{
    line-height: 10px;
  }
  .previewImages img{
    width: 32px;
    height: 32px;
    margin-right: 5px;
  }
</style>
<style>
  .el-popover {
    width: auto !important;
    max-width: 440px;
    min-width: 120px;
  }
</style>
<template>
  <div>
    <el-table :data="projectSplashDataList" stripe>
      <el-table-column prop="splashName" label="分辨率"></el-table-column>
      <el-table-column prop="orientationName" label="屏幕方向"></el-table-column>
      <el-table-column label="图片资源">
        <template scope="scope">
          <el-popover v-if="scope.row.picList.length>0"
                      placement="bottom"
                      title="预览图片"
                      width="200"
                      trigger="hover">
            <div class="img-content">
              <div class="img-item" v-for="(pItem,pIndex) in scope.row.picList">
                <div class="el-icon-close img-item-icon" @click="handleFileRemove(scope.$index,pIndex)"></div>
                <img :src="pItem.picUrl + '?o_O='+ new Date().getTime()">
              </div>
            </div>
            <div slot="reference" class="previewImages" :style="'width:'+scope.row.picList.length*40+'px'">
              <img v-for="(pItem,pIndex) in scope.row.picList" :src="pItem.picUrl + '?o_O='+ new Date().getTime()">
            </div>
            <!--<el-button slot="reference" type="text" class="table-option-button">预览</el-button>-->
          </el-popover>
          <span v-if="scope.row.picList.length<=0">----</span>
        </template>
      </el-table-column>
      <el-table-column
        label="操作" width="100">
        <template scope="scope">
          <el-upload
            v-if="fileConfig.platformType==1?scope.row.picList.length<1:scope.row.picList.length<4"
            class="upload-demo upload-demo-table"
            :action="proxyDevApi+'/uploadFile/' + fileUploadDirId + '/' + scope.row.splashId +','+ scope.row.orientationId + '/platform/' + fileConfig.platformType + '/pic/' + fileConfig.picType + '/V2'"
            :show-file-list="false"
            :multiple="true"
            :headers="headersFile"
            :before-upload="beforeAvatarUpload"
            :on-success="handleFileSuccess">
            <el-button type="text" @click="selectFileUpload(scope.$index)">上传</el-button>
          </el-upload>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {
    },
    props: ['fileConfig'],
    computed: {
      ...mapGetters([
        'headersFile', 'projectSplashDataList', 'deleteGamePicIds', 'fileUploadDirId', 'proxyDevApi'
      ])
    },
    data () {
      return {
        optionIndex: -1
      }
    },
    methods: {
      selectFileUpload ($index) {
        this.optionIndex = $index
      },
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegImg = /.(png|jpg|bmp|gif)/
        let iosRegImg = /.png/
        let isUpload = false
        if (this.fileConfig.platformType === 1) {
          isUpload = iosRegImg.test(fileType)
          if (!isUpload) {
            this.$alert('图片类型只能为png', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        } else {
          isUpload = androidRegImg.test(fileType)
          if (!isUpload) {
            this.$alert('图片类型只能为png|jpg|bmp|gif', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        }
        return isUpload
      },
      handleFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          this.$store.dispatch('updateProjectSplashPath', {index: this.optionIndex, fileData: response.data, platformType: this.fileConfig.platformType})
        } else {
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleFileRemove ($index, pIndex) {
//        let iPicId = this.projectSplashDataList[$index].iPicId
//        if (iPicId && this.deleteGamePicIds.indexOf(iPicId) < 0) {
//          // 判断为修改，先保存iPicId，在删除
//          this.$store.dispatch('deleteGamePicIds', iPicId)
//        } else {
//          this.$store.dispatch('deleteGameConfigImage', this.projectSplashDataList[$index].picId[pIndex])
//        }
//        this.$store.dispatch('deleteGameConfigImage', this.projectSplashDataList[$index].picId[pIndex])
        this.$store.dispatch('deleteProjectSplashPath', {index: $index, pIndex: pIndex})
      }
    }
  }
</script>
