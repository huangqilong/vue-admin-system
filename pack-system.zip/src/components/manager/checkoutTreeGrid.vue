<style scoped>
  .row-content .row-content .col-span-title {
    padding-left: 15px;
  }
  .row-content .col-span{
    color: #5a5e66;
    font-size: 14px;
    border-top: 1px solid #ccc;
    min-height: 43px;
  }
  .row-content .col-span .empty-label{
    margin-left: 15px;
    line-height: 39px;
  }
  .row-content .col-span .el-checkbox{
    line-height: 36px;
  }
  .row-content .col-span.col-span-title .el-checkbox{
    margin-left: 5px;
  }
  .row-content .col-span.col-span-list .el-checkbox{
    margin-left: 10px;
  }
  .row-content .col-span.col-span-list .el-checkbox+.el-checkbox{
    margin-left: 10px;
  }
  .row-content .col-span-title .el-checkbox{
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    width: 97%;
  }
  .row-content .col-span-list{
    border-left: 1px solid #ccc;
  }
  .row-content .col-span-list .el-checkbox{
    width: 150px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
</style>
<template>
  <div>
    <el-row class="row-content" v-for="(item,index) in dataList">
      <el-col class="col-span col-span-title" :span="colSpan[0]" :style="'padding-left:'+(treeCount*20)+'px;'">
        <el-checkbox :indeterminate="item.isIndeterminate" v-model="item.checkAll" @change="handleCheckAllChange($event, item, dataList)">{{item.cMenuName}}</el-checkbox>
      </el-col>
      <el-col class="col-span col-span-list" :span="colSpan[1]">
        <span v-if="!item.childrenNode || item.childrenNode.length<=0">&nbsp;</span>
        <el-checkbox-group v-if="item.childrenNode && item.childrenNode.length>0" v-model="item.childrenNodes" @change="handleCheckedChange($event, item, dataList)">
          <el-checkbox v-for="cItem in item.childrenNode" :label="cItem" :key="cItem.iMenuId">{{cItem.cMenuName}}</el-checkbox>
        </el-checkbox-group>
      </el-col>
      <checkout-tree-grid ref="treeGridMethod" :parentNode="item" :dataList="item.children" :treeNum="treeCount" :parentCallBack="parentHandleChange"
                          v-if="item.children && item.children.length>0"></checkout-tree-grid>
    </el-row>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default {
    name: 'checkoutTreeGrid',
    props: ['parentNode', 'dataList', 'treeNum', 'parentCallBack'],
    components: {
    },
    data () {
      return {
        colSpan: [6, 18],
        treeCount: 0
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    watch: {
    },
    created: function () {
      this.treeCount = this.treeNum + 1
    },
    methods: {
      childrenHandleChange (event, childrenNodeList) {
        for (let item of childrenNodeList) {
          this.initCheckBoxParams(item)
          item.checkAll = event
          item.isIndeterminate = false
          if (item.childrenNodes) {
            item.childrenNodes = event ? item.childrenNode : []
          }
          if (item.children && item.children.length > 0) {
            this.childrenHandleChange(event, item.children)
          }
        }
      },
      parentHandleChange (parentNode, dataList) {
        if (parentNode) {
          this.initCheckBoxParams(parentNode)
          let dcCount = 0
          let diCount = 0
          for (let dItem of parentNode.children) {
            if (dItem.checkAll) {
              dcCount++
            }
            if (dItem.isIndeterminate) {
              diCount++
            }
          }
          if (parentNode.childrenNodes) {
            let cNodesCount = 0
            if (parentNode.childrenNodes.length === parentNode.childrenNode.length) {
              cNodesCount = 1
            } else if (parentNode.childrenNodes.length > 0) {
              cNodesCount = -1
            }
            if (dcCount === parentNode.children.length && cNodesCount === 1) {
              parentNode.checkAll = true
              parentNode.isIndeterminate = false
            } else if (dcCount === 0 && diCount === 0 && cNodesCount === 0) {
              parentNode.checkAll = false
              parentNode.isIndeterminate = false
            } else {
              parentNode.checkAll = false
              parentNode.isIndeterminate = true
            }
          } else {
            if (dcCount === parentNode.children.length) {
              parentNode.checkAll = true
              parentNode.isIndeterminate = false
            } else if (dcCount === 0 && diCount === 0) {
              parentNode.checkAll = false
              parentNode.isIndeterminate = false
            } else {
              parentNode.checkAll = false
              parentNode.isIndeterminate = true
            }
          }
        }
        if (this.parentCallBack) {
          this.parentCallBack(this.parentNode, this.dataList)
        }
      },
      initCheckBoxParams (item) {
        if (typeof item.checkAll === 'undefined') {
          this.$set(item, 'checkAll', true)
        }
        if (typeof item.isIndeterminate === 'undefined') {
          this.$set(item, 'isIndeterminate', true)
        }
      },
      handleCheckAllChange (event, item, dataList) {
        this.initCheckBoxParams(item)
        item.isIndeterminate = false
        if (item.childrenNodes) {
          item.childrenNodes = item.checkAll ? item.childrenNode : []
        }
        if (item.children && item.children.length > 0) {
          this.childrenHandleChange(item.checkAll, item.children)
        }
        if (this.parentCallBack) {
          this.parentCallBack(this.parentNode, dataList)
        }
      },
      handleCheckedChange (event, item, dataList) {
        this.initCheckBoxParams(item)
        let checkedCount = event.length
        item.checkAll = checkedCount === item.childrenNode.length
        item.isIndeterminate = checkedCount > 0 && checkedCount < item.childrenNode.length
        if (this.parentCallBack) {
          this.parentCallBack(this.parentNode, dataList)
        }
      }
    }
  }
</script>
