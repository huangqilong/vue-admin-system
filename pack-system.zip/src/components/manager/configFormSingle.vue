<style scoped>
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <el-form :model="configSingleForm" ref="configSingleForm">
    <el-row v-if="0==configSingleForm.dataList.length">
      <el-col :span="5">&nbsp;</el-col>
      <el-col :span="14">
        <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('configSingleForm')">添&nbsp;&nbsp;加</el-button>
      </el-col>
      <el-col :span="5">&nbsp;</el-col>
    </el-row>
    <el-row v-for="(domain,index) in configSingleForm.dataList" :gutter="30">
      <el-col :span="5">&nbsp;</el-col>
      <el-col :span="11">
        <el-form-item
          :prop="'dataList.' + index + '.value'"
          :rules="{required: true, message: '数据不能为空', trigger: 'blur'}">
          <el-input size="small" v-model="domain.value" placeholder="urlscheme"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item>
          <el-button size="small" @click.prevent="removeItem(index)">删除</el-button>
          <el-button size="small" type="primary" @click.prevent="addItem('configSingleForm')" v-if="index==configSingleForm.dataList.length-1">添加</el-button>
        </el-form-item>
      </el-col>
      <el-col :span="2">&nbsp;</el-col>
    </el-row>
  </el-form>
</template>
<script>
export default{
  props: ['configSingleForm'],
  methods: {
    // 新增
    addItem (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.configSingleForm.dataList.push({
            value: ''
          })
        } else {
          return false
        }
      })
    },
    // 删除
    removeItem ($index) {
      if (this.configSingleForm.dataList[$index].id) {
        this.configSingleForm.dataIds.push(this.configSingleForm.dataList[$index].id)
      }
      this.configSingleForm.dataList.splice($index, 1)
    }
  }
}
</script>
