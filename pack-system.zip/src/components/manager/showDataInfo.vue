<style>
  .option-dialog-show-info .el-dialog{
    width: 600px;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogShowVisible"
             class="option-dialog option-dialog-show-info" :width="optionData.dialogWidth ? optionData.dialogWidth + 'px' : '500px'">
    <div class="dialog-table-content">
      <el-table :data="optionData.tableDataList" stripe>
        <el-table-column label="序号" type="index"></el-table-column>
        <el-table-column v-for="(hItem, hIndex) in optionData.tableHeader" :label="hItem.label" :prop="hItem.prop"></el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogShowVisible = false">关  闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    props: ['optionData'],
    data () {
      return {
        dataList: [
          {}
        ]
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {
    },
    methods: {}
  }
</script>
