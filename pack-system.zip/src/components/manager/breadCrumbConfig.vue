<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
  .top-crumb .nav-font{
    font-size: 16px;
  }
</style>
<template>
<div class="top-crumb">
  <el-breadcrumb separator=">>">
    <el-breadcrumb-item v-for="(item,index) in breadCrumbData" v-if="routerPathList" :to="{ path: routerPathList[index] }"><span class="nav-font">{{item+(index>0?routeType:'')}}</span></el-breadcrumb-item>
    <el-breadcrumb-item v-for="(item,index) in breadCrumbData" v-if="!routerPathList"><span class="nav-font">{{item}}</span>
      <el-popover v-if="$route.path=='/home/pack/rule/list'"
        placement="bottom"
        title=""
        width="300"
        trigger="hover">
        <div class="popover-content-pack-config">
          <b>功能说明：</b>
          <p>主要用于解决好玩友渠道不同游戏差异化需求</p>
          <b>举例说明：</b>
          <p>a、短信支付功能开启或关闭</p>
          <p>b、sdk个人中心手机绑定功能开启或关闭</p>
        </div>
        <span slot="reference" style="cursor: pointer;font-size: 18px;color: #ff0000;">?</span>
      </el-popover>
    </el-breadcrumb-item>
  </el-breadcrumb>
</div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    props: ['routerPathList'],
    components: {
    },
    data () {
      return {
        breadCrumbData: [],
        routeType: '',
        intervalTime: null
      }
    },
    computed: {
      ...mapGetters([
        'breadCrumbDataList'
      ])
    },
    created: function () {
      let routePath = ''
      if (this.$route.path.indexOf('/android') >= 0) {
        this.routeType = 'Android'
        routePath = this.$route.path.substring(0, this.$route.path.indexOf('android'))
      } else if (this.$route.path.indexOf('/ios') >= 0 && this.$route.path !== '/home/ioscert/list') {
        this.routeType = 'IOS'
        routePath = this.$route.path.substring(0, this.$route.path.indexOf('ios'))
      } else {
        this.routeType = ''
        routePath = this.$route.path
      }
      if (this.breadCrumbDataList) {
        this.breadCrumbData = this.breadCrumbDataList[routePath].split(',')
      } else {
        this.intervalTime = setInterval(() => {
          if (this.breadCrumbDataList) {
            this.breadCrumbData = this.breadCrumbDataList[routePath].split(',')
            clearInterval(this.intervalTime)
          }
        }, 1000)
      }
    },
    methods: {
    }
  }
</script>
