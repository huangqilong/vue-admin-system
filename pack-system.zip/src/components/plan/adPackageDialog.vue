<style>
  .option-dialog-pack-channel .el-dialog{
    width: 600px;
  }
  .option-dialog-pack-channel .el-select{
    width: 100%;
  }
  .option-dialog-pack-channel .tabs-content{
    padding-left: 10px;
  }
  .option-dialog-pack-channel .tabs-content .el-tabs__content {
    max-height: 300px;
    overflow-y: auto;
  }
  .option-dialog-pack-channel .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog-pack-channel.el-dialog__wrapper{
    overflow:hidden;
  }
  .option-dialog-pack-channel  .el-dialog__body{max-height:600px;overflow-Y:auto;}
</style>
<template>
  <el-dialog  :title="'广告包（' + optionConfigData.dialogCurrentTitle+ '）'"
             :visible.sync="optionConfigData.dialogFormVisible"
             class="option-dialog option-dialog-pack-channel">
    <div class="content-list">
      <el-table :data="dataInfoForm" stripe>
        <el-table-column type="index" label="序号" width="50"></el-table-column>
        <el-table-column prop="cAdcpsCode" label="广告码" ></el-table-column>
        <el-table-column prop="sDemo" label="备注" ></el-table-column>
        <el-table-column  label="广告插件" >
          <template scope="scope">
            {{scope.row.cAdPluginIds ? getPluginInfo(scope.row.cAdPluginIds, scope.row.cAdPluginConfigIds).join(',') : '--'}}
          </template>
        </el-table-column>
        <el-table-column prop="cStatus" label="状态" >
          <template scope="scope">
            <span v-html="getStatusCharacter(scope.row.cStatus)"></span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionConfigData.dialogFormVisible = false">关  闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planUtil from '../../utils/plan-util'
  import pluginApi from '../../apis/plugin-api'
  export default{
    components: {},
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {
        pluginList: []
      }
    },
    computed: {
      ...mapGetters([
        'planInfo'
      ])
    },
    created: function () {
      this.getPluginList()
    },
    methods: {
      getPluginList () {
        let _this = this
        let params = {
          platformId: this.planInfo.iPlatformId,
          languageId: this.planInfo.iLanguageId,
          areaId: this.planInfo.iAreaId
        }
        pluginApi.getPluginDataList(2, params).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      getPluginInfo (plugins, pluginConfigIds) {
        let spList = []
        for (let pItem of this.pluginList) {
          if (plugins.indexOf(pItem.iPluginId) >= 0) {
            for (let spItem of pItem.pluginVersionList) {
              if (pluginConfigIds.indexOf(spItem.iPluginConfigId) >= 0) {
                pItem.iPluginConfigId = spItem.iPluginConfigId
                spList.push(pItem.pluginName + '--' + spItem.pluginVersion)
              }
            }
          }
        }
        return spList
      },
      getStatusCharacter (status) {
        return planUtil.getPlanStatus(status, 3)
      }
    }
  }
</script>
