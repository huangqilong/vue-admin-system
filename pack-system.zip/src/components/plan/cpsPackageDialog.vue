<style>
  .option-dialog-pack .el-dialog{
    width: 600px;
  }
  .option-dialog-pack-cps .el-select{
    width: 100%;
  }
  .option-dialog-pack-cps .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog-pack-cps.el-dialog__wrapper{
    overflow:hidden;
  }
  .option-dialog-pack-cps  .el-dialog__body{max-height:600px;overflow-Y:auto;}
</style>
<template>
  <el-dialog :title="'cps包（' + optionConfigData.dialogCurrentTitle+ '）'"
             :visible.sync="optionConfigData.dialogFormVisible"
             class="option-dialog option-dialog-pack option-dialog-pack-cps">
    <div class="content-list">
      <el-table :data="dataInfoForm" stripe>
        <el-table-column type="index" label="序号" width="50"></el-table-column>
        <el-table-column prop="cAdcpsCode" label="广告码" ></el-table-column>
        <el-table-column prop="sDemo" label="备注" ></el-table-column>
        <el-table-column prop="cStatus" label="状态" >
          <template scope="scope">
            <span v-html="getStatusCharacter(scope.row.cStatus)"></span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionConfigData.dialogFormVisible = false">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planUtil from '../../utils/plan-util'
  export default{
    components: {},
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {}
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {},
    methods: {
      getStatusCharacter (status) {
        return planUtil.getPlanStatus(status, 4)
      }
    }
  }
</script>
