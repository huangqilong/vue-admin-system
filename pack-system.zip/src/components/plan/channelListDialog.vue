<style>
  .option-dialog-relevance .el-dialog{
    width: 600px;
  }
</style>
<style scoped>
  .option-dialog-relevance .plugin-item{
    padding-left: 10px;
    padding-right: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 5px;
    line-height: 12px;
  }
  .option-dialog-relevance .plugin-item .plugin-item-checkbox{
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }
</style>
<template>
  <el-dialog title="选择打包渠道" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-relevance">
    <div style="margin: 0 0 15px 0;">
      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
      <el-checkbox-group v-model="selectChannelList" @change="handleCheckedChange" style="margin-top: 5px">
        <el-row :gutter="10">
          <el-col :span="8" v-for="item in channelList" class="plugin-item">
            <el-checkbox :label="item" :key="item.iChannelId" class="plugin-item-checkbox">
              <span v-if="item.channelName.replace(/[\u0391-\uFFE5]/g,'aa').length<=21">{{item.channelName}}</span>
              <el-tooltip :content="item.channelName" placement="bottom" effect="light" v-if="item.channelName.replace(/[\u0391-\uFFE5]/g,'aa').length>21">
                <span>{{item.channelName}}</span>
              </el-tooltip>
            </el-checkbox>
          </el-col>
        </el-row>
      </el-checkbox-group>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import channelApi from '../../apis/channel-api'
  export default{
    components: {},
    props: ['optionData', 'dataInfoForm', 'optionCallBack', 'packChannelIdsList'],
    data () {
      return {
        selectChannelList: [],
        checkAll: true,
        isIndeterminate: true,
        channelList: []
      }
    },
    created () {
      // 获取渠道列表
      this.getChannelList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      getChannelList () {
        let _this = this
        channelApi.getAllDataList(this.dataInfoForm.iAreaId, this.dataInfoForm.iPlatformId, this.dataInfoForm.iLanguageId).then((data) => {
          if (data.code === 1) {
            _this.channelList = data.data
            for (let item of _this.channelList) {
              if (_this.packChannelIdsList.indexOf(item.iChannelId) >= 0) {
                _this.selectChannelList.push(item)
              }
            }
            _this.handleCheckedChange(_this.selectChannelList)
          }
        }, (error) => {
          console.log(error)
          _this.channelList = null
        })
      },
      handleCheckAllChange (event) {
        this.selectChannelList = event ? this.channelList : []
        this.isIndeterminate = false
      },
      handleCheckedChange (value) {
        let checkedCount = value.length
        this.checkAll = checkedCount === this.channelList.length
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.channelList.length
      },
      submitForm () {
        this.optionData.dialogVisible = false
        this.optionCallBack(this.selectChannelList)
      }
    }
  }

</script>
