<style>
  .option-dialog-channel-pass .el-dialog{
    width: 600px;
  }
  .option-dialog-channel-pass .el-form-item__label{
    width:100%;
    text-align:left;
  }


</style>
<template>
  <el-dialog  :title="'录入渠道地址（' + optionData.dialogCurrentTitle+ '）'"
              :visible.sync="optionData.dialogFormVisible"
              class="option-dialog option-dialog-channel-pass">
    <div class="content-list">
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules">
        <el-form-item prop="url" label="渠道下载地址">
          <el-input type="textarea" v-model="dataInfoForm.url" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary"  @click="submitData('dataInfoForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
          url: [
            {required: true, message: '请输入渠道下载地址', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {},
    methods: {
      submitData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.dialogFlag === 'channel') {
              const params = {
                channelIds: '',
                iPlanChannelId: 0,
                sDesc: this.dataInfoForm.url
              }
              //  整包渠道通过
              planApi.channelPass(_this.dataInfoForm.iPlanChannelId, params, _this.optionData.currentStatus).then((data) => {
                if (data.code === 1) {
                  this.optionCallBack()
                  this.optionData.dialogFormVisible = false
                } else {
                  _this.$alert(data.msg, '操作失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                _this.$alert('请求失败，请稍后重试！', '提示', {
                  confirmButtonText: '确定'
                })
              })
            } else {
              const params = {
                iPlanAdId: _this.dataInfoForm.iPlanAdId,
                adAppUrl: this.dataInfoForm.url
              }
            //   广告包、cps包渠道通过
              planApi.addAdChannelPassUrl(params).then((data) => {
                if (data.code === 1) {
                  this.optionCallBack()
                  this.optionData.dialogFormVisible = false
                } else {
                  _this.$alert(data.msg, '操作失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                _this.$alert('请求失败，请稍后重试！', '提示', {
                  confirmButtonText: '确定'
                })
              })
            }
          }
        })
      }
    }
  }
</script>
