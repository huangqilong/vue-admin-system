<style>
  .option-dialog-pack-config .el-dialog{
    width: 900px;
  }
  .option-dialog-pack-config .el-form .el-row .el-col, .popover-content-pack-config .el-row .el-col {
    line-height: 25px;
    overflow: hidden;
    text-overflow: ellipsis;
    height: 36px;
  }
  .img-content{
  }
  .img-content .img-item{
    width: 100px;
    height: 100px;
    margin: 0 auto;
    position: relative;
  }
  .img-content .img-item .img-item-icon{
    position: absolute;
    right: 2px;
    top: 2px;
    cursor: pointer;
  }
  .img-content .img-item img{
    width: 100%;
    height: 100%;
  }
  .option-dialog-plan-config.el-dialog__wrapper{
    overflow:hidden;
  }
  .option-dialog-plan-config  .detail-form-content{padding-right: 5px; height:600px;overflow-Y:auto;}
  .option-dialog-plan-config .detail-form-content .el-form-item__label {
    font-size: 15px;
    font-weight: bold;
  }
</style>
<style scoped>
  .row-col{
    border: 1px solid #dfe6ec;
    padding: 5px 5px 5px 10px;
  }
  .label-title{
    background-color: #eef1f6;
    text-align: right;
  }
  .multi-row-div{
    width:859px;
    border:1px solid #dfe6ec;
    background-color:#eef1f6
  }
  .multi-row-span-title{
    display:block;
    border-right:1px solid #dfe6ec;
    width: 214px;
    text-align:right;
    padding:0 10px;
    box-sizing:border-box;
    float:left;
  }
  .multi-row-div-content{
    display:inline-block;
    width:644px;
    padding:0 10px;
    border-left:1px solid #dfe6ec;
    box-sizing:border-box;
    background-color:#fff;
  }
  .multi-row-span-list{
    display:inline-block;
    width:100%;
  }
</style>
<template>
  <el-dialog :title="'查看配置（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pack-config option-dialog-plan-config">
    <el-form :model="dataInfoForm" label-position="top" class="detail-form-content">
      <el-form-item label="游戏配置：">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">游戏名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.gameName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">资源类型：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">工程code：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.projectCode || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">代理类型：</el-col>
          <el-col :span="colSpans[3]" class="row-col">
            {{gameInfo.cAssertType==gameTypeList[0].iDicId?gameTypeList[0].sDicName:(gameInfo.cAssertType==gameTypeList[1].iDicId?gameTypeList[1].sDicName:gameTypeList[2].sDicName)}}
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">服务器版本号：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.serverVersion || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">资源key：</el-col>
          <el-tooltip class="item" effect="dark" :content="gameInfo.appKey || '--'" placement="top">
            <el-col :span="colSpans[3]" class="row-col">
              <span>{{gameInfo.appKey || '--'}}</span>
            </el-col>
          </el-tooltip>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">额外拼接：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.extraSign || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">&nbsp;</el-col>
          <el-col :span="colSpans[3]" class="row-col">&nbsp;</el-col>
        </el-row>
        <!--<el-row>-->
          <!--<el-col :span="colSpans[0]" class="row-col label-title">资源名称：</el-col>-->
          <!--<el-col :span="colSpans[1]" class="row-col">{{gameInfo.assetsName || '&#45;&#45;'}}</el-col>-->
          <!--<el-col :span="colSpans[2]" class="row-col label-title">额外拼接：</el-col>-->
          <!--<el-col :span="colSpans[3]" class="row-col">{{gameInfo.extraSign || '&#45;&#45;'}}</el-col>-->
        <!--</el-row>-->
      </el-form-item>
      <el-form-item label="渠道公共配置：" v-if="gameInfo.androidChannelConfig">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">最小系统版本：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.minSdkVersion || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">指定系统版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.targetSdkVersion || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">渠道版本值：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.channelVersionValue || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">版本额外字段：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.channelVersionExtra || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">maven的名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.mavenChannelName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">maven的group：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.mavenChannelGroup || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">applicationName：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.applicationName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">特殊处理的渠道配置ID：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.specChannelConfig || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否分包：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.cDex==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否需要生成微信jar：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.cWxjar==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否需要填写metadata：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.cMetadata==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">渠道自定义参数：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.metaData || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否需要特殊处理：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.cSpeHand==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">特殊处理路径：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.spePath || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">特殊处理文件名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.speFileName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">特殊处理文件内容：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidChannelConfig.speContent || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">客户端是否请求接口初始化接口：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidChannelConfig.cRequestParams==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">&nbsp;</el-col>
          <el-col :span="colSpans[3]" class="row-col">&nbsp;</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="游戏渠道配置：" v-if="gameInfo.androidProjectChannelVO">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">渠道名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.channelName || gameInfo.iChannelName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">渠道版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.channelVersion || gameInfo.iChannelConfigName || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">代理版本：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.cMiddleareVersion || gameInfo.cMiddleareVersion || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">版本号：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.versionCode || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">maven的名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.mavenChannelName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">maven的group：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.mavenChannelGroup || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">版本名字：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.versionName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">渠道包名：</el-col>
          <el-tooltip class="item" effect="dark" :content="gameInfo.androidProjectChannelVO.packageName || '--'" placement="top">
            <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.packageName || '--'}}</el-col>
          </el-tooltip>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">签名文件：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.keystorePath || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">签名密码：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.keyPassword || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">渠道额外资源：</el-col>
          <el-tooltip class="item" effect="dark" :content="gameInfo.androidProjectChannelVO.extraResPath || '--'" placement="top">
            <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.extraResPath || '--'}}</el-col>
          </el-tooltip>
          <el-col :span="colSpans[2]" class="row-col label-title">最小sdk版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.minVersion || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否使用obb：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{!!gameInfo.androidProjectChannelVO.crcValue?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">指定sdk版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.targetVersion || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">crc值：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.crcValue || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">谷歌密钥：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.publicKey || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否分包：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.androidProjectChannelVO.cDex==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">游戏比例：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.iRate || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否要填写metadata：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{!!gameInfo.androidProjectChannelVO.cMetadata?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">metadata值：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.androidProjectChannelVO.cMetadata || '--'}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="游戏渠道配置：" v-if="gameInfo.iOSProjectChannelVO">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">包名：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iOSProjectChannelVO.bundleId || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">最小版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iOSProjectChannelVO.minIosVersionName || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">代理版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iOSProjectChannelVO.projectChannelProxyName || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">构建版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iOSProjectChannelVO.buildVersion || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">项目名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iOSProjectChannelVO.cProjectName || '--'}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="插件信息：">
        <el-table :data="pluginsList" border>
          <el-table-column prop="pluginType" label="插件类型"></el-table-column>
          <el-table-column prop="pluginName" label="插件名称"></el-table-column>
          <el-table-column prop="channelVersion" label="插件版本"></el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="安装包信息：" v-if="packInfoJson">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">{{packInfoJson.name1}}：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{packInfoJson.value1|| '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">{{packInfoJson.name2}}：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">
            <el-tooltip placement="top" v-if="packInfoJson.value2">
              <div slot="content" style="max-height:300px;width:500px;overflow-Y:auto;">
                <p  v-for="item in packInfoJson.value2Split">{{item}}</p>
              </div>
              <span>{{packInfoJson.value2 ? packInfoJson.value2.split('&&')[0] + '......' : ''}}</span>
            </el-tooltip>
          </el-col>
        </el-row>
        <div class="multi-row-div">
          <span  class="label-title multi-row-span-title">{{packInfoJson.name3}}：</span>
          <div class="multi-row-div-content" >
            <template v-for="item in packInfoJson.value3">
              <span class="multi-row-span-list" >
                {{item}}
              </span>
            </template>
          </div>
        </div>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">{{packInfoJson.name4}}：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{packInfoJson.value4|| '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">{{packInfoJson.name5}}：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{packInfoJson.value5|| '--'}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="IOS证书配置：" v-if="platformType=='IOS'">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">游戏平台：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.platformName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">签名方式：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{iOSCertConfigInfo.cCertType==signatureTypeList[0].iDicId?signatureTypeList[0].sDicName:signatureTypeList[1].sDicName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">证书名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{iOSCertConfigInfo.cCertName || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">安装密码：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{iOSCertConfigInfo.cCertPwd || '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">证书文件：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{iOSCertConfigInfo.cCertPath || '--'}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="权限配置："  v-if="platformType=='IOS' && gameInfo.iosPermissionSetting && gameInfo.iosPermissionSetting.iosPermissions">
        <el-table :data="gameInfo.iosPermissionSetting.iosPermissions || []" border>
          <el-table-column prop="permissionName" label="权限名称"></el-table-column>
          <el-table-column prop="sDesc" label="权限描述"></el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="分享开关：">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">分享列表：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{(dataInfoForm && dataInfoForm.shareInfo) ? dataInfoForm.shareInfo.replace(',',' ') : '--'}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="bugly配置：" v-if="false">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">bugly ID：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.buglyId|| '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">bugly Key：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col" >{{gameInfo.buglyKey|| '--'}}</el-col>
        </el-row>
      </el-form-item>
      <!--<el-form-item label="代理信息：" v-if="platformType=='IOS'">-->
        <!--<el-row>-->
          <!--<el-col :span="colSpans[0]" class="row-col label-title">平台：</el-col>-->
          <!--<el-col :span="colSpans[1]" class="row-col">{{gameInfo.platformName || '&#45;&#45;'}}</el-col>-->
          <!--<el-col :span="colSpans[2]" class="row-col label-title">版本：</el-col>-->
          <!--<el-col :span="colSpans[3]" class="row-col">{{gameInfo.cMiddleareVersion || '&#45;&#45;'}}</el-col>-->
        <!--</el-row>-->
      <!--</el-form-item>-->
      <el-form-item label="打包配置：">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">配置名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.gameConfigName|| '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">引擎版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.iEngineName|| '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否更新：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUpdate==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">屏幕拉伸策略：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.iScreenstretchName|| '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否使用plist：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUsePlist==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否使用plistbin：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUsePlistBin==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否启用崩溃日志：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseCrash==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否使用内网：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseLan==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否使用后台运行：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseBackgroundRun==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否使用调试：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseDebug==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否多点触控：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseMutiTouch==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">状态栏：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.iStatusbarName|| '--'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">屏幕方向：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.iScreenDirectionName|| '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">自定义返回键：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseCustomBack==1?'使用':'不使用'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">自动锁屏：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseAutoLock==1?'使用':'不使用'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否启用离线模式：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseOffline==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">打包机版本：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.sVersion || '--'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">&nbsp;</el-col>
          <el-col :span="colSpans[3]" class="row-col">&nbsp;</el-col>
        </el-row>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关  闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packToolApi from '../../apis/pack-tool-api'
  import channelApi from '../../apis/channel-api'

  export default{
    props: ['optionData'],
    data () {
      return {
        platformType: 'IOS',
        tabValue: 'first',
        colSpans: [6, 6, 6, 6],
        colSpansSecond: [6, 18],
        dataInfoForm: null,
        gameInfo: {
          areaName: ''
        },
        pluginsList: [],
        gameConfigInfo: {
          gameConfigName: ''
        },
        gameProjectChannelInfo: null,
        packInfoJson: null,
        channelConfigInfo: {
          minSdkVersion: ''
        },
        iOSCertConfigInfo: {
          cCertType: 1
        },
        // 白名单列表
        whiteListForm: [],
        // Url映射列表
        urlMapListForm: [],
        // info额外配置列表
        infoConfigForm: [],
        // entitments配置列表
        entitmentsConfigForm: []
      }
    },
    computed: {
      ...mapGetters([
        'platformList', 'gameAssetsTypeList', 'gameTypeList', 'planChannelInfo', 'projectSplashDataList', 'projectIconDataList', 'signatureTypeList', 'planInfo'
      ])
    },
    created: function () {
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let pType = this.planInfo.iPlatformName === '安卓' ? 0 : 1
        this.platformType = this.planInfo.iPlatformName
        packToolApi.getPackGameConfigDataInfo(pType, this.planChannelInfo.iGamePackId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.gameInfo = this.platformType === 'IOS' ? data.data.iosSettingVO : data.data.androidSettingVO
            this.pluginsList = JSON.parse(JSON.stringify(this.gameInfo.pluginsList))
            this.gameConfigInfo = this.platformType === 'IOS' ? this.gameInfo.gameConfigVO : this.gameInfo.gameConfig
            /*
            if (this.platformType === '安卓' && this.gameInfo.iChannelConfigId) {
              this.configDataInfo(this.gameInfo.iChannelConfigId)
            } */
            if (this.platformType === 'IOS') {
//              this.gameProjectChannelInfo = this.gameInfo.iOSProjectChannelVO
              this.iOSCertConfigInfo = this.gameInfo.iOSCertConfig
              /*
              for (const dItem of this.gameProjectChannelInfo.iosWhiteVOList) {
                this.whiteListForm.push({
                  id: dItem.iWhitelistId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value: dItem.cQueriesScheme
                })
              }
              for (const dItem of this.gameProjectChannelInfo.iosUrlSchemeVOList) {
                this.urlMapListForm.push({
                  id: dItem.iUrlSchemeId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value1: dItem.urlSchemeName,
                  value2: dItem.urlSchemeIdentifer
                })
              }
              for (const dItem of this.gameProjectChannelInfo.iosPlistVOList) {
                this.infoConfigForm.push({
                  id: dItem.iPlistId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value2: dItem.infoValue,
                  value1: dItem.infoKey
                })
              }
              for (const dItem of this.gameProjectChannelInfo.entitlementsVOList) {
                this.entitmentsConfigForm.push({
                  id: dItem.iEntitlementsId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value2: dItem.entitlementsValue,
                  value1: dItem.entitlementsKey
                })
              }
              this.$store.dispatch('updateProjectIconDataList', this.gameProjectChannelInfo.iconList)
              this.$store.dispatch('updateProjectSplashDataList', this.gameProjectChannelInfo.splashList) */
            }
            // 安装包信息
            if (data.data.packInfoJson) {
              this.packInfoJson = JSON.parse(data.data.packInfoJson)
              this.packInfoJson.value3 = this.packInfoJson.value3.split('&&')
              this.packInfoJson.value2Split = this.packInfoJson.value2.split('&&')
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
          this.$alert('请求失败，请重新操作', '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 配置数据
      configDataInfo (iChannelConfigId) {
        channelApi.getVersionDataInfo(this.platformType, iChannelConfigId).then((data) => {
          if (data.code === 1) {
            this.channelConfigInfo = data.data
          }
        }, (error) => {
          console.log(error)
        })
      }
    }
  }
</script>
