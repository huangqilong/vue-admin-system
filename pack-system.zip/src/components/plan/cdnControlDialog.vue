<style>
  .option-dialog-cdn-control .el-dialog{
    width: 400px;
  }
  .option-dialog-cdn-control .el-form-item__label{
    width:100%;
    text-align:left;
  }


</style>
<template>
  <el-dialog  :title="optionData.title"
              :visible.sync="optionData.dialogVisible"
              class="option-dialog option-dialog-cdn-control">
    <div class="content-list">
      <el-row>
        <el-col :span="24">
          <el-radio-group v-model="optionData.cdnFlag">
            <el-radio class="radio" :label="1">开启自动上传CDN</el-radio>
            <el-radio class="radio" :label="0" :disabled="oldCdnFlag">关闭自动上传CDN</el-radio>
            <!--<el-radio class="radio" :label="0">关闭自动上传CDN</el-radio>-->
          </el-radio-group>
        </el-col>
      </el-row>
      <el-row style="margin-top: 15px;">
        <el-col :span="24">
          <span style="color: red;">提示：请确保广告码包质检通过且不会再次打包后开启该功能，开启该功能后，如果广告码包多次刷CDN链接，可能会发生用户使用到旧的CDN地址！每次只能处理一个包，每个包持续时间大概5分钟！</span>
        </el-col>
      </el-row>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogVisible = false">取消</el-button>
      <el-button size="small" type="primary"  @click="submitData()" :disabled="oldCdnFlag">确 定</el-button>
      <!--<el-button size="small" type="primary"  @click="submitData()">确 定</el-button>-->
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {
    },
    props: ['optionData', 'optionCallBack', 'optionSelectTabCallBack'],
    data () {
      return {
        oldCdnFlag: false
      }
    },
    computed: {
      ...mapGetters([
        'planProgressSelectedTab'
      ])
    },
    created: function () {
      this.oldCdnFlag = this.optionData.cdnFlag === 0 ? false : true
    },
    methods: {
      submitData () {
        planApi.putCdnOpenControlOption(this.$route.query.iPlanId, this.optionData.cdnFlag).then((data) => {
          if (data.code === 1) {
            this.optionData.dialogVisible = false
            if (this.planProgressSelectedTab !== '1') {
              this.optionSelectTabCallBack({name: '1'})
            }
            this.optionCallBack()
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
