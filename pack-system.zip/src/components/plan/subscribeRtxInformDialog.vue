<style>
  .option-dialog-rtx-inform .el-dialog{
    width: 900px;
  }
</style>
<style scoped>
  .config-content {
    border-left: 1px solid #ccc;
    border-top: 1px solid #ccc;
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    margin-top: 0px;
    border-radius: 5px;
  }
  .config-content .row-content .row-content .col-span-title {
    padding-left: 15px;
  }
  .config-content .row-content .col-span{
    color: #5a5e66;
    font-size: 14px;
    border-top: 0.5px solid #ccc;
    min-height: 44px;
  }
  .config-content .row-content .col-span .empty-label{
    margin-left: 15px;
    line-height: 39px;
  }
  .config-content .row-content .col-span .el-checkbox{
    margin-left: 15px;
    line-height: 36px;
  }
  .config-content .row-content .col-span .el-checkbox+.el-checkbox{
    margin-left: 15px;
  }
  .config-content .row-content .col-span-title .el-checkbox{
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    width: 97%;
  }
  .config-content .row-content .col-span-list{
    border-left: 1px solid #ccc;
  }
  .config-content .row-content .col-span-list .el-checkbox{
    width: 150px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
</style>
<template>
  <el-dialog title="计划消息定制" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-rtx-inform">
    <div class="config-content">
      <el-row class="row-content">
        <el-col class="col-span col-span-title" :span="colSpan[0]">
          <el-checkbox :indeterminate="dataList.isIndeterminate" v-model="dataList.checkAll" @change="handleCheckAllChangeFirst($event, dataList)">选择全部</el-checkbox>
        </el-col>
        <el-col class="col-span col-span-list" :span="colSpan[1]">
          <span class="empty-label">&nbsp;</span>
        </el-col>
        <el-row class="row-content" v-for="item in dataList.children">
          <el-col class="col-span col-span-title" :span="colSpan[0]" :style="'padding-left:'+(15*2)+'px;'">
            <el-checkbox :indeterminate="item.isIndeterminate" v-model="item.checkAll" @change="handleCheckAllChangeThird($event, item, dataList)">{{item.titleName}}</el-checkbox>
          </el-col>
          <el-col class="col-span col-span-list" :span="colSpan[1]">
            <el-checkbox-group v-model="item.checkedChildren" @change="handleCheckedChange($event, item, dataList)">
              <el-checkbox v-for="cItem in item.children" :label="cItem.sDicValue" :key="cItem.iDicId">{{cItem.sDicName}}</el-checkbox>
            </el-checkbox-group>
          </el-col>
        </el-row>
      </el-row>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import userRoleApi from '../../apis/user-role-api'
  export default{
    components: {},
    props: ['optionData'],
    data () {
      return {
        colSpan: [5, 19],
        dataList: {}
      }
    },
    created () {
      this.getRoleRtxInformDataList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      getRoleRtxInformDataList () {
        // 获取菜单列表
        userRoleApi.getSubcribeRtxInformDataList(this.optionData.subcribeId).then((data) => {
          if (data.code === 1) {
            let gameDicts = data.data.gameDicts
            let channelDicts = data.data.channelDicts
            let packageDicts = data.data.packageDicts
            let gameIds = data.data.gameIds || []
            let channelIds = data.data.channelIds || []
            let packageIds = data.data.packageIds || []
//            let adIds = data.data.adIds || []
//            let cpsIds = data.data.cpsIds || []
            this.dataList = {
              id: data.data.id || '',
              children: [
                {
                  titleName: '母包消息',
                  checkAll: false,
                  checkedChildren: gameIds,
                  children: gameDicts
                },
                {
                  titleName: '渠道消息',
                  checkAll: false,
                  checkedChildren: channelIds,
                  children: channelDicts
                },
                {
                  titleName: '整包消息',
                  checkAll: false,
                  checkedChildren: packageIds,
                  children: packageDicts
                }
//                ,
//                {
//                  titleName: '广告包消息',
//                  checkAll: false,
//                  checkedChildren: adIds,
//                  children: packageDicts
//                },
//                {
//                  titleName: 'cps包消息',
//                  checkAll: false,
//                  checkedChildren: cpsIds,
//                  children: packageDicts
//                }
              ]
            }
            for (let item of this.dataList.children) {
              this.handleCheckedChange(null, item, this.dataList)
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      initCheckBoxParams (item, dataList) {
        if (item) {
          if (typeof item.checkAll === 'undefined') {
            this.$set(item, 'checkAll', true)
          }
          if (typeof item.isIndeterminate === 'undefined') {
            this.$set(item, 'isIndeterminate', true)
          }
        }
        if (dataList) {
          if (typeof dataList.checkAll === 'undefined') {
            this.$set(dataList, 'checkAll', true)
          }
          if (typeof dataList.isIndeterminate === 'undefined') {
            this.$set(dataList, 'isIndeterminate', true)
          }
        }
      },
      checkBoxAllOption (item, dataList) {
        if (dataList) {
          let dcCount = 0
          let diCount = 0
          for (let dItem of dataList.children) {
            if (dItem.checkAll) {
              dcCount++
            }
            if (dItem.isIndeterminate) {
              diCount++
            }
          }
          if (dcCount === dataList.children.length) {
            dataList.checkAll = true
            dataList.isIndeterminate = false
          } else if (dcCount === 0 && diCount === 0) {
            dataList.checkAll = false
            dataList.isIndeterminate = false
          } else {
            dataList.checkAll = false
            dataList.isIndeterminate = true
          }
        }
      },
      handleCheckAllChangeFirst (event, dataList) {
        this.initCheckBoxParams(null, dataList)
        dataList.isIndeterminate = false
        for (let item of dataList.children) {
          this.initCheckBoxParams(item, null)
          let arr = []
          for (let cItem of item.children) {
            arr.push(cItem.sDicValue)
          }
          item.checkAll = dataList.checkAll
          item.isIndeterminate = false
          item.checkedChildren = dataList.checkAll ? arr : []
        }
      },
      handleCheckAllChangeThird (event, item, dataList) {
        this.initCheckBoxParams(item, dataList)
        let arr = []
        for (let cItem of item.children) {
          arr.push(cItem.sDicValue)
        }
        item.checkedChildren = item.checkAll ? arr : []
        item.isIndeterminate = false

        this.checkBoxAllOption(null, dataList)
      },
      handleCheckedChange (event, item, dataList) {
        this.initCheckBoxParams(item, dataList)
        let checkedCount = event ? event.length : item.checkedChildren.length
        item.checkAll = checkedCount === item.children.length
        item.isIndeterminate = checkedCount > 0 && checkedCount < item.children.length
        this.checkBoxAllOption(null, dataList)
      },
      submitForm () {
        const params = {
          subcribeId: this.optionData.subcribeId,
          gameIds: this.dataList.children[0].checkedChildren,
          channelIds: this.dataList.children[1].checkedChildren,
          packageIds: this.dataList.children[2].checkedChildren,
          adIds: [],
          cpsIds: []
//          adIds: this.dataList.children[3].checkedChildren,
//          cpsIds: this.dataList.children[4].checkedChildren
        }
        userRoleApi.putRoleRtxInformData(params).then((data) => {
          if (data.code === 1) {
            this.optionData.dialogVisible = false
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
        })
      }
    }
  }

</script>
