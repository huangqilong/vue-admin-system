<style>
  .option-dialog-anew-upload .el-dialog{
    width: 600px;
  }
  .option-dialog-anew-upload .el-form-item__label{
    width:100%;
    text-align:left;
  }
  .option-dialog-anew-upload .el-checkbox-group .el-checkbox{
    /*width:25%;*/
    margin-right:5px;
    margin-left:0;
  }
  .tip-wraning-message-item{
    color:#c29068;
    font-size:13px;
    font-weight:200;
    margin-bottom:5px;
  }
  .tip-wraning-message-item .el-icon-warning{
    margin-right:5px;
  }
</style>
<style scoped>
  /*.agaginUploadDialog */
</style>
<template>
  <el-dialog :title="'选择渠道（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-anew-upload">
    <div class="content-list agaginUploadDialog">
      <el-row class="tip-wraning-message-item">
        <el-col><i class="el-icon-warning"></i><span>提示：选择的渠道将使用新的母包打渠道整包！</span></el-col>
      </el-row>
      <el-form  :model="dataInfoForm" ref="dataInfoForm"  >
        <el-form-item label="选择渠道:" prop="channelArrayIds" v-if="channelDataList.length>0">
          <el-row>
          <el-col :span="24"><el-checkbox label="全选" v-model="checkedAll" @change="checkAllChange"></el-checkbox></el-col>
          <el-checkbox-group v-model="dataInfoForm.channelArrayIds">
          <template v-for="(item,index) in channelDataList">
          <el-col :span="6"><el-checkbox :label="item.iChannelId" @change="checkOneChange($event,item)">{{item.channelName}}</el-checkbox></el-col>
          </template>
          </el-checkbox-group>
          </el-row>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary" @click="submitFormData('dataInfoForm')" >确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
//          channelArrayIds: [
//            { type: 'array', required: true, message: '请至少选择一个渠道', trigger: 'change' }
//          ]
        },
        checkedAll: false,
        channelDataList: []
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planChannelInfo'
      ])
    },
    created: function () {
      // 获取ChannelList
      this.getChannelList()
    },
    methods: {
      getChannelList () {
        const _this = this
        planApi.getPackChannelDataList(this.planInfo.iPlanId).then((data) => {
          if (data.code === 1) {
            this.channelDataList = data.data
          } else {
            _this.$alert(data.msg, '提示', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      checkAllChange (event) {
        const _this = this
        if (event) {
          for (let i in _this.channelDataList) {
            this.dataInfoForm.channelArrayIds.push(_this.channelDataList[i].iChannelId)
          }
        } else {
          this.dataInfoForm.channelArrayIds = []
        }
      },
      // 单个选中
      checkOneChange (event, item) {
        const _this = this
        if (_this.channelDataList.length === _this.dataInfoForm.channelArrayIds.length) {
          _this.checkedAll = true
        } else {
          _this.checkedAll = false
        }
      },
      submitFormData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let submitData = JSON.parse(JSON.stringify(this.dataInfoForm))
            submitData.channelIds = submitData.channelArrayIds.join(',')
            delete submitData.channelArrayIds
            planApi.againChooseChannel(this.optionData.currentStatus, submitData).then((data) => {
              if (data.code === 1) {
                _this.optionCallBack()
                this.optionData.dialogFormVisible = false
              } else {
                _this.$alert(data.msg, '操作失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert('请求失败，请稍后重试！', '提示', {
                confirmButtonText: '确定'
              })
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
