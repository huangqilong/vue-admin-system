<style>
  .option-dialog-pack-channel-0 .el-dialog{
    width: 1000px;
  }
  .option-dialog-pack-channel-0 .el-select{
    width: 100%;
  }
  .option-dialog-pack-channel-0 .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog-pack-channel-0.el-dialog__wrapper{
    overflow:hidden;
  }
  .option-dialog-pack-channel-0  .el-dialog__body{max-height:600px;overflow-Y:auto;}
</style>
<template>
  <el-dialog :title="optionData.type+'次数（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pack-channel-0">
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="update" label="操作时间" width="160"></el-table-column>
        <el-table-column prop="cRealName" label="操作人" width="80"></el-table-column>
        <el-table-column prop="sDesc" label="操作类型" width="100">
          <template scope="scope">
            <span :style="scope.row.sDesc.split('::')[0].indexOf('驳回')>=0?'color:#ef5350;':''">{{scope.row.sDesc.split('::')[0]}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="problemType" label="问题归属" width="100">
          <template scope="scope">
            {{scope.row.problemType ? scope.row.problemType : '--'}}
          </template>
        </el-table-column>
        <!--<el-table-column label="说明"  width="90">-->
          <!--<template scope="scope">-->
            <!--{{scope.row.sDesc.split('::')[1]}}-->
          <!--</template>-->
        <!--</el-table-column>-->
        <!--<el-table-column label="类型" v-if="optionData.type=='驳回'" width="90">-->
          <!--<template scope="scope">-->
            <!--{{scope.row.sDesc.split('::')[0]}}-->
          <!--</template>-->
        <!--</el-table-column>-->
        <!--<el-table-column prop="sDesc" label="说明" v-if="optionData.type=='驳回'">-->
          <!--<template scope="scope">-->
            <!--<div style="text-align: left;" v-for="item in scope.row.sDesc.split('::')[1].split('\n')">{{item}}</div>-->
          <!--</template>-->
        <!--</el-table-column>-->
        <!--v-if="optionData.type!='驳回'"-->
        <el-table-column prop="sDesc" label="说明" >
          <!--<template scope="scope">-->
            <!--<div style="text-align: left;" v-for="item in scope.row.sDesc.split('\n')">{{item}}</div>-->
          <!--</template>-->
          <template scope="scope">
            <div style="text-align: left;" v-for="item in scope.row.sDesc.split('::')[1].split('\n')">{{item}}</div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {},
    props: ['optionData', 'dataInfoForm'],
    data () {
      return {
        dataList: []
      }
    },
    computed: {
      ...mapGetters([
        'planChannelInfo'
      ])
    },
    created: function () {
      this.searchDataList()
    },
    methods: {
      searchDataList () {
        let _this = this
        planApi.getSendCheckReason(this.planChannelInfo.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.dataList = null
        })
      }
    }
  }
</script>
