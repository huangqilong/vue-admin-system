
<style>
  .search-form-page .el-input {
    width:180px;
  }
</style>

<template>
  <div>
    <div class="search-form-page">
      <el-row>
        <el-col :span="22">
          <el-form :model="searchDataForm" :inline="true" labelWidth="110px">
            <el-form-item label="操作人：">
              <el-input size="small" v-model="searchDataForm.cOpName"></el-input>
            </el-form-item>
            <el-form-item label="事件类型：">
              <el-select size="small" v-model="searchDataForm.iEventType" clearable placeholder="全部" @change="eventTypeChange">
                <el-option
                  v-for="item in eventTypeList"
                  :key="item.valueKey"
                  :label="item.valueName"
                  :value="item.valueKey">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="事件名称：" >
              <el-select size="small" v-model="searchDataForm.iMessageType" clearable placeholder="全部">
                <el-option
                  v-for="item in eventNameList"
                  :key="item"
                  :label="item"
                  :value="item">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="渠道名称：">
              <el-select size="small" v-model="searchDataForm.channelName" clearable placeholder="全部">
                <el-option
                  v-for="item in channelNameSelectList"
                  :key="item"
                  :label="item"
                  :value="item">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item>
              <el-button size="small" type="primary" @click="searchDataList()" v-if="false">查询</el-button>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
    </div>
    <el-table :data="dataList" stripe>
      <el-table-column prop="cOpName" label="操作人" width="100"></el-table-column>
      <el-table-column prop="dCreate" label="操作时间" width="200"></el-table-column>
      <el-table-column prop="iEventType" label="事件类型" width="150">
        <template scope="scope">
          {{getEventTypeCharacter(scope.row.iEventType)}}
        </template>
      </el-table-column>
      <el-table-column prop="messageName" label="事件名称" width="150"></el-table-column>
      <el-table-column prop="channelName" label="渠道名称" width="150"></el-table-column>
      <el-table-column prop="cMessge"  label="操作内容" >
        <template scope="scope">
          <div style="text-align:left;">{{scope.row.cMessge}}</div>
        </template>
      </el-table-column>
    </el-table>
    <pagination :pageData="pageData"></pagination>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  import pagination from '../../components/manager/pagination'

  export default{
    components: {
      pagination
    },
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {
        dataList: [],
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        searchDataForm: {
          cOpName: '',
          iEventType: '',
          iMessageType: '',
          channelName: ''
        },
        eventTypeList: [
          {
            valueKey: 1,
            valueName: '母包进度'
          },
          {
            valueKey: 2,
            valueName: '渠道进度'
          },
          {
            valueKey: 3,
            valueName: '整包进度'
          }
        ],
        eventNameList: [],
        channelNameSelectList: []
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planProgressSelectedTab', 'pageNumber'
      ])
    },
    created: function () {
      if (this.planProgressSelectedTab === '5') {
        this.pageData.number = this.pageNumber
        this.searchDataList()
        this.getChannelList()
      }
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          this.searchDataList()
        },
        deep: true
      },
      planProgressSelectedTab: function (newVal) {
        if (newVal === '5') {
          this.pageData.number = this.pageNumber
          this.searchDataList()
          this.getChannelList()
        }
      }
    },
    methods: {
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.searchDataForm}
        planApi.getPlanPackEventDataList(this.planInfo.iPlanId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 获取渠道select数据
      getChannelList () {
        const _this = this
        planApi.getplanEventChannelList(this.planInfo.iPlanId).then((data) => {
          if (data.code === 1) {
            this.channelNameSelectList = data.data.channelName
          } else {
            _this.$alert(data.msg, '提示', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          _this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      eventTypeChange (value) {
        if (value === 1) {
          this.eventNameList = ['打包完成', '质检通过', '质检驳回', '打包失败', '提交质检', '选择渠道', '项目经理通过', '项目经理驳回', '更换母包']
        } else if (value === 2) {
          this.eventNameList = ['打包完成', '质检通过', '质检驳回', '打包失败', '提交质检', '重新接入']
        } else if (value === 3) {
          this.eventNameList = ['打包完成', '质检通过', '质检驳回', '打包失败', '渠道审核中', '渠道通过', '渠道驳回']
        } else {
          this.eventNameList = []
        }
      },
      getEventTypeCharacter (value) {
        switch (value) {
          case 1:
            value = '母包进度'
            break
          case 2:
            value = '渠道进度'
            break
          case 3:
            value = '整包进度'
            break
        }
        return value
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      }
    }
  }
</script>
