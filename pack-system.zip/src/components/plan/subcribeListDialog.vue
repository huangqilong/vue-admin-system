<style>
  .option-dialog-rtx-subcribe .el-dialog{
    width: 600px;
  }
  .left-rtx-user-list .el-tree{
    border: 0px solid #eee;
    background-color: #f9f9f9;
  }
  .right-rtx-user-list .el-checkbox{
    margin-left: 15px;
    width: 90%;
    margin-bottom: 5px;
  }
</style>
<style scoped>
  .option-dialog-rtx-subcribe .plugin-item{
    padding-left: 10px;
    padding-right: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 5px;
  }
  .option-dialog-rtx-subcribe .plugin-item .plugin-item-checkbox{
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }
  .config-content {
    border-left: 1px solid #ccc;
    border-top: 1px solid #ccc;
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    border-radius: 5px;
  }
  .config-content .row-content .row-content .col-span-title {
    padding-left: 15px;
  }
  .config-content .row-content .col-span{
    color: #5a5e66;
    font-size: 14px;
    border-top: 0.5px solid #ccc;
    min-height: 44px;
  }
  .config-content .row-content .col-span .empty-label{
    margin-left: 15px;
    line-height: 39px;
  }
  .config-content .row-content .col-span .el-checkbox{
    margin-left: 15px;
    line-height: 36px;
  }
  .config-content .row-content .col-span .el-checkbox+.el-checkbox{
    margin-left: 15px;
  }
  .config-content .row-content .col-span-title .el-checkbox{
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    width: 97%;
  }
  .config-content .row-content .col-span-list{
    border-left: 1px solid #ccc;
  }
  .config-content .row-content .col-span-list .el-checkbox{
    width: 100px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
  .rtx-title {
    margin-bottom: 10px;
  }
  .left-search-input {
    margin-bottom: 10px;
  }
  .left-rtx-user-list{
    width: 100%;
    height: 350px;
    overflow: auto;
    border: 1px solid #bbb;
    background-color: #f9f9f9;
  }
  .right-rtx-user-list{
    width: 100%;
    height: 396px;
    overflow: auto;
    border: 1px solid #999;
    padding-top: 5px;
    background-color: #f9f9f9;
  }
  .center-rtx-button{
    padding-top: 180px;
    text-align: center;
  }
  .center-rtx-button button{
    margin-bottom: 30px;
    width: 100px;
  }

</style>
<template>
  <el-dialog title="选择订阅人员" :visible.sync="optionData.dialogVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-rtx-subcribe">
    <div class="config-content-rtx">
      <el-row>
        <el-col :span="9">
          <div class="rtx-title">选择订阅人员</div>
          <div class="left-search-input">
            <el-autocomplete
              popper-class="my-autocomplete"
              v-model="subcribeInputSearch"
              :fetch-suggestions="subscribeQuerySearchFun"
              placeholder="请输入内容"
              @select="subscribeSearchIconClick">
              <i
                class="el-icon-search el-input__icon"
                slot="suffix"
                @click="handleSearchIconClick">
              </i>
              <template slot-scope="props">
                <div class="name">{{ props.item.name+'('+props.item.pinyinName+')'}}</div>
              </template>
            </el-autocomplete>
          </div>
          <div class="left-rtx-user-list">
            <el-tree
              :data="rtxUserLeftList"
              show-checkbox
              node-key="name"
              ref="rtxUserTree"
              highlight-current
              @check-change="rtxUserListTreeCheckChange"
              :filter-node-method="rtxUserNodeFilter"
              empty-text="数据加载中..."
              :props="defaultProps">
            </el-tree>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="center-rtx-button">
            <el-button type="primary" size="small" @click="getRtxUserCheckedNodes" :disabled="!hasRtxUserChecked">添加 >></el-button>
            <el-button type="primary" size="small" @click="deleteRtxUserCheckedNodes" style="margin-left: 0px;" :disabled="rtxUserCheckedList.length == 0"><< 删除</el-button>
          </div>
        </el-col>
        <el-col :span="9">
          <div class="rtx-title">已订阅人员</div>
          <div class="right-rtx-user-list">
            <el-checkbox-group v-model="rtxUserCheckedList">
              <el-checkbox v-for="item in rtxUserLeftCheckedList" :label="item.name" :key="item.name+item.pinyinName" v-if="item.type==1">{{item.name}}</el-checkbox>
            </el-checkbox-group>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="config-content" v-if="false">
      <el-row class="row-content">
        <el-col class="col-span col-span-title" :span="colSpan[0]">
          <el-checkbox :indeterminate="dataList.isIndeterminate" v-model="dataList.checkAll" @change="handleCheckAllChangeFirst($event, dataList)">选择全部</el-checkbox>
        </el-col>
        <el-col class="col-span col-span-list" :span="colSpan[1]">
          <span class="empty-label">&nbsp;</span>
        </el-col>
        <el-row class="row-content" v-for="item in dataList.children">
          <el-col class="col-span col-span-title" :span="colSpan[0]" :style="'padding-left:'+(15*2)+'px;'">
            <el-checkbox :indeterminate="item.isIndeterminate" v-model="item.checkAll" @change="handleCheckAllChangeThird($event, item, dataList)">{{item.titleName}}</el-checkbox>
          </el-col>
          <el-col class="col-span col-span-list" :span="colSpan[1]">
            <el-checkbox-group v-model="item.checkedChildren" @change="handleCheckedChange($event, item, dataList)">
              <el-checkbox v-for="cItem in item.children" :label="cItem" :key="cItem.iUserId">{{cItem.cRealName}}</el-checkbox>
            </el-checkbox-group>
          </el-col>
        </el-row>
      </el-row>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import userAccountApi from '../../apis/user-account-api'
  export default{
    components: {},
    props: ['optionData', 'dataInfoForm', 'optionCallBack', 'packSubcribeIdsList', 'packSubcribeList'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        colSpan: [4, 20],
        subcribeInputSearch: '',
        rtxUserList: [],
        rtxUserLeftList: [],
        rtxUserLeftCheckedList: [],
        rtxUserLeftCheckedName: '',
        rtxUserCheckedList: [],
        hasRtxUserChecked: false,
        subscribeRestaurants: [],
        dataList: {
          id: '',
          children: []
        },
        defaultProps: {
          children: 'childList',
          label: 'name'
        }
      }
    },
    watch: {
      dataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created () {
      this.getRtxUserList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      subscribeSearchIconClick (item) {
        this.subcribeInputSearch = item.name
        this.handleSearchIconClick()
      },
      subscribeQuerySearchFun (queryString, cb) {
        var restaurants = JSON.parse(JSON.stringify(this.subscribeRestaurants))
        var results = queryString ? restaurants.filter(this.subscribeCreateFilter(queryString)) : []
        // 调用 callback 返回建议列表的数据
        cb(results)
      },
      subscribeCreateFilter (queryString) {
        return (restaurant) => {
          return (restaurant.name.toLowerCase().indexOf(queryString.toLowerCase()) >= 0 || restaurant.pinyinName.toLowerCase().indexOf(queryString.toLowerCase()) >= 0)
        }
      },
      rtxUserListTreeCheckChange (value, data, node) {
        this.hasRtxUserChecked = data
      },
      deleteRtxUserCheckedNodes () {
        let deleteRtxName = this.rtxUserCheckedList.join(',')
        for (let i = 0; i < this.rtxUserLeftCheckedList.length; i++) {
          let item = this.rtxUserLeftCheckedList[i]
          if (deleteRtxName.indexOf(item.name) >= 0) {
            this.rtxUserLeftCheckedList.splice(i, 1)
            i--
          }
        }
        let nameArray = []
        for (let item of this.rtxUserLeftCheckedList) {
          nameArray.push(item.name)
          nameArray.push(item.pinyinName)
        }
        this.rtxUserLeftCheckedName = nameArray.join(',')
        this.$refs.rtxUserTree.setCheckedNodes(this.rtxUserLeftCheckedList)
        this.$refs.rtxUserTree.filter(this.subcribeInputSearch)
        this.rtxUserCheckedList = []
      },
      rtxUserNodeFilter (value, data, node) {
        data.disabled = false
        if (!value) {
          if (this.rtxUserLeftCheckedName && (this.rtxUserLeftCheckedName.indexOf(data.name) >= 0 || this.rtxUserLeftCheckedName.indexOf(data.pinyinName) >= 0)) {
            data.disabled = true
          }
          return true
        } else {
          if (data.type !== 1) {
            let flag = data.name.indexOf(value) !== -1
            return flag
          } else {
            if (this.rtxUserLeftCheckedName && (this.rtxUserLeftCheckedName.indexOf(data.name) >= 0 || this.rtxUserLeftCheckedName.indexOf(data.pinyinName) >= 0)) {
              data.disabled = true
            }
            let flag = data.name.indexOf(value) !== -1 || data.pinyinName.indexOf(value) !== -1 || data.parentName.indexOf(value) !== -1 || data.parentParentName.indexOf(value) !== -1
            if (!flag) {
              data.disabled = true
            }
            return flag
          }
        }
      },
      handleSearchIconClick () {
        this.$refs.rtxUserTree.filter(this.subcribeInputSearch)
//        if (this.subcribeInputSearch) {
//
//        } else {
//          this.rtxUserLeftList = JSON.parse(JSON.stringify(this.rtxUserList))
//          this.$refs.rtxUserTree.setCheckedNodes(this.rtxUserLeftCheckedList)
//        }
      },
      getRtxUserCheckedNodes () {
        this.rtxUserLeftCheckedList = this.$refs.rtxUserTree.getCheckedNodes(true)
        let nameArray = []
        for (let item of this.rtxUserLeftCheckedList) {
          nameArray.push(item.name)
          nameArray.push(item.pinyinName)
        }
        this.rtxUserLeftCheckedName = nameArray.join(',')
        this.rtxUserCheckedList = []
        this.$refs.rtxUserTree.setCheckedNodes(this.rtxUserLeftCheckedList)
        this.$refs.rtxUserTree.filter(this.subcribeInputSearch)
        this.hasRtxUserChecked = false
      },
      setRtxUserLeftCheckedList () {
        this.rtxUserLeftCheckedList = JSON.parse(JSON.stringify(this.packSubcribeList))
        let nameArray = []
        for (let item of this.rtxUserLeftCheckedList) {
          nameArray.push(item.name)
          nameArray.push(item.pinyinName)
        }
        this.rtxUserLeftCheckedName = nameArray.join(',')
        this.rtxUserCheckedList = []
        this.$refs.rtxUserTree.setCheckedNodes(this.rtxUserLeftCheckedList)
        this.$refs.rtxUserTree.filter(this.subcribeInputSearch)
      },
      getRtxUserList () {
        let _this = this
        userAccountApi.getRtxUserDataList().then((data) => {
          if (data.code === 1) {
            _this.rtxUserList = data.data
            _this.rtxUserLeftList = JSON.parse(JSON.stringify(_this.rtxUserList))
            this.subscribeRestaurants = []
            this.setSubscribeRestaurants(data.data)
            setTimeout(function () {
              _this.setRtxUserLeftCheckedList()
            }, 500)
          }
        }, (error) => {
        })
      },
      setSubscribeRestaurants (data) {
        for (let item of data) {
          if (item.type === 1) {
            this.subscribeRestaurants.push(item)
          } else {
            this.setSubscribeRestaurants(item.childList)
          }
        }
      },
      getRoleList (userClassifyList, userCheckedList) {
        const params = {'currentPage': 1, 'number': 100}
        userAccountApi.getRoleDataList(params).then((data) => {
          if (data.code === 1) {
            for (let item of data.data.list) {
              this.dataList.children.push({
                titleName: item.cRoleName,
                checkAll: false,
                checkedChildren: userCheckedList[item.cRoleName] || [],
                children: userClassifyList[item.cRoleName] || []
              })
            }
            for (let item of this.dataList.children) {
              this.handleCheckedChange(null, item, this.dataList)
            }
          }
          this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataList))
        }, (error) => {
          console.log(error)
        })
      },

      initCheckBoxParams (item, dataList) {
        if (item) {
          if (typeof item.checkAll === 'undefined') {
            this.$set(item, 'checkAll', true)
          }
          if (typeof item.isIndeterminate === 'undefined') {
            this.$set(item, 'isIndeterminate', true)
          }
        }
        if (dataList) {
          if (typeof dataList.checkAll === 'undefined') {
            this.$set(dataList, 'checkAll', true)
          }
          if (typeof dataList.isIndeterminate === 'undefined') {
            this.$set(dataList, 'isIndeterminate', true)
          }
        }
      },
      checkBoxAllOption (item, dataList) {
        if (dataList) {
          let dcCount = 0
          let diCount = 0
          for (let dItem of dataList.children) {
            if (dItem.checkAll) {
              dcCount++
            }
            if (dItem.isIndeterminate) {
              diCount++
            }
          }
          if (dcCount === dataList.children.length) {
            dataList.checkAll = true
            dataList.isIndeterminate = false
          } else if (dcCount === 0 && diCount === 0) {
            dataList.checkAll = false
            dataList.isIndeterminate = false
          } else {
            dataList.checkAll = false
            dataList.isIndeterminate = true
          }
        }
      },
      handleCheckAllChangeFirst (event, dataList) {
        this.initCheckBoxParams(null, dataList)
        dataList.isIndeterminate = false
        for (let item of dataList.children) {
          this.initCheckBoxParams(item, null)
          let arr = []
          for (let cItem of item.children) {
            arr.push(cItem)
          }
          item.checkAll = dataList.checkAll
          item.isIndeterminate = false
          item.checkedChildren = dataList.checkAll ? arr : []
        }
      },
      handleCheckAllChangeThird (event, item, dataList) {
        this.initCheckBoxParams(item, dataList)
        let arr = []
        for (let cItem of item.children) {
          arr.push(cItem)
        }
        item.checkedChildren = item.checkAll ? arr : []
        item.isIndeterminate = false

        this.checkBoxAllOption(null, dataList)
      },
      handleCheckedChange (event, item, dataList) {
        this.initCheckBoxParams(item, dataList)
        let checkedCount = event ? event.length : item.checkedChildren.length
        item.checkAll = checkedCount === item.children.length
        item.isIndeterminate = checkedCount > 0 && checkedCount < item.children.length
        this.checkBoxAllOption(null, dataList)
      },
      submitForm () {
        /*
        this.optionData.dialogVisible = false
        let selectUserIds = []
        for (let item of this.dataList.children) {
          selectUserIds = selectUserIds.concat(item.checkedChildren)
        }
        this.optionCallBack(selectUserIds) */
        let submitParams = {
          userNames: [],
          userOrgList: []
        }
        for (let item of this.rtxUserLeftCheckedList) {
          if (item.type === 1) {
            submitParams.userNames.push(item.name)
            submitParams.userOrgList.push({
              cRealName: item.name,
              cUserName: item.pinyinName
            })
          }
        }
        this.optionCallBack(submitParams)
      }
    }
  }

</script>
