<style scoped>
  .row-col{
    padding: 0 5px 0 10px;
    line-height: 25px;
    color: #666;
  }
  .label-title{
    text-align: right;
    color: #999;
  }
</style>
<template>
  <el-dialog :title="'查看原因（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-anew-Join-up">
    <div class="content-list">
      <el-row>
        <el-col :span="4" class="row-col label-title">驳回人：</el-col>
        <el-col :span="20" class="row-col">{{dataInfoForm.userName}}</el-col>
      </el-row>
      <el-row v-if="dataInfoForm.bugUrl">
        <el-col :span="4" class="row-col label-title">bug地址：</el-col>
        <el-col :span="20" class="row-col"><a target="_blank" :href="dataInfoForm.bugUrl">{{dataInfoForm.bugUrl}}</a></el-col>
      </el-row>
      <el-row>
        <el-col :span="4" class="row-col label-title">驳回理由：</el-col>
        <el-col :span="20" class="row-col" v-if="optionData.dialogFlag == 'intact'">
          <div v-for="item in dataInfoForm.sDesc.split('::')[1].split('\n')">{{item}}</div>
        </el-col>
        <el-col :span="20" class="row-col" v-if="optionData.dialogFlag == 'channel'">
          <div v-for="item in dataInfoForm.sDesc.split('::')[1].split('\n')">{{item}}</div>
        </el-col>
        <el-col :span="20" class="row-col" v-if="optionData.dialogFlag != 'channel' && optionData.dialogFlag != 'intact'">
          <div>{{dataInfoForm.sDesc}}</div>
        </el-col>
      </el-row>
    </div>
  <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm'],
    created: function () {
    },
    data () {
      return {
      }
    }
  }
</script>
