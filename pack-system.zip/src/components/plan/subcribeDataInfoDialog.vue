<style>
  .option-dialog-subcribe-data-info .el-dialog{
    width: 600px;
  }
  .option-dialog-subcribe-data-info.option-dialog .el-dialog .el-dialog__body {
    padding: 5px 20px 0 20px;
  }
  .option-dialog-subcribe-data-info .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog-subcribe-data-info.el-dialog__wrapper{
    overflow:hidden;
  }
  .option-dialog-subcribe-data-info  .el-dialog__body{max-height:600px;overflow-Y:auto;}
  .option-dialog-subcribe-data-info .el-radio-button .el-radio-button__inner{
    border-left: 1px solid #dcdfe6;
    border-radius: 4px;
    margin: 5px;
  }
  .option-dialog-subcribe-data-info .el-radio-button.is-active .el-radio-button__inner,
  .option-dialog-subcribe-data-info .el-radio-button.is-focus .el-radio-button__inner{
    border-color: #409EFF;
    border-left: 1px solid #20a0ff;
  }
</style>
<template>
  <el-dialog  :title="optionData.title"
               :visible.sync="optionData.dialogFormVisible"
               class="option-dialog option-dialog-subcribe-data-info">
    <div class="content-list">
      <el-row>
        <el-col :span="24">
          <el-radio-group v-model="subcribeRoleNames" size="small" @change="getSelectDataList">
            <el-radio-button label="全部" key="全部">全部（{{dataList.length}}）</el-radio-button>
            <el-radio-button v-for="(item,key) in subcribeRoleList" :label="key" :key="key">{{ key }}（{{ item }}）</el-radio-button>
          </el-radio-group>
        </el-col>
      </el-row>
      <el-table :data="selectDataList" border :span-method="subscribeSpanMethod" :default-sort = "{prop: 'cRoleName', order: 'descending'}">
        <el-table-column type="index" label="序号" width="60"></el-table-column>
        <el-table-column prop="cRoleName" label="角色"></el-table-column>
        <el-table-column prop="cRealName" label="真实姓名"></el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  let subcribeSpanCount = 0
  export default{
    components: {},
    props: ['optionData'],
    data () {
      return {
        dataList: [],
        selectDataList: [],
        subcribeRoleNames: '',
        subcribeRoleList: {}
      }
    },
    computed: {
      ...mapGetters([
        'planInfo'
      ])
    },
    created: function () {
      this.getSubcribeDataList()
    },
    methods: {
      subscribeSpanMethod ({ row, column, rowIndex, columnIndex }) {
        if (columnIndex === 1) {
          if (rowIndex === 0) {
            subcribeSpanCount = 0
          }
          if ((rowIndex - subcribeSpanCount) % this.subcribeRoleList[row.cRoleName] === 0) {
            if ((rowIndex - subcribeSpanCount) === this.subcribeRoleList[row.cRoleName] - 1) {
              subcribeSpanCount += this.subcribeRoleList[row.cRoleName]
            }
            return {
              rowspan: this.subcribeRoleList[row.cRoleName],
              colspan: 1
            }
          } else {
            if ((rowIndex - subcribeSpanCount) === this.subcribeRoleList[row.cRoleName] - 1) {
              subcribeSpanCount += this.subcribeRoleList[row.cRoleName]
            }
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        }
      },
      getSelectDataList () {
        if (this.subcribeRoleNames === '全部') {
          this.selectDataList = JSON.parse(JSON.stringify(this.dataList))
        } else {
          let temp = []
          for (let item of this.dataList) {
            if (this.subcribeRoleNames === item.cRoleName) {
              temp.push(item)
            }
          }
          this.selectDataList = temp
        }
      },
      getSubcribeDataList () {
        planApi.getSubscribeUserInfo(this.planInfo.iPlanId).then((data) => {
          if (data.code === 1) {
            this.dataList = data.data
            this.selectDataList = data.data
            this.subcribeRoleList = {}
            for (let item of data.data) {
              if (typeof this.subcribeRoleList[item.cRoleName] === 'undefined') {
                this.$set(this.subcribeRoleList, item.cRoleName, 0)
              }
              this.subcribeRoleList[item.cRoleName]++
            }
            this.subcribeRoleNames = '全部'
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
