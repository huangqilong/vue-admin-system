<style>
  .option-dialog-channel-check .el-dialog{
    width: 600px;
  }
  .option-dialog-channel-check .content-list .el-form-item__label{
    width:100%;
    text-align:right;
  }
</style>
<template>
  <el-dialog  :title="'渠道检测（' + optionData.dialogCurrentTitle+ '）'"
              :visible.sync="optionData.dialogFormVisible"
              class="option-dialog option-dialog-channel-check">
    <div class="content-list">
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="150px">
        <el-form-item label="已接入最高版本：" style="margin-bottom: 2px;">{{lastChannelInfo.channelVersion}}</el-form-item>
        <el-form-item label="渠道是否需要更新：" prop="isCheck" style="margin-bottom: 5px;">
          <el-radio-group v-model="dataInfoForm.isCheck" @change="channelCheckFun">
            <el-radio label="1">需要更新</el-radio>
            <el-radio label="0">无需更新</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item prop="reason" label="渠道检测说明：">
          <el-input type="textarea"  v-model="dataInfoForm.reason" auto-complete="off" placeholder="请输入更新渠道版本"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary"  @click="submitData('dataInfoForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        lastChannelInfo: {
          channelVersion: ''
        },
        rules: {
          isCheck: [
            { required: true, message: '请选择渠道是否需要更新', trigger: 'change' }
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'planInfo'
      ])
    },
    created: function () {
      this.getChannelVersion()
    },
    methods: {
      channelCheckFun () {
        if (this.dataInfoForm.isCheck === '1') {
          this.dataInfoForm.reason = ''
        } else {
          this.dataInfoForm.reason = '无'
        }
      },
      getChannelVersion () {
        let _this = this
        let type = this.planInfo.iPlatformName === '安卓' ? 0 : 1
        planApi.getChannelLastVersion(this.dataInfoForm.iPlanChannelId, type).then((data) => {
          if (data.code === 1) {
            _this.lastChannelInfo = data.data
          } else {
            _this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      submitData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let submitData = JSON.parse(JSON.stringify(this.dataInfoForm))
            let isUpdate = this.dataInfoForm.isCheck
            submitData.sDesc = submitData.reason
            delete submitData.reason
            delete submitData.isCheck
            planApi.channelCheckIsUpdate(this.dataInfoForm.iPlanChannelId, this.optionData.currentStatus, isUpdate, submitData).then((data) => {
              if (data.code === 1) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
              } else {
                _this.$alert(data.msg, '请求失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert('请求失败，请稍后重试！', '提示', {
                confirmButtonText: '确定'
              })
            })
          }
        })
      }
    }
  }
</script>
