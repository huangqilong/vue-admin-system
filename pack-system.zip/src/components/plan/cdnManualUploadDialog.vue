<style>
  .option-dialog-cdn-manual .el-dialog{
    width: 400px;
  }
  .option-dialog-cdn-manual .el-form-item__label{
    width:100%;
    text-align:left;
  }


</style>
<template>
  <el-dialog  :title="optionData.title"
              :visible.sync="optionData.dialogFormVisible"
              class="option-dialog option-dialog-cdn-manual">
    <div class="content-list">
      <el-row>
        <el-col :span="24">
          <span>提示：如果系统自动上传cdn地址失败，请走原有广告包cdn处理OA流程，并手动录入cdn下载地址！</span>
        </el-col>
      </el-row>
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules">
        <el-form-item prop="cdnUrl" label="CDN下载地址：">
          <el-input type="textarea" v-model="dataInfoForm.cdnUrl" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary"  @click="submitData('dataInfoForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {
    },
    props: ['optionData', 'optionCallBack'],
    data () {
      return {
        dataInfoForm: {
          cdnUrl: ''
        },
        rules: {
          cdnUrl: [
            {required: true, message: '请输入CDN下载地址', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {},
    methods: {
      submitData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let params = {
              iPlanAdId: _this.optionData.iPlanAdId,
              cdnUrl: _this.dataInfoForm.cdnUrl
            }
            planApi.putCdnUrlUpload(params).then((data) => {
              if (data.code === 1) {
                _this.optionCallBack()
                _this.optionData.dialogFormVisible = false
              } else {
                _this.$alert(data.msg, '操作失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              _this.$alert('请求失败，请稍后重试！', '提示', {
                confirmButtonText: '确定'
              })
            })
          }
        })
      }
    }
  }
</script>
