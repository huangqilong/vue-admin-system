<style>
  .option-dialog-down-file .el-dialog{
    width: 350px;
  }
  .option-dialog-down-file .el-dialog .el-dialog__body {
    padding: 10px 20px 0 20px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
  }
  .content-list .path{
    margin-top: 15px;
    word-break: break-all;
    line-height: 20px;
    text-align: left;
  }
  .content-list .path-split{
    border-top: 3px dashed #ff0000;
    margin: 10px 0;
  }
  .shared-disk-path{
    margin-top: 10px;
    word-break: break-all;
    line-height: 20px;
    text-align: left;
  }
  .shared-disk-btn{
    padding: 5px;
    letter-spacing: 5px;
    width: 140px;
  }
  .down-waring-text{
    margin-top: 15px;
    color: red;
  }
</style>
<template>
  <el-dialog  :title="'渠道地址下载（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-down-file">
    <div class="content-list">
      <div class="path">渠道下载地址（{{localNetwork}}）：
        <span @click="clickDownFile(downloadHref)" style="color: #0190fe;cursor: pointer;" v-clipboard:copy="downloadHref">{{downloadHref}}</span></div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogVisible = false">关闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import QRCode from 'qrcode'
  export default{
    components: {},
    props: ['optionData', 'dataParams'],
    data () {
      return {
        imgSrc: '',
        downloadHref: '',
        appstoreHref: '',
        localNetwork: '内网'
      }
    },
    computed: {
      ...mapGetters([
        'planInfo'
      ])
    },
    created: function () {
      let _this = this
      QRCode.toDataURL(_this.dataParams.downLoadPath, { errorCorrectionLevel: 'H' }, (err, url) => {
        if (url) {
          _this.imgSrc = url
        } else {
          this.$alert('二维码生成失败', '下载', {
            confirmButtonText: '确定'
          })
        }
      })
      if (_this.dataParams.downLoadPath.indexOf('.html') >= 0 && _this.dataParams.resourceName) {
        let rPath = _this.dataParams.downLoadPath.substring(0, _this.dataParams.downLoadPath.lastIndexOf('/') + 1)
        this.downloadHref = rPath + _this.dataParams.resourceName
        this.appstoreHref = rPath + _this.dataParams.appstoreName
      } else {
        this.downloadHref = _this.dataParams.downLoadPath
      }
      this.localNetwork = this.downloadHref.indexOf('https://dl.9917.com') >= 0 ? '内网' : '公网'
    },
    methods: {
      clickDownFile (downHref) {
        window.location.href = downHref
      },
      getSharedDiskPath (downHref) {
        let downPath = downHref.replace('//', '')
        let pIndex = downPath.indexOf('/')
        downPath = downPath.substring(pIndex)
        downPath = downPath.replace(/\//g, '\\')
        return '\\\\192.168.0.158\\hwy_packages' + downPath
      },
      onCopy () {
        this.$alert('复制成功', '提醒', {
          confirmButtonText: '确定'
        })
      },
      onError () {
        this.$alert('复制失败', '提醒', {
          confirmButtonText: '确定'
        })
      }
    }
  }
</script>
