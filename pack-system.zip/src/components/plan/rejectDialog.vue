<style>
  .option-dialog-reject .el-dialog{
    width: 600px;
  }
  .option-dialog-reject .el-form-item__label{
    width:100%;
    text-align:left;
  }


</style>
<template>
  <el-dialog  :title="'驳回（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-reject">
    <div class="content-list">
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules">
        <el-form-item prop="reason"  label="驳回理由：">
          <el-input type="textarea"  v-model="dataInfoForm.reason" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary"  @click="submitData('dataInfoForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
          reason: [
            {required: true, message: '请输入驳回理由', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {},
    methods: {
      submitData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.dialogFlag === 'channel') {
              let id = this.dataInfoForm.iPlanChannelId
              let roleType = this.dataInfoForm.roleType
              let params = {
                channelIds: '',
                iPlanChannelId: this.dataInfoForm.iPlanChannelId,
                sDesc: this.dataInfoForm.reason
              }
              // 母包、渠道包、整包驳回
              planApi.rejectPlanReason(id, roleType, params, _this.optionData.currentStatus).then((data) => {
                if (data.code === 1) {
                  _this.optionCallBack()
                  _this.optionData.dialogFormVisible = false
                } else {
                  _this.$alert(data.msg, '操作失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                this.$alert('请求失败，请稍后重试！', '提示', {
                  confirmButtonText: '确定'
                })
              })
            } else if (this.optionData.dialogFlag === 'ad') {
              let id = this.dataInfoForm.iPlanAdId
              let params = {
                channelIds: '',
                iPlanChannelId: 0,
                sDesc: this.dataInfoForm.reason
              }
              // 广告包、cps包驳回
              planApi.rejectPlanAdReason(id, params, _this.optionData.currentStatus).then((data) => {
                if (data.code === 1) {
                  _this.optionCallBack()
                  _this.optionData.dialogFormVisible = false
                } else {
                  _this.$alert(data.msg, '操作失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                this.$alert('请求失败，请稍后重试！', '提示', {
                  confirmButtonText: '确定'
                })
              })
            }
          }
        })
      }
    }
  }
</script>
