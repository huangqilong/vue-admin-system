<style scoped>
  .main-container {
    position: absolute;
    top: 60px;
    left: 230px;
    right: 0;
    bottom: 0;
    overflow: hidden;
    -webkit-transition: all .28s ease-out;
    transition: all .28s ease-out;
    background-color: #eee;
  }

  .sdp-container-scroll {
    position: absolute;
    width: 100%;
    top: 0px;
    left: 0px;
    overflow: auto;
    /* overflow-y: auto; */
    -moz-transition: all 0.2s ease;
    -webkit-transition: all 0.2s ease;
    transition: all 0.2s ease;
    height: 100%;
  }

  .content-container {
    position: relative;
    padding: 0;
    min-width: 1500px;
    margin: 0;
  }

</style>
<template>
  <main class="main-container">
    <div class="sdp-container-scroll">
      <div class="content-container height100">
        <router-view></router-view>
      </div>
    </div>
    <back-top :scrollMySelf='true'></back-top>
  </main>
</template>
<script>
  import {mapGetters, mapActions} from 'vuex'
  import backTop from '../components/manager/backTop'

  export default {
    name: 'cMain',
    computed: {
      ...mapGetters([
        'menuIsFold', 'userId'
      ])
    },
    components: {
      backTop
    },
    created: function () {
//      this.$store.dispatch('dictionaryInit')
    },
    methods: {
      ...mapActions([
        'toggleMenu'
      ])
    }
  }
</script>
