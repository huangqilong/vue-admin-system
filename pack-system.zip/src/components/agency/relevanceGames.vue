<style scoped>
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<style>
  .option-dialog-relevance .el-dialog{
    width: 1000px;
  }
</style>

<template>
  <el-dialog title="关联游戏" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-relevance">
    <el-form :model="dataInfoForm" ref="dataInfoForm">
      <el-row>
        <el-col>
          <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('dataInfoForm')" v-if="0==dataInfoForm.sdkMiddleareGameConfigList.length">添&nbsp;&nbsp;加</el-button>
        </el-col>
      </el-row>
      <el-row v-for="(domain,index) in dataInfoForm.sdkMiddleareGameConfigList" :gutter="10">
        <el-col :span="3">
          <el-form-item
            :prop="'sdkMiddleareGameConfigList.' + index + '.iAreaId'"
            :rules="{type: 'number', required: true, message: '请选择地区', trigger: 'change'}">
            <el-select v-model="domain.iAreaId" placeholder="请选择" @change="getGameList(domain)">
              <el-option
                v-for="item in areaList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="3">
          <el-form-item
            :prop="'sdkMiddleareGameConfigList.' + index + '.iLanguageId'"
            :rules="{type: 'number', required: true, message: '请选择语言', trigger: 'change'}">
            <el-select v-model="domain.iLanguageId" placeholder="请选择" @change="getGameList(domain)">
              <el-option
                v-for="item in languageList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item
            :prop="'sdkMiddleareGameConfigList.' + index + '.iProjectId'"
            :rules="{type: 'number', required: true, message: '请选择游戏', trigger: 'change'}">
            <el-select v-model="domain.iProjectId" placeholder="请选择" @change="getGameVersionList(domain)">
              <el-option
                v-for="item in domain.list.gameList"
                :key="item.iProjectId"
                :label="item.gameName"
                :value="item.iProjectId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="3">
          <el-form-item
            :prop="'sdkMiddleareGameConfigList.' + index + '.iGameAssertId'"
            :rules="{type: 'number', required: true, message: '请选择游戏版本', trigger: 'change'}">
            <el-select v-model="domain.iGameAssertId" placeholder="请选择" @change="getGameAssetsDataList(domain)">
              <el-option
                v-for="item in domain.list.gameVersionList"
                :key="item.iAssertId"
                :label="item.gameAssetsVersion"
                :value="item.iAssertId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="3">
          <el-form-item :prop="'sdkMiddleareGameConfigList.' + index + '.cVersionType'"
                        :rules="{required: true, message: '请选择游戏资源类型', trigger: 'change'}">
            <el-select v-model="domain.cVersionType" placeholder="请选择" @change="getGameAssetsDataList(domain)">
              <el-option
                v-for="item in gameAssetsTypeList"
                :key="item.value"
                :label="item.name"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item :prop="'sdkMiddleareGameConfigList.' + index + '.iProjectAssetId'"
                        :rules="{type: 'number', required: true, message: '请选择游戏资源', trigger: 'change'}">
            <el-select v-model="domain.iProjectAssetId" placeholder="请选择">
              <el-option
                v-for="item in domain.list.gameAssetsList"
                :key="item.iProjectAssetId"
                :label="item.gameAssetsName"
                :value="item.iProjectAssetId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item>
            <el-button size="small" @click.prevent="removeItem(index)">删除</el-button>
            <el-button size="small" type="primary" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.sdkMiddleareGameConfigList.length-1">添加</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('dataInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import packToolApi from '../../apis/pack-tool-api'
  import agencyApi from '../../apis/agency-api'
  export default{
    props: ['optionData'],
    data () {
      return {
        platformType: 'android',
        dataInfoForm: {
          iMiddleareId: '',
          cMiddleareVersion: '',
          sdkMiddleareGameConfigList: []
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'gameAssetsTypeList', 'buttonLoading'
      ])
    },
    created: function () {
      this.dataInfoForm.iMiddleareId = this.optionData.iMiddleareId
      this.dataInfoForm.cMiddleareVersion = this.optionData.cMiddleareVersion
      // 获取关联游戏列表
      this.getRelevanceGameDataList()
    },
    methods: {
      // 判断平台类型
      judgePlatformType () {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === this.optionData.iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
      },
      // 获取游戏列表
      getGameList (dataInfo, opType) {
        const optionParams = {
          areaId: dataInfo.iAreaId,
          languageId: dataInfo.iLanguageId,
          platformId: this.optionData.iPlatformId
        }
        this.judgePlatformType()
        // 获得打包游戏项目表
        packToolApi.getPackGameDataList(optionParams).then((data) => {
          if (data.code === 1) {
            dataInfo.list.gameList = data.data
            if (opType && opType === 'get') {
              this.getGameVersionList(dataInfo, opType)
            }
          } else {
            this.$alert(data.msg, '游戏列表获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 获得打包游戏版本列表
      getGameVersionList (dataInfo, opType) {
        let pType = this.platformType === 'ios' ? 1 : 0
        packToolApi.getPackGameVersionDataList(dataInfo.iProjectId, pType).then((data) => {
          if (data.code === 1) {
            dataInfo.list.gameVersionList = data.data
            if (opType && opType === 'get') {
              this.getGameAssetsDataList(dataInfo)
            }
          } else {
            this.$alert(data.msg, '游戏版本列表获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 获得打包游戏资源列表
      getGameAssetsDataList (dataInfo) {
        // 获得打包游戏资源列表
        let pType = this.platformType === 'ios' ? 1 : 0
        packToolApi.getPackGameAssetsDataList(dataInfo.iGameAssertId, pType, dataInfo.cVersionType).then((data) => {
          if (data.code === 1) {
            dataInfo.list.gameAssetsList = data.data
          } else {
            this.$alert(data.msg, '游戏资源列表获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const dataInfo = {
              iMiddleareId: this.optionData.iMiddleareId,
              iAreaId: this.areaList[0].iDicId,
              iLanguageId: this.languageList[0].iDicId,
              iPlatformId: this.optionData.iPlatformId,
              iProjectId: '',
              iGameAssertId: '',
              cVersionType: '1',
              iProjectAssetId: '',
              list: {
                gameList: null,
                gameVersionList: null,
                gameAssetsList: null
              }
            }
            this.dataInfoForm.sdkMiddleareGameConfigList.push(dataInfo)
            this.getGameList(dataInfo)
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        this.dataInfoForm.sdkMiddleareGameConfigList.splice($index, 1)
      },
      getRelevanceGameDataList () {
        agencyApi.getRelevanceGameDataList(this.optionData.iMiddleareId).then((data) => {
          if (data.code === 1) {
            for (let item of data.data.list) {
              item.list = {
                gameList: null,
                gameVersionList: null,
                gameAssetsList: null
              }
              this.dataInfoForm.sdkMiddleareGameConfigList.push(item)
              this.getGameList(item, 'get')
            }
          } else {
            this.$alert(data.msg, '关联游戏获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const paramsList = JSON.parse(JSON.stringify(this.dataInfoForm))
            for (let item of paramsList.sdkMiddleareGameConfigList) {
              delete item.iAreaId
              delete item.iLanguageId
              delete item.iPlatformId
              delete item.cVersionType
              delete item.list
            }
            // 数据新增
            agencyApi.addRelevanceGameDataList(paramsList).then((data) => {
              if (data.code === 1) {
                _this.optionData.dialogFormVisible = false
              } else {
                _this.$alert(data.msg, '关联游戏失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              console.log(error)
            })
          } else {
            return false
          }
        })
      }
    }
  }

</script>
