/**
 * Created by lichb on 2017/2/7.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger'
import createPersistedState from 'vuex-persistedstate'
import Cookies from 'js-cookie'
import state from './state'
import mutations from './mutations'
import actions from './actions'
import getters from './getters'
import common from './modules/common'
import login from './modules/login'
import dictionary from './modules/dictionary'
import projectGame from './modules/project'
import game from './modules/game'
import channel from './modules/channel'
import plugin from './modules/plugin'
import agency from './modules/agency'
import engine from './modules/engine'
import user from './modules/user'
import role from './modules/role'
import pack from './modules/pack'
import plan from './modules/plan'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'
/*
* vuex的数据持久化支持，默认localStorage

 vuex2与cookie的持久化支持
 let persistedState = {
 paths: ['login'],
 getState: (key) =>  Cookies.getJSON(key),
 setState: (key, state) => Cookies.set(key, state, {expires: 3}) //expires->cookie过期时间，单位为天
 }
* */
let modulesArray = {
  common,
  login,
  dictionary,
  projectGame,
  game,
  pack,
  plan,
  channel,
  plugin,
  agency,
  engine,
  user,
  role
}
let sessionPersistedModulesArray = {
  game,
  plan
}
let localPersistedModulesArray = {
  common,
  dictionary,
  pack,
  plan,
  projectGame,
  login,
  game,
  channel,
  plugin,
  agency,
  engine,
  user,
  role
}
let cookiePersistedModulesArray = {
  login
}
const getPlugins = () => {
  const plugins = []
  for (let model in sessionPersistedModulesArray) {
    // sessionStorage存储
    plugins.push(createPersistedState({
      key: model + '-session',
      storage: window.sessionStorage,
      paths: [model + '.session']
    }))
  }
  for (let model in localPersistedModulesArray) {
    // localStorage存储
    plugins.push(createPersistedState({
      key: model + '-local',
      paths: [model + '.local']
    }))
  }
  for (let model in cookiePersistedModulesArray) {
    // cookieStorage存储
    plugins.push(createPersistedState({
      key: model + '-cookie',
      paths: [model + '.cookie'],
      getState: (key) => Cookies.getJSON(key),
      setState: (key, state) => Cookies.set(key, state, {expires: 1})
    }))
  }
  if (debug) {
    plugins.unshift(createLogger())
  }
  return plugins
}

export default new Vuex.Store({
  state,
  mutations,
  actions,
  getters,
  modules: modulesArray,
  strict: debug,
  plugins: getPlugins()
})
