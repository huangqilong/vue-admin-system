
import {PLAN_INFO,
  PLAN_CHANNEL_INFO,
  PLAN_PROGRESS_SELECTED_TAB, PLAN_OPTION_PARAMS, PLAN_PROGRESS_STATUS_TAB} from '../mutation-types'

// initial state
const state = {
  session: {
    planInfo: null,
    planChannelInfo: null,
    planProgressTabStatus: {
      gameStatus: '',
      sdkStatus: '',
      packageStatus: '',
      adStatus: '',
      cpsStatus: ''
    }
  },
  local: {
    planProgressSelectedTab: '',
    planOptionParams: null
  },
  planTypeDataList: [
    {
      iDicId: 1,
      sDicName: '正式计划'
    },
    {
      iDicId: 0,
      sDicName: '测试计划'
    }
  ]
}

// getters
const getters = {
  planInfo: state => state.session.planInfo,
  planChannelInfo: state => state.session.planChannelInfo,
  planProgressSelectedTab: state => state.local.planProgressSelectedTab,
  planProgressTabStatus: state => state.session.planProgressTabStatus,
  planOptionParams: state => state.local.planOptionParams,
  planTypeDataList: state => state.planTypeDataList
}

// actions
const actions = {
  addPlanInfo ({commit, state}, data) {
    commit(PLAN_INFO, data)
  },
  planChannelInfo ({commit, state}, data) {
    commit(PLAN_CHANNEL_INFO, data)
  },
  setPlanProgressSelectedTab ({commit, state}, data) {
    commit(PLAN_PROGRESS_SELECTED_TAB, data)
  },
  setPlanProgressTabStatus ({commit, state}, data) {
    commit(PLAN_PROGRESS_STATUS_TAB, data)
  },
  setPlanOptionParams ({commit, state}, data) {
    commit(PLAN_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [PLAN_INFO] (state, data) {
    state.session.planInfo = data
  },
  [PLAN_CHANNEL_INFO] (state, data) {
    state.session.planChannelInfo = data
  },
  [PLAN_PROGRESS_SELECTED_TAB] (state, data) {
    state.local.planProgressSelectedTab = data
  },
  [PLAN_PROGRESS_STATUS_TAB] (state, data) {
    state.session.planProgressTabStatus = data
  },
  [PLAN_OPTION_PARAMS] (state, data) {
    state.local.planOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
