/**
 * Created by huangjinbiao on 2017/7/14.
 */
import {DICTS_TYPE_LIST} from '../../config/common'
import {DICT_INIT, DICT_LOGIN_OUT,
  DICT_PICONLIST_INIT,
  DICT_PICONLIST_ICON_UPDATE,
  DICT_PICONLIST_SPLASH_UPDATE,
  DICT_PICONLIST_ICON_UPDATE_PATH,
  DICT_PICONLIST_SPLASH_UPDATE_PATH,
  DICT_PICONLIST_ICON_DELETE_PATH,
  DICT_PICONLIST_SPLASH_DELETE_PATH} from '../mutation-types'
import dictionaryApi from '../../apis/dictionary-api'

// initial state
const state = {
  local: {
    defaultAreaPlatLanInfo: {
      iAreaId: '',
      iLanguageId: '',
      iPlatformId: ''
    },
    areaList: null,
    platformList: null,
    languageList: null,
    pluginTypeList: null,
    orientationList: null,
    androidIconResolutionList: null,
    iosIconResolutionList: null,
    androidSplashResolutionList: null,
    iosSplashResolutionList: null,
    problemAttributionList: null,
    screenStretchingList: null,
    statusBarList: null,
    orientationForPackList: null,
    iosSystemVersionList: null,
    shareSwitchList: null
  },
  projectIconDataList: null,
  projectSplashDataList: null,
  packStatusList: [
    {
      iDicId: -1,
      sDicName: '排队中',
      className: 'status-line'
    },
    {
      iDicId: 0,
      sDicName: '打包中',
      className: 'status-ing'
    },
    {
      iDicId: 1,
      sDicName: '打包完成',
      className: 'status-success'
    },
    {
      iDicId: 2,
      sDicName: '打包失败',
      className: 'status-failure'
    }
  ],
  planStatusList: [
    {
      iDicId: '0',
      sDicName: '进行中',
      className: 'status-noStart'
    },
    {
      iDicId: '1',
      sDicName: '已结束',
      className: 'status-ing'
    }
  ],
  signatureTypeList: [
    {
      iDicId: '0',
      sDicName: '官方签名'
    },
    {
      iDicId: '1',
      sDicName: '好玩友签名'
    }
  ],
  agencyTypeList: [
    {
      iDicId: '0',
      sDicName: '老代理'
    },
    {
      iDicId: '1',
      sDicName: '友财'
    },
    {
      iDicId: '2',
      sDicName: '其它'
    }
  ],
  gameTypeList: [
    {
      iDicId: '0',
      sDicName: '老代理'
    },
    {
      iDicId: '1',
      sDicName: '友财'
    },
    {
      iDicId: '2',
      sDicName: '其它'
    }
  ],
  fileResourceTypeList: [
    {
      iDicId: '0',
      sDicName: '裸包'
    },
    {
      iDicId: '1',
      sDicName: '母包'
    },
    {
      iDicId: '2',
      sDicName: '渠道'
    },
    {
      iDicId: '3',
      sDicName: '整包'
    },
    {
      iDicId: '4',
      sDicName: '广告包'
    },
    {
      iDicId: '5',
      sDicName: 'CPS'
    }
  ],
  roleAuthorityList: [
    {
      iDicId: 'searchBtn',
      sDicName: '查询按钮'
    },
    {
      iDicId: 'insertBtn',
      sDicName: '新增按钮'
    },
    {
      iDicId: 'statusBtn',
      sDicName: '状态按钮'
    },
    {
      iDicId: 'updateBtn',
      sDicName: '编辑按钮'
    },
    {
      iDicId: 'deleteBtn',
      sDicName: '删除按钮'
    },
    {
      iDicId: 'clickPack',
      sDicName: '点击打包按钮'
    },
    {
      iDicId: 'downLoad',
      sDicName: '下载按钮'
    },
    {
      iDicId: 'downLoadBareFile',
      sDicName: '下载母包按钮'
    },
    {
      iDicId: 'againPack',
      sDicName: '重新打包按钮'
    },
    {
      iDicId: 'revocationRejectBtn',
      sDicName: '撤销驳回按钮'
    },
    {
      iDicId: 'lineAgainPack',
      sDicName: '排队中重新打包按钮'
    },
    {
      iDicId: 'checkCause',
      sDicName: '查看原因按钮'
    },
    {
      iDicId: 'checkLog',
      sDicName: '日志按钮'
    },
    {
      iDicId: 'sdkTestPack',
      sDicName: 'SDK测试Tab页'
    },
    {
      iDicId: 'gameTestPack',
      sDicName: '游戏测试Tab页'
    },
    {
      iDicId: 'gameInstallPack',
      sDicName: '打整包Tab页'
    },
    {
      iDicId: 'channelPack',
      sDicName: '打渠道码包按钮'
    },
    {
      iDicId: 'cpsAdvCodeConfig',
      sDicName: '广告码配置按钮'
    },
    {
      iDicId: 'keystoreConfig',
      sDicName: '签名配置按钮'
    },
    {
      iDicId: 'packNameConfig',
      sDicName: '包名配置按钮'
    },
    {
      iDicId: 'iOSPermissionConfig',
      sDicName: 'IOS游戏权限配置'
    },
    {
      iDicId: 'gameSubcribeConfig',
      sDicName: '游戏人员配置按钮'
    },
    {
      iDicId: 'buglyConfig',
      sDicName: 'bugly配置按钮/上传bugly按钮'
    },
    {
      iDicId: 'packConfig',
      sDicName: '打包配置按钮'
    },
    {
      iDicId: 'cdnControlOptionBtn',
      sDicName: 'CDN开启控制按钮'
    },
    {
      iDicId: 'svnSecretKeyConfig',
      sDicName: 'svn密钥配置'
    },
    {
      iDicId: 'relevanceOperatorConfig',
      sDicName: '关联渠道/运营商按钮'
    },
    {
      iDicId: 'versionPage',
      sDicName: '版本列表按钮'
    },
    {
      iDicId: 'assetsPage',
      sDicName: '游戏资源配置按钮'
    },
    {
      iDicId: 'channelPage',
      sDicName: '游戏资源渠道配置按钮'
    },
    {
      iDicId: 'channelSync',
      sDicName: '游戏渠道同步按钮'
    },
    {
      iDicId: 'shareSwitch',
      sDicName: '分享开关按钮'
    },
    {
      iDicId: 'relevancePluginConfig',
      sDicName: '关联插件按钮'
    },
    {
      iDicId: 'channelConfig',
      sDicName: '渠道OR插件配置按钮'
    },
    {
      iDicId: 'showChannelConfig',
      sDicName: '查看渠道OR插件配置按钮'
    },
    {
      iDicId: 'relevanceGameConfig',
      sDicName: '关联游戏按钮'
    },
    {
      iDicId: 'insertChildrenBtn',
      sDicName: '添加子菜单按钮'
    },
    {
      iDicId: 'relevanceFunctionConfig',
      sDicName: '关联功能按钮'
    },
    {
      iDicId: 'permissionsBindingConfig',
      sDicName: '权限绑定按钮'
    },
    {
      iDicId: 'rtxInformConfigBtn',
      sDicName: '消息配置按钮'
    },
    {
      iDicId: 'dataListPage',
      sDicName: '数据列表界面'
    },
    {
      iDicId: 'defineParams',
      sDicName: '定义参数按钮'
    },
    {
      iDicId: 'enteringParams',
      sDicName: '录入参数按钮'
    },
    {
      iDicId: 'showParams',
      sDicName: '参数查看按钮'
    },
    {
      iDicId: 'progressBtn',
      sDicName: '进度按钮'
    },
    {
      iDicId: 'sdkTestAssets',
      sDicName: 'SDK测试资源按钮'
    },
    {
      iDicId: 'launchPlan',
      sDicName: '发起计划'
    },
    {
      iDicId: 'openOrClosePlan',
      sDicName: '开启或关闭计划'
    },
    {
      iDicId: 'configDetails',
      sDicName: '配置详情'
    },
    {
      iDicId: 'openEjectReview',
      sDicName: '开启审核服按钮'
    },
    {
      iDicId: 'workOrderOpen',
      sDicName: '走工单开启按钮'
    },
    {
      iDicId: 'workOrderClose',
      sDicName: '走工单关闭按钮'
    },
    {
      iDicId: 'uploadBtn',
      sDicName: '上传按钮'
    },
    {
      iDicId: 'updateSubcribeList',
      sDicName: '计划订阅人员修改'
    },
    {
      iDicId: 'againUpload',
      sDicName: '重新上传按钮'
    },
    {
      iDicId: 'againChooseChannel',
      sDicName: '母包重新选择渠道'
    },
    {
      iDicId: 'joinUpComplete',
      sDicName: '接入完成按钮'
    },
    {
      iDicId: 'againJoinUp',
      sDicName: '重新接入按钮'
    },
    {
      iDicId: 'commitQA',
      sDicName: '提交质检/审核按钮'
    },
    {
      iDicId: 'QAPass',
      sDicName: '质检通过按钮'
    },
    {
      iDicId: 'channelPass',
      sDicName: '渠道通过按钮'
    },
    {
      iDicId: 'managerPass',
      sDicName: '项目经理通过按钮'
    },
    {
      iDicId: 'rejectBtn',
      sDicName: '质检驳回按钮'
    },
    {
      iDicId: 'channelReject',
      sDicName: '渠道驳回按钮'
    },
    {
      iDicId: 'managerReject',
      sDicName: '项目经理驳回按钮'
    },
    {
      iDicId: 'channelSendCheck',
      sDicName: '渠道送审按钮'
    },
    {
      iDicId: 'channelDownloadUrl',
      sDicName: '渠道下载地址按钮'
    },
    {
      iDicId: 'enterChannelUrl',
      sDicName: '录入渠道下载地址按钮'
    },
    {
      iDicId: 'cdnManualUpload',
      sDicName: '手动上传按钮'
    },
    {
      iDicId: 'gameShortcutConfig',
      sDicName: '游戏快捷配置按钮'
    },
    {
      iDicId: 'cdnDownloadUrl',
      sDicName: 'CDN地址下载按钮'
    },
    {
      iDicId: 'planBarePackageProgressTab',
      sDicName: '母包进度Tab页'
    },
    {
      iDicId: 'planChannelPackageProgressTab',
      sDicName: '渠道进度Tab页'
    },
    {
      iDicId: 'planIntactPackageProgressTab',
      sDicName: '整包进度Tab页'
    },
    {
      iDicId: 'planAdPackageProgressTab',
      sDicName: '广告包进度Tab页'
    },
    {
      iDicId: 'planCpsPackageProgressTab',
      sDicName: 'CPS包进度Tab页'
    },
    {
      iDicId: 'planEventTab',
      sDicName: '计划事件Tab页'
    },
    {
      iDicId: 'planChannelSummary',
      sDicName: '计划渠道汇总'
    },
    {
      iDicId: 'channelCheckBtn',
      sDicName: '渠道检测按钮'
    },
    {
      iDicId: 'channelCheckExplain',
      sDicName: '检测说明按钮'
    }
  ],
  methodTypeList: [
    {
      iDicId: 'get',
      sDicName: 'get'
    },
    {
      iDicId: 'post',
      sDicName: 'post'
    },
    {
      iDicId: 'put',
      sDicName: 'put'
    },
    {
      iDicId: 'delete',
      sDicName: 'delete'
    }
  ]
}

// getters
const getters = {
  defaultAreaPlatLanInfo: state => state.local.defaultAreaPlatLanInfo,
  areaList: state => state.local.areaList,
  platformList: state => state.local.platformList,
  languageList: state => state.local.languageList,
  pluginTypeList: state => state.local.pluginTypeList,
  orientationList: state => state.local.orientationList,
  androidIconResolutionList: state => state.local.androidIconResolutionList,
  iosIconResolutionList: state => state.local.iosIconResolutionList,
  androidSplashResolutionList: state => state.local.androidSplashResolutionList,
  iosSplashResolutionList: state => state.local.iosSplashResolutionList,
  packStatusList: state => state.packStatusList,
  planStatusList: state => state.planStatusList,
  screenStretchingList: state => state.local.screenStretchingList,
  statusBarList: state => state.local.statusBarList,
  orientationForPackList: state => state.local.orientationForPackList,
  signatureTypeList: state => state.signatureTypeList,
  iosSystemVersionList: state => state.local.iosSystemVersionList,
  shareSwitchList: state => state.local.shareSwitchList,
  roleAuthorityList: state => state.roleAuthorityList,
  projectIconDataList: state => state.projectIconDataList,
  projectSplashDataList: state => state.projectSplashDataList,
  methodTypeList: state => state.methodTypeList,
  agencyTypeList: state => state.agencyTypeList,
  gameTypeList: state => state.gameTypeList,
  fileResourceTypeList: state => state.fileResourceTypeList,
  problemAttributionList: state => state.local.problemAttributionList
}

// actions
const actions = {
  dictionaryInit ({commit, state}) {
    const dictsTypeArray = []
    if (!state.local.areaList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.area)
    }
    if (!state.local.platformList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.platform)
    }

    if (!state.local.languageList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.language)
    }

    if (!state.local.pluginTypeList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.plugintype)
    }

    if (!state.local.orientationList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.orientation)
    }

    if (!state.local.androidIconResolutionList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.androidIconResolution)
    }

    if (!state.local.iosIconResolutionList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.iosIconResolution)
    }

    if (!state.local.androidSplashResolutionList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.androidSplashResolution)
    }

    if (!state.local.iosSplashResolutionList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.iosSplashResolution)
    }
    if (!state.local.screenStretchingList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.screenStretching)
    }
    if (!state.local.statusBarList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.statusBar)
    }
    if (!state.local.orientationForPackList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.orientationForPack)
    }
    if (!state.local.iosSystemVersionList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.iosSystemVersion)
    }
    if (!state.local.shareSwitchList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.shareSwitch)
    }
    if (!state.local.problemAttributionList) {
      dictsTypeArray.push(DICTS_TYPE_LIST.problemAttribution)
    }
    for (let i = 0; i < dictsTypeArray.length; i++) {
      // 获取所有字典数据列表
      let dictType = dictsTypeArray[i]
      dictionaryApi.getDictsByType(dictType).then((data) => {
        if (data.code === 1) {
          let params = {
            dictType: dictType,
            data: data.data
          }
          commit(DICT_INIT, params)
        }
      }, (error) => {
        console.log(error)
      })
    }
  },
  dictionaryUpdate ({commit, state}, dictType) {
    dictionaryApi.getDictsByType(dictType).then((data) => {
      if (data.code === 1) {
        let params = {
          dictType: dictType,
          data: data.data
        }
        commit(DICT_INIT, params)
      }
    }, (error) => {
      console.log(error)
    })
  },
  loginOutDictionaryUpdate ({commit, state}) {
    commit(DICT_LOGIN_OUT)
  },
  projectIconListInit ({commit, state}, {platformType, source}) {
    dictionaryApi.getGamePicRess(platformType, source).then((data) => {
      if (data.code === 1) {
        commit(DICT_PICONLIST_INIT, {'dataList': data.data, 'platformType': platformType})
      }
    }, (error) => {
      console.log(error)
    })
  },
  updateProjectIconDataList ({commit, state}, iconList) {
    commit(DICT_PICONLIST_ICON_UPDATE, iconList)
  },
  updateProjectSplashDataList ({commit, state}, splashList) {
    commit(DICT_PICONLIST_SPLASH_UPDATE, splashList)
  },
  updateProjectIconPath ({commit, state}, resData) {
    commit(DICT_PICONLIST_ICON_UPDATE_PATH, resData)
  },
  deleteProjectIconPath ({commit, state}, resData) {
    commit(DICT_PICONLIST_ICON_DELETE_PATH, resData)
  },
  updateProjectSplashPath ({commit, state}, resData) {
    commit(DICT_PICONLIST_SPLASH_UPDATE_PATH, resData)
  },
  deleteProjectSplashPath ({commit, state}, resData) {
    commit(DICT_PICONLIST_SPLASH_DELETE_PATH, resData)
  }
}

// mutations
const mutations = {
  [DICT_INIT] (state, {dictType, data}) {
    if (DICTS_TYPE_LIST.area === dictType) {
      state.local.areaList = data
      if (data.length > 0) {
        state.local.defaultAreaPlatLanInfo.iAreaId = data[0].iDicId
      }
    }
    if (DICTS_TYPE_LIST.platform === dictType) {
      state.local.platformList = data
      if (data.length > 0) {
        state.local.defaultAreaPlatLanInfo.iPlatformId = data[0].iDicId
      }
    }
    if (DICTS_TYPE_LIST.language === dictType) {
      state.local.languageList = data
      if (data.length > 0) {
        state.local.defaultAreaPlatLanInfo.iLanguageId = data[0].iDicId
      }
    }
    if (DICTS_TYPE_LIST.plugintype === dictType) {
      state.local.pluginTypeList = data
    }
    if (DICTS_TYPE_LIST.orientation === dictType) {
      state.local.orientationList = data
    }
    if (DICTS_TYPE_LIST.androidIconResolution === dictType) {
      state.local.androidIconResolutionList = data
    }
    if (DICTS_TYPE_LIST.iosIconResolution === dictType) {
      state.local.iosIconResolutionList = data
    }
    if (DICTS_TYPE_LIST.androidSplashResolution === dictType) {
      state.local.androidSplashResolutionList = data
    }
    if (DICTS_TYPE_LIST.iosSplashResolution === dictType) {
      state.local.iosSplashResolutionList = data
    }
    if (DICTS_TYPE_LIST.screenStretching === dictType) {
      state.local.screenStretchingList = data
    }
    if (DICTS_TYPE_LIST.statusBar === dictType) {
      state.local.statusBarList = data
    }
    if (DICTS_TYPE_LIST.orientationForPack === dictType) {
      state.local.orientationForPackList = data
    }
    if (DICTS_TYPE_LIST.iosSystemVersion === dictType) {
      state.local.iosSystemVersionList = data
    }
    if (DICTS_TYPE_LIST.shareSwitch === dictType) {
      state.local.shareSwitchList = data
    }
    if (DICTS_TYPE_LIST.problemAttribution === dictType) {
      state.local.problemAttributionList = data
    }
  },
  [DICT_LOGIN_OUT] (state, data) {
    state.local.defaultAreaPlatLanInfo = {
      iAreaId: '',
      iLanguageId: '',
      iPlatformId: ''
    }
    state.local.areaList = null
    state.local.platformList = null
    state.local.languageList = null
    state.local.pluginTypeList = null
    state.local.orientationList = null
    state.local.androidIconResolutionList = null
    state.local.iosIconResolutionList = null
    state.local.androidSplashResolutionList = null
    state.local.iosSplashResolutionList = null
    state.local.screenStretchingList = null
    state.local.statusBarList = null
    state.local.orientationForPackList = null
    state.local.iosSystemVersionList = null
    state.local.shareSwitchList = null
    state.local.problemAttributionList = null
  },
  [DICT_PICONLIST_INIT] (state, {dataList, platformType}) {
    state.projectIconDataList = []
    state.projectSplashDataList = []
    for (let dItem of dataList) {
      if (dItem.picType === '0') {
        for (let iItem of dItem.picResList) {
          state.projectIconDataList.push({
            iDicId: iItem.cDictIds,
            sDicName: iItem.sDictNames,
            cPicType: iItem.cPicType,
            cSource: iItem.cSource,
            iPlatformId: iItem.iPlatformId,
            picId: '',
            resId: '',
            picUrl: ''
          })
        }
      } else {
        for (let iItem of dItem.picResList) {
          state.projectSplashDataList.push({
            splashId: iItem.cDictIds.split(',')[0],
            splashName: iItem.sDictNames.split(',')[0],
            orientationId: iItem.cDictIds.split(',')[1],
            orientationName: iItem.sDictNames.split(',')[1],
            cPicType: iItem.cPicType,
            cSource: iItem.cSource,
            iPlatformId: iItem.iPlatformId,
            picList: []
          })
        }
      }
    }
  },
  [DICT_PICONLIST_ICON_UPDATE] (state, iconList) {
    state.projectIconDataList = []
    for (let tempItem of iconList) {
      state.projectIconDataList.push({
        iDicId: tempItem.cDictIds,
        sDicName: tempItem.sDictNames,
        iRefId: tempItem.iRefId,
        iPicId: tempItem.iPicId,
        cPicType: tempItem.cPicType,
        cSource: tempItem.cSource,
        iPlatformId: tempItem.iPlatformId,
        picId: tempItem.picIds,
        resId: tempItem.resIds,
        picUrl: tempItem.picUrl
      })
    }
  },
  [DICT_PICONLIST_SPLASH_UPDATE] (state, splashList) {
    state.projectSplashDataList = []
    for (let tempSItem of splashList) {
      let tempItem = {
        splashId: tempSItem.cDictIds.split(',')[0],
        splashName: tempSItem.sDictNames.split(',')[0],
        orientationId: tempSItem.cDictIds.split(',')[1],
        orientationName: tempSItem.sDictNames.split(',')[1],
        iRefId: tempSItem.iRefId,
        cPicType: tempSItem.cPicType,
        cSource: tempSItem.cSource,
        iPlatformId: tempSItem.iPlatformId,
        iPicId: tempSItem.iPicId,
        picList: []
      }
      if (tempSItem.picIds) {
        let picIds = tempSItem.picIds.split(',')
        let picUrls = tempSItem.picUrl.split(',')
        let resIds = !tempSItem.resIds ? [] : tempSItem.resIds.split(',')
        for (let pIndex in picIds) {
          tempItem.picList.push(
            {
              picId: picIds[pIndex],
              resId: resIds.length > 0 ? resIds[pIndex] : '',
              picUrl: picUrls[pIndex]
            }
          )
        }
      }
      state.projectSplashDataList.push(tempItem)
    }
  },
  [DICT_PICONLIST_ICON_UPDATE_PATH] (state, {index, fileData}) {
    state.projectIconDataList[index].picId = ''
    state.projectIconDataList[index].resId = fileData.resId
    state.projectIconDataList[index].picUrl = fileData.url
  },
  [DICT_PICONLIST_ICON_DELETE_PATH] (state, {index}) {
    state.projectIconDataList[index].picId = ''
    state.projectIconDataList[index].resId = ''
    state.projectIconDataList[index].picUrl = ''
  },
  [DICT_PICONLIST_SPLASH_UPDATE_PATH] (state, {index, fileData, platformType}) {
    if (platformType && platformType === 1) {
      for (let i = 0; i < fileData.length && state.projectSplashDataList[index].picList.length < 1; i++) {
        const fItem = fileData[i]
        state.projectSplashDataList[index].picList.push({
          picId: '',
          resId: fItem.resId,
          picUrl: fItem.url
        })
        break
      }
    } else {
      for (let i = 0; i < fileData.length && state.projectSplashDataList[index].picList.length < 4; i++) {
        const fItem = fileData[i]
        state.projectSplashDataList[index].picList.push({
          picId: '',
          resId: fItem.resId,
          picUrl: fItem.url
        })
      }
    }
  },
  [DICT_PICONLIST_SPLASH_DELETE_PATH] (state, {index, pIndex}) {
    state.projectSplashDataList[index].picList.splice(pIndex, 1)
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
