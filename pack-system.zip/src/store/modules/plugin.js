/**
 * Created by huangjinbiao on 2018/1/11.
 */

import {PLUGIN} from '../mutation-types'

// initial state
const state = {
  local: {
    pluginOptionParams: null
  }
}

// getters
const getters = {
  pluginOptionParams: state => state.local.pluginOptionParams
}

// actions
const actions = {
  setPluginOptionParams ({commit, state}, data) {
    commit(PLUGIN.PLUGIN_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [PLUGIN.PLUGIN_OPTION_PARAMS] (state, data) {
    state.local.pluginOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
