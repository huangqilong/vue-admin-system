/**
 * Created by huangjinbiao on 2017/7/17.
 */

import {PROJECT_INFO} from '../mutation-types'

// initial state
const state = {
  local: {
    projectGameInfo: null
  }
}

// getters
const getters = {
  projectGameInfo: state => state.local.projectGameInfo
}

// actions
const actions = {
  addProjectGameInfo ({commit, state}, data) {
    commit(PROJECT_INFO, data)
  }
}

// mutations
const mutations = {
  [PROJECT_INFO] (state, data) {
    state.local.projectGameInfo = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
