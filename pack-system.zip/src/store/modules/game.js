
import {GAME} from '../mutation-types'
import gameApi from '../../apis/game-api'

// initial state
const state = {
  session: {
    gameInfo: null,
    gameVersionInfo: null,
    gameAssetsInfo: null,
    gameChannelInfo: null,
    gameAssetsTypeList: [
      {
        name: '正式资源',
        value: '1'
      },
      {
        name: '其它资源',
        value: '0'
      }
    ]
  },
  local: {
    gameOptionParams: null
  },
  deleteGamePicIds: [],
  fileUploadDirId: '',
  messageFileUploadDirId: '',
  extraResPath: 'http://192.168.0.147/cms/upload/extraRes.zip',
  iosExtraResPath: 'http://192.168.0.147/cms/upload/iosExtraRes.zip'
}

// getters
const getters = {
  gameInfo: state => state.session.gameInfo,
  gameVersionInfo: state => state.session.gameVersionInfo,
  gameAssetsInfo: state => state.session.gameAssetsInfo,
  gameChannelInfo: state => state.session.gameChannelInfo,
  gameAssetsTypeList: state => state.session.gameAssetsTypeList,
  gameOptionParams: state => state.local.gameOptionParams,
  deleteGamePicIds: state => state.deleteGamePicIds,
  fileUploadDirId: state => state.fileUploadDirId,
  messageFileUploadDirId: state => state.messageFileUploadDirId,
  extraResPath: state => state.extraResPath,
  iosExtraResPath: state => state.iosExtraResPath
}

// actions
const actions = {
  setGameOptionParams ({commit, state}, data) {
    commit(GAME.GAME_GAME_OPTION_PARAMS, data)
  },
  addGameInfo ({commit, state}, data) {
    commit(GAME.GAME_ADD, data)
  },
  addGameVersionInfo ({commit, state}, data) {
    commit(GAME.GAME_VERSION_ADD, data)
  },
  addGameAssetsInfo ({commit, state}, data) {
    commit(GAME.GAME_ASSETS_ADD, data)
  },
  addGameChannelInfo ({commit, state}, data) {
    commit(GAME.GAME_CHANNEL_ADD, data)
  },
  deleteGamePicIds ({commit, state}, id) {
    commit(GAME.GAME_IMAGE_DELETE_IDS, id)
  },
  deleteGameConfigImage ({commit, state}, id) {
    gameApi.deleteGameConfigImage(id).then((data) => {
      if (data.code === 1) {
        console.log('文件删除成功')
      } else {
        console.log('文件删除失败')
      }
    }, (error) => {
      console.log('文件删除请求错误')
    })
  },
  getFileUploadDir ({commit, state}, id) {
    if (id) {
      commit(GAME.GAME_FILE_UPLOAD_DIR, id)
    } else {
      gameApi.getFileUploadDir().then((data) => {
        if (data.code === 1) {
          commit(GAME.GAME_FILE_UPLOAD_DIR, data.val)
        } else {
          console.log('图片路径获取失败')
          commit(GAME.GAME_FILE_UPLOAD_DIR, '')
        }
      }, (error) => {
        console.log('图片路径获取请求错误')
        commit(GAME.GAME_FILE_UPLOAD_DIR, '')
      })
    }
  },
  getMessageFileUploadDir ({commit, state}, id) {
    if (id) {
      commit(GAME.GAME_MESSAGE_FILE_UPLOAD_DIR, id)
    } else {
      gameApi.getFileUploadDir().then((data) => {
        if (data.code === 1) {
          commit(GAME.GAME_MESSAGE_FILE_UPLOAD_DIR, data.val)
        } else {
          console.log('图片路径获取失败')
          commit(GAME.GAME_MESSAGE_FILE_UPLOAD_DIR, '')
        }
      }, (error) => {
        console.log('图片路径获取请求错误')
        commit(GAME.GAME_MESSAGE_FILE_UPLOAD_DIR, '')
      })
    }
  }
}

// mutations
const mutations = {
  [GAME.GAME_GAME_OPTION_PARAMS] (state, data) {
    state.local.gameOptionParams = data
  },
  [GAME.GAME_ADD] (state, data) {
    state.session.gameInfo = data
  },
  [GAME.GAME_VERSION_ADD] (state, data) {
    state.session.gameVersionInfo = data
  },
  [GAME.GAME_ASSETS_ADD] (state, data) {
    state.session.gameAssetsInfo = data
  },
  [GAME.GAME_CHANNEL_ADD] (state, data) {
    state.session.gameChannelInfo = data
  },
  [GAME.GAME_IMAGE_DELETE_IDS] (state, id) {
    state.deleteGamePicIds.push(id)
  },
  [GAME.GAME_FILE_UPLOAD_DIR] (state, id) {
    state.fileUploadDirId = id
  },
  [GAME.GAME_MESSAGE_FILE_UPLOAD_DIR] (state, id) {
    state.messageFileUploadDirId = id
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
