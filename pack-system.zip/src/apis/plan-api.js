import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 新增计划进度
  postPackPlanRecord (params) {
    return request.post(PROXY_DEV_API + '/packPlanRecords', params)
  },
  // 新增计划进度
  getPackPlanDataInfo (id) {
    return request.get(PROXY_DEV_API + '/packPlanRecords/' + id)
  },
  // 获取数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/packPlanRecords', params)
  },
  // 删除数据
  deleteDataInfo (id) {
    return request.delete(PROXY_DEV_API + '/packPlanRecords/' + id)
  },
  // 状态修改数据
  changeStatusDataInfo (id, status) {
    return request.put(PROXY_DEV_API + '/packPlanRecords/' + id + '/cplanstatus/' + status)
  },
  // 获取单条打包计划信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/packPlanRecords/' + id)
  },
  // 获取计划已订阅人员信息
  getSubscribeUserInfo (id) {
    return request.get(PROXY_DEV_API + '/packPlanSubcribes/iplanid/' + id)
  },
  // 订阅人员修改
  saveSubscribeUser (params) {
    return request.put(PROXY_DEV_API + '/packPlanRecords/saveSubcribe', params)
  },
  saveRTXSubscribeUser (id, params) {
    return request.put(PROXY_DEV_API + '/packPlanSubcribes/iplanid/' + id + '/subcribe', params)
  },
  // 添加和取消订阅
  addSubscribeUser (id, userId) {
    return request.put(PROXY_DEV_API + '/packPlanSubcribes/iplanid/' + id + '/userid/' + userId)
  },
  // 获取进度分类信息的状态
  getPlanRecordsStatusInfo (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/currentStatus/' + id)
  },
  // 获取游戏裸包进度、渠道进度、整包进度表
  getPackageProgressDataList (id, packType) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/planid/' + id + '/packtype/' + packType)
  },
  // 获取广告包进度、cps包进度表
  getCpsOrAdvProgressDataList (id, packType) {
    return request.get(PROXY_DEV_API + '/packPlanAdRecords/planid/' + id + '/packType/' + packType)
  },
  // 母包、渠道、整包更改事件状态
  updateDataStatus (id, event, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/' + id + '/event/' + event)
  },
  // 上传游戏裸包
  uploadGameBarePackage (id, params, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/upload/iPlanChannelId/' + id, params)
  },
  // 上传游戏SDK测试包
  uploadGameSdkTestPackage (params) {
    return request.put(PROXY_DEV_API + '/packPlanRecords/upload', params)
  },
  uploadGameSdkTestPackageSvnStatus (id, params, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/svnpath/iPlanChannelId/' + id, params)
  },
  // 上传游戏SDK测试包，SVN路径
  uploadGameSdkTestPackageSvn (params) {
    return request.put(PROXY_DEV_API + '/packPlanRecords/svnpath', params)
  },
  // CDN开启控制
  putCdnOpenControlOption (iplanid, cdnflag) {
    return request.put(PROXY_DEV_API + '/packPlanRecords/' + iplanid + '/cdnflag/' + cdnflag)
  },
  // 打游戏测试包
  packGameTestPackage (id, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/beginPack/' + id)
  },
  // 重新打包
  againPackGamePackage (id, roleType, status, param) {
    if (param) {
      return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/rePack/' + id + '/roletype/' + roleType, param)
    } else {
      return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/rePack/' + id + '/roletype/' + roleType)
    }
  },
  // 母包进度、渠道进度-排队中--重新打包操作
  lineAgainPackGamePackage (id, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/reCallJenkins/status/' + status + '/iPlanChannelId/' + id)
  },
  //  更新母包
  againUploadgamePackage (params, status) {
    return request.post(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/gameReUpload', params)
  },
  // 母包进度--重新选择渠道
  againChooseChannel (status, params) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/updateChannels', params)
  },
  // 母包进度、渠道进度--提交质检
  commitQualityTest (status, id, params) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/exam/' + id, params)
  },
  //  渠道进度-质检通过-重新接入
  againJoinUpPackage (params, status) {
    return request.post(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/gameReLink', params)
  },
  //  渠道进度-其他状态-重新接入
  justAgainJoinUpPackage (status, id) {
    return request.post(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/gameReLink/iPlanChannelId/' + id)
  },
  // 渠道进度-接入完成
  channelJoinUpComplete (status, id) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/iPlanChannelId/' + id + '/connectchannel')
  },
  // 获取打包渠道列表
  getPackChannelDataList (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/channels/planid/' + id)
  },
  // 获取打包广告码列表
  getPackAdvCpsDataList (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/adcodes/planid/' + id)
  },
  // 母包、渠道包、整包驳回接口
  rejectPlanReason (id, roletype, params, status) {
    return request.post(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/reject/iplanchannelid/' + id + '/roletype/' + roletype, params)
  },
  // 渠道进度-渠道检测
  channelCheckIsUpdate (id, status, update, params) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/iPlanChannelId/' + id + '/update/' + update, params)
  },
  // 获取接入渠道的最高版本
  getChannelLastVersion (id, type) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/getlastchannel/' + id + '/platformtype/' + type)
  },
  // 渠道进度-检测说明
  channelCheckExplain (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/iPlanChannelId/' + id + '/update')
  },
  // 整包进度-获取驳回原因
  getRejectReason (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/rejectReason/iPlanChannelId/' + id)
  },
  // 整包进度-渠道包通过
  channelPass (id, params, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/addUrl/iPlanChannelId/' + id, params)
  },
  addChannelPassUrl (params) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords', params)
  },
  // 广告包、cps包修改进度状态
  updateAdProgressStatus (id, event, status) {
    return request.put(PROXY_DEV_API + '/packPlanAdRecords/status/' + status + '/' + id + '/event/' + event)
  },
  // 获取打包服务器记录
  gamePackServerLogs (params) {
    return request.get(PROXY_DEV_API + '/gamePackServerLogs', params)
  },
  // 广告包、cps包驳回接口
  rejectPlanAdReason (id, params, status) {
    return request.post(PROXY_DEV_API + '/packPlanAdRecords/status/' + status + '/reject/iplanadid/' + id, params)
  },
  //  广告包、cps包
  getAdRejectReason (id) {
    return request.get(PROXY_DEV_API + '/packPlanAdRecords/rejectReason/iPlanAdId/' + id)
  },
  // 广告包、cps包、渠道通过接口
  adChannelPass (id, params, status) {
    return request.put(PROXY_DEV_API + '/packPlanAdRecords/status/' + status + '/addUrl/iPlanAdId/' + id, params)
  },
  addAdChannelPassUrl (params) {
    return request.put(PROXY_DEV_API + '/packPlanAdRecords', params)
  },
  // 获取计划事件列表
  getPlanPackEventDataList (id, params) {
    return request.get(PROXY_DEV_API + '/gamePackEventLogs/iplanid/' + id, params)
  },
  //  获取送检原因
  getSendCheckReason (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/reasons/iPlanChannelId/' + id)
  },
  //  项目经理驳回、通过--获取原因和渠道接口
  getQualityDescChannels (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/getLastChannels/iPlanChannelId/' + id)
  },
  //  获取下载地址
  getPackRecordInfo (id) {
    return request.get(PROXY_DEV_API + '/packPlanChannelRecords/getRecord/' + id)
  },
  getAdCpsPackRecordInfo (id) {
    return request.get(PROXY_DEV_API + '/packPlanAdRecords/getRecord/' + id)
  },
  getplanEventChannelList (id) {
    return request.get(PROXY_DEV_API + '/gamePackEventLogs/filters/iplanid/' + id)
  },
  putCdnUrlUpload (params) {
    return request.put(PROXY_DEV_API + '/packPlanAdRecords/cdnstatus', params)
  },
  putWorkOrderOption (id, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/iPlanChannelId/' + id + '/reviewFlag/' + status)
  },
  putOpenEjectReview (id) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/eject/' + id)
  },
  putPlanRevocationReject (id, status) {
    return request.put(PROXY_DEV_API + '/packPlanChannelRecords/status/' + status + '/cancel/' + id)
  }
}
