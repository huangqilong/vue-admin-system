/**
 * Created by huangjinbiao on 2017/7/5.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameProjects/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/gameProjects', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/gameProjects', params)
  },
  // 数据列表
  getAllDataList (params) {
    return request.get(PROXY_DEV_API + '/gameProjects/game/list', params)
  },
  // 修改数据
  updateDataInfo (params, type) {
    if (type === 'keystore') {
      return request.post(PROXY_DEV_API + '/androidGameKeystores', params)
    } else if (type === 'svnSecret') {
      return request.post(PROXY_DEV_API + '/androidGameKeystores', params)
    } else {
      return request.put(PROXY_DEV_API + '/gameProjects', params)
    }
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/gameProjects/' + id + '/status/' + status)
  },
  // 获取游戏配置信息
  getGameConfigInfo (id, type) {
    if (type === 'game') {
      return request.get(PROXY_DEV_API + '/gameConfigs/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/gameConfigs/v2/' + id)
    }
  },
  // 修改游戏配置信息
  updateGameConfigInfo (params, type) {
    if (type === 'game') {
      return request.post(PROXY_DEV_API + '/gameConfigs', params)
    } else {
      return request.post(PROXY_DEV_API + '/gameConfigs/v2', params)
    }
  },
  // Cps Dev码新增
  postCpsAdvPackInfo (params) {
    return request.post(PROXY_DEV_API + '/gameAdcodeConfigs', params)
  },
  // 获取cps adv 的记录
  getCpsAdvPackInfo (projectId) {
    return request.get(PROXY_DEV_API + '/gameAdcodeConfigs/game/' + projectId)
  },
  // 版本数据信息
  getVersionDataInfo (type, id) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosGameAssets/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/androidGameAssets/' + id)
    }
  },
  // 获取上一个版本信息
  getPreVersionInfo (id) {
    return request.get(PROXY_DEV_API + '/androidGameAssets/android/' + id)
  },
  // 版本数据列表
  getVersionDataList (type, projectId, params) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosGameAssets/project/' + projectId, params)
    } else {
      return request.get(PROXY_DEV_API + '/androidGameAssets/project/' + projectId, params)
    }
  },
  // 版本新增数据
  addVersionDataInfo (type, params) {
    if (type === 'ios') {
      return request.post(PROXY_DEV_API + '/iosGameAssets', params)
    } else {
      return request.post(PROXY_DEV_API + '/androidGameAssets', params)
    }
  },
  // 版本修改数据
  updateVersionDataInfo (type, params) {
    if (type === 'ios') {
      return request.put(PROXY_DEV_API + '/iosGameAssets', params)
    } else {
      return request.post(PROXY_DEV_API + '/androidGameAssets', params)
    }
  },
  // 资源数据信息
  getAssetsDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/' + id)
  },
  // 判断资源文件是否已存在
  isAssetsExist (md5) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/md5/' + md5)
  },
  // 资源数据列表
  getAssetsDataList (platformType, assertId, params) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/platform/' + platformType + '/assert/' + assertId, params)
  },
  // 资源新增数据
  addAssetsDataInfo (params) {
    return request.post(PROXY_DEV_API + '/gameProjectAssets', params)
  },
  // 资源修改数据
  updateAssetsDataInfo (params) {
    return request.put(PROXY_DEV_API + '/gameProjectAssets', params)
  },
  // 配置数据信息
  getConfigDataInfo (type, id) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosProjectChannels/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/androidProjectChannels/' + id)
    }
  },
  getConfigV2DataInfo (type, id) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosProjectChannels/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/androidProjectChannels/v2/' + id)
    }
  },
  // 配置数据列表
  getConfigDataList (type, assertId, params) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosProjectChannels/assert/' + assertId, params)
    } else {
      return request.get(PROXY_DEV_API + '/androidProjectChannels/assert/' + assertId, params)
    }
  },
  // 配置新增数据
  addConfigDataInfo (type, params) {
    if (type === 'ios') {
      return request.post(PROXY_DEV_API + '/iosProjectChannels', params)
    } else {
      return request.post(PROXY_DEV_API + '/androidProjectChannels', params)
    }
  },
  updateConfigDataInfo (type, params) {
    return this.addConfigDataInfo(type, params)
  },
  addConfigDataInfoV2 (type, params) {
    if (type === 'ios') {
      return request.post(PROXY_DEV_API + '/iosProjectChannels/V2', params)
    } else {
      return request.post(PROXY_DEV_API + '/androidProjectChannels/V2', params)
    }
  },
  // 配置修改数据
  updateConfigDataInfoV2 (type, params) {
    return this.addConfigDataInfoV2(type, params)
  },
  // 配置图片删除接口
  deleteGameConfigImage (id) {
    return request.delete(PROXY_DEV_API + '/fileUploadLogs/' + id)
  },
  // 获取文件上传路径
  getFileUploadDir () {
    return request.get(PROXY_DEV_API + '/fileUploadDir')
  },
  // 获取筛选游戏数据列表
  getSearchDataList () {
    return request.get(PROXY_DEV_API + '/gameProjects/gameList')
  },
  // 获取筛选游戏版本列表
  getSearchVersionDataList (gameId, iAreaId, iLanguageId, iPlatformType) {
    return request.get(PROXY_DEV_API + '/gameProjects/gameVersions/gameId/' + gameId + '/iAreaId/' + iAreaId + '/iLanguageId/' + iLanguageId + '/iPlatformType/' + iPlatformType)
  },
  // 获取渠道的同步信息
  getChannelSyncDataList (projectid, platformtype) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/copylist/projectid/' + projectid + '/platformtype/' + platformtype)
  },
  // 提交渠道的同步信息
  postChannelSyncInfo (type, sourceid, targetid) {
    if (type === 'ios') {
      return request.post(PROXY_DEV_API + '/iosProjectChannels/copy/sourceid/' + sourceid + '/targetid/' + targetid)
    } else {
      return request.post(PROXY_DEV_API + '/androidProjectChannels/copy/sourceid/' + sourceid + '/targetid/' + targetid)
    }
  },
  // 获取签名配置信息接口
  getKeystoreConfigDataInfo (projectid) {
    return request.get(PROXY_DEV_API + '/androidGameKeystores/' + projectid)
  },
  getKeystoreConfigV2DataInfo (projectid) {
    return request.get(PROXY_DEV_API + '/androidGameKeystores/v2/' + projectid)
  },
  postKeystoreConfigV2DataInfo (params) {
    return request.post(PROXY_DEV_API + '/androidGameKeystores/v2', params)
  },
  // 包名配置信息接口
  getPackNameConfigDataInfo (params) {
    return request.get(PROXY_DEV_API + '/androidGamePackages', params)
  },
  // 包名配置信息接口
  postPackNameConfigDataInfo (params) {
    return request.post(PROXY_DEV_API + '/androidGamePackages', params)
  },
  // 获取安卓项目渠道分享开关配置
  getShareSwitchDataInfo (type, id) {
    if (type === 'android') {
      return request.get(PROXY_DEV_API + '/androidProjectChannels/sharePlug/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/iosProjectChannels/sharePlug/' + id)
    }
  },
  postShareSwitchDataInfo (type, params) {
    if (type === 'android') {
      return request.post(PROXY_DEV_API + '/androidProjectChannels/sharePlug', params)
    } else {
      return request.post(PROXY_DEV_API + '/iosProjectChannels/sharePlug', params)
    }
  },
  // 获取配置信息
  getIOSPermissionDataInfo (id, type) {
    if (type === 'game') {
      return request.get(PROXY_DEV_API + '/iosPermissions/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/iosPermissions/v2/' + id)
    }
  },
  // 提交配置信息
  putIOSPermissionDataInfo (id, param, type) {
    if (type === 'game') {
      return request.put(PROXY_DEV_API + '/iosPermissions/' + id, param)
    } else {
      return request.put(PROXY_DEV_API + '/iosPermissions/v2/' + id, param)
    }
  },
  // 获取配置信息
  getGameBulgyDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/' + id)
  },
  // 母包SDK制定接口
  putBareSdkMain (type, id) {
    return request.put(PROXY_DEV_API + '/gameProjectAssets/defaultChannel/' + id + '/platformtype/' + type)
  },
  // 关联插件列表
  getGameChannelRelevancePluginList (id, type) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosProjectChannels/list/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/androidProjectChannels/pluginlist/' + id)
    }
  },
  getGameChannelRelevancePluginListV1 (type, gameId, iProjectChannelId, channelAlias) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/platform/' + type + '/game/' + gameId + '/' + iProjectChannelId + '/channel/' + channelAlias)
  },
  getGameChannelRelevancePluginConfigDataInfo (id) {
    return request.get(PROXY_DEV_API + '/androidProjectChannels/plugin/' + id)
  },
  putGameChannelRelevancePluginConfigData (param) {
    return request.put(PROXY_DEV_API + '/androidProjectChannels/plugin', param)
  },
  getGameSubcribesDataList (id) {
    return request.get(PROXY_DEV_API + '/gameSubcribes/' + id)
  },
  postGameSubcribesDataList (id, param) {
    return request.post(PROXY_DEV_API + '/gameSubcribes/gameId/' + id + '/subcribe', param)
  },
  postGameChannelPluginsParam (param) {
    return request.post(PROXY_DEV_API + '/productChannelPlugins/V1', param)
  }
}
