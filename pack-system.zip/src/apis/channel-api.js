/**
 * Created by huangjinbiao on 2017/7/5.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameChannels/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/gameChannels', params)
  },
  // 数据列表
  getDropDownDataList (id) {
    return request.get(PROXY_DEV_API + '/gameChannels/platform/' + id)
  },
  // 数据列表
  getAllDataList (areaid, platformid, languageid) {
    return request.get(PROXY_DEV_API + '/packPlanRecords/channels/areaid/' + areaid + '/platformid/' + platformid + '/languageid/' + languageid)
  },
  // 新增数据
  addDataInfo (type, params) {
    return request.post(PROXY_DEV_API + '/gameChannels/type/' + type, params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/gameChannels', params)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/gameChannels/' + id + '/status/' + status)
  },
  // 版本数据信息
  getVersionDataInfo (type, id) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosChannelConfigs/' + id)
    } else {
      return request.get(PROXY_DEV_API + '/androidChannelConfigs/' + id)
    }
  },
  // 版本数据列表
  getVersionDataList (type, channelId, params) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosChannelConfigs/channel/' + channelId, params)
    } else {
      return request.get(PROXY_DEV_API + '/androidChannelConfigs/channels/' + channelId, params)
    }
  },
  // 数据列表
  getDropDownVersionDataList (type, channelId) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosChannelConfigs/channel/' + channelId)
    } else {
      return request.get(PROXY_DEV_API + '/androidChannelConfigs/channels/' + channelId + '/list')
    }
  },
  // 版本新增数据
  addVersionDataInfo (type, params) {
    if (type === 'ios') {
      return request.post(PROXY_DEV_API + '/iosChannelConfigs', params)
    } else {
      return request.post(PROXY_DEV_API + '/androidChannelConfigs', params)
    }
  },
  // 版本修改数据
  updateVersionDataInfo (type, params) {
    if (type === 'ios') {
      return request.put(PROXY_DEV_API + '/iosChannelConfigs', params)
    } else {
      return request.put(PROXY_DEV_API + '/androidChannelConfigs', params)
    }
  },
  // 获取渠道游戏介入数
  getChannelGameDataList (platform, ichannelconfigid) {
    return request.get(PROXY_DEV_API + '/gameChannel/platform/' + platform + '/ichannelconfigid/' + ichannelconfigid)
  },
  // 获取安卓项目渠道分享开关配置
  getShareSwitchDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameChannels/SharePlug/' + id)
  },
  postShareSwitchDataInfo (params) {
    return request.post(PROXY_DEV_API + '/gameChannels/SharePlug', params)
  }
}
