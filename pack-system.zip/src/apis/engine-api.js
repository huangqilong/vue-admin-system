/**
 * Created by huangjinbiao on 2017/7/13.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameEngines/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/gameEngines', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/gameEngines', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/gameEngines', params)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/gameEngines/' + id + '/status/' + status)
  },
  // 平台游戏引擎表
  getPlatEnginDataList (platformId) {
    return request.get(PROXY_DEV_API + '/gameEngines/platform/' + platformId)
  },
  // 获取引擎游戏介入数
  getEnginGameDataList (engineId) {
    return request.get(PROXY_DEV_API + '/gameEnine/projectgames/' + engineId)
  }
}
