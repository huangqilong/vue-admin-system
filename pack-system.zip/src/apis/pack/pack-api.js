/**
 * Created by huangjinbiao on 2017/6/27.
 */
import request from '../../utils/request'

export default {
  //获取游戏列表
  getGameList(){
    return request.get('/home/packstep/game/list')
  },
  //获取版本列表
  getVersionList(){
    return request.get('/home/packstep/version/list')
  },
  //获取渠道列表
  getChannelList(){
    return request.get('/home/packstep/channel/list')
  },
  //获取插件列表
  getPlugInList(){
    return request.get('/home/packstep/plugin/list')
  },
  //获取打包列表
  getPackList(){
    return request.get('/home/pack/list')
  }



}
