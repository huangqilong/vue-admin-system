/**
 * Created by huangjinbiao on 2017/12/27.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/projectItems/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/projectItems', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/projectItems', params)
  },
  // 修改数据
  updateDataInfo (params, type) {
    return request.put(PROXY_DEV_API + '/projectItems', params)
  },
  // 关联渠道数据信息列表
  getOperatorDataList (id, params) {
    return request.get(PROXY_DEV_API + '/operatorSettings/iitemid/' + id, params)
  },
  getOperatorDataListAll (id) {
    return request.get(PROXY_DEV_API + '/operatorSettings/list/iitemid/' + id)
  },
  getOperatorDataInfo (id) {
    return request.get(PROXY_DEV_API + '/operatorSettings/' + id)
  },
  addOperatorDataInfo (id, params) {
    return request.post(PROXY_DEV_API + '/operatorSettings/iitemid/' + id, params)
  },
  updateOperatorDataInfo (params) {
    return request.put(PROXY_DEV_API + '/operatorSettings', params)
  }
}
