/**
 * Created by huangjinbiao on 2017/6/23.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'
export default {
  toLogin (params) {
    return request.post(PROXY_DEV_API + '/user/login', params)
  },
  toLogout () {
    return request.post(PROXY_DEV_API + '/user/logout')
  },
  judgeSystemVersion () {
    return request.get(PROXY_DEV_API + '/sysConfigs/md5')
  }
}
