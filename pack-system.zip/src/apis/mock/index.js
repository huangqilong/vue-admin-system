/**
 * Created by lichb on 2017/2/10.
 */
import MockFetch from 'mock-fetch-api'
import gameList from './data/gameList'
import versionList from './data/versionList'
import channelList from './data/channelList'
import pluginList from './data/pluginList'
import packList from './data/packList'
import gameList2 from './data/gameList2'
export default {
  start(){
    // MockFetch.when('GET','/login').respondWith(200, '{"userName":"黄金彪","tokens":"6C15B16A70AE9FEDC6546343E79103532AB88DCE1B91B0DF77BE49AE9F493D04"}');
    MockFetch.when('GET','/home/packstep/game/list').respondWith(200,JSON.stringify(gameList));
    MockFetch.when('GET','/home/packstep/version/list').respondWith(200,JSON.stringify(versionList));
    MockFetch.when('GET','/home/packstep/channel/list').respondWith(200,JSON.stringify(channelList));
    MockFetch.when('GET','/home/packstep/plugin/list').respondWith(200,JSON.stringify(pluginList));
    MockFetch.when('GET','/home/pack/list').respondWith(200,JSON.stringify(packList));

    //游戏管理
    MockFetch.when('GET','/game/list').respondWith(200,JSON.stringify(gameList2));
    MockFetch.when('POST','/game/add').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/game/update').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/game/update/status').respondWith(200,'{"code":"1"}');
    MockFetch.when('GET','/game/version/list').respondWith(200,JSON.stringify(gameList2));
    MockFetch.when('GET','/game/config/list/ios').respondWith(200,JSON.stringify(gameList2));
    MockFetch.when('GET','/game/config/info/ios').respondWith(200,JSON.stringify(gameList2[0]));
    MockFetch.when('GET','/game/config/ios/channel/list').respondWith(200,JSON.stringify(gameList2));

    //渠道管理
    MockFetch.when('GET','/channel/list').respondWith(200,JSON.stringify(gameList2));
    MockFetch.when('POST','/channel/add').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/channel/update').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/channel/update/status').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/channel/version/add').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/channel/version/update').respondWith(200,'{"code":"1"}');

    //IOS证书管理
    MockFetch.when('GET','/cert/list').respondWith(200,JSON.stringify(gameList2));


    //字典管理
    MockFetch.when('GET','/dictionary/list').respondWith(200,JSON.stringify(gameList2));
    MockFetch.when('POST','/dictionary/add').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/dictionary/update').respondWith(200,'{"code":"1"}');
    MockFetch.when('POST','/dictionary/update/status').respondWith(200,'{"code":"1"}');


  }
}
