/**
 * Created by huangjinbiao on 2017/8/10.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/sysConfigs/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/sysConfigs', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/sysConfigs', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/sysConfigs', params)
  },
  // 数据信息
  deleteDataInfo (id) {
    return request.delete(PROXY_DEV_API + '/sysConfigs/' + id)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/sysConfigs/' + id + '/status/' + status)
  }
}
