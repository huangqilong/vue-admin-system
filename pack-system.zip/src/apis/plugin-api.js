/**
 * Created by huangjinbiao on 2017/7/13.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/gamePlugins', params)
  },
  // 获取渠道的插件列表
  getChannelPluginList (type, id, platformId) {
    if (type === 'game') {
      return request.get(PROXY_DEV_API + '/gamePluginVersionConfigs/game/' + id + '/platform/' + platformId)
    } else if (type === 'channel') {
      return request.get(PROXY_DEV_API + '/channelPluginVersionConfigs/channel/' + id + '/platform/' + platformId)
    } else {
      return request.get(PROXY_DEV_API + '/projectChannelPluginVersionConfigs/channel/' + id + '/platform/' + platformId)
    }
  },
  // 新增渠道的插件
  addChannelPlugin (type, params) {
    if (type === 'game') {
      return request.post(PROXY_DEV_API + '/gamePluginVersionConfigs', params)
    } else if (type === 'channel') {
      return request.post(PROXY_DEV_API + '/channelPluginVersionConfigs', params)
    } else {
      return request.post(PROXY_DEV_API + '/projectChannelPluginVersionConfigs', params)
    }
  },
  addChannelPluginV2 (type, id, params) {
    return request.post(PROXY_DEV_API + '/projectChannelPluginVersionConfigs/' + id + '/platformtype/' + type, params)
  },
  // 版本数据列表
  getVersionDataList (type, pluginId, params) {
    if (type === 'ios') {
      return request.get(PROXY_DEV_API + '/iosChannelConfigs/plugins/' + pluginId, params)
    } else {
      return request.get(PROXY_DEV_API + '/androidChannelConfigs/plugins/' + pluginId, params)
    }
  },
  // 获取安卓插件(包含上个版本)
  getPreVersionDataInfo (id, pluginId) {
    return request.get(PROXY_DEV_API + '/androidChannelConfigs/' + id + '/' + pluginId)
  },
  // 插件参数配置接口
  // 插件参数配置数据信息
  getGcConfigDataInfo (id) {
    return request.get(PROXY_DEV_API + '/productChannelPlugins/' + id)
  },
  // 插件参数配置数据列表
  getGcConfigDataList (params) {
    return request.get(PROXY_DEV_API + '/productChannelPlugins', params)
  },
  // 插件参数配置新增数据
  addGcConfigDataInfo (params) {
    return request.post(PROXY_DEV_API + '/productChannelPlugins', params)
  },
  // 插件参数配置数据状态修改
  updateGcConfigDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/productChannelPlugins/' + id + '/status/' + status)
  },
  // 获取插件版本表列表
  getPluginDataList (pluginType, params) {
    return request.get(PROXY_DEV_API + '/gamePlugins/version/' + pluginType, params)
  }
}
