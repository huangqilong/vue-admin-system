/**
 * Created by huangjinbiao on 2017/10/17.
 */
export default {
  /**
   * 获取计划状态
   * @param status
   * @param type{0:渠道包,1:母包,2:整包,3:广告码包,4:cps包}
   * @returns {planStatus}
   */
  getPlanStatus (status, type) {
    var barePackStatus = {
      '0': '待上传',
      '5': '待打包',
      '6': '排队中',
      '10': '打包中',
      '15': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">打包失败</span>',
      '20': '<span class="plan-process-status" style="color: #fff;background-color: #90a4ae;">待自测</span>',
      '25': '<span class="plan-process-status" style="color: #fff;background-color: #1976d2;">待质检</span>',
      '26': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">被驳回</span>',
      '30': '<span class="plan-process-status" style="color: #13ce66;">质检通过</span>',
      '31': '待选择渠道',
      '35': '待项目经理审批',
      '40': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">项目经理驳回</span>'
    }
    var channelPackStatus = {
      '0': '待接入',
      '1': '待检测',
      '5': '待打包',
      '6': '排队中',
      '10': '打包中',
      '15': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">打包失败</span>',
      '20': '<span class="plan-process-status" style="color: #fff;background-color: #90a4ae;">待自测</span>',
      '25': '<span class="plan-process-status" style="color: #fff;background-color: #1976d2;">待质检</span>',
      '26': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">被驳回</span>',
      '30': '<span class="plan-process-status" style="color: #13ce66;">质检通过</span>',
      '31': '<span style="color: #bbb;">无需质检</span>'
    }
    var installPackStatus = {
      '0': '待打包',
      '5': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">打包失败</span>',
      '6': '排队中',
      '10': '打包中',
      '15': '<span class="plan-process-status" style="color: #fff;background-color: #1976d2;">待质检</span>',
      '20': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">被驳回</span>',
      '25': '<span class="plan-process-status" style="color: #13ce66;">质检通过</span>',
      '30': '渠道审核中',
      '35': '<span class="plan-process-status" style="color: #13ce66;">渠道审核通过</span>',
      '40': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">渠道审核未通过</span>'
    }
    var advPackStatus = {
      '0': '待打包',
      '6': '排队中',
      '10': '打包中',
      '15': '<span class="plan-process-status" style="color: #fff;background-color: #1976d2;">待质检</span>',
      '20': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">被驳回</span>',
      '25': '<span class="plan-process-status" style="color: #13ce66;">质检通过</span>',
      '30': '渠道审核中',
      '35': '<span class="plan-process-status" style="color: #13ce66;">渠道审核通过</span>',
      '40': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">渠道审核未通过</span>'
    }
    var cpsPackStatus = {
      '0': '待打包',
      '6': '排队中',
      '10': '打包中',
      '15': '<span class="plan-process-status" style="color: #fff;background-color: #1976d2;">待质检</span>',
      '20': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">被驳回</span>',
      '25': '<span class="plan-process-status" style="color: #13ce66;">质检通过</span>',
      '30': '渠道审核中',
      '35': '<span class="plan-process-status" style="color: #13ce66;">渠道审核通过</span>',
      '40': '<span class="plan-process-status" style="color: #fff;background-color: #ef5350;">渠道审核未通过</span>'
    }
    if (type === 0) {
      return channelPackStatus[status]
    } else if (type === 1) {
      return barePackStatus[status]
    } else if (type === 2) {
      return installPackStatus[status]
    } else if (type === 3) {
      return advPackStatus[status]
    } else if (type === 4) {
      return cpsPackStatus[status]
    }
  },
  /**
   * 获取图标css
   * @returns {string}
   */
  getPlanIconClass (iconName) {
    let iconClass = ''
    switch (iconName) {
      case '帝王雄心':
        iconClass = 'ext-icon-project-dwxx'
        break
      case 34:
        iconClass = 'ext-icon-project-dwxx'
        break
      case '宫廷计手游':
        iconClass = 'ext-icon-project-gtj'
        break
      case '宫廷计':
        iconClass = 'ext-icon-project-gtj'
        break
      case 32:
        iconClass = 'ext-icon-project-gtj'
        break
      case '幻宠大陆':
        iconClass = 'ext-icon-project-hcdl'
        break
      case 29:
        iconClass = 'ext-icon-project-hcdl'
        break
      case '京门风月':
        iconClass = 'ext-icon-project-jmfy'
        break
      case 26:
        iconClass = 'ext-icon-project-jmfy'
        break
      case '马踏千军':
        iconClass = 'ext-icon-project-mtqj'
        break
      case 28:
        iconClass = 'ext-icon-project-mtqj'
        break
      case '破军天下':
        iconClass = 'ext-icon-project-pjtx'
        break
      case 25:
        iconClass = 'ext-icon-project-pjtx'
        break
      case '熹妃Q传':
        iconClass = 'ext-icon-project-xfqz'
        break
      case 30:
        iconClass = 'ext-icon-project-xfqz'
        break
      case '熹妃传':
        iconClass = 'ext-icon-project-xfz'
        break
      case 18:
        iconClass = 'ext-icon-project-xfz'
        break
      case '诸神幻想':
        iconClass = 'ext-icon-project-zshx'
        break
      case 10002:
        iconClass = 'ext-icon-project-zshx'
        break
      case '安卓':
        iconClass = 'ext-icon-platform-android'
        break
      case 'IOS':
        iconClass = 'ext-icon-platform-ios'
        break
      case '国际':
        iconClass = 'ext-icon-area-guoji'
        break
      case '新马':
        iconClass = 'ext-icon-area-guoji'
        break
      case '日本':
        iconClass = 'ext-icon-area-riben'
        break
      case '大陆':
        iconClass = 'ext-icon-area-zhongguo'
        break
      case '台湾':
        iconClass = 'ext-icon-area-zhongguo'
        break
      case '北美':
        iconClass = 'ext-icon-area-meiguo'
        break
      case '韩国':
        iconClass = 'ext-icon-area-hanguo'
        break
      case '泰国':
        iconClass = 'ext-icon-area-taiguo'
        break
      case '越南':
        iconClass = 'ext-icon-area-yuenan'
        break
    }
    return iconClass
  }
}
