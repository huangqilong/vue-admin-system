/**
 * Created by huangjinbiao on 2017/12/28.
 */

export default {
  arrayEqual (oldArray, newArray) {
    if (!newArray) {
      return false
    }
    if (oldArray.length !== newArray.length) {
      return false
    }
    for (var i = 0, l = oldArray.length; i < l; i++) {
      if (oldArray[i] instanceof Array && newArray[i] instanceof Array) {
        if (!this.arrayEqual(oldArray[i], newArray[i])) {
          return false
        }
      } else if (oldArray[i] instanceof Object && newArray[i] instanceof Object) {
        if (!this.objectEqual(oldArray[i], newArray[i])) {
          return false
        }
      } else if (oldArray[i] !== newArray[i]) {
        return false
      }
    }
    return true
  },
  objectEqual (oldObject, newObject) {
    if (!oldObject) {
      return false
    }
    for (let propName in oldObject) {
      if (oldObject.hasOwnProperty(propName) !== newObject.hasOwnProperty(propName)) {
        return false
      } else if (typeof oldObject[propName] !== typeof newObject[propName]) {
        return false
      }
    }
    for (let propName in newObject) {
      if (oldObject.hasOwnProperty(propName) !== newObject.hasOwnProperty(propName)) {
        return false
      } else if (typeof oldObject[propName] !== typeof newObject[propName]) {
        return false
      }
      if (!oldObject.hasOwnProperty(propName)) {
        continue
      }
      if (oldObject[propName] instanceof Array && newObject[propName] instanceof Array) {
        if (!this.arrayEqual(oldObject[propName], newObject[propName])) {
          return false
        }
      } else if (oldObject[propName] instanceof Object && newObject[propName] instanceof Object) {
        if (!this.objectEqual(oldObject[propName], newObject[propName])) {
          return false
        }
      } else if (oldObject[propName] !== newObject[propName]) {
        return false
      }
    }
    return true
  }
}

