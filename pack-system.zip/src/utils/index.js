/**
 * Created by huangjinbiao on 2017/8/1.
 */
import MSDataTransfer from './dataTranslate.js'
export default {
  MSDataTransfer
}
