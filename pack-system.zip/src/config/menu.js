/**
 * Created by huangjinbiao on 2017/8/7.
 */
export default [
  {'iMenuId': 168,  'cUrl': '/home/plan/list',  'cIcon': 'icon-gongzuojihua',  'children': null,  'label': '计划管理'},
  {'iMenuId': 33, 'cUrl': '', 'cIcon': 'icon-chengyuanguanli', 'label': '管理中心',
    'children':
    [
      {'iMenuId': 284, 'cUrl': '/home/project/list', 'cIcon': 'icon-xiangmuguanli', 'children': null, 'label': '项目管理'},
      {'iMenuId': 34, 'cUrl': '/home/game/list', 'cIcon': 'icon-xitongguanli', 'children': null, 'label': '应用列表'},
      {'iMenuId': 37, 'cUrl': '/home/agency/list', 'cIcon': 'icon-dailishang', 'children': null, 'label': '代理列表'},
      {'iMenuId': 38, 'cUrl': '/home/engine/list', 'cIcon': 'icon-sousuoyinqingchuanbo', 'children': null, 'label': '引擎列表'},
      {'iMenuId': 35, 'cUrl': '/home/channel/list', 'cIcon': 'icon-jinbi', 'children': null, 'label': '渠道列表'},
      {'iMenuId': 36, 'cUrl': '/home/plugin/list', 'cIcon': 'icon-yingyongkuangjiachajian', 'children': null, 'label': '插件列表'},
      {'iMenuId': 172, 'cUrl': '/home/plugin/config/list', 'cIcon': 'icon-canshushezhi', 'children': null, 'label': '插件参数配置'},
      {'iMenuId': 39, 'cUrl': '/home/ioscert/list', 'cIcon': 'icon-zhengshu', 'children': null, 'label': 'IOS证书列表'},
      {'iMenuId': 44, 'cUrl': '/home/dictionary/list', 'cIcon': 'icon-zidian', 'children': null, 'label': '字典列表'},
      {'iMenuId': 45, 'cUrl': '/home/pack/rule/list', 'cIcon': 'icon-dabaocaiji', 'children': null, 'label': '打包规则配置'},
      {'iMenuId': 307, 'cUrl': '/home/pack/machine/list', 'cIcon': 'icon-banbengengxin', 'children': null, 'label': '打包机版本管理'},
      {'iMenuId': 342, 'cUrl': '/home/manager/system/log', 'cIcon': null, 'children': null, 'label': '系统日志'},
      {'iMenuId': 343, 'cUrl': '/home/manager/file/log', 'cIcon': null, 'children': null, 'label': '文件管理'}
    ]
  },
  {'iMenuId': 40, 'cUrl': '', 'cIcon': 'icon-jiaoseguanli', 'label': '用户管理',
    'children': [
    {'iMenuId': 41, 'cUrl': '/home/user/account/list', 'cIcon': 'icon-weibiaoti5', 'children': null, 'label': '账户列表'},
    {'iMenuId': 42, 'cUrl': '/home/user/role/list', 'cIcon': 'icon-jiaosequanxian', 'children': null, 'label': '角色列表'},
    {'iMenuId': 43, 'cUrl': '/home/user/menu/list', 'cIcon': 'icon-menu3caidan3', 'children': null, 'label': '菜单列表'}]
  }
]
