<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="16">
          <bread-crumb-config></bread-crumb-config>
        </el-col>
        <el-col :span="8" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="sysConfigName" label="配置名称" width="250"></el-table-column>
        <el-table-column prop="sysConfigParam" label="配置参数" width="200"></el-table-column>
        <el-table-column prop="sysConfigValue" label="参数值">
          <template scope="scope">
            <div style="text-overflow: ellipsis;overflow: hidden;cursor: pointer;white-space: nowrap;" @click="showSysConfigDialog(scope.$index, dataList)">{{scope.row.sysConfigValue}}</div>
          </template>
        </el-table-column>
        <el-table-column prop="sysConfigRule" label="配置规则"></el-table-column>
        <el-table-column prop="sysConfigStatus" label="状态" width="50">
          <template scope="scope">
            {{scope.row.sysConfigStatus==0?'关闭':'开启'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="150">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].sysConfigStatus==1?'关闭':'开启'}}</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.deleteBtn" @click="deleteDataInfo(scope.$index, dataList)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
    <sysConfigValueDialog v-if="sysConfigValueDialog.dialogFormVisible" :optionData="sysConfigValueDialog"></sysConfigValueDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packRuleApi from '../../apis/pack-rule-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/pack-rule/optionDialog'
  import sysConfigValueDialog from '../../components/pack-rule/sysConfigValueDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      sysConfigValueDialog,
      optionDialog
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        sysConfigValueDialog: {
          sysConfig: null,
          sysConfigValue: '',
          dialogFormVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        packRuleApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          _this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          sysConfigName: '',
          sysConfigParam: '',
          sysConfigValue: '',
          sysConfigRule: '',
          sysConfigStatus: 1
        }
      },
      // 编辑数据
      updateDataInfo ($index, $data) {
        packRuleApi.getDataInfo($data[$index].iConfigId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $data[$index].iConfigId
          let status = $data[$index].sysConfigStatus === 0 ? 1 : 0
          packRuleApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $data[$index].sysConfigStatus = status
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            console.log(error)
          })
        }).catch(() => {
          // 取消操作
        })
      },
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该条数据吗？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          packRuleApi.deleteDataInfo($data[$index].iConfigId).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '信息删除失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      showSysConfigDialog ($index, $data) {
        this.sysConfigValueDialog.sysConfig = $data[$index]
        this.sysConfigValueDialog.sysConfigValue = $data[$index].sysConfigValue
        this.sysConfigValueDialog.dialogFormVisible = true
      }
    }
  }

</script>

