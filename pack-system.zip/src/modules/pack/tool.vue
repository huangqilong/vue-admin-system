<style scoped>
  .tabs-content{
    margin-top: 20px;
  }

</style>
<style>
  .el-table{
    text-align: center;
  }
  .el-table td, .el-table th {
    text-align: center;
    height: 45px;
    font-weight: normal;
    color: #666;
  }
  .el-table th .cell{
    color: #999;
  }
  .pack-tool-form{
    width: 70%;
  }
  .pack-tool-form .el-select{
    width: 100%;
  }
  .pack-tool-form .pack-tool-form-btn{
    width: 100%;
    font-size: 18px;
    letter-spacing: 1em;
  }
</style>

<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <el-tabs v-model="firstTabValue" type="card" class="tabs-content" @tab-click="selectTabFirst">
      <el-tab-pane label="SDK测试" :name="firstTabList[0]" v-if="roleAuthority.sdkTestPack">
        <packToolSdk packType="sdkPack"></packToolSdk>
      </el-tab-pane>
      <el-tab-pane label="游戏测试" :name="firstTabList[1]" v-if="roleAuthority.gameTestPack">
        <packToolRule packType="rulePack"></packToolRule>
      </el-tab-pane>
      <el-tab-pane label="打整包" :name="firstTabList[2]" v-if="roleAuthority.gameInstallPack">
        <packToolInstall packType="channelPack"></packToolInstall>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import packToolRule from '../../components/pack/packToolRule'
  import packToolSdk from '../../components/pack/packToolSdk'
  import packToolInstall from '../../components/pack/packToolInstall'
  export default{
    components: {
      breadCrumbConfig,
      packToolSdk,
      packToolRule,
      packToolInstall
    },
    computed: {
      ...mapGetters([
        'firstTabValue', 'firstTabList', 'roleAuthority'
      ])
    },
    data () {
      return {
      }
    },
    created: function () {
    },
    methods: {
      selectTabFirst (data) {
        this.$store.dispatch('setFirstTabValue', data.name)
      }
    }
  }

</script>
