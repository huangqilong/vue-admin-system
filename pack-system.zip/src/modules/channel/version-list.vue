<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn && channelInfo.cDisplay=='0'" >新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="channelName" label="渠道名称"></el-table-column>
        <el-table-column prop="channelVersion" label="渠道版本"></el-table-column>
        <el-table-column prop="cDesc" label="版本描述"></el-table-column>
        <el-table-column label="接入游戏列表">
          <template scope="scope">
            <a v-if="scope.row.gameNum>0" @click="showJoinUpDialog(scope.$index, dataList)">{{scope.row.gameNum}}</a>
            <span v-if="scope.row.gameNum<=0">{{scope.row.gameNum}}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作" :width="optionType=='ios'?100:200">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.channelConfig && optionType!='ios'&&channelInfo.cDisplay=='0'" @click="configDataInfo(scope.$index, dataList, 'write')">渠道配置</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.showChannelConfig && optionType!='ios'" @click="configDataInfo(scope.$index, dataList, 'read')">查看配置</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionChannelVersion v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionChannelVersion>
    <optionConfig v-if="optionConfigData.dialogFormVisible" :optionData="optionConfigData" :dataInfoForm="configInfoForm"></optionConfig>
    <joinUpGameDialog v-if="joinUpGameData.dialogFormVisible" :optionConfigData="joinUpGameData" :dataInfoForm="joinUpGameList"></joinUpGameDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import channelApi from '../../apis/channel-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionChannelVersion from '../../components/channel/versionDialog'
  import optionConfig from '../../components/channel/configDialog'
  import joinUpGameDialog from '../../components/game/joinUpDialog'
  export default{
    components: {
      breadCrumbConfig,
      pagination,
      optionChannelVersion,
      optionConfig,
      joinUpGameDialog
    },
    data () {
      return {
        routerPathList: ['/home/channel/list', ''],
        optionType: '',
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          title: '',
          channelInfo: null,
          dialogFormVisible: false
        },
        dataInfoForm: null,
        optionConfigData: {
          title: '渠道配置',
          type: '',
          dialogFormVisible: false
        },
        configInfoForm: null,
        joinUpGameList: null,
        joinUpGameData: {
          dialogFormVisible: false
        },
        dataList: null,
        channelInfo: {
          cDisplay: 0
        }
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority'
      ])
    },
    created: function () {
      this.optionType = this.$route.params.type || 'android'
      this.pageData.number = this.pageNumber
      // 获取游戏的信息
      this.getChannelInfo()
      this.searchDataList()
    },
    methods: {
      getChannelInfo () {
        channelApi.getDataInfo(this.$route.query.iChannelId).then((data) => {
          if (data.code === 1) {
            this.channelInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        channelApi.getVersionDataList(this.optionType, this.$route.query.iChannelId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.title = '新增渠道版本'
        this.optionDataDialog.channelInfo = this.channelInfo
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          iChannelId: this.channelInfo.iChannelId,
          channelVersion: '',
          cDesc: '',
          linkUrl: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        let dataId = this.optionType === 'ios' ? data[$index].iIosChannelId : data[$index].iAndrChannelId
        channelApi.getVersionDataInfo(this.optionType, dataId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.title = '修改渠道版本'
            this.optionDataDialog.channelInfo = this.channelInfo
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 配置数据
      configDataInfo ($index, $data, type) {
        let dataId = this.optionType === 'ios' ? $data[$index].iIosChannelId : $data[$index].iAndrChannelId
        channelApi.getVersionDataInfo(this.optionType, dataId).then((data) => {
          if (data.code === 1) {
            this.configInfoForm = data.data
            this.configInfoForm.minSdkVersion = this.configInfoForm.minSdkVersion || 16
            this.configInfoForm.channelVersionValue = $data[$index].channelVersion
            this.configInfoForm.channelVersionExtra = this.configInfoForm.channelVersionExtra || '.+'
            this.configInfoForm.mavenChannelGroup = this.configInfoForm.mavenChannelGroup || 'bjm.channel'
            this.optionConfigData.type = type
            this.optionConfigData.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      showJoinUpDialog ($index, $data) {
        // 获取引擎接入游戏列表
        let dataId = this.optionType === 'ios' ? $data[$index].iIosChannelId : $data[$index].iAndrChannelId
        channelApi.getChannelGameDataList(this.channelInfo.iPlatformId, dataId).then((data) => {
          if (data.code === 1) {
            this.joinUpGameList = data.data.list
            this.joinUpGameData.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }

</script>
