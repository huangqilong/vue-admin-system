<style scoped>
  .main-wrapper {
    width: 100%;
    height: 100%;
    padding: 0;
  }

  .main-header {
    position: fixed;
    top: 0;
    padding: 0;
    min-width: 860px;
    width: 100%;
    height: 60px;
    background: #409EFF;
  }
  .logo-content{
    float: left;
    padding: 6px 0 0 40px;
  }
  .logo-content .main-logo{
    display: block;
    float: left;
  }
  .logo-content span{
    display: block;
    float: left;
    font-size: 22px;
    color: #fff;
    padding-left: 15px;
    padding-top: 8px;
  }
  .user-content{
    float: right;
    font-size: 16px;
    color: #fff;
    padding-top: 20px;
    padding-right: 40px;
  }
  .login-out-btn{
    font-size: 16px;
    color: #fff;
    float: right;
    padding: 4px 10px;
    border-left: 1px #4fc8ff solid;
    margin-left: 10px;
    border-radius: 0;
  }
  .logo-content span.waring-text{
    float: right;
    padding-top: 0px;
    color: #ff0000;
    font-size: 22px;
  }
  .loading-full{
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    background-color: hsla(0,0%,100%,.1);
  }
  .loading-full .loading-icon-div{
    color: #50bfff;
    font-size: 40px;
    position: relative;
    top:45%;
  }
</style>
<style >

</style>
<template>
  <div class="main-wrapper">
    <header class="main-header">
      <div class="logo-content">
        <!--<img src="../../assets/logo.png" class="main-logo">-->
        <span class="logo-text">vue2.0+elementUI2.0后台管理系统</span>
      </div>
      <div class="user-content">
        <span>欢迎您，</span><span>{{cRealName}}</span>
        <el-button type="text" class="login-out-btn" @click="userLogout" :disabled="buttonLoading">退出</el-button>
      </div>
    </header>
    <c-menu></c-menu>
    <c-main></c-main>
    <div class="loading-full" v-if="buttonLoading">
      <div class="loading-icon-div el-icon-loading"></div>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import loginApi from '../../apis/login-api'
  import CMenu from '../../components/CMenu'
  import CMain from '../../components/CMain'

  export default {
    computed: {
      ...mapGetters([
        'cRealName', 'buttonLoading'
      ])
    },
    components: {
      CMenu,
      CMain
    },
    data () {
      return {
        realPath: ''
      }
    },
    created: function () {
      this.realPath = window.location.href
    },
    methods: {
      userLogout () {
        loginApi.toLogout().then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('logout')
            this.$store.dispatch('loginOutDictionaryUpdate')
            this.$store.dispatch('setPackNewIds', [])
            this.$router.push('/login')
          } else {
            this.$alert(data.msg, '退出失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求错误', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
