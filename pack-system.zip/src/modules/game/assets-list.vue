<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn && gameInfo.cDisplay=='0'">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column label="游戏名称">
          <template scope="scope">
            {{gameInfo.gameName}}
          </template>
        </el-table-column>
        <el-table-column label="游戏版本">
          <template scope="scope">
            {{gameVersionInfo.gameAssetsVersion}}
          </template>
        </el-table-column>
        <el-table-column prop="gameAssetsName" label="资源名称"></el-table-column>
        <el-table-column label="资源类型">
          <template scope="scope">
            {{scope.row.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}
          </template>
        </el-table-column>
        <el-table-column label="游戏资源" v-if="false">
          <template scope="scope">
            {{!!scope.row.gameAssetPath?'已上传':'未上传'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="200">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, scope.row, dataList)">编辑</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.channelPage && (new Date(scope.row.dCreate) - new Date(gameConfigOldDate) < 0)"
                         @click="gameChannelConfig(scope.$index, scope.row, dataList)">渠道配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.channelSync && scope.row.channelNum==0"
                         @click="gameChannelSync(scope.$index, scope.row, dataList)">渠道同步</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <assetsDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></assetsDialog>
    <channelSyncDialog v-if="channelSyncData.dialogFormVisible" :optionData="channelSyncData"></channelSyncDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import assetsDialog from '../../components/game/assetsDialog'
  import channelSyncDialog from '../../components/game/channelSyncDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      assetsDialog,
      channelSyncDialog
    },
    data () {
      return {
        routerPathList: [],
        optionType: '',
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          gameInfo: null,
          gameVersionInfo: null,
          isAddRealAsset: false,
          dialogFormVisible: false
        },
        dataInfoForm: null,
        channelSyncData: {
          gameInfo: null,
          gameAssetsInfo: null,
          dialogFormVisible: false
        },
        dataList: null,
        gameInfo: {
          gameName: '',
          cDisplay: 0
        },
        gameVersionInfo: {
          gameAssetsVersion: ''
        }
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'gameAssetsTypeList', 'roleAuthority', 'gameConfigOldDate'
      ])
    },
    created: function () {
      this.optionType = this.$route.params.type || 'android'
      this.routerPathList = ['/home/game/list', '/home/game/list/version/' + this.optionType + '?iProjectId=' + this.$route.query.iProjectId, '']
      this.pageData.number = this.pageNumber
      this.getGameInfo()
      this.getGameVersionInfo()
      this.searchDataList()
    },
    methods: {
      getGameInfo () {
        gameApi.getDataInfo(this.$route.query.iProjectId).then((data) => {
          if (data.code === 1) {
            this.gameInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getGameVersionInfo () {
        gameApi.getVersionDataInfo(this.optionType, this.$route.query.iAssertId).then((data) => {
          if (data.code === 1) {
            this.gameVersionInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
//        let dataId = this.optionType === 'ios' ? this.gameVersionInfo.iIosAssertId : this.gameVersionInfo.iAndrAssertId
        let dataId = this.$route.query.iAssertId
        let type = this.optionType === 'ios' ? 1 : 0

        gameApi.getAssetsDataList(type, dataId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.gameInfo = null
        this.optionDataDialog.gameVersionInfo = null
        this.optionDataDialog.dialogFormVisible = true
        this.optionDataDialog.isAddRealAsset = false
        for (let dItem of this.dataList) {
          if (dItem.cVersionType === '1') {
            this.optionDataDialog.isAddRealAsset = true
          }
        }
        let dataId = this.optionType === 'ios' ? this.gameVersionInfo.iIosAssertId : this.gameVersionInfo.iAndrAssertId
        let type = this.optionType === 'ios' ? 1 : 0
        this.dataInfoForm = {
          iGameAssertId: dataId,
          cVersionType: this.gameAssetsTypeList[0].value,
          cPlatformType: type,
          uploadType: '0',
          gameAssetPath: '',
          gameAssetsName: '',
          assetsName: '',
          resDirId: '',
          resId: '',
          cMd5: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, $item, $data) {
        gameApi.getAssetsDataInfo($item.iProjectAssetId).then((data) => {
          if (data.code === 1) {
            data.data.uploadType = '0'
            this.dataInfoForm = JSON.parse(JSON.stringify(data.data))
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.gameInfo = this.gameInfo
            this.optionDataDialog.gameVersionInfo = this.gameVersionInfo
            this.optionDataDialog.dialogFormVisible = true
            this.optionDataDialog.isAddRealAsset = false
            for (let dItem of this.dataList) {
              if (dItem.cVersionType === '1' && this.dataInfoForm.cVersionType !== '1') {
                this.optionDataDialog.isAddRealAsset = true
              }
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      gameChannelConfig ($index, $item, $data) {
        this.$router.push({path: '/home/game/list/config/' + this.optionType,
          query: {iProjectId: this.$route.query.iProjectId, iAssertId: this.$route.query.iAssertId, iProjectAssetId: $item.iProjectAssetId}})
      },
      gameChannelSync ($index, $item, $data) {
        this.channelSyncData.gameInfo = this.gameInfo
        this.channelSyncData.gameAssetsInfo = $item
        this.channelSyncData.dialogFormVisible = true
      }
    }
  }

</script>
