<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>

</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn && gameInfo.cDisplay=='0'">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column label="游戏名称">
          <template scope="scope">
            {{gameInfo.gameName}}
          </template>
        </el-table-column>
        <el-table-column prop="gameAssetsVersion" label="版本号"></el-table-column>
        <el-table-column prop="sDesc" label="版本描述"></el-table-column>
        <el-table-column label="游戏资源">
          <template scope="scope">
            <a @click="showJoinUpDialog(scope.$index, dataList)" v-if="scope.row.resNum>0">{{scope.row.resNum}}</a>
            <span v-if="scope.row.resNum<=0">{{scope.row.resNum}}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="250">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.assetsPage" @click="gameChannelConfig(scope.$index, dataList)">资源配置</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.channelPage && scope.row.resNum>0 && (new Date(scope.row.dCreate) - new Date(gameConfigOldDate) > 0)" @click="gameAssetsChannelConfig(scope.$index, dataList)">资源渠道配置</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <versionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList" :dataList="dataList"></versionDialog>
    <joinUpAssetsDialog v-if="joinUpDataDialog.dialogFormVisible" :optionData="joinUpDataDialog"></joinUpAssetsDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import versionDialog from '../../components/game/versionDialog'
  import joinUpAssetsDialog from '../../components/game/joinUpAssetsDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      versionDialog,
      joinUpAssetsDialog
    },
    data () {
      return {
        routerPathList: ['/home/game/list', ''],
        optionType: '',
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          gameInfo: null,
          dialogFormVisible: false
        },
        dataInfoForm: null,
        joinUpDataDialog: {
          gameVersionInfo: null,
          dialogFormVisible: false
        },
        dataList: null,
        gameInfo: {
          gameName: '',
          cDisplay: 0
        }
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'gameConfigOldDate'
      ])
    },
    created: function () {
      this.optionType = this.$route.params.type || 'android'
      this.pageData.number = this.pageNumber
      // 获取游戏的信息
      this.getGameInfo()
      this.searchDataList()
    },
    methods: {
      getGameInfo () {
        gameApi.getDataInfo(this.$route.query.iProjectId).then((data) => {
          if (data.code === 1) {
            this.gameInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        gameApi.getVersionDataList(this.optionType, this.$route.query.iProjectId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.gameInfo = null
        this.optionDataDialog.dialogFormVisible = true
        if (this.optionType === 'ios') {
          this.dataInfoForm = {
            iProjectId: this.gameInfo.iProjectId,
            gameAssetsVersion: '',
            sDesc: ''
          }
        } else {
          // 初始化游戏ICON和渠道闪屏
          this.$store.dispatch('projectIconListInit', {'platformType': this.optionType === 'ios' ? 1 : 0, 'source': 0})
          this.dataInfoForm = {
            iProjectId: this.gameInfo.iProjectId,
            gameAssetsVersion: '',
            sDesc: '',
//            keystorePath: '',
//            keyPassword: '',
//            resId: '',
            resDirId: '',
            iconList: [],
            splashList: []
          }
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        let dataId = this.optionType === 'ios' ? data[$index].iIosAssertId : data[$index].iAndrAssertId
        gameApi.getVersionDataInfo(this.optionType, dataId).then((data) => {
          if (data.code === 1) {
            if (this.optionType === 'android') {
              this.$store.dispatch('updateProjectIconDataList', data.data.iconList)
              this.$store.dispatch('updateProjectSplashDataList', data.data.splashList)
            }
            this.dataInfoForm = data.data
            this.optionDataDialog.gameInfo = this.gameInfo
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      gameChannelConfig ($index, $data) {
        let dataId = this.optionType === 'ios' ? $data[$index].iIosAssertId : $data[$index].iAndrAssertId
        this.$router.push({path: '/home/game/list/assets/' + this.optionType, query: {iProjectId: this.$route.query.iProjectId, iAssertId: dataId}})
      },
      gameAssetsChannelConfig ($index, $data) {
        let dataId = this.optionType === 'ios' ? $data[$index].iIosAssertId : $data[$index].iAndrAssertId
        this.$router.push({path: '/home/game/list/assets/channel/' + this.optionType, query: {iProjectId: this.$route.query.iProjectId, iAssertId: dataId}})
      },
      showJoinUpDialog ($index, $data) {
        this.joinUpDataDialog.gameVersionInfo = $data[$index]
        this.joinUpDataDialog.dialogFormVisible = true
      }
    }
  }

</script>
