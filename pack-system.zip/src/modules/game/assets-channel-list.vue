<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>

</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="24" style="text-align: left;">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="24">
          <el-form :inline="true" label-width="85px" class="form-text-desc">
            <el-form-item label="当前游戏：">
              <span style="color:#409EFF;font-size: 16px;">{{gameInfo.gameName}}-{{gameInfo.iAreaName}}地区-{{optionType=='ios'?'IOS':'安卓'}}-{{gameVersionInfo.gameAssetsVersion}}</span>
            </el-form-item>
          </el-form>
        </el-col>
        <el-col :span="24">
          <el-form :inline="true" label-width="85px" class="form-text-desc-2">
            <el-form-item label="资源名称：">
              <el-select size="small" v-model="searchAssertId" placeholder="请选择" @change="searchDataList()">
                <el-option
                  v-for="item in gameAssetsList"
                  :key="item.iProjectAssetId"
                  :label="item.gameAssetsName+'（'+(item.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name)+ '）'"
                  :value="item.iProjectAssetId">
                </el-option>
              </el-select>
            </el-form-item>
            <!--<el-form-item>-->
              <!--<el-button size="small" type="primary" @click="searchDataList()">查询</el-button>-->
            <!--</el-form-item>-->
          </el-form>
        </el-col>
        <el-col :span="20">
          <el-button type="primary" size="small" v-if="roleAuthority.buglyConfig" @click="buglyConfig()">bugly配置</el-button>
          <el-button type="primary" size="small" v-if="roleAuthority.packConfig" @click="gamePackConfig()">打包配置</el-button>
          <el-button type="primary" size="small" v-if="roleAuthority.keystoreConfig && optionType=='android'" @click="keystoreConfig()">签名配置</el-button>
          <el-button type="primary" size="small" v-if="roleAuthority.iOSPermissionConfig && optionType=='ios'" @click="iOSPermissionConfig()">权限配置</el-button>
          <el-button type="primary" size="small" v-if="$route.query.iPlanId && dataList.length > 13" @click="gobackPlanDetail()">返回计划页</el-button>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button type="success" size="small" @click="addDataItem()" v-if="roleAuthority.insertBtn">新增渠道</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column label="母包sdk指定" width="120px">
          <template scope="scope">
            <el-radio v-model="scope.row.iIsMain" label="1" @change="bareGameAssetMain(scope.$index,scope.row, dataList)">&nbsp;</el-radio>
          </template>
        </el-table-column>
        <el-table-column prop="channelName" label="渠道名称" width="200px"></el-table-column>
        <el-table-column prop="channelVersion" label="渠道版本" width="100px"></el-table-column>
        <el-table-column prop="proxyVersion" label="代理版本" width="100px">
          <template scope="scope">
            {{scope.row.proxyVersion?scope.row.proxyVersion:'--'}}
          </template>
        </el-table-column>
        <el-table-column prop="versionCode" label="version code" width="120px" v-if="optionType == 'android'">
          <template scope="scope">
            {{scope.row.versionCode?scope.row.versionCode:'--'}}
          </template>
        </el-table-column>
        <el-table-column prop="versionName" label="version name" width="120px" v-if="optionType == 'android'">
          <template scope="scope">
            {{scope.row.versionName?scope.row.versionName:'--'}}
          </template>
        </el-table-column>
        <el-table-column label="插件明细" width="100px">
          <template scope="scope">
            <a @click="showJoinUpDialog(scope.$index, scope.row, dataList)" v-if="scope.row.pluginCount>0">{{scope.row.pluginCount}}</a>
            <span v-if="scope.row.pluginCount<=0">--</span>
          </template>
        </el-table-column>
        <!--<el-table-column prop="pluginInfo" label="插件明细" :show-overflow-tooltip="true"></el-table-column>-->
        <el-table-column prop="shareInfo" label="分享明细" :show-overflow-tooltip="true">
          <template scope="scope">
            <span v-if="scope.row.isContainShare == 1">{{scope.row.shareInfo}}</span>
            <span v-if="scope.row.isContainShare != 1">--</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="200">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, scope.row, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.relevancePluginConfig" @click="relevancePlugin(scope.$index, scope.row, dataList)">关联插件</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.shareSwitch && scope.row.isContainShare == 1" @click="shareSwitchConfig(scope.$index, scope.row, dataList)">分享开关</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div v-if="$route.query.iPlanId" style="margin-top: 15px;">
      <el-button type="primary" @click="gobackPlanDetail">返回计划页</el-button>
    </div>
    <config-assets-android-dialog v-if="optionType!='ios'&& optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="androidDataInfoForm" :optionCallBack="searchDataList"></config-assets-android-dialog>
    <config-assets-i-o-s-dialog v-if="optionType=='ios'&& optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="iosDataInfoForm" :optionCallBack="searchDataList"></config-assets-i-o-s-dialog>
    <shareSwitchDialog v-if="shareSwitchDataDialog.dialogVisible" :optionData="shareSwitchDataDialog" :shareSwitchData="shareSwitchData" :selectShareSwitch="selectShareSwitch"></shareSwitchDialog>
    <relevance-plugin-game-channel v-if="relevancePluginDataDialog.dialogFormVisible" :optionData="relevancePluginDataDialog" :optionCallBack="searchDataList"></relevance-plugin-game-channel>
    <configDialog v-if="configDataDialog.dialogVisible" :optionData="configDataDialog"></configDialog>
    <optionGameConfigDialog v-if="optionGameConfigDataDialog.dialogVisible" :optionData="optionGameConfigDataDialog" :dataInfoForm="dataInfoForm"></optionGameConfigDialog>
    <ios-permission-dialog v-if="iosPermissionDataDialog.dialogFormVisible" :optionData="iosPermissionDataDialog"></ios-permission-dialog>
    <join-up-channel-plugin-dialog v-if="joinUpPluginDataDialog.dialogFormVisible" :optionData="joinUpPluginDataDialog"></join-up-channel-plugin-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import configAssetsIOSDialog from '../../components/game/configAssetsIOSDialog'
  import configAssetsAndroidDialog from '../../components/game/configAssetsAndroidDialog'
  import shareSwitchDialog from '../../components/game/shareSwitchDialog'
  import relevancePluginGameChannel from '../../components/game/relevancePluginGameChannel'
  import configDialog from '../../components/game/configDialog'
  import optionGameConfigDialog from '../../components/game/optionGameConfigDialog'
  import iosPermissionDialog from '../../components/game/iosPermissionDialog'
  import joinUpChannelPluginDialog from '../../components/game/joinUpChannelPluginDialog'
  export default{
    components: {
      breadCrumbConfig,
      configAssetsIOSDialog,
      configAssetsAndroidDialog,
      shareSwitchDialog,
      relevancePluginGameChannel,
      configDialog,
      optionGameConfigDialog,
      iosPermissionDialog,
      joinUpChannelPluginDialog
    },
    data () {
      return {
        isMainBareSdk: 1,
        gameAssetsList: [],
        searchAssertId: '',
        routerPathList: [],
        optionType: '',
        optionDataDialog: {
          type: 'add',
          gameInfo: null,
          dialogFormVisible: false
        },
        iosDataInfoForm: {
          channelName: ''
        },
        shareSwitchData: '',
        shareSwitchDataDialog: {
          title: '',
          dialogVisible: false
        },
        androidDataInfoForm: null,
        dataList: [],
        gameInfo: {
          gameName: '',
          cDisplay: 0
        },
        gameVersionInfo: {
          gameAssetsVersion: ''
        },
        relevancePluginDataDialog: {
          title: '',
          type: 'assetsChannel',
          gameInfo: null,
          projectChannelInfo: null,
          dialogFormVisible: false
        },
        configDataDialog: {
          title: '',
          type: 'gameChannel',
          gameInfo: null,
          iProjectAssetId: '',
          dialogVisible: false
        },
        optionGameConfigDataDialog: {
          title: '',
          type: 'bugly',
          dialogVisible: false
        },
        dataInfoForm: null,
        iosPermissionDataDialog: {
          iProjectId: '',
          iProjectAssetId: '',
          title: '',
          type: 'gameChannel',
          gameInfo: null,
          dialogFormVisible: false
        },
        joinUpPluginDataDialog: {
          title: '',
          channelInfo: null,
          pluginDataList: [],
          dialogFormVisible: false
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'pageNumber', 'signatureTypeList', 'iosSystemVersionList', 'roleAuthority', 'gameAssetsTypeList'
      ])
    },
    created: function () {
//      this.pageData.number = this.pageNumber
      this.optionType = this.$route.params.type || 'android'
      this.routerPathList = [
        '/home/game/list',
        '/home/game/list/version/' + this.optionType + '?iProjectId=' + this.$route.query.iProjectId,
        ''
      ]
      this.getGameInfo()
      this.getGameVersionInfo()
      this.getGameAssetsList()
    },
    methods: {
      getGameInfo () {
        gameApi.getDataInfo(this.$route.query.iProjectId).then((data) => {
          if (data.code === 1) {
            this.gameInfo = data.data
            for (const pItem of this.areaList) {
              if (pItem.iDicId === this.gameInfo.iAreaId) {
                this.gameInfo.iAreaName = pItem.sDicName
              }
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getGameVersionInfo () {
        gameApi.getVersionDataInfo(this.optionType, this.$route.query.iAssertId).then((data) => {
          if (data.code === 1) {
            this.gameVersionInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getGameAssetsList () {
        let _this = this
        const params = {'currentPage': 1, 'number': 9999}
        // 获取数据列表
        let dataId = this.$route.query.iAssertId
        let type = this.optionType === 'ios' ? 1 : 0

        gameApi.getAssetsDataList(type, dataId, params).then((data) => {
          if (data.code === 1) {
            _this.gameAssetsList = data.data.list
            if (data.data.list.length > 0) {
              if (_this.$route.query.iProjectAssetId) {
                _this.searchAssertId = Number.parseInt(_this.$route.query.iProjectAssetId)
              } else {
                _this.searchAssertId = data.data.list[0].iProjectAssetId
                for (let item of data.data.list) {
                  if (item.cVersionType === '1') {
                    _this.searchAssertId = item.iProjectAssetId
                  }
                }
              }
              _this.searchDataList()
            }
          } else {
            this.gameAssetsList = []
            _this.searchAssertId = ''
          }
        }, (error) => {
          this.gameAssetsList = []
          _this.searchAssertId = ''
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': 1, 'number': 9999}
        // 获取数据列表
        gameApi.getConfigDataList(this.optionType, this.searchAssertId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
          }
        }, (error) => {
          console.log(error)
          this.dataList = []
        })
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.gameInfo = this.gameInfo
        this.optionDataDialog.dialogFormVisible = true
        // 初始化游戏ICON和渠道闪屏
        this.$store.dispatch('projectIconListInit', {'platformType': this.optionType === 'ios' ? 1 : 0, 'source': 1})
        if (this.optionType === 'ios') {
          this.iosDataInfoForm = {
            iProjectAssetId: this.searchAssertId,
            iChannelId: '',
            iChannelConfigId: '',
            iMiddleareId: '',
            iCertId: '',
            buglyId: '',
            buglyKey: '',
            bundleId: '',
            cCertType: this.signatureTypeList[0].iDicId,
            minIosVersion: this.iosSystemVersionList[0].iDicId,
            resDirId: '',
            resId: '',
            keystorePath: '',
            extraResPath: '',
            extraResId: '',
            cProjectName: 'BJMPublish',
            buildVersion: '',
            iUseAppstore: 0,
            iUseImessage: 0,
            imessageCertId: '',
            imessageBundleId: '',
            imessageResId_pp1: '',
            imessageResId_ppim: '',
            imessageResId_ppim1: '',
            imessageResDirId: '',
            imessagePathPp1: '',
            imessagePathPpim: '',
            imessagePathPpim1: '',
            iosWhiteVOList: [],
            iosUrlSchemeVOList: [],
            iosPlistVOList: [],
            entitlementsVOList: [],
            iconList: [],
            splashList: []
          }
        } else {
          this.androidDataInfoForm = {
            iProjectAssetId: this.searchAssertId,
            iChannelId: '',
            iChannelConfigId: '',
            iMiddleareId: '',
            versionCode: '',
            versionName: '',
            packageName: '',
            keystorePath: '',
            resId: '',
            resDirId: '',
            extraResPath: '',
            extraResId: '',
            keyPassword: '',
            minVersion: '',
            targetVersion: '',
            cDex: '0',
            crcValue: '',
            publicKey: '',
            buglyId: '',
            buglyKey: '',
            iRate: '',
            cMetadata: 0,
            metaData: '',
            iconList: [],
            splashList: [],
//            minSdkVersion: '',
//            targetSdkVersion: '',
            channelVersionValue: '',
            channelVersionExtra: '',
            mavenChannelName: '',
            mavenChannelGroup: '',
//            applicationName: '',
//            specChannelConfig: '',
            cWxjar: '0',
            cSpeHand: '0',
            spePath: '',
            speFileName: '',
            speContent: '',
            cLauncher: '',
            cRequestParams: '0'
          }
        }
      },
      // 编辑数据
      updateDataInfo ($index, $item, data) {
        gameApi.getConfigV2DataInfo(this.optionType, $item.iProjectChannelId).then((data) => {
          if (data.code === 1) {
            const dataInfo = this.optionType === 'ios' ? data.data[0] : data.data
            this.$store.dispatch('updateProjectIconDataList', dataInfo.iconList || [])
            this.$store.dispatch('updateProjectSplashDataList', dataInfo.splashList || [])
            if (this.optionType === 'ios') {
              this.iosDataInfoForm = dataInfo
              this.$set(this.iosDataInfoForm, 'imessagePathPp1', '')
              this.$set(this.iosDataInfoForm, 'imessagePathPpim', '')
              this.$set(this.iosDataInfoForm, 'imessagePathPpim1', '')
            } else {
              this.androidDataInfoForm = dataInfo
            }
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.gameInfo = this.gameInfo
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 关联插件
      relevancePlugin ($index, $item, data) {
        this.relevancePluginDataDialog.title = '关联插件（' + $item.channelName + '）'
        this.relevancePluginDataDialog.projectChannelInfo = $item
        this.relevancePluginDataDialog.gameInfo = this.gameInfo
        this.relevancePluginDataDialog.dialogFormVisible = true
      },
      shareSwitchConfig ($index, $item, $data) {
        this.$store.dispatch('addGameChannelInfo', $item)
        gameApi.getShareSwitchDataInfo(this.optionType, $item.iProjectChannelId).then((data) => {
          if (data.code === 1) {
            this.shareSwitchData = data.data
            this.shareSwitchDataDialog.title = '分享开关(' + $item.channelName + ')'
            this.shareSwitchDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      bareGameAssetMain ($index, $item, $data) {
        this.$confirm('指定的sdk在更换母包或首次上传母包后生效！', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          gameApi.putBareSdkMain(this.optionType === 'ios' ? 1 : 0, $item.iProjectChannelId).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          $item.iIsMain = 0
        })
      },
      selectShareSwitch (params) {
        gameApi.postShareSwitchDataInfo(this.optionType, params).then((data) => {
          if (data.code === 1) {
            this.shareSwitchDataDialog.dialogVisible = false
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      gamePackConfig () {
        this.configDataDialog.dialogVisible = true
        this.configDataDialog.title = '打包配置（' + this.gameInfo.gameName + '）'
        this.configDataDialog.gameInfo = this.gameInfo
        this.configDataDialog.iProjectAssetId = this.searchAssertId
      },
      buglyConfig () {
        gameApi.getGameBulgyDataInfo(this.searchAssertId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionGameConfigDataDialog.title = 'bugly配置（' + this.gameInfo.gameName + '）'
            this.optionGameConfigDataDialog.dialogVisible = true
            this.optionGameConfigDataDialog.type = 'bugly'
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      keystoreConfig () {
        // 获取签名配置信息
        gameApi.getKeystoreConfigV2DataInfo(this.searchAssertId).then((data) => {
          if (data.code === 1) {
            this.optionGameConfigDataDialog.title = '签名配置（' + this.gameInfo.gameName + '）'
            this.optionGameConfigDataDialog.dialogVisible = true
            this.optionGameConfigDataDialog.type = 'keystore'
            if (data.data) {
              this.dataInfoForm = data.data
            } else {
              this.dataInfoForm = {
                iProjectAssetId: this.searchAssertId,
                keystorePath: '',
                resId: '',
                resDirId: '',
                keyPassword: '',
                sDemo: ''
              }
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      iOSPermissionConfig () {
        this.iosPermissionDataDialog.iProjectId = this.gameInfo.iProjectId
        this.iosPermissionDataDialog.iProjectAssetId = this.searchAssertId
        this.iosPermissionDataDialog.title = '权限配置（' + this.gameInfo.gameName + '）'
        this.iosPermissionDataDialog.dialogFormVisible = true
      },
      showJoinUpDialog ($index, $item, $data) {
//        gameApi.getGameChannelRelevancePluginList($item.iProjectChannelId, this.optionType).then((data) => {
//          if (data.code === 1) {
//            this.joinUpPluginDataDialog.title = '关联插件列表（' + $item.channelName + '）'
//            this.joinUpPluginDataDialog.channelInfo = $item
//            this.joinUpPluginDataDialog.pluginDataList = data.data
//            this.joinUpPluginDataDialog.dialogFormVisible = true
//          }
//        }, (error) => {
//          console.log(error)
//        })
        gameApi.getGameChannelRelevancePluginListV1(this.optionType === 'ios' ? 1 : 0, this.gameInfo.iProjectId, $item.iProjectChannelId, $item.cChannelAlias).then((data) => {
          if (data.code === 1) {
            this.joinUpPluginDataDialog.title = '关联插件列表（' + $item.channelName + '）'
            this.joinUpPluginDataDialog.channelInfo = $item
            this.joinUpPluginDataDialog.pluginDataList = data.data
            this.joinUpPluginDataDialog.dialogFormVisible = true
          }
        }, (error) => {
          console.log(error)
        })
      },
      gobackPlanDetail () {
        this.$router.push({path: '/home/plan/list/progress', query: {iPlanId: this.$route.query.iPlanId, planTab: this.$route.query.planTab}})
      }
    }
  }

</script>
