<style scoped>
  .el-form-item .el-input{
    width: 216px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <div class="option-form">
      <el-form :inline="true" label-width="85px">
        <el-row>
          <el-col :span="20" style="text-align: left;">
            <el-form-item label="用户角色：">
              <el-input size="small" v-model="searchForm.cRoleName" style="width:150px;"></el-input>
            </el-form-item>
            <el-form-item label="状态：">
              <el-select size="small" v-model="searchForm.cStatus" clearable placeholder="请选择" style="width:150px;">
                <el-option
                  v-for="item in [{name:'启用',value:1},{name:'禁用',value:0}]"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item v-if="false">
              <el-button size="small" type="primary" @click="searchDataList()" v-if="roleAuthority.searchBtn">查询</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="4" style="text-align: right;">
            <el-form-item>
              <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn">添加</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="iRoleId" label="角色ID"></el-table-column>
        <el-table-column prop="cRoleName" label="角色名称"></el-table-column>
        <el-table-column prop="cRemark" label="角色描述"></el-table-column>
        <el-table-column label="状态">
          <template scope="scope">
            {{scope.row.cStatus==0?'禁用':'启用'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="300">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].cStatus==1?'禁用':'启用'}}</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.permissionsBindingConfig" @click="configSetting(scope.$index, dataList)">绑定权限</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.rtxInformConfigBtn" @click="rtxInformSetting(scope.$index, dataList)">消息配置</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.deleteBtn" @click="deleteDataInfo(scope.$index, dataList)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import userRoleApi from '../../apis/user-role-api'
//  import menuApi from '../../apis/menu-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/user/optionRoleDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      optionDialog
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        searchForm: {
          cRoleName: '',
          cStatus: ''
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    watch: {
      searchForm: {
        handler: function (newVal) {
          this.searchDataList()
        },
        deep: true
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'roleOptionParams'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.roleOptionParams) {
        this.searchForm.cRoleName = this.roleOptionParams.cRoleName
        this.searchForm.cStatus = this.roleOptionParams.cStatus
      }
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.searchForm}
        // 获取数据列表
        userRoleApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setRoleOptionParams', JSON.parse(JSON.stringify(this.searchForm)))
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          cRoleName: '',
          cRemark: '',
          cStatus: 1
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        userRoleApi.getDataInfo(data[$index].iRoleId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该角色？', '删除角色', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 确定操作
          userRoleApi.deleteDataInfo($data[$index].iRoleId).then((data) => {
            if (data.code === 1) {
              $data.splice($index, 1)
            } else {
              this.$alert(data.msg, '信息删除失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $data[$index].iRoleId
          let status = $data[$index].cStatus === '0' ? '1' : '0'
          userRoleApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $data[$index].cStatus = status
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            console.log(error)
          })
        }).catch(() => {
          // 取消操作
        })
      },
      rtxInformSetting ($index, $data) {
        this.$router.push({path: '/home/user/role/inform', query: {iRoleId: this.dataList[$index].iRoleId}})
      },
      // 版本
      configSetting ($index, $data) {
        this.$router.push({path: '/home/user/role/setting', query: {iRoleId: this.dataList[$index].iRoleId}})
      }
    }
  }

</script>

