<style scoped>
  .content-list{
    border-bottom: 1px solid #ccc;
    border-left: 1px solid #ccc;
    border-right: 1px solid #ccc;
  }
</style>
<style>
  .config-tree-content .el-tree-node__content{
    height: 40px;
    border: 1px solid #ccc;
  }
</style>
<template>
  <div class="content">
    <bread-crumb-config :routerPathList="routerPathList" id="aaa"></bread-crumb-config>
    <div class="content-list">
      <checkout-tree-grid :dataList="dataList" :treeNum="0"></checkout-tree-grid>
      <!--
      <el-tree
        :data="userAllMenuList"
        :show-checkbox="true"
        default-expand-all
        ref="allMenuTree"
         node-key="iMenuId"
        :default-checked-keys="[5]"
        :props="defaultProps">
      </el-tree> -->
    </div>
    <div style="padding:20px 0;">
      <el-button type="primary" @click="submitRoleMenuSetData" v-if="userRoleInfo && userRoleInfo.cStatus==1">确定并返回列表</el-button>
      <el-button type="primary" @click="submitRoleToList" v-if="userRoleInfo && userRoleInfo.cStatus==0">返回列表</el-button>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import userRoleApi from '../../apis/user-role-api'
  import menuApi from '../../apis/menu-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import checkoutTreeGrid from '../../components/manager/checkoutTreeGrid'

  export default{
    components: {
      breadCrumbConfig,
      checkoutTreeGrid
    },
    data () {
      return {
        routerPathList: ['/home/user/role/list', ''],
        dataList: [],
        selectMenuIds: [],
        selectMenuDataList: [],
        defaultProps: {
          children: 'children',
          label: 'cMenuName'
        },
        userRoleInfo: null
//        userAllMenuList: []
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {
      this.getMenuAllList()
      this.getRoleDataInfo()
    },
    methods: {
      getMenuAllList () {
        // 获取菜单列表
        menuApi.getAllDataList().then((data) => {
          if (data.code === 1) {
            /*
            this.userAllMenuList = data.data
            // 获取以选中的权限
            this.getSelectMenuDataList()
            */
            this.dataList = data.data
            // 获取角色选中的菜单列表
            this.getRoleMenuAccessDataList()
          }
        }, (error) => {
          console.log(error)
        })
      },
      getRoleDataInfo () {
        userRoleApi.getDataInfo(this.$route.query.iRoleId).then((data) => {
          if (data.code === 1) {
            this.userRoleInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      /*
      getSelectMenuDataList () {
        menuApi.getSelectMenuDataList(this.$route.query.iRoleId).then((data) => {
          if (data.code === 1) {
            this.$refs.allMenuTree.setCheckedNodes(data.data)
          }
        }, (error) => {
          console.log(error)
        })
      }, */
      getRoleMenuAccessDataList () {
        menuApi.getSelectMenuDataList(this.$route.query.iRoleId).then((data) => {
          if (data.code === 1) {
            for (let item of data.data) {
              this.selectMenuIds.push(item.iMenuId)
            }
            for (let item of this.dataList) {
              this.treeDataDispose(item)
            }
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      treeDataDispose (data) {
        if (data.children) {
          for (let i = 0; i < data.children.length; i++) {
            let item = data.children[i]
            if (typeof data.checkAll === 'undefined') {
              this.$set(data, 'checkAll', false)
              this.$set(data, 'isIndeterminate', false)
            }
            if (item.iParentId > 0 && item.cMenuType === 2) {
              if (typeof data.childrenNode === 'undefined') {
                this.$set(data, 'childrenNode', [])
                this.$set(data, 'childrenNodes', [])
              }
              data.childrenNode.push(item)
              if (this.selectMenuIds.indexOf(item.iMenuId) >= 0) {
                data.childrenNodes.push(item)
              }
              data.children.splice(i, 1)
              i--
            } else {
              this.treeDataDispose(item)
            }
          }
          this.parentHandleChange(data)
        }
      },
      parentHandleChange (parentNode) {
        if (parentNode) {
          let dcCount = 0
          let diCount = 0
          for (let dItem of parentNode.children) {
            if (dItem.checkAll) {
              dcCount++
            }
            if (dItem.isIndeterminate) {
              diCount++
            }
          }
          if (parentNode.childrenNodes) {
            let cNodesCount = 0
            if (parentNode.childrenNodes.length === parentNode.childrenNode.length) {
              cNodesCount = 1
            } else if (parentNode.childrenNodes.length > 0) {
              cNodesCount = -1
            }
            if (dcCount === parentNode.children.length && cNodesCount === 1) {
              parentNode.checkAll = true
              parentNode.isIndeterminate = false
            } else if (dcCount === 0 && diCount === 0 && cNodesCount === 0) {
              parentNode.checkAll = false
              parentNode.isIndeterminate = false
            } else {
              parentNode.checkAll = false
              parentNode.isIndeterminate = true
            }
          } else {
            if (dcCount === parentNode.children.length) {
              parentNode.checkAll = true
              parentNode.isIndeterminate = false
            } else if (dcCount === 0 && diCount === 0) {
              parentNode.checkAll = false
              parentNode.isIndeterminate = false
            } else {
              parentNode.checkAll = false
              parentNode.isIndeterminate = true
            }
          }
        }
      },
      getMenuSelectDataList (dataList) {
        for (let item of dataList) {
          if (item.childrenNodes && item.childrenNodes.length > 0) {
            this.selectMenuDataList = this.selectMenuDataList.concat(item.childrenNodes)
          }
          if (item.children) {
            this.getMenuSelectDataList(item.children)
          }
        }
      },
      submitRoleMenuSetData () {
        const params = {
          'roleID': this.$route.query.iRoleId,
          'sysMenuIdList': []
        }
        this.selectMenuDataList = []
        this.getMenuSelectDataList(this.dataList)
        for (let item of this.selectMenuDataList) {
          params.sysMenuIdList.push(item.iMenuId)
        }
        menuApi.setRoleMenu(params).then((data) => {
          if (data.code === 1) {
            this.$router.push({path: '/home/user/role/list'})
          }
        }, (error) => {
          console.log(error)
        })
      },
      submitRoleToList () {
        this.$router.push({path: '/home/user/role/list'})
      }
    }
  }

</script>
