<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
  .el-form-item .el-input{
    width: 216px;
  }
</style>
<style>
  .content-list-table-tree .el-table .cell{
    word-break: inherit;
    padding-left: 10px;
    padding-right: 10px;
  }
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <bread-crumb-config></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn">添加</el-button>
        </el-col>
      </el-row>
    </div>

    <div class="content-list content-list-table-tree">
      <tableTreeGrid :columns="columns" :tree-structure="true" :default-expand-all="true" :data-source="dataSource"
                     :update-data-call-back="updateDataInfo" :delete-data-call-back="deleteDataInfo"
                     :add-child-call-back="addChildDataItem" :relevance-call-back="relevanceConfig"></tableTreeGrid>
    </div>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import menuApi from '../../apis/menu-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import tableTreeGrid from '../../components/manager/tableTreeGrid'
  import optionDialog from '../../components/user/optionMenuDialog'

  export default{
    components: {
      breadCrumbConfig,
      optionDialog,
      tableTreeGrid
    },
    data () {
      return {
        columns: [
          {
            label: '菜单名称',
            dataIndex: 'cMenuName'
          },
          {
            label: '父菜单',
            dataIndex: 'parentName'
          },
          {
            label: '菜单类型',
            dataIndex: 'typeName'
          },
          {
            label: '排序',
            dataIndex: 'iOrderNum'
          },
          {
            label: '菜单图标',
            dataIndex: 'cIcon'
          },
          {
            label: '菜单路径',
            dataIndex: 'cUrl'
          }
        ],
        dataSource: [],
        optionDataDialog: {
          type: 'add',
          optionType: 'menuList',
          dialogFormVisible: false
        },
        dataInfoForm: null
      }
    },
    computed: {
      ...mapGetters([
        'roleAuthority'
      ])
    },
    created: function () {
      this.searchDataList()
    },
    methods: {
      searchDataList () {
        // 获取数据列表
        menuApi.getDataList().then((data) => {
          if (data.code === 1) {
            this.dataSource = data.data
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          cMenuName: '',
          cMenuType: '',
          cUrl: '',
          cIcon: '',
          iParentId: 0,
          iOrderNum: 0
        }
      },
      // 新增子节点数据窗口回调
      addChildDataItem ($index, $data) {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          cMenuName: '',
          cMenuType: '',
          cUrl: '',
          iOrderNum: 0,
          iParentId: $data[$index].iMenuId
        }
      },
      // 编辑数据
      updateDataInfo ($index, $data) {
        menuApi.getDataInfo($data[$index].iMenuId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该菜单？', '删除菜单', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 确定操作
          menuApi.deleteDataInfo($data[$index].iMenuId).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '菜单删除失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      // 关联功能
      relevanceConfig ($index, $data) {
        this.$router.push({path: '/home/user/menu/operation/list', query: {iParentIds: $data[$index].iMenuId + ''}})
      }
    }
  }

</script>

