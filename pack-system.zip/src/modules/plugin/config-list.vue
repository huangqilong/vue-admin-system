<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="areaName" label="地区" width="100">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.areaName)"></i>{{scope.row.areaName}}
          </template>
        </el-table-column>
        <el-table-column prop="platformName" label="平台" width="100">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.platformName)"></i>{{scope.row.platformName}}
          </template>
        </el-table-column>
        <el-table-column prop="languageName" label="语言" width="150"></el-table-column>
        <el-table-column prop="gameName" label="游戏名称" width="200"></el-table-column>
        <el-table-column prop="sChannelName" label="渠道名称"></el-table-column>
        <el-table-column prop="pluginType" label="插件类型" width="100">
          <template scope="scope">
            {{scope.row.pluginType==1?'功能':'广告'}}
          </template>
        </el-table-column>
        <el-table-column prop="sPlugin" label="插件名称" width="150"></el-table-column>
        <el-table-column
          label="操作" width="200">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.showParams" @click="optionParamsFun(scope.$index, dataList)">参数查看</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.deleteBtn" @click="deleteDataInfo(scope.$index, dataList)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
    <params-option-dialog v-if="optionParamsDataDialog.dialogFormVisible" :optionData="optionParamsDataDialog" :dataInfoForm="dataInfoForm"></params-option-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import pluginApi from '../../apis/plugin-api'
  import planUtil from '../../utils/plan-util'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import optionForm from '../../components/manager/optionForm'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/plugin/optionPcDialog'
  import paramsOptionDialog from '../../components/plugin/paramsOptionDialog'

  export default{
    components: {
      breadCrumbConfig,
      optionForm,
      pagination,
      optionDialog,
      paramsOptionDialog
    },
    data () {
      return {
        optionParams: {
          areaId: '',
          languageId: '',
          platformId: '',
          gameId: ''
        },
        optionData: {
          showArea: true,
          showLanguage: true,
          showPlatform: true,
          showSearchGame: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        optionParamsDataDialog: {
          dialogFormVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        // 获取数据列表
        pluginApi.getGcConfigDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          _this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          iAreaId: this.defaultAreaPlatLanInfo.iAreaId,
          iLanguageId: this.defaultAreaPlatLanInfo.iLanguageId,
          iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
          gameId: '',
          iChannelId: '',
          pluginType: '1',
          pluginDictId: '',
          paramsKey: '',
          paramsValue: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, $data) {
        pluginApi.getGcConfigDataInfo($data[$index].pluginId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该条数据吗？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          pluginApi.updateGcConfigDataStatus($data[$index].pluginId, 0).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '信息删除失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      optionParamsFun ($index, $data) {
        pluginApi.getGcConfigDataInfo($data[$index].pluginId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionParamsDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>

