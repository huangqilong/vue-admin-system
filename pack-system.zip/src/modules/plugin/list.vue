<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="areaName" label="地区" width="150">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.areaName)"></i>{{scope.row.areaName}}
          </template>
        </el-table-column>
        <el-table-column prop="platformName" label="平台" width="150">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.platformName)"></i>{{scope.row.platformName}}
          </template>
        </el-table-column>
        <el-table-column prop="languageName" label="语言" width="200"></el-table-column>
        <el-table-column prop="channelName" label="插件名称"></el-table-column>
        <el-table-column prop="channelTypName" label="插件类型" width="100"></el-table-column>
        <el-table-column prop="sDesc" label="描述" width="200"></el-table-column>
        <el-table-column prop="cDisplay" label="状态" :width="80">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="180">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].cDisplay==0?'下架':'上架'}}</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.versionPage" @click="dataVersion(scope.$index, dataList)">版本列表</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import pluginApi from '../../apis/plugin-api'
  import channelApi from '../../apis/channel-api'
  import planUtil from '../../utils/plan-util'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/plugin/optionDialog'
  import optionForm from '../../components/manager/optionForm'

  export default{
    components: {
      breadCrumbConfig,
      optionForm,
      pagination,
      optionDialog
    },
    data () {
      return {
        optionParams: {
          name: '',
          areaId: '',
          languageId: '',
          platformId: '',
          typeId: '',
          cDisplay: '0'
        },
        optionData: {
          showPluginName: true,
          showArea: true,
          showLanguage: true,
          showPlatform: true,
          showPluginType: true,
          showDataDisplay: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          title: '',
          dialogFormVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo', 'pluginOptionParams'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.pluginOptionParams) {
        this.optionParams.name = this.pluginOptionParams.name
        this.optionParams.areaId = this.pluginOptionParams.areaId
        this.optionParams.languageId = this.pluginOptionParams.languageId
        this.optionParams.platformId = this.pluginOptionParams.platformId
        this.optionParams.typeId = this.pluginOptionParams.typeId
        this.optionParams.cDisplay = this.pluginOptionParams.cDisplay
      }
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        // 获取数据列表
        pluginApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setPluginOptionParams', JSON.parse(JSON.stringify(this.optionParams)))
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.title = ''
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          iAreaId: this.defaultAreaPlatLanInfo.iAreaId,
          iLanguageId: this.defaultAreaPlatLanInfo.iLanguageId,
          iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
          channelName: '',
          channelSign: '',
          channelExtraSign: '',
          channelOtherSign: '',
          relateType: '0',
          typeId: '',
          sDesc: '',
          cReqParam: '0'
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        channelApi.getDataInfo(data[$index].iChannelId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.title = data.data.channelName
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $data[$index].iChannelId
          let status = $data[$index].cDisplay === '0' ? '1' : '0'
          channelApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $data[$index].cDisplay = status
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            console.log(error)
          })
        }).catch(() => {
          // 取消操作
        })
      },
      // 版本
      dataVersion ($index, data) {
        if (this.dataList[$index].platformName === '安卓') {
          this.$router.push({path: '/home/plugin/list/version/android', query: {iChannelId: this.dataList[$index].iChannelId}})
        } else {
          this.$router.push({path: '/home/plugin/list/version/ios', query: {iChannelId: this.dataList[$index].iChannelId}})
        }
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>

