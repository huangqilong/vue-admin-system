<style>
  .search-form-page .el-input {
    width:180px;
  }
</style>
<template>
  <div class="content">
    <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
    <el-row style="margin-top: 15px;margin-bottom: 10px;">
      <el-col :span="21">
        当前渠道：<span style="color: rgb(64, 158, 255);font-size: 16px;">大陆地区-安卓-好玩友</span>
      </el-col>
    </el-row>
    <div class="content-list">
      <div class="summary-progress-tabs">
        <el-tabs class="tabs-content" @tab-click="planChannelSelectTab">
          <el-tab-pane label="更新记录" name="1">
          </el-tab-pane>
          <el-tab-pane label="驳回汇总" name="0">
          </el-tab-pane>
        </el-tabs>
      </div>
      <div class="update-table" v-if="false">
        <el-table :data="updateDataList" stripe>
          <el-table-column prop="channelVersion" label="渠道版本">
            <template scope="scope">
              <div v-if="scope.row.docUrl && scope.row.channelVersion">
                <a class="doc-url-a" :href="scope.row.docUrl" target="_blank">{{scope.row.channelVersion}}</a>
              </div>
              <div v-else>
                {{scope.row.channelVersion ? scope.row.channelVersion : '--'}}
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="channelCheckDate" label="验收通知时间"></el-table-column>
          <el-table-column prop="channelCheckUser" label="验收人"></el-table-column>
          <el-table-column prop="planNum" label="接入计划明细">
            <template scope="scope">
              <a v-if="scope.row.planNum>0" @click="joinUpPlanDetailShow(scope.$index,scope.row,updateDataList)">{{scope.row.planNum}}</a>
              <span v-if="scope.row.planNum<=0">{{scope.row.planNum}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="reject-table">
        <div class="search-form-page">
          <el-row>
            <el-col :span="22">
              <el-form :model="searchDataForm" :inline="true" labelWidth="90px">
                <el-form-item label="应用列表">
                  <el-select size="small" v-model="searchDataForm.gameId" clearable placeholder="请选择">
                    <el-option
                      v-for="item in searchGameList"
                      :key="item.gameId"
                      :label="item.gameName"
                      :value="item.gameId">
                      <span>{{ item.gameName }}</span>
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="事件类型：">
                  <el-select size="small" v-model="searchDataForm.iEventType" clearable placeholder="全部" @change="eventTypeChange">
                    <el-option
                      v-for="item in eventTypeList"
                      :key="item.valueKey"
                      :label="item.valueName"
                      :value="item.valueKey">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="事件名称：" >
                  <el-select size="small" v-model="searchDataForm.iMessageType" clearable placeholder="全部">
                    <el-option
                      v-for="item in eventNameList"
                      :key="item"
                      :label="item"
                      :value="item">
                    </el-option>
                  </el-select>
                </el-form-item>
                <el-form-item>
                  <el-button size="small" type="primary" @click="searchDataList()" v-if="false">查询</el-button>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>
        </div>
        <el-table :data="rejectDataList" stripe>
          <el-table-column prop="iEventType" label="事件类型"></el-table-column>
          <el-table-column prop="messageName" label="事件名称"></el-table-column>
          <el-table-column prop="iProblemType" label="问题归属"></el-table-column>
          <el-table-column prop="cMessge" label="操作内容"></el-table-column>
          <el-table-column prop="reason" label="原因"></el-table-column>
          <el-table-column prop="cOpName" label="责任人"></el-table-column>
          <el-table-column prop="gameName" label="项目名称"></el-table-column>
          <el-table-column prop="gameAssetsVersion" label="游戏版本"></el-table-column>
          <el-table-column prop="channelVersion" label="渠道版本"></el-table-column>
          <el-table-column prop="dCreate" label="操作时间"></el-table-column>
        </el-table>
        <pagination :pageData="pageData"></pagination>
      </div>
    </div>
    <join-up-plan-detail-dialog v-if="joinUpPlanDetailDataDialog.dialogFormVisible" :optionData="joinUpPlanDetailDataDialog"></join-up-plan-detail-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import joinUpPlanDetailDialog from '../../components/plan/joinUpPlanDetailDialog'

  export default {
    components: {
      breadCrumbConfig,
      pagination,
      joinUpPlanDetailDialog
    },
    data () {
      return {
        routerPathList: [],
        updateDataList: [],
        rejectDataList: [],
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        joinUpPlanDetailDataDialog: {
          title: '',
          planDataList: [],
          dialogFormVisible: false
        },
        searchDataForm: {
          cOpName: '',
          iEventType: '',
          iMessageType: '',
          channelName: ''
        },
        eventTypeList: [
          {
            valueKey: 1,
            valueName: '母包进度'
          },
          {
            valueKey: 2,
            valueName: '渠道进度'
          },
          {
            valueKey: 3,
            valueName: '整包进度'
          }
        ],
        eventNameList: []
      }
    },
    searchDataForm: {
      handler: function (newVal) {
//        this.searchDataList()
      },
      deep: true
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'planInfo', 'planProgressSelectedTab', 'searchGameList'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.routerPathList = ['/home/plan/list', '/home/plan/list/progress?iPlanId=' + this.$route.query.iPlanId + '&planTab=' + this.planProgressSelectedTab, '']
      this.getPlanDataInfo()
      this.updateDataList = [
        {
          channelVersion: '1.0.1',
          channelCheckDate: '2018-02-03 12:23:21',
          channelCheckUser: '黄金彪',
          planNum: 1
        },
        {
          channelVersion: '1.1.1',
          channelCheckDate: '2018-02-03 12:23:21',
          channelCheckUser: '黄金彪',
          planNum: 4
        },
        {
          channelVersion: '2.0.1',
          channelCheckDate: '2018-02-03 12:23:21',
          channelCheckUser: '黄金彪',
          planNum: 6
        }
      ]
      this.rejectDataList = [
        {
          iEventType: '渠道进度',
          messageName: '质检驳回',
          iProblemType: 'sdk',
          cMessge: '赵定俊质检驳回了好玩友，驳回原因：【32361】游客呼不出充值',
          reason: 'xxxxxxxxxxxxx',
          cOpName: '张三',
          gameName: '熹妃q传',
          gameAssetsVersion: '1.3.0',
          channelVersion: '3.2.0',
          dCreate: '2018-01-26 19:35:09'
        },
        {
          iEventType: '渠道进度',
          messageName: '质检驳回',
          iProblemType: 'sdk',
          cMessge: '赵定俊质检驳回了好玩友，驳回原因：【32361】游客呼不出充值',
          reason: 'xxxxxxxxxxxxx',
          cOpName: '张三',
          gameName: '熹妃q传',
          gameAssetsVersion: '1.3.0',
          channelVersion: '3.2.0',
          dCreate: '2018-01-26 19:35:09'
        },
        {
          iEventType: '渠道进度',
          messageName: '质检驳回',
          iProblemType: 'sdk',
          cMessge: '赵定俊质检驳回了好玩友，驳回原因：【32361】游客呼不出充值',
          reason: 'xxxxxxxxxxxxx',
          cOpName: '张三',
          gameName: '熹妃q传',
          gameAssetsVersion: '1.3.0',
          channelVersion: '3.2.0',
          dCreate: '2018-01-26 19:35:09'
        }
      ]
    },
    methods: {
      getPlanDataInfo () {
        planApi.getPackPlanDataInfo(this.$route.query.iPlanId).then((data) => {
          if (data.code === 1) {
            data.data.planTime = data.data.dPlanStart.split(' ')[0] + ' ~ ' + data.data.dPlanEnd.split(' ')[0]
            this.$store.dispatch('addPlanInfo', data.data)
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      planChannelSelectTab (data) {
        console.log(data.name)
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
//        this.searchDataList()
      },
      joinUpPlanDetailShow ($index, $item, $data) {
        this.joinUpPlanDetailDataDialog.title = '接入计划列表（' + $item.channelVersion + '）'
        this.joinUpPlanDetailDataDialog.planDataList = []
        this.joinUpPlanDetailDataDialog.dialogFormVisible = true
      },
      eventTypeChange (value) {
        if (value === 1) {
          this.eventNameList = ['打包完成', '质检通过', '质检驳回', '打包失败', '提交质检', '选择渠道', '项目经理通过', '项目经理驳回', '更换母包']
        } else if (value === 2) {
          this.eventNameList = ['打包完成', '质检通过', '质检驳回', '打包失败', '提交质检', '重新接入']
        } else if (value === 3) {
          this.eventNameList = ['打包完成', '质检通过', '质检驳回', '打包失败', '渠道审核中', '渠道通过', '渠道驳回']
        } else {
          this.eventNameList = []
        }
      }
    }
  }
</script>
