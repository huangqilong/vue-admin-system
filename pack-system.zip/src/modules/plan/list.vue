<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="iPlanId" label="编号" width="80"></el-table-column>
        <el-table-column prop="iAreaName" label="地区" width="100" class-name="table-left-th" sortable>
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.iAreaName)"></i>{{scope.row.iAreaName}}
          </template>
        </el-table-column>
        <el-table-column prop="iPlatformName" label="平台" width="100" class-name="table-left-th" sortable>
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.iPlatformName)"></i>{{scope.row.iPlatformName}}
          </template>
        </el-table-column>
        <el-table-column prop="projectName" label="项目名称" width="150" class-name="table-left-th" sortable>
          <template scope="scope">
            <i class="ext-icon-plan-big" :class="getIconClassName(scope.row.projectName)"></i>{{scope.row.projectName ? scope.row.projectName : '--'}}
          </template>
        </el-table-column>
        <el-table-column prop="gameVersion" label="游戏版本" width="100" class-name="table-left-th">
          <template scope="scope">
            {{scope.row.gameVersion ? scope.row.gameVersion : '--'}}
          </template>
        </el-table-column>
        <el-table-column  label="计划名称" class-name="table-left-th">
          <template scope="scope">
            <a @click="planProgress(scope.$index,scope.row, dataList)">{{scope.row.sPackPlanName}}</a>
          </template>
        </el-table-column>
        <el-table-column  prop="iPlanType" label="计划类型" width="100" sortable>
          <template scope="scope">
            <span :style="scope.row.iPlanType==0?'color: #aaa;':''">{{scope.row.iPlanType==planTypeDataList[0].iDicId?planTypeDataList[0].sDicName:planTypeDataList[1].sDicName}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="planTime" label="起止时间" width="190">
          <template scope="scope">
            {{scope.row.dPlanStart.split(' ')[0] + ' ~ ' + scope.row.dPlanEnd.split(' ')[0]}}
          </template>
        </el-table-column>
        <el-table-column  label="打包渠道"  width="100">
          <template scope="scope">
            <a v-if="scope.row.channelNum>0" @click="showPackChannelDialog(scope.$index, scope.row, dataList)">{{scope.row.channelNum}}</a>
            <!--<span v-if="scope.row.channelNum<=0">{{scope.row.channelNum}}</span>-->
          </template>
        </el-table-column>
        <el-table-column  label="广告包"  width="60">
          <template scope="scope">
            <a v-if="scope.row.iPlatformName=='安卓'&& scope.row.adNum>0" @click="showAdPackageDialog(scope.$index, scope.row, dataList)">{{scope.row.adNum}}</a>
            <!--<span v-if="scope.row.iPlatformName=='安卓'&& scope.row.adNum<=0">{{scope.row.adNum}}</span>-->
          </template>
        </el-table-column>
        <el-table-column prop="cpsPack" label="cps包"  width="50">
          <template scope="scope">
            <a v-if="scope.row.iPlatformName=='安卓'&& scope.row.cpsNum>0" @click="showCpsPackageDialog(scope.$index, scope.row, dataList)">{{scope.row.cpsNum}}</a>
            <!--<span v-if="scope.row.iPlatformName=='安卓'&& scope.row.cpsNum<=0">{{scope.row.cpsNum}}</span>-->
          </template>
        </el-table-column>
        <el-table-column prop="cPlanStatusVal" label="状态" width="70">
          <template scope="scope">
            {{scope.row.cPlanStatus==planStatusList[1].iDicId?planStatusList[1].sDicName:planStatusList[0].sDicName}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="60">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.configDetails" @click="showPlanConfig(scope.$index, scope.row, dataList)">详情</el-button>
            <el-button type="text" class="table-option-button" v-if="false && roleAuthority.progressBtn" @click="planProgress(scope.$index, scope.row, dataList)">进度</el-button>
            <el-button type="text" class="table-option-button" v-if="false && roleAuthority.sdkTestAssets" @click="sdkTestAssets(scope.$index, scope.row, dataList)">SDK测试资源</el-button>
            <!--
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="changePlanStatus(scope.$index, scope.row, dataList)">{{scope.row.cPlanStatus==planStatusList[0].iDicId?'结束':'开启'}}</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, scope.row, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.deleteBtn" @click="deleteDataInfo(scope.$index, scope.row, dataList)">删除</el-button> -->
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <packChannelDialog v-if="packChannelDialogSet.dialogFormVisible" :optionConfigData="packChannelDialogSet"  :dataInfoForm="packChannelList"></packChannelDialog>
    <adPackageDialog v-if="adPackageDialogConfig.dialogFormVisible" :optionConfigData="adPackageDialogConfig"  :dataInfoForm="adPackageList"></adPackageDialog>
    <cpsPackageDialog v-if="cpsPackageDialogConfig.dialogFormVisible" :optionConfigData="cpsPackageDialogConfig"  :dataInfoForm="cpsPackageList"></cpsPackageDialog>
    <plan-detail-config v-if="planDetailDialogConfig.dialogFormVisible" :optionData="planDetailDialogConfig"
                        :changeStatusCallbackFun="changePlanStatus" :updateCallbackFun="updateDataInfo" :deleteCallbackFun="deleteDataInfo"></plan-detail-config>
    <sdk-test-assets-upload-dialog v-if="sdkTestAssetsUpload.dialogFormVisible" :optionData="sdkTestAssetsUpload"></sdk-test-assets-upload-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  import planUtil from '../../utils/plan-util'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import optionForm from '../../components/manager/optionForm'
  import pagination from '../../components/manager/pagination'
  import packChannelDialog from '../../components/plan/packChannelDialog'
  import adPackageDialog from '../../components/plan/adPackageDialog'
  import cpsPackageDialog from '../../components/plan/cpsPackageDialog'
  import planDetailConfig from '../../components/plan/planDetailConfig'
  import sdkTestAssetsUploadDialog from '../../components/plan/sdkTestAssetsUploadDialog'

  export default {
    components: {
      breadCrumbConfig,
      optionForm,
      pagination,
      packChannelDialog,
      adPackageDialog,
      cpsPackageDialog,
      planDetailConfig,
      sdkTestAssetsUploadDialog
    },
    data () {
      return {
        optionParams: {
          areaId: '',
          platformId: '',
          gameId: '',
          cPlanStatus: '0',
          iPlanType: ''
        },
        optionData: {
          showArea: true,
          showPlatform: true,
          showSearchBtn: true,
          showLaunchPlanBtn: true,
          showSearchGame: true,
          showPlanStatus: true,
          showPlanType: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        dataList: [],
        dataInfoForm: null,
        packChannelDialogSet: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        adPackageDialogConfig: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        cpsPackageDialogConfig: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        planDetailDialogConfig: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        packChannelList: '',
        adPackageList: [],
        cpsPackageList: [],
        sdkTestAssetsUpload: {
          dialogFormVisible: false
        }
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'planStatusList', 'planInfo', 'planOptionParams', 'planTypeDataList'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.planOptionParams) {
        this.optionParams.areaId = this.planOptionParams.areaId
        this.optionParams.platformId = this.planOptionParams.platformId
        this.optionParams.gameId = this.planOptionParams.gameId
        this.optionParams.cPlanStatus = this.planOptionParams.cPlanStatus
        this.optionParams.iPlanType = this.planOptionParams.iPlanType
      }
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
//         获取数据列表
        planApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setPlanOptionParams', JSON.parse(JSON.stringify(this.optionParams)))
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.$router.push('/home/plan/option/add')
      },
      // 编辑接口
      updateDataInfo ($index, $data) {
        if ($index && $data) {
          this.$store.dispatch('addPlanInfo', this.dataList[$index])
        }
        this.$router.push({path: '/home/plan/option/update', query: {iPlanId: this.planInfo.iPlanId}})
      },
      // 删除数据
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该条计划？', '删除计划', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 确定操作
          let iPlanId = ''
          if ($index && $data) {
            iPlanId = $data[$index].iPlanId
          } else {
            iPlanId = this.planInfo.iPlanId
          }
          planApi.deleteDataInfo(iPlanId).then((data) => {
            this.searchDataList()
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
            // 取消操作
        })
      },
      changePlanStatus ($index, $data) {
        let iPlanId = ''
        let cPlanStatus = ''
        if ($index && $data) {
          iPlanId = $data[$index].iPlanId
          cPlanStatus = $data[$index].cPlanStatus === this.planStatusList[0].iDicId ? this.planStatusList[1].iDicId : this.planStatusList[0].iDicId
        } else {
          iPlanId = this.planInfo.iPlanId
          cPlanStatus = this.planInfo.cPlanStatus === this.planStatusList[0].iDicId ? this.planStatusList[1].iDicId : this.planStatusList[0].iDicId
        }
        planApi.changeStatusDataInfo(iPlanId, cPlanStatus).then((data) => {
          this.searchDataList()
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 详情
      showPlanConfig ($index, $item, $data) {
        planApi.getPackPlanDataInfo($item.iPlanId).then((data) => {
          if (data.code === 1) {
            data.data.planTime = data.data.dPlanStart.split(' ')[0] + ' ~ ' + data.data.dPlanEnd.split(' ')[0]
            this.$store.dispatch('addPlanInfo', data.data)
            this.planDetailDialogConfig.dialogCurrentTitle = $item.sPackPlanName
            this.planDetailDialogConfig.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
    //  查看打包渠道
      showPackChannelDialog ($index, $item, $data) {
        let _this = this
        this.packChannelList = []
        const id = $item.iPlanId
        const packType = 2
        planApi.getPackageProgressDataList(id, packType).then((data) => {
          if (data.code === 1) {
            _this.packChannelList = data.data
            this.packChannelDialogSet.dialogCurrentTitle = $item.sPackPlanName
            this.packChannelDialogSet.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.packChannelList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.packChannelList = null
        })
      },
      // 查看广告包
      showAdPackageDialog ($index, $item, $data) {
        planApi.getCpsOrAdvProgressDataList($item.iPlanId, 0).then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('addPlanInfo', $item)
            this.adPackageList = data.data
            this.adPackageDialogConfig.dialogCurrentTitle = $item.sPackPlanName
            this.adPackageDialogConfig.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '数据获取失败', {
              confirmButtonText: '确定'
            })
            this.adPackageList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.adPackageList = null
        })
      },
      // 查看cps包
      showCpsPackageDialog ($index, $item, $data) {
        planApi.getCpsOrAdvProgressDataList($item.iPlanId, 1).then((data) => {
          if (data.code === 1) {
            this.cpsPackageList = data.data
            this.cpsPackageDialogConfig.dialogCurrentTitle = $item.sPackPlanName
            this.cpsPackageDialogConfig.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '数据获取失败', {
              confirmButtonText: '确定'
            })
            this.cpsPackageList = []
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.cpsPackageList = null
        })
      },
      // 进度
      planProgress ($index, $item, $data) {
        this.$store.dispatch('setPlanProgressSelectedTab', '1')
        this.$store.dispatch('addPlanInfo', $item)
        this.$router.push({path: '/home/plan/list/progress', query: {iPlanId: $item.iPlanId, planTab: '1'}})
        /*
        planApi.getPackPlanDataInfo($item.iPlanId).then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('setPlanProgressSelectedTab', '1')
            this.$store.dispatch('addPlanInfo', data.data)
            this.$router.push({path: '/home/plan/list/progress', query: {iPlanId: $item.iPlanId}})
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        }) */
      },
      // SDK测试资源
      sdkTestAssets ($index, $item, $data) {
        planApi.getPackPlanDataInfo($item.iPlanId).then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('addPlanInfo', data.data)
            this.sdkTestAssetsUpload.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>
