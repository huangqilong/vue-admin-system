<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
  .row-col{
    border: 1px solid #dfe6ec;
    padding: 0 5px 0 10px;
    height: 35px;
    line-height: 35px;
    color: #666;
  }
  .label-title{
    background-color: #eef1f6;
    text-align: right;
    color: #999;
  }
  .plan-info-box{
    background-color:#fff;
    padding:20px;
    font-size:14px;
  }
  .plan-title-name{
    font-size:18px;
    margin-bottom:10px;
  }
  .plan-title-name .plan-name{
    text-align:left;
    margin-left: 10px;
    color: #666;
  }
  .progress-tabs{
    margin-top:20px;
  }
  .progress-tabs .tip-wraning-message-item{
    color:#db5757;
    font-size:12px;
    margin-bottom:5px;
  }
  .progress-tabs .event-explain-box{
    margin-bottom:10px;
  }
  .subscribe-icon{
    display:inline-block;
    width:32px;
    height:32px;
    background-repeat:  no-repeat ;
    background-position: center;
    background-size:35px 35px;
    vertical-align: middle;
  }
  .subscribed {
    background-image: url('../../assets/icon/subscribed.png');
  }
  .noSubscribe{
    background-image: url('../../assets/icon/no-subscribe.png');
  }
  .subscribe-icon-text{
    display:inline-block;height:32px;line-height:32px;
    font-size: 16px;
  }
  .subscribe-div{display:inline-block;cursor:pointer;}
  .plan-user-rtx-inform{
    display:inline-block;
    cursor:pointer;
    margin-left: 10px;
  }
</style>
<style>
  .progress-tabs .el-tabs__nav-scroll .el-tabs__nav {
    float:none;
    position: inherit;
  }
  .progress-tabs .el-tabs--card>.el-tabs__header .el-tabs__item{
    width:16.66667%;
    text-align:center;
    height:35px;
    line-height:35px;
    font-size:16px;
    color: #666;
  }
  .progress-tabs .el-tabs--card>.el-tabs__header .el-tabs__item.is-active{
    background:#20a0ff;
    color:#fff;
  }
  .progress-tabs .tip-wraning-message-item .el-icon-warning{
    margin-right:5px;
  }
  .progress-tabs .event-explain-box .el-col{
    margin-bottom:10px;
    font-size:20px;
    font-weight:500;
  }
  .plan-demo-div{
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    height: 35px;
    word-break: break-all;
  }
</style>
<template>
  <div class="content" v-if="planInfo">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align:right;">
          <div @click="subscribeHandle()" class="subscribe-div">
            <i class="subscribe-icon" :class="isSubscribed ? 'subscribed' : 'noSubscribe'"></i>
            <span class="subscribe-icon-text" v-if="isSubscribed" style="color: red">已订阅</span>
            <span class="subscribe-icon-text" v-else>订阅</span>
          </div>
          <div class="plan-user-rtx-inform" v-if="isSubscribed">
            <el-button type="text" style="font-size: 16px;color:#1976d2;" @click="rtxInformSetting()">定制消息</el-button>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="plan-info-box">
      <el-row class="plan-title-name">
        <el-col :span="24">计划名称:<span class="plan-name">{{planInfo.sPackPlanName}}</span></el-col>
      </el-row>
      <el-row>
        <el-col :span="3" style="text-align: left;width: 160px;">
          <i class="ext-icon-plan-biger" :class="getIconClassName(planInfo.gameId)"></i>
        </el-col>
        <el-col :span="21">
          <el-row>
            <el-col :span="colSpans[0]" class="row-col label-title">起止时间：</el-col>
            <el-col :span="colSpans[1]" class="row-col">{{planInfo.planTime}}</el-col>
            <el-col :span="colSpans[2]" class="row-col label-title">游戏名称：</el-col>
            <el-col :span="colSpans[3]" class="row-col">{{planInfo.gameName}}</el-col>
            <el-col :span="colSpans[4]" class="row-col label-title">计划发起人：</el-col>
            <el-col :span="colSpans[5]" class="row-col">{{planInfo.user}}<span style="color: #999;" v-if="planInfo.user && planInfo.dCreate">&nbsp;&nbsp;创建于{{planInfo.dCreate}}</span></el-col>
          </el-row>
          <el-row>
            <el-col :span="colSpans[0]"  class="row-col label-title">所在地区：</el-col>
            <el-col :span="colSpans[1]" class="row-col"><i class="ext-icon-plan-small" :class="getIconClassName(planInfo.iAreaName)"></i>{{planInfo.iAreaName}}地区</el-col>
            <el-col :span="colSpans[2]" class="row-col label-title">游戏版本：</el-col>
            <el-col :span="colSpans[3]" class="row-col">{{planInfo.gameVersion}}</el-col>
            <el-col :span="colSpans[4]" class="row-col label-title">最后更新人：</el-col>
            <el-col :span="colSpans[5]" class="row-col">
              {{planInfo.updateUser?planInfo.updateUser:'--'}}<span style="color: #999;" v-if="planInfo.updateUser && planInfo.dUpdate">&nbsp;&nbsp;更新于{{planInfo.dUpdate}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="colSpans[0]" class="row-col label-title">打包平台：</el-col>
            <el-col :span="colSpans[1]" class="row-col"><i class="ext-icon-plan-small" :class="getIconClassName(planInfo.iPlatformName)"></i>{{planInfo.iPlatformName}}</el-col>
            <el-col :span="colSpans[2]" class="row-col label-title">母包上传截止时间：</el-col>
            <el-col :span="colSpans[3]" class="row-col">
              <template>
                {{planInfo.dUploadEnd.split(' ')[0]}}
              </template>
            </el-col>
            <el-col :span="colSpans[4]" class="row-col label-title">备注：</el-col>
            <el-col :span="colSpans[5]" class="row-col">
              <el-tooltip placement="top" v-if="planInfo.sDemo && planInfo.sDemo.replace(/[\u0391-\uFFE5]/g,'aa').length>32">
                <div slot="content" style="max-height:300px;width:200px;overflow-Y:auto;">
                  <p >{{planInfo.sDemo}}</p>
                </div>
                <div class="plan-demo-div">{{planInfo.sDemo ? planInfo.sDemo : '--'}}</div>
              </el-tooltip>
              <div class="plan-demo-div" v-if="!planInfo.sDemo || planInfo.sDemo.replace(/[\u0391-\uFFE5]/g,'aa').length<=32">{{planInfo.sDemo ? planInfo.sDemo : '--'}}</div>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="colSpans[0]" class="row-col label-title">游戏语言：</el-col>
            <el-col :span="colSpans[1]" class="row-col">{{planInfo.iLanguageName}}</el-col>
            <el-col :span="colSpans[2]" class="row-col label-title">订阅人员列表：</el-col>
            <el-col :span="colSpans[3]" class="row-col">
              <el-button type="text" class="table-option-button"  @click="showPlanSubcribeList()">查看({{planInfo.packPlanSubcribeVOList?planInfo.packPlanSubcribeVOList.length:0}})</el-button>
              <el-button type="text" class="table-option-button"  v-if="roleAuthority.updateSubcribeList" @click="showAllSubcribeList()">修改</el-button>
            </el-col>
            <el-col :span="colSpans[4]" class="row-col label-title">快捷操作：</el-col>
            <el-col :span="colSpans[5]" class="row-col">
              <el-button type="text" class="table-option-button"
                         v-if="roleAuthority.gameShortcutConfig && (new Date(planInfo.dCreate) - new Date(gameConfigOldDate) > 0)" @click="gameShortcutConfig()">一键配置</el-button>
              <el-button type="text" class="table-option-button"
                         v-if="roleAuthority.cdnControlOptionBtn && planInfo.iPlanType==1 && planInfo.iAreaName=='大陆' && planInfo.iPlatformName=='安卓' && planInfo.gameCdnFlag == 1" @click="showCDNControl()">CDN开启控制</el-button>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
    </div>
    <div class="progress-tabs">
      <template>
          <el-tabs type="card" class="tabs-content" :value="planProgressSelectedTab" @tab-click="planSelectTab">
            <el-tab-pane  :label="(planInfo.iUseSvn==1?'工程进度':'母包进度')+'（'+planProgressTabStatus.gameStatus+'）'" name="1">
              <barePackageProgress></barePackageProgress>
            </el-tab-pane>
            <el-tab-pane name="0">
              <span slot="label">
                <el-tooltip content="质检通过数 / 渠道总数" placement="top">
                  <span>渠道sdk进度（{{planProgressTabStatus.sdkStatus}}）</span>
                </el-tooltip>
              </span>
              <channelProgress></channelProgress>
            </el-tab-pane>
            <el-tab-pane name="2">
              <span slot="label">
                <el-tooltip content="渠道通过数 / 质检通过数 / 渠道总数" placement="top">
                  <span>整包进度（{{planProgressTabStatus.packageStatus}}）</span>
                </el-tooltip>
              </span>
             <intactPackageProgress></intactPackageProgress>
            </el-tab-pane>
            <el-tab-pane name="3" v-if="planInfo.isContainOffical == 1 && planInfo.iPlatformName == '安卓' && planProgressTabStatus.adStatus != '0/0/0'">
              <span slot="label">
                <el-tooltip content="渠道通过数 / 质检通过数 / 广告码总数数" placement="top">
                  <span>广告包进度（{{planProgressTabStatus.adStatus}}）</span>
                </el-tooltip>
              </span>
              <adPackageProgress></adPackageProgress>
            </el-tab-pane>
            <el-tab-pane name="4" v-if="planInfo.isContainOffical == 1 && planInfo.iPlatformName == '安卓' && planProgressTabStatus.cpsStatus != '0/0/0'">
              <span slot="label">
                <el-tooltip content="渠道通过数 / 质检通过数 / CPS码总数数" placement="top">
                  <span>cps包进度（{{planProgressTabStatus.cpsStatus}}）</span>
                </el-tooltip>
              </span>
              <cpsPackageProgress></cpsPackageProgress>
            </el-tab-pane>
            <el-tab-pane label="计划事件" name="5">
             <planEvent></planEvent>
            </el-tab-pane>
          </el-tabs>
      </template>
    </div>
    <show-data-info-dialog v-if="showInfoDataDialog.dialogShowVisible" :optionData="showInfoDataDialog"></show-data-info-dialog>
    <subcribe-list-dialog v-if="optionSubcribeListDataDialog.dialogVisible" :optionData="optionSubcribeListDataDialog"
                          :packSubcribeIdsList="packSubcribeIdsList" :packSubcribeList="packSubcribeList" :optionCallBack="submitSubcribeList"></subcribe-list-dialog>
    <subscribe-rtx-inform-dialog v-if="subcribeRtxInformDataDialog.dialogVisible" :optionData="subcribeRtxInformDataDialog"></subscribe-rtx-inform-dialog>
    <cdn-control-dialog v-if="cdnControlDataDialog.dialogVisible" :optionData="cdnControlDataDialog" :optionSelectTabCallBack="planSelectTab" :optionCallBack="getPlanDataInfo"></cdn-control-dialog>
    <subcribe-data-info-dialog v-if="showSubcribeDataInfoDialog.dialogFormVisible" :optionData="showSubcribeDataInfoDialog"></subcribe-data-info-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  import planUtil from '../../utils/plan-util'
  import barePackageProgress from '../../components/plan/barePackageProgress'
  import channelProgress from '../../components/plan/channelProgress'
  import intactPackageProgress from '../../components/plan/intactPackageProgress'
  import adPackageProgress from '../../components/plan/adPackageProgress'
  import cpsPackageProgress from '../../components/plan/cpsPackageProgress'
  import planEvent from '../../components/plan/planEvent'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import showDataInfoDialog from '../../components/manager/showDataInfo'
  import subcribeListDialog from '../../components/plan/subcribeListDialog'
  import subscribeRtxInformDialog from '../../components/plan/subscribeRtxInformDialog'
  import cdnControlDialog from '../../components/plan/cdnControlDialog'
  import subcribeDataInfoDialog from '../../components/plan/subcribeDataInfoDialog'
  export default{
    components: {
      barePackageProgress,
      channelProgress,
      adPackageProgress,
      cpsPackageProgress,
      planEvent,
      intactPackageProgress,
      breadCrumbConfig,
      showDataInfoDialog,
      subcribeListDialog,
      subscribeRtxInformDialog,
      cdnControlDialog,
      subcribeDataInfoDialog
    },
    data () {
      return {
        routerPathList: ['/home/plan/list', ''],
        colSpans: [3, 5, 3, 5, 3, 5],
        isSubscribed: false,
        iPlanSubcribeId: '',
        planDetailDialogConfig: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        showInfoDataDialog: {
          dialogShowVisible: false,
          title: '',
          tableHeader: [],
          tableDataList: []
        },
        optionSubcribeListDataDialog: {
          dialogVisible: false
        },
        subcribeRtxInformDataDialog: {
          subcribeId: '',
          dialogVisible: false
        },
        cdnControlDataDialog: {
          title: '',
          gameCdnFlag: 0,
          dialogVisible: false,
          cdnFlag: 0
        },
        showSubcribeDataInfoDialog: {
          dialogFormVisible: false,
          title: ''
        },
        packSubcribeIdsList: [],
        packSubcribeList: [],
        planTabStatus: null
      }
    },
    mounted () {
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planProgressSelectedTab', 'userName', 'userId', 'roleAuthority', 'planProgressTabStatus', 'gameConfigOldDate'
      ])
    },
    created: function () {
      this.$store.dispatch('setPlanProgressSelectedTab', this.$route.query.planTab)
      this.getPlanDataInfo()
      this.searchSubscribeUserInfo()
      this.getPlanRecordsStatus()
    },
    methods: {
      getPlanRecordsStatus () {
        planApi.getPlanRecordsStatusInfo(this.$route.query.iPlanId).then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('setPlanProgressTabStatus', data.data)
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getPlanDataInfo () {
        planApi.getPackPlanDataInfo(this.$route.query.iPlanId).then((data) => {
          if (data.code === 1) {
            data.data.planTime = data.data.dPlanStart.split(' ')[0] + ' ~ ' + data.data.dPlanEnd.split(' ')[0]
            this.$store.dispatch('addPlanInfo', data.data)
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      searchSubscribeUserInfo () {
        planApi.getSubscribeUserInfo(this.$route.query.iPlanId).then((data) => {
          if (data.code === 1) {
            this.isSubscribed = false
            this.iPlanSubcribeId = ''
            for (let item of data.data) {
              if (item.iUserId === this.userId) {
                this.isSubscribed = true
                this.iPlanSubcribeId = item.iPlanSubcribeId
              }
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 订阅
      subscribeHandle () {
        let _this = this
        planApi.addSubscribeUser(this.planInfo.iPlanId, this.userId).then((data) => {
          if (data.code === 1) {
            if (this.isSubscribed) {
              _this.isSubscribed = false
            } else {
              _this.isSubscribed = true
              this.searchSubscribeUserInfo()
            }
            this.getPlanDataInfo()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      submitSubcribeList (selectSubcribeDataList) {
        let subParams = {
          dels: '',
          userOrgList: selectSubcribeDataList.userOrgList
        }
        let userNames = selectSubcribeDataList.userNames.join(',')
        let deleteNames = []
        for (let item of this.packSubcribeList) {
          if (userNames.indexOf(item.name) === -1) {
            deleteNames.push(item.pinyinName)
          }
        }
        subParams.dels = deleteNames.join(',')
        planApi.saveRTXSubscribeUser(this.planInfo.iPlanId, subParams).then((data) => {
          if (data.code === 1) {
            this.optionSubcribeListDataDialog.dialogVisible = false
            this.getPlanDataInfo()
            this.searchSubscribeUserInfo()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      showAllSubcribeList () {
        planApi.getSubscribeUserInfo(this.planInfo.iPlanId).then((data) => {
          if (data.code === 1) {
            this.packSubcribeIdsList = []
            this.packSubcribeList = []
            for (let packItem of data.data) {
              this.packSubcribeIdsList.push(packItem.iUserId)
              this.packSubcribeList.push({
                name: packItem.cRealName,
                pinyinName: packItem.cUserName,
                type: 1
              })
            }
            this.optionSubcribeListDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      showPlanSubcribeList () {
        this.showSubcribeDataInfoDialog.dialogFormVisible = true
        this.showSubcribeDataInfoDialog.title = '订阅人员列表'
      },
      planSelectTab (data) {
        this.$store.dispatch('setPlanProgressSelectedTab', data.name)
        this.$store.dispatch('setRoleAuthorityRouter', {routerUrl: '/home/plan/list/progress', tabVal: data.name})
        this.getPlanRecordsStatus()
        this.$router.push({path: '/home/plan/list/progress', query: {iPlanId: this.$route.query.iPlanId, planTab: data.name}})
      },
      rtxInformSetting () {
        this.subcribeRtxInformDataDialog.subcribeId = this.iPlanSubcribeId
        this.subcribeRtxInformDataDialog.dialogVisible = true
      },
      showCDNControl () {
        this.cdnControlDataDialog.title = 'CDN开启控制'
        this.cdnControlDataDialog.gameCdnFlag = this.planInfo.gameCdnFlag || 0
        this.cdnControlDataDialog.cdnFlag = this.planInfo.cdnFlag
        this.cdnControlDataDialog.dialogVisible = true
      },
      gameShortcutConfig () {
        let type = this.planInfo.iPlatformName === '安卓' ? 'android' : 'ios'
        this.$router.push({path: '/home/game/list/assets/channel/' + type,
          query: {iPlanId: this.$route.query.iPlanId, planTab: this.$route.query.planTab, iProjectId: this.planInfo.iProjectId, iAssertId: this.planInfo.iGameAssetsId, iProjectAssetId: this.planInfo.iProjectAssetId}})
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }
</script>
