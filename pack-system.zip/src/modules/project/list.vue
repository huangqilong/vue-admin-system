<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
  .top-crumb .nav-font{
    font-size: 16px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="16">
          <el-breadcrumb separator=">>">
            <el-breadcrumb-item><span class="nav-font">游戏工程列表</span></el-breadcrumb-item>
          </el-breadcrumb>
        </el-col>
        <el-col :span="8" style="text-align: right;">
          <el-button size="small" type="primary" @click="addDataItem()" v-if="roleAuthority.insertBtn">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="projectCode" label="工程code"></el-table-column>
        <el-table-column prop="serverVersion" label="服务器版本号"></el-table-column>
        <el-table-column prop="appKey" label="资源key"></el-table-column>
        <el-table-column prop="gameId" label="游戏ID"></el-table-column>
        <el-table-column prop="extraSign" label="额外拼接"></el-table-column>
        <!--<el-table-column prop="iChannelNum" label="接入渠道数量"></el-table-column>-->
        <el-table-column prop="cDisplay" label="状态">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="290">
          <template scope="scope">
            <el-button type="primary" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].cDisplay==0?'下架':'上架'}}</el-button>
            <el-button type="primary" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="primary" class="table-option-button" @click="toChannelList(scope.$index, dataList)">接入渠道</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import projectApi from '../../apis/project-api'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/project/optionDialog'

  export default{
    components: {
      pagination,
      optionDialog
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        dataInfoForm: {
          projectCode: '',
          serverVersion: '',
          extraSign: '',
          gameId: '',
          appKey: ''
        },
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        projectApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          projectCode: '',
          serverVersion: '',
          extraSign: '',
          gameId: '',
          appKey: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        projectApi.getDataInfo(data[$index].iAssetsConfigId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        let id = $data[$index].iAssetsConfigId
        let status = $data[$index].cDisplay === '0' ? '1' : '0'
        projectApi.updateDataStatus(id, status).then((data) => {
          if (data.code === 1) {
            $data[$index].cDisplay = status
          } else {
            this.$alert(data.msg, '修改失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 版本
      toChannelList ($index, data) {
        this.$store.dispatch('addProjectGameInfo', this.dataList[$index])
        this.$router.push({path: '/home/project/list/channel'})
      }
    }
  }

</script>

