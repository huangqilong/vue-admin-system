<style scoped>
  .login-page{
    height: 100%;
    width: 100%;
    position: absolute;
    top: 0px;
    left: 0px;
    background: #fff url(../../assets/login/login_bg.jpg) no-repeat center;
    z-index: 0;
    overflow: hidden;
    word-break: break-all;
  }
  .content{
    width: 500px;
    height: 360px;
    position: absolute;
    top: 50%;
    left: 50%;
    text-align: center;
    margin-left: -250px;
    margin-top: -180px;
  }
  .login-logo{
    margin-top: 45px;
  }
  p.title{
    font-size: 20px;
    color: #fff;
    line-height: 30px;
    margin-top: 0;
  }

  .input-icon{
    width: 25px;
    height: 27px;
    display: block;
    float: left;
    background-image: url(../../assets/login/sprite.png);
    position: absolute;
    top: 12px;
    left: 15px;
  }
  .login-icon-name{
    background-position: 0 0;
  }
  .login-icon-password{
    background-position: -25px 0;
  }

  .login-btn{
    width: 100%;
    height: 50px;
    font-size: 20px;
    color: #fff;
    border-radius: 30px;
  }
  .col-split{
    border-left: 1px #454c59 solid;
  }
  .right-content{
    padding: 0 20px 0 40px;
  }
</style>
<style>
  .login-page .login-input .el-input__inner{
    background: transparent;
    border-radius: 25px;
    padding-left: 50px;
    padding-right: 25px;
    height: 50px;
    font-size: 18px;
    color: #fff;
  }
  .login-page .login-input-code .el-input__inner{
    padding-right: 100px;
  }
</style>
<template>
  <div class="login-page">
    <div class="content">
      <el-row>
        <!--<el-col :span="10" >-->
          <!--<img class="login-logo" src="../../assets/login/login_logo.png">-->
        <!--</el-col>-->
        <el-col :span="24">
          <div class="right-content">
            <p class="title">用户登录/login</p>
            <el-form :model="loginInfo" :rules="rules" ref="loginForm">
              <el-form-item prop="userName">
                <i class="input-icon login-icon-name"></i>
                <el-input v-model.trim="loginInfo.userName" class="login-input inline-input" placeholder="用户名" auto-complete="off"></el-input>
              </el-form-item>
              <el-form-item prop="password">
                <i class="input-icon login-icon-password"></i>
                <el-input v-model="loginInfo.password" class="login-input" type="password" placeholder="密码" auto-complete="off" @keyup.enter.native="keyLogin"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" class="login-btn" @click="login('loginForm')">登&nbsp;&nbsp;&nbsp;&nbsp;录</el-button>
              </el-form-item>
              <!--<span style="color:#ff0;font-size:14px;">提示：系统支持使用电脑开机账号和密码登录！</span>-->
            </el-form>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import loginApi from '../../apis/login-api'
  import userRoleApi from '../../apis/user-role-api'
  export default {
    data () {
      return {
        loginInfo: {
          userName: '',
          password: ''
        },
        rules: {
          userName: [
            {required: true, message: '请输入用户名', trigger: 'blur'}
          ],
          password: [
            {required: true, message: '请输入密码', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'userName', 'tokens', 'userLoginInfo'
      ])
    },
    watch: {

    },
    created: function () {
      if (this.userLoginInfo) {
        this.loginInfo = {
          userName: this.userLoginInfo.userName,
          password: this.userLoginInfo.password
        }
      }
    },
    methods: {
      keyLogin () {
        this.login('loginForm')
      },
      login (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let resData = {
              'roleName': '',
              'password': this.loginInfo.password,
              'iUserId': 33,
              'cUserName': 'huangjinbiao',
              'cRealName': '黄金彪',
              'permsSet': null,
              'dataAccessMap': {
                'area': [8,7,6,5,4,3,2],
                'game': [34,12,26,4,32,10002,3,30,25],
                'language': [72,15,14,13],
                'platform': [18,17]
              },
              'jwtToken': 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJodWFuZ2ppbmJpYW8iLCJpc3MiOiJod3lBZElzc3VlciIsImV4cCI6MTUxOTI5MDUzNiwiaWF0IjoxNTE5MjgzMzM2LCJqdGkiOiIzMyJ9.f2hxLv6Vnkn_KiNfyYtefbLHjNssQS6cTHYIR9xkP6q5PGBtqGTbP7vtuOb_urPuXKTziCRIAfwBJDhEpqwbUw',
              'expireTime': 7200000,
              'loginTime': '20180222150856',
              'roleId': '1'
            }
            this.$store.dispatch('login', resData)
            this.$router.push('/home/plan/list')
            /*
            loginApi.toLogin(this.loginInfo).then((data) => {
              if (data.code === 1) {
                let userData = {
                  roleName: '',
                  password: this.loginInfo.password,
                  ...data.data
                }
                this.$store.dispatch('login', userData)
                if (data.data.cUserName === 'admin') {
                  this.$store.dispatch('getRoleMenus', -1)
                } else {
                  this.$store.dispatch('getRoleMenus', data.data.roleId)
                }
                this.$store.dispatch('getSearchGameList')

                userRoleApi.getDataInfo(data.data.roleId).then((roleData) => {
                  let roleName = ''
                  if (roleData.code === 1) {
                    roleName = roleData.data.cRoleName
                  }
                  userData = {
                    roleName: roleName,
                    password: this.loginInfo.password,
                    ...data.data
                  }
                  this.$store.dispatch('login', userData)
                  if (this.$route.query.redirect) {
                    let redirectPath = this.$route.query.redirect
                    if (redirectPath === '/login') {
                      redirectPath = '/home/plan/list'
                    } else {
                      redirectPath = redirectPath.replace('/login?redirect=', '')
                    }
                    this.$router.push(decodeURIComponent(redirectPath))
                  } else {
                    this.$router.push('/home/plan/list')
                  }
                }, (error) => {
                  console.log(error)
                })
              } else {
                this.$alert(data.msg, '登录失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert(error, '请求错误', {
                confirmButtonText: '确定'
              })
            }) */
          } else {
            return false
          }
        })
      }
    }
  }
</script>
