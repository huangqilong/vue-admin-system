<style>
  .judgeVersionMessage{
    width: 100%;
    top: 0;
    border-radius: 0;
  }
</style>
<template>
  <transition name="fade">
    <router-view></router-view>
  </transition>
</template>
<script>
  import {mapGetters} from 'vuex'
  import $ from 'jquery'
  export default {
    computed: {
      ...mapGetters([
        'packSystemVersion', 'proxyDevApi'
      ])
    },
    components: {
    },
    data () {
      return {
      }
    },
    created: function () {
//      let _this = this
//      clearInterval()
//      setInterval(function () {
//        $.ajax({
//          type: 'get',
//          url: _this.proxyDevApi + '/sysConfigs/md5',
//          cache: false,
//          async: false,
//          success: function (data) {
//            if (data.code === 1) {
//              if (_this.packSystemVersion !== data.val) {
//                _this.$message({
//                  showClose: true,
//                  dangerouslyUseHTMLString: true,
//                  message: '<div>检测到新版本，为了避免数据显示错误，请使用<strong style="color: #ef5350;">Ctrl+F5</strong>强制刷新一下页面！</div>',
//                  type: 'warning',
//                  center: true,
//                  customClass: 'judgeVersionMessage',
//                  duration: 0
//                })
// //                _this.$store.dispatch('clearCommonLocalData')
// //                _this.$store.dispatch('logout')
//                _this.$store.dispatch('setPackSystemVersion', data.val)
// //                _this.$router.push('/login')
//              }
//            }
//          }
//        })
//      }, 60000)
    },
    methods: {
    }
  }
</script>
