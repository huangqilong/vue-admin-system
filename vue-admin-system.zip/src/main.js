// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill'
import Vue from 'vue'
import axios from 'axios'
import store from './store'
import VueRouter from 'vue-router'
import ElementUI from 'element-ui'
// import iView from 'iview'
import vueClipboard2 from 'vue-clipboard2'
// import 'iview/dist/styles/iview.css'
// import 'element-ui/lib/theme-default/index.css'
import 'element-ui/lib/theme-chalk/index.css'
import 'element-ui/lib/theme-chalk/base.css'
import './css/common.css'
import './css/iconfont.css'
import './css/ionicons.css'
import './css/icon-extend.css'

import routes from './config/routes'
import App from './App'

Vue.use(VueRouter) // 路由注册
// Vue.use(iView)
Vue.use(ElementUI) // UI框架注册
Vue.use(vueClipboard2)

/*
* 在创建的 router 对象中，如果不配置 mode，就会使用默认的 hash 模式，该模式下会将路径格式化为 #! 开头。
 添加 mode: 'history' 之后将使用 HTML5 history 模式，该模式下没有 # 前缀，而且可以使用 pushState 和 replaceState 来管理记录。
* */
const router = new VueRouter({
  routes: routes
})
router.beforeEach(({meta, path, fullPath}, from, next) => {
  let {auth = true} = meta
  let isLogin = Boolean(store.state.login.cookie.tokens !== '') // true用户已登录， false用户未登录
  if (auth && !isLogin && path !== '/login') {
    return next({path: '/login', query: {redirect: fullPath}})
  }
  if (isLogin && (path === '/login' || path === '/')) { // 已登录过，则跳转到主页
    return next({path: '/home/plan/list'})
  }
  next()
})

router.afterEach(({meta, path}, from, next) => {
  if (store.state.login.cookie.userName === 'admin') {
    store.dispatch('setRoleAuthorityRouter', null)
  } else {
    let tabVal = ''
    if (path === '/home/plan/list/progress') {
      tabVal = store.state.plan.local.planProgressSelectedTab
    }
    store.dispatch('setRoleAuthorityRouter', {routerUrl: path, tabVal: tabVal})
  }
  if (path.indexOf('/home/') >= 0) {
    store.dispatch('getMenuActiveIndex', {menus: store.state.common.local.menuConfig, path: path})
  }
})

// 添加请求拦截器
axios.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  if (store.state.login.cookie.tokens) {
    config.headers.common['jwtToken'] = store.state.login.cookie.tokens
    config.headers.common['userId'] = store.state.login.cookie.userId
    config.headers.post['Content-Type'] = 'application/json'
  }
  if (config.url.indexOf('/user/logout') === -1 && config.url.indexOf('/sysConfigs/md5') === -1) {
    store.dispatch('setButtonLoading', true)
  }
  return config
}, function (error) {
  store.dispatch('setButtonLoading', false)
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  store.dispatch('setButtonLoading', false)
  // 请求认证失败
  // if (response.data.code === 1025 || response.data.code === 1021 || response.data.code === 1019) {
  //   store.commit('login/LOGIN_OUT')
  //   store.commit('dictionary/DICT_LOGIN_OUT')
  //   router.replace({
  //     path: '/login'
  //   })
  // }
  return response
}, function (error) {
  store.dispatch('setButtonLoading', false)
  if (error.response) {
    switch (error.response.status) {
      case 401:
        if (store.state.login.cookie.tokens) {
          // 返回 401 清除token信息并跳转到登录页面
          store.commit('login/LOGIN_OUT')
          store.commit('dictionary/DICT_LOGIN_OUT')
          router.replace({
            path: '/login',
            query: {redirect: router.currentRoute.fullPath}
          })
        }
    }
  }
  // 对响应错误做点什么
  return Promise.reject(error)
})

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
