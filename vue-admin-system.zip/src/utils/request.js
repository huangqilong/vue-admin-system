import 'whatwg-fetch'
import axios from 'axios'

export default {
  /**
   * 基于 AXIOS 封装的 GET请求
   * @param url
   * @param params {}
   * @returns {Promise}
   */
  get (url, params) {
    url += '?O_o=' + (new Date().getTime())
    return new Promise(function (resolve, reject) {
      axios.get(url, {params: params})
      .then((response) => {
        if (response.status === 200) {
          resolve(response.data)
        } else {
          reject({status: response.status})
        }
      }).catch((err) => {
        // reject({status: -1})
      })
    })
  },
  /**
   * 基于 AXIOS 封装的 POST请求  JSON数据
   * @param url
   * @param params
   * @returns {Promise}
   */
  post (url, params) {
    url += '?O_o=' + (new Date().getTime())
    return new Promise(function (resolve, reject) {
      axios.post(url, params).then((response) => {
        if (response.status === 200) {
          resolve(response.data)
        } else {
          reject({status: response.status})
        }
      }).catch((err) => {
        reject({status: -1})
      })
    })
  },

  /**
   * 基于 AXIOS 封装的 PUT请求  JSON数据
   * @param url
   * @param params
   * @returns {Promise}
   */
  put (url, params) {
    url += '?O_o=' + (new Date().getTime())
    return new Promise(function (resolve, reject) {
      axios.put(url, params).then((response) => {
        if (response.status === 200) {
          resolve(response.data)
        } else {
          reject({status: response.status})
        }
      }).catch((err) => {
        reject({status: -1})
      })
    })
  },
  /**
   * 基于 AXIOS 封装的 DELETE请求
   * @param url
   * @param params {}
   * @returns {Promise}
   */
  delete (url, params) {
    url += '?O_o=' + (new Date().getTime())
    return new Promise(function (resolve, reject) {
      axios.delete(url, {params: params})
        .then((response) => {
          if (response.status === 200) {
            resolve(response.data)
          } else {
            reject({status: response.status})
          }
        }).catch((err) => {
          reject({status: -1})
        })
    })
  }
}

