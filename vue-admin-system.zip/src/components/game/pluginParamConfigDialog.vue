<style>
  .option-dialog-plugin-param .el-dialog{
    width: 600px;
  }
</style>
<template>
  <el-dialog :title="optionData.title"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-plugin-param">
    <div class="content-list">
      <el-table :data="paramsDataList" stripe>
        <el-table-column prop="paramsKey" label="参数名"></el-table-column>
        <el-table-column prop="paramsValue" label="参数值">
          <template scope="scope">
            <el-input v-model="scope.row.paramsValue" placeholder="请输入参数值"></el-input>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'
  export default{
    components: {
    },
    props: ['optionData', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        optionType: '',
        paramsDataList: []
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    watch: {
      paramsDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.optionType = this.$route.params.type || 'android'
      this.selectPluginDic()
    },
    methods: {
      selectPluginDic () {
        let keyData = this.optionData.dataInfoForm.paramsKey ? this.optionData.dataInfoForm.paramsKey.split(',') : []
        let valData = this.optionData.dataInfoForm.paramsValue ? this.optionData.dataInfoForm.paramsValue.split(',') : []
        for (let i in keyData) {
          this.paramsDataList.push({
            paramsKey: keyData[i],
            paramsValue: valData.length > 0 ? valData[i] : ''
          })
        }
        this.oldDataInfoForm = JSON.parse(JSON.stringify(this.paramsDataList))
      },
      submitForm () {
        let paramsKeys = []
        let paramsValues = []
        for (let item of this.paramsDataList) {
          paramsKeys.push(item.paramsKey)
          paramsValues.push(item.paramsValue)
        }
        let params = JSON.parse(JSON.stringify(this.optionData.dataInfoForm))
        params.paramsKey = paramsKeys.join(',')
        params.paramsValue = paramsValues.join(',')
        gameApi.postGameChannelPluginsParam(params).then((data) => {
          if (data.code === 1) {
            if (this.optionCallBack) {
              this.optionCallBack()
            }
            this.optionData.dialogFormVisible = false
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
