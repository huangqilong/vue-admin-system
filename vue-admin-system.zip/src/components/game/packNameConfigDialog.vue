<style>
  .option-dialog-pack-name .el-dialog{
    width: 800px;
  }
  .option-dialog-pack-name .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .option-dialog-pack-name .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
    max-height: 450px;
    overflow-y: auto;
    overflow-x: hidden;
  }
  .content-list .path{
    margin-top: 10px;
  }
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.title"
             :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-pack-name">
    <div class="content-list" id="myData">
      <el-form :model="dataInfoForm" ref="dataInfoForm">
        <el-row v-if="0 == dataInfoForm.androidGamePackageList.length">
          <el-col :span="2">&nbsp;</el-col>
          <el-col :span="20">
            <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('dataInfoForm')">添&nbsp;&nbsp;加</el-button>
          </el-col>
          <el-col :span="2">&nbsp;</el-col>
        </el-row>
        <el-row v-if="dataInfoForm.androidGamePackageList.length > 0">
          <el-col :span="6" class="table-head">渠道名称</el-col>
          <el-col :span="15" class="table-head">渠道包名</el-col>
          <el-col :span="3" class="table-head">&nbsp;</el-col>
        </el-row>
        <el-row v-for="(domain,index) in dataInfoForm.androidGamePackageList" :gutter="10">
          <el-col :span="6">
            <el-form-item
              :prop="'androidGamePackageList.' + index + '.channelId'"
              :rules="[{type: 'number', required: true, message: '请选择渠道名称', trigger: 'change'},{validator: checkChannelExit, trigger: 'change'}]">
              <el-select v-model="domain.channelId" placeholder="请选择">
                <el-option v-for="item in channelList"
                  :key="item.iChannelId"
                  :label="item.channelName"
                  :value="item.iChannelId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="14">
            <el-form-item
              :prop="'androidGamePackageList.' + index + '.packageName'"
              :rules="[{required: true, message: '请输入渠道包名', trigger: 'blur'}]">
              <el-input v-model="domain.packageName" placeholder="请输入渠道包名"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4" style="text-align: left;">
            <el-button type="text" class="table-option-button" @click.prevent="removeItem(index)">删除</el-button>
            <el-button type="text" class="table-option-button" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.androidGamePackageList.length-1">添加</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import channelApi from '../../apis/channel-api'
  import gameApi from '../../apis/game-api'
  export default{
    components: {
    },
    props: ['optionData'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        dataInfoForm: {
          andrPackIds: '',
          androidGamePackageList: []
        },
        deleteChannelIds: [],
        channelList: [],
        gamePackDataLength: 0
      }
    },
    watch: {
      gamePackDataLength () {
        this.$nextTick(() => {
          var container = this.$el.querySelector('#myData')
          container.scrollTop = container.scrollHeight
        })
      },
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      // 获取渠道列表
      this.getChannelList()
      this.getPackNameList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      getPackNameList () {
        // 获取签名配置信息
        gameApi.getPackNameConfigDataInfo({'projectId': this.optionData.gameInfo.iProjectId}).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm.androidGamePackageList = data.data
            this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
          }
        }, (error) => {
          console.log(error)
        })
      },
      getChannelList () {
        let _this = this
        channelApi.getDropDownDataList(this.optionData.gameInfo.iPlatformId).then((data) => {
          if (data.code === 1) {
            _this.channelList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.channelList = null
        })
      },
      checkChannelExit (rule, value, callback) {
        if (!value) {
          return callback(new Error('请选择渠道'))
        }
        setTimeout(() => {
          let isExit = 0
          for (let item of this.dataInfoForm.androidGamePackageList) {
            if (item.channelId === value) {
              isExit++
            }
          }
          if (isExit === 1) {
            callback()
          } else {
            callback(new Error('渠道已存在'))
          }
        }, 1000)
      },
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.androidGamePackageList.push({
              projectId: this.optionData.gameInfo.iProjectId,
              channelId: '',
              packageName: ''
            })
            this.gamePackDataLength = this.dataInfoForm.androidGamePackageList.length
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        let packInfo = this.dataInfoForm.androidGamePackageList[$index]
        if (packInfo.iAndrPackId) {
          this.deleteChannelIds.push(packInfo.iAndrPackId)
        }
        this.dataInfoForm.androidGamePackageList.splice($index, 1)
      },
      submitForm (formName) {
        if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm)) {
          this.optionData.dialogVisible = false
          return
        }
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.deleteChannelIds.length > 0) {
              this.dataInfoForm.andrPackIds = this.deleteChannelIds.join(',')
            }
            gameApi.postPackNameConfigDataInfo(_this.dataInfoForm).then((data) => {
              if (data.code === 1) {
                this.optionData.dialogVisible = false
              } else {
                this.$alert(data.msg, '包名配置失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              console.log(error)
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
