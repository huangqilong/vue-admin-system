<style>
  .option-dialog-project .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select,.option-dialog .el-input-number{
    width: 100%;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-project">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="120px">
      <template v-if="optionData.type=='add'||optionData.type=='update'">
        <el-form-item label="项目ID：" prop="gameId">
          <el-input v-model.number.trim="dataInfoForm.gameId"></el-input>
        </el-form-item>
        <el-form-item label="项目名称：" prop="projectName">
          <el-input v-model.trim="dataInfoForm.projectName"></el-input>
        </el-form-item>
        <!--
        <el-form-item label="工程code：" prop="projectCode">
          <el-input v-model.trim="dataInfoForm.projectCode"></el-input>
        </el-form-item>
        <el-form-item label="服务器版本号：" prop="serverVersion">
          <el-input v-model.trim="dataInfoForm.serverVersion"></el-input>
        </el-form-item>
        <el-form-item label="代理类型：" prop="cAssertType">
          <el-radio-group v-model="dataInfoForm.cAssertType">
            <el-radio class="radio" :label="gameTypeList[0].iDicId">{{gameTypeList[0].sDicName}}</el-radio>
            <el-radio class="radio" :label="gameTypeList[1].iDicId">{{gameTypeList[1].sDicName}}</el-radio>
            <el-radio class="radio" :label="gameTypeList[2].iDicId">{{gameTypeList[2].sDicName}}</el-radio>
          </el-radio-group>
        </el-form-item> -->
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogVisible = false" v-if="dataInfoForm.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameProjectApi from '../../apis/game-project-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        rules: {
          gameId: [
            {type: 'number', required: true, message: '游戏ID不可为空且必须是数字', trigger: 'blur'}
          ],
          projectName: [
            {required: true, message: '请输入项目名称', trigger: 'blur'}
          ],
          projectCode: [
            {required: true, message: '请输入工程code', trigger: 'blur'}
          ],
          serverVersion: [
            {required: true, message: '请输入服务器版本号', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading', 'gameTypeList'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              gameProjectApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              gameProjectApi.updateDataInfo(_this.dataInfoForm, this.optionData.type).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
