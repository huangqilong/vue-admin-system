<style>
  .option-dialog-project-game .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select,.option-dialog .el-input-number{
    width: 100%;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-project-game">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="项目名称：">
        {{optionData.projectDataInfo.projectName}}
      </el-form-item>
      <el-form-item label="地区：" prop="iAreaId">
        {{dataInfoForm.areaName}}
      </el-form-item>
      <el-form-item label="语言：" prop="iLanguageId">
        {{dataInfoForm.languageName}}
      </el-form-item>
      <el-form-item label="平台：" prop="iPlatformId">
        {{dataInfoForm.platformName}}
      </el-form-item>
      <el-form-item label="渠道名称：" prop="iPlatformId">
        {{dataInfoForm.operatorName}}
      </el-form-item>
      <el-form-item label="应用ID：" prop="sChannelCode">
        <el-input v-model.number.trim="dataInfoForm.sChannelCode"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('dataInfoForm')" :disabled="isEqualsOption" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameProjectApi from '../../apis/game-project-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        rules: {
          sChannelCode: [
            {type: 'number', required: true, message: '应用ID不可为空且必须为数字', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let submitParams = {
              iOperatorId: _this.dataInfoForm.iOperatorId,
              sChannelCode: _this.dataInfoForm.sChannelCode
            }
            gameProjectApi.updateOperatorDataInfo(submitParams).then((data) => {
              if (data.code === 1) {
                this.optionData.dialogVisible = false
                _this.optionCallBack()
              } else {
                this.$alert(data.msg, '修改失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              console.log(error)
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
