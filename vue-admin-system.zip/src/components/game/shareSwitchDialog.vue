<style>
  .option-dialog-share-switch .el-dialog{
    width: 400px;
  }
</style>
<style scoped>
  .option-dialog-share-switch .plugin-item{
    padding-left: 10px;
    padding-right: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 5px;
  }
  .option-dialog-share-switch .plugin-item .plugin-item-checkbox{
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }
  .option-dialog-share-switch .switch-warn-tip {
    color: red;
    font-size: 14px;
    margin-bottom: 10px;
    margin-top: -10px;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-share-switch">
    <div class="switch-warn-tip">提示：分享开关默认开启，选中表示关闭该分享</div>
    <div style="margin: 0 0 15px 0;">
      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
      <el-checkbox-group v-model="selectShareSwitchList" @change="handleCheckedChange" style="margin-top: 5px">
        <el-row :gutter="10">
          <el-col :span="8" v-for="item in shareSwitchList" class="plugin-item">
            <el-checkbox :label="item" :key="item.iDicId" class="plugin-item-checkbox">{{item.sDicName}}</el-checkbox>
          </el-col>
        </el-row>
      </el-checkbox-group>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  export default{
    components: {},
    props: ['optionData', 'shareSwitchData', 'selectShareSwitch'],
    data () {
      return {
        isEqualsOption: true,
        oldSelectShareSwitchList: null,
        selectShareSwitchList: [],
        checkAll: true,
        isIndeterminate: true
      }
    },
    watch: {
      selectShareSwitchList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldSelectShareSwitchList, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created () {
      // 获取渠道列表
      this.initSelectShareSwitchList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading', 'shareSwitchList'
      ])
    },
    methods: {
      initSelectShareSwitchList () {
        for (let item of this.shareSwitchList) {
          if (this.shareSwitchData && this.shareSwitchData.shareIds && this.shareSwitchData.shareIds.indexOf(item.iDicId) >= 0) {
            this.selectShareSwitchList.push(item)
          }
        }
        this.handleCheckedChange(this.selectShareSwitchList)
        this.oldSelectShareSwitchList = JSON.parse(JSON.stringify(this.selectShareSwitchList))
      },
      handleCheckAllChange (event) {
        this.selectShareSwitchList = event ? this.shareSwitchList : []
        this.isIndeterminate = false
      },
      handleCheckedChange (value) {
        let checkedCount = value.length
        this.checkAll = checkedCount === this.shareSwitchList.length
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.shareSwitchList.length
      },
      submitForm () {
        let params = {
          id: this.shareSwitchData.id,
          shareIds: ''
        }
        let selectShareIds = []
        for (let item of this.selectShareSwitchList) {
          selectShareIds.push(item.iDicId)
        }
        if (selectShareIds.length > 0) {
          params.shareIds = selectShareIds.join(',')
        }
        this.selectShareSwitch(params)
      }
    }
  }

</script>
