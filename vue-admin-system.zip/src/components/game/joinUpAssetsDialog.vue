<style>
  .option-dialog-join-up-assets .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
</style>
<template>
  <el-dialog title="接入游戏资源列表"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-join-up-assets">
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="gameAssetsName" label="资源名称"></el-table-column>
        <el-table-column label="资源类型">
          <template scope="scope">
            {{scope.row.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}
          </template>
        </el-table-column>
        <el-table-column label="游戏资源">
          <template scope="scope">
            {{!!scope.row.gameAssetPath?'已上传':'未上传'}}
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import pagination from '../../components/manager/pagination'

  export default{
    components: {
      pagination
    },
    props: ['optionData'],
    data () {
      return {
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'gameAssetsTypeList'
      ])
    },
    created: function () {
      this.optionType = this.$route.params.type || 'android'
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': 1, 'number': 9999}
        // 获取数据列表
        let dataId = this.optionType === 'ios' ? this.optionData.gameVersionInfo.iIosAssertId : this.optionData.gameVersionInfo.iAndrAssertId
        let type = this.optionType === 'ios' ? 1 : 0

        gameApi.getAssetsDataList(type, dataId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      }
    }
  }
</script>
