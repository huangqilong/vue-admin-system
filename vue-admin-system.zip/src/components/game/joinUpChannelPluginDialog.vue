<style>
  .option-dialog-channel-plugin .el-dialog{
    width: 700px;
  }
</style>
<template>
  <div>
    <el-dialog :title="optionData.title"
               :visible.sync="optionData.dialogFormVisible"
               class="option-dialog option-dialog-channel-plugin">
      <div class="content-list">
        <el-table :data="optionData.pluginDataList" stripe :default-sort = "{prop: 'pluginType', order: 'ascending'}">
          <el-table-column prop="pluginName" label="插件名称"></el-table-column>
          <el-table-column prop="channelVersion" label="插件版本" width="120"></el-table-column>
          <el-table-column prop="pluginType" label="插件类型" width="100">
            <template scope="scope">
              {{scope.row.pluginType=='1'?'功能':scope.row.pluginType=='2'?'广告':'渠道'}}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="220">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="pluginConfig(scope.$index, scope.row)"
                         v-if="roleAuthority.channelConfig && optionType=='android'">插件配置</el-button>
              <el-button type="text" class="table-option-button" @click="pluginParamConfig(scope.$index, scope.row)"
                         v-if="roleAuthority.enteringParams && scope.row.cReqParam == '1'">参数配置</el-button>
              <el-button type="text" class="table-option-button" @click="pluginParamShow(scope.$index, scope.row)"
                         v-if="roleAuthority.showParams && scope.row.cReqParam == '1' && scope.row.pluginParamId">查看参数</el-button>
              <span v-if="optionType=='ios' && !(roleAuthority.enteringParams && scope.row.cReqParam == '1') && !(roleAuthority.showParams && scope.row.cReqParam == '1' && scope.row.pluginParamId)">--</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关  闭</el-button>
      </div>
    </el-dialog>
    <relevance-plugin-config-dialog v-if="optionConfigData.dialogFormVisible"  :optionData="optionConfigData" :dataInfoForm="configInfoForm"></relevance-plugin-config-dialog>
    <show-data-info-dialog v-if="showInfoDataDialog.dialogShowVisible" :optionData="showInfoDataDialog"></show-data-info-dialog>
    <plugin-param-config-dialog v-if="pluginParamConfigDialog.dialogFormVisible" :optionData="pluginParamConfigDialog" :optionCallBack="getPluginDataList"></plugin-param-config-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import pluginApi from '../../apis/plugin-api'
  import relevancePluginConfigDialog from '../../components/game/relevancePluginConfigDialog'
  import showDataInfoDialog from '../../components/manager/showDataInfo'
  import pluginParamConfigDialog from '../../components/game/pluginParamConfigDialog'
  export default{
    components: {
      relevancePluginConfigDialog,
      showDataInfoDialog,
      pluginParamConfigDialog
    },
    props: ['optionData'],
    data () {
      return {
        optionType: 'android',
        optionConfigData: {
          title: '插件配置',
          dialogFormVisible: false
        },
        configInfoForm: null,
        showInfoDataDialog: {
          dialogShowVisible: false,
          title: '',
          tableHeader: [],
          tableDataList: []
        },
        pluginParamConfigDialog: {
          title: '',
          paramsDataList: [],
          dialogFormVisible: false
        }
      }
    },
    computed: {
      ...mapGetters([
        'pluginTypeList', 'roleAuthority'
      ])
    },
    created: function () {
      this.optionType = this.$route.params.type || 'android'
    },
    methods: {
      pluginConfig ($index, $item) {
        gameApi.getGameChannelRelevancePluginConfigDataInfo($item.iPluginId).then((data) => {
          if (data.code === 1) {
            this.configInfoForm = data.data
            this.optionConfigData.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getPluginDataList () {
        gameApi.getGameChannelRelevancePluginListV1(this.optionType === 'ios' ? 1 : 0, this.$route.query.iProjectId, this.optionData.channelInfo.iProjectChannelId, this.optionData.channelInfo.cChannelAlias).then((data) => {
          if (data.code === 1) {
            this.optionData.pluginDataList = data.data
          }
        }, (error) => {
          console.log(error)
        })
      },
      pluginParamConfig ($index, $item) {
        if ($item.pluginParamId) {
          pluginApi.getGcConfigDataInfo($item.pluginParamId).then((data) => {
            if (data.code === 1) {
              this.pluginParamConfigDialog.title = '插件参数配置（' + $item.pluginName + '）'
              delete data.data.iPlatformId
              delete data.data.iLanguageId
              delete data.data.iAreaId
              delete data.data.gameId
              data.data.projectId = parseInt(this.$route.query.iProjectId)
              data.data.iChannelId = this.optionData.channelInfo.iChannelId
              this.pluginParamConfigDialog.dataInfoForm = data.data
              this.pluginParamConfigDialog.dialogFormVisible = true
            } else {
              this.$alert(data.msg, '信息获取失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        } else {
          this.pluginParamConfigDialog.title = '插件参数配置（' + $item.pluginName + '）'
          let params = {
            projectId: parseInt(this.$route.query.iProjectId),
            iChannelId: this.optionData.channelInfo.iChannelId,
            cChannelAlias: this.optionData.channelInfo.cChannelAlias,
            iUserId: 0,
            paramsKey: $item.paramsKey,
            paramsValue: null,
            platformType: this.optionType === 'ios' ? '1' : '0',
            pluginDictId: $item.iDictId,
            pluginId: $item.pluginParamId,
            pluginType: $item.pluginType,
            sChannelName: this.optionData.channelInfo.channelName,
            sPlugin: $item.sPlugin
          }
          this.pluginParamConfigDialog.dataInfoForm = params
          this.pluginParamConfigDialog.dialogFormVisible = true
        }
      },
      pluginParamShow ($index, $item) {
        pluginApi.getGcConfigDataInfo($item.pluginParamId).then((data) => {
          if (data.code === 1) {
            let keyData = data.data.paramsKey ? data.data.paramsKey.split(',') : []
            let valData = data.data.paramsValue ? data.data.paramsValue.split(',') : []
            let paramsDataList = []
            for (let i in keyData) {
              paramsDataList.push({
                paramsKey: keyData[i],
                paramsValue: valData.length > 0 ? valData[i] : ''
              })
            }
            this.showInfoDataDialog.dialogShowVisible = true
            this.showInfoDataDialog.title = '查看参数（' + $item.pluginName + '）'
            this.showInfoDataDialog.tableHeader = [
              {
                label: '参数名',
                prop: 'paramsKey'
              },
              {
                label: '参数值',
                prop: 'paramsValue'
              }
            ]
            this.showInfoDataDialog.tableDataList = paramsDataList
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
