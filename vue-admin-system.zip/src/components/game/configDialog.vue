<style>
  .option-dialog-game-config .el-dialog{
    width: 900px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog-game-config .el-dialog .el-dialog__body {
    padding: 20px 20px 0 20px;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog .upload-demo-table{
    width: 80px;
  }
</style>
<template>
  <el-dialog :title="optionData.title"
             :visible.sync="optionData.dialogVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-game-config">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" :inline="true" label-width="140px">
      <div><b>基本配置：</b></div>
      <el-row>
        <el-col :span="12">
          <el-form-item label="配置名称：" prop="gameConfigName">
            <el-input v-model.trim="dataInfoForm.gameConfigName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="引擎版本：" prop="iEngineId">
            <el-select v-model="dataInfoForm.iEngineId" clearable placeholder="请选择">
              <el-option
                v-for="item in engineList"
                :key="item.iEngineId"
                :label="item.engineVersion"
                :value="item.iEngineId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否更新：" prop="cUpdate">
            <el-radio class="radio" v-model="dataInfoForm.cUpdate" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUpdate" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="屏幕拉伸策略：" prop="iScreenstretchId">
            <el-select v-model="dataInfoForm.iScreenstretchId" placeholder="请选择">
              <el-option
                v-for="item in screenStretchingList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否使用plist：" prop="cUsePlist">
            <el-radio class="radio" v-model="dataInfoForm.cUsePlist" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUsePlist" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否使用plistbin：" prop="cUsePlistBin">
            <el-radio class="radio" v-model="dataInfoForm.cUsePlistBin" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUsePlistBin" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否启用崩溃日志：" prop="cUseCrash">
            <el-radio class="radio" v-model="dataInfoForm.cUseCrash" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseCrash" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否使用内网：" prop="cUseLan">
            <el-radio class="radio" v-model="dataInfoForm.cUseLan" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseLan" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否使用后台运行：" prop="cUseBackgroundRun">
            <el-radio class="radio" v-model="dataInfoForm.cUseBackgroundRun" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseBackgroundRun" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否使用调试：" prop="cUseDebug">
            <el-radio class="radio" v-model="dataInfoForm.cUseDebug" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseDebug" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否多点触控：" prop="cUseMutiTouch">
            <el-radio class="radio" v-model="dataInfoForm.cUseMutiTouch" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseMutiTouch" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="状态栏：" prop="iStatusbarId">
            <el-select v-model="dataInfoForm.iStatusbarId" placeholder="请选择">
              <el-option
                v-for="item in statusBarList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="屏幕方向：" prop="iScreenDirectionId">
            <el-select v-model="dataInfoForm.iScreenDirectionId" placeholder="请选择">
              <el-option
                v-for="item in orientationForPackList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="自定义返回键：" prop="cUseCustomBack">
            <el-radio class="radio" v-model="dataInfoForm.cUseCustomBack" :label="1">使用</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseCustomBack" :label="0">不使用</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="自动锁屏：" prop="cUseAutoLock">
            <el-radio class="radio" v-model="dataInfoForm.cUseAutoLock" :label="1">使用</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseAutoLock" :label="0">不使用</el-radio>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="是否启用离线模式：" prop="cUseOffline">
            <el-radio class="radio" v-model="dataInfoForm.cUseOffline" :label="1">是</el-radio>
            <el-radio class="radio" v-model="dataInfoForm.cUseOffline" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
      </el-row>
      <div v-if="optionData.type=='gameChannel' || platformType=='android'"><b>其它配置：</b></div>
      <el-row v-if="optionData.type=='gameChannel' || platformType=='android'">
        <el-col :span="12" v-if="optionData.type=='gameChannel'">
          <el-form-item label="打包机版本配置：" prop="iScreenDirectionId">
            <el-select v-model="dataInfoForm.iPackMachineId" placeholder="请选择">
              <el-option
                v-for="item in packMachineDataList"
                :key="item.iPackMachineId+''"
                :label="item.sVersion"
                :value="item.iPackMachineId+''">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12" v-if="platformType=='android'">
          <el-form-item label="是否要填写metadata：" label-width="160px">
            <el-radio class="radio" v-model="isMetadata" :label="1">是</el-radio>
            <el-radio class="radio" v-model="isMetadata" :label="0">否</el-radio>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="platformType=='android'">
        <el-col :span="24" v-if="isMetadata == 1">
          <el-form-item label="metadata：">
            <el-input type="textarea" :rows="3" v-model="dataInfoForm.cMetadata" style="width: 635px;"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false" v-if="optionData.gameInfo.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading" v-if="optionData.gameInfo.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogVisible = false" v-if="optionData.gameInfo.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import packMachineApi from '../../apis/pack-machine-api'
  import gameApi from '../../apis/game-api'
  import engineApi from '../../apis/engine-api'

  export default{
    props: ['optionData'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        isMetadata: 1,
        platformType: 'ios',
        dataInfoForm: {
          gameConfigName: ''
        },
        engineList: null,
        packMachineDataList: [],
        rules: {
          gameConfigName: [
            {required: true, message: '请输入配置名称', trigger: 'blur'}
          ]
          /*
          iEngineId: [
            {type: 'number', required: true, message: '请选择引擎版本', trigger: 'change'}
          ],
          iScreenstretchId: [
            {type: 'number', required: true, message: '请选择屏幕拉伸策略', trigger: 'change'}
          ],
          iStatusbarId: [
            {type: 'number', required: true, message: '请选择状态栏', trigger: 'change'}
          ],
          iScreenDirectionId: [
            {type: 'number', required: true, message: '请选择屏幕方向', trigger: 'change'}
          ] */
        }
      }
    },
    computed: {
      ...mapGetters([
        'orientationForPackList', 'statusBarList', 'screenStretchingList', 'buttonLoading', 'platformList'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      for (const pItem of this.platformList) {
        if (pItem.iDicId === this.optionData.gameInfo.iPlatformId) {
          this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
        }
      }
      // 获取对应平台的引擎版本列表
      this.getEngineList()
      // 获取游戏配置信息
      this.getGameConfigInfo()
      // 获取打包机版本列表
      this.getPackMachineDataList()
    },
    methods: {
      getPackMachineDataList () {
        let _this = this
        // 获取数据列表
        packMachineApi.getDataListForPlatform(this.optionData.gameInfo.iPlatformId).then((data) => {
          if (data.code === 1) {
            _this.packMachineDataList = data.data
          } else {
            this.packMachineDataList = []
          }
        }, (error) => {
          this.packMachineDataList = []
        })
      },
      getEngineList () {
        let _this = this
        // 获取数据列表
        engineApi.getPlatEnginDataList(this.optionData.gameInfo.iPlatformId).then((data) => {
          if (data.code === 1) {
            _this.engineList = data.data
          } else {
            _this.$alert(data.msg, '引擎列表获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          _this.engineList = null
          _this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getGameConfigInfo () {
        let _this = this
        let id = ''
        if (this.optionData.type === 'game') {
          id = this.optionData.gameInfo.iProjectId
        } else {
          id = this.optionData.iProjectAssetId
        }
        // 获取数据列表
        gameApi.getGameConfigInfo(id, this.optionData.type).then((data) => {
          if (data.code === 1) {
            _this.dataInfoForm = data.data
            _this.dataInfoForm.iScreenstretchId = _this.dataInfoForm.iScreenstretchId === 0 ? '' : _this.dataInfoForm.iScreenstretchId
            _this.dataInfoForm.iStatusbarId = _this.dataInfoForm.iStatusbarId === 0 ? '' : _this.dataInfoForm.iStatusbarId
            _this.dataInfoForm.iScreenDirectionId = _this.dataInfoForm.iScreenDirectionId === 0 ? '' : _this.dataInfoForm.iScreenDirectionId
            this.isMetadata = this.dataInfoForm.cMetadata ? 1 : 0
            this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
          } else {
            _this.$alert(data.msg, '游戏配置信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          _this.dataInfoForm = null
          _this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'game') {
              _this.dataInfoForm.iProjectId = this.optionData.gameInfo.iProjectId
            } else {
              _this.dataInfoForm.iProjectAssetId = this.optionData.iProjectAssetId
            }
            let configInfo = JSON.parse(JSON.stringify(_this.dataInfoForm))
            if (!_this.dataInfoForm.iEngineId) {
              configInfo.iEngineId = 0
            }
            gameApi.updateGameConfigInfo(configInfo, this.optionData.type).then((data) => {
              if (data.code === 1) {
                _this.optionData.dialogVisible = false
              } else {
                _this.$alert(data.msg, '修改失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              console.log(error)
            })
          }
        })
      }
    }
  }
</script>
