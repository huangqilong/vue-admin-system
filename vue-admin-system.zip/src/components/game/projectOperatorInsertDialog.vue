<style>
  .option-dialog-project-game .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select,.option-dialog .el-input-number{
    width: 100%;
  }
</style>
<style scoped>
  .checkout-item-checkbox{
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-project-game">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="项目名称：">{{optionData.projectDataInfo.projectName}}</el-form-item>
      <el-form-item label="地区：" prop="iAreaId">
        <el-select v-model="dataInfoForm.iAreaId" placeholder="请选择" @change="getChannelList">
          <el-option
            v-for="item in areaList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="语言：" prop="iLanguageId">
        <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择" @change="getChannelList">
          <el-option
            v-for="item in languageList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="平台：" prop="iPlatformId">
        <el-radio-group v-model="dataInfoForm.iPlatformId" @change="getChannelList">
          <el-radio v-for="item in platformList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="渠道：">
        <el-row style="margin-top: 5px;">
          <el-checkbox-group v-model="packChannelIdsList">
            <el-col :span="6" v-for="item in channelList" class="channel-checkbox">
              <el-checkbox :label="item.iChannelId" :key="item.iChannelId" class="checkout-item-checkbox">
                <span v-if="item.channelName.replace(/[\u0391-\uFFE5]/g,'aa').length<=12">{{item.channelName}}</span>
                <el-tooltip :content="item.channelName" placement="bottom" effect="light" v-if="item.channelName.replace(/[\u0391-\uFFE5]/g,'aa').length>12">
                  <span>{{item.channelName}}</span>
                </el-tooltip>
              </el-checkbox>
            </el-col>
          </el-checkbox-group>
        </el-row>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm('dataInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameProjectApi from '../../apis/game-project-api'
  import channelApi from '../../apis/channel-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        channelList: [],
        packChannelIdsList: [],
        rules: {
          iAreaId: [
            {type: 'number', required: true, message: '请选择地区', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择语言', trigger: 'change'}
          ],
          iPlatformId: [
            {type: 'number', required: true, message: '请选择平台', trigger: 'change'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'buttonLoading'
      ])
    },
    created: function () {
      this.getChannelList()
    },
    methods: {
      getChannelList () {
        let _this = this
        channelApi.getAllDataList(this.dataInfoForm.iAreaId, this.dataInfoForm.iPlatformId, this.dataInfoForm.iLanguageId).then((data) => {
          if (data.code === 1) {
            _this.channelList = []
            for (let item of data.data) {
              if (_this.optionData.channelIds.indexOf(item.iChannelId) < 0) {
                _this.channelList.push(item)
              }
            }
          }
        }, (error) => {
          _this.channelList = null
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.packChannelIdsList.length <= 0) {
              this.$alert('请选择渠道', '提示', {
                confirmButtonText: '确定'
              })
              return
            }
            let submitParams = []
            for (let item of this.packChannelIdsList) {
              let param = {
                iItemId: this.$route.query.iItemId,
                iAreaId: this.dataInfoForm.iAreaId,
                iPlatformId: this.dataInfoForm.iPlatformId,
                iLanguageId: this.dataInfoForm.iLanguageId,
                iChannelId: item
              }
              submitParams.push(param)
            }
            // 数据新增
            gameProjectApi.addOperatorDataInfo(this.$route.query.iItemId, submitParams).then((data) => {
              if (data.code === 1) {
                this.optionData.dialogVisible = false
                _this.optionCallBack()
              } else {
                this.$alert(data.msg, '新增失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              console.log(error)
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
