<style>
  .option-dialog-game-version .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog .upload-demo-table{
    width: 80px;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
  .sync-pre-version-select .el-input__inner{
    height: 30px;
    line-height: inherit;
  }
</style>
<style scoped>
  .sync-pre-version{
    width: 400px;
    line-height: 35px;
    position: absolute;
    top: 12px;
    left: 130px;
  }
  .sync-pre-version .sync-pre-version-btn{
    padding: 7px 9px;
    font-size: 12px;
    border-radius: 4px;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增游戏版本':'修改游戏版本'"
             :visible.sync="optionData.dialogFormVisible" :close-on-click-modal="false"
             class="option-dialog option-dialog-game-version">
    <div class="sync-pre-version" v-if="false&&optionData.type=='add'&&this.$route.params.type=='android'&&dataList.length>0">
      <el-row :gutter="10">
        <el-col :span="7">同步版本信息：</el-col>
        <el-col :span="7">
          <el-select v-model="iAndrAssertId" placeholder="请选择" class="sync-pre-version-select" style="width: 100%;">
            <el-option
              v-for="item in dataList"
              :key="item.iAndrAssertId"
              :label="item.gameAssetsVersion"
              :value="item.iAndrAssertId">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="10">
          <el-button size="small" type="primary" class="sync-pre-version-btn" @click="getPreVersionInfo()">同 步</el-button>
        </el-col>
      </el-row>
    </div>
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="版本号：" prop="gameAssetsVersion">
        <el-input v-model.trim="dataInfoForm.gameAssetsVersion"></el-input>
      </el-form-item>
      <el-form-item label="版本同步：" v-if="optionData.type=='add'&&this.$route.params.type=='android'&&dataList.length>0">
        <el-select v-model="iAndrAssertId" placeholder="请选择" clearable @change="getPreVersionInfo()">
          <el-option
            v-for="item in dataList"
            :key="item.iAndrAssertId"
            :label="item.gameAssetsVersion"
            :value="item.iAndrAssertId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="版本描述：">
        <el-input type="textarea" :rows="3" v-model.trim="dataInfoForm.sDesc"></el-input>
      </el-form-item>
      <template v-if="this.$route.params.type=='android'">
        <el-form-item label="游戏ICON：">
          <iconConfigTable :fileConfig="iconFileConfig"></iconConfigTable>
        </el-form-item>
        <el-form-item label="渠道闪屏：">
          <splashConfigTable :fileConfig="splashFileConfig"></splashConfigTable>
        </el-form-item>
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || optionData.gameInfo.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='update' && optionData.gameInfo.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import equalsExtend from '../../utils/equals-extend'
  import iconConfigTable from '../manager/iconConfigTable'
  import splashConfigTable from '../manager/splashConfigTable'

  export default{
    components: {
      iconConfigTable,
      splashConfigTable
    },
    props: ['optionData', 'dataInfoForm', 'optionCallBack', 'dataList'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        oldProjectSplashDataList: null,
        oldProjectIconDataList: null,
        iAndrAssertId: '',
//        fileStoreUploadList: [],
        iconFileConfig: {
          platformType: 0,
          sourceType: 0,
          picType: 0
        },
        splashFileConfig: {
          platformType: 0,
          sourceType: 0,
          picType: 1
        },
        rules: {
          gameAssetsVersion: [
            {required: true, message: '请输入版本号', trigger: 'blur'},
            { pattern: /^[^\u4e00-\u9fa5]*$/, message: '版本号不能为中文', trigger: 'blur' }
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'projectSplashDataList', 'projectIconDataList', 'deleteGamePicIds', 'buttonLoading', 'fileUploadDirId'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      projectSplashDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      projectIconDataList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm) &&
            equalsExtend.objectEqual(this.oldProjectSplashDataList, this.projectSplashDataList) &&
            equalsExtend.objectEqual(this.oldProjectIconDataList, this.projectIconDataList)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.$route.params.type === 'android') {
        if (this.dataInfoForm.resDirId) {
          this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
        } else {
          this.$store.dispatch('getFileUploadDir', null)
        }
        this.oldProjectSplashDataList = JSON.parse(JSON.stringify(this.projectSplashDataList))
        this.oldProjectIconDataList = JSON.parse(JSON.stringify(this.projectIconDataList))
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      getPreVersionInfo () {
        if (this.iAndrAssertId === '') {
          return
        }
        gameApi.getPreVersionInfo(this.iAndrAssertId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm.sDesc = data.data.sDesc
            this.dataInfoForm.resDirId = data.data.resDirId
            this.$store.dispatch('updateProjectIconDataList', data.data.iconList)
            this.$store.dispatch('updateProjectSplashDataList', data.data.splashList)
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              if (_this.$route.params.type === 'android') {
                _this.dataInfoForm.resDirId = this.fileUploadDirId
                _this.dataInfoForm.splashList = []
                _this.dataInfoForm.iconList = []
                for (let iItem of _this.projectIconDataList) {
                  if (iItem.picUrl) {
                    _this.dataInfoForm.iconList.push({
                      cDictIds: iItem.iDicId,
                      sDictNames: iItem.sDicName,
                      cPicType: iItem.cPicType,
                      cSource: iItem.cSource,
                      iPlatformId: iItem.iPlatformId,
                      resIds: iItem.resId,
                      picUrl: iItem.picUrl
                    })
                  }
                }
                for (let sItem of _this.projectSplashDataList) {
                  let isNull = true
                  let tempRes = {
                    resId: [],
                    picUrl: []
                  }
                  let tempItem = {
                    cDictIds: sItem.splashId + ',' + sItem.orientationId,
                    sDictNames: sItem.splashName + ',' + sItem.orientationName,
                    cPicType: sItem.cPicType,
                    cSource: sItem.cSource,
                    iPlatformId: sItem.iPlatformId,
                    resIds: '',
                    picUrl: ''
                  }
                  for (let picItem of sItem.picList) {
                    if (picItem.picUrl) {
                      isNull = false
                      tempRes.resId.push(picItem.resId)
                      tempRes.picUrl.push(picItem.picUrl)
                    }
                  }
                  if (!isNull) {
                    tempItem.resIds = tempRes.resId.join(',')
                    tempItem.picUrl = tempRes.picUrl.join(',')
                    _this.dataInfoForm.splashList.push(tempItem)
                  }
                }
              }
              // 数据新增
              gameApi.addVersionDataInfo(_this.$route.params.type, _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (_this.$route.params.type === 'android') {
                _this.dataInfoForm.resDirId = this.fileUploadDirId
                if (equalsExtend.objectEqual(_this.oldDataInfoForm, this.dataInfoForm) &&
                  equalsExtend.objectEqual(_this.oldProjectSplashDataList, _this.projectSplashDataList) &&
                  equalsExtend.objectEqual(_this.oldProjectIconDataList, _this.projectIconDataList)) {
                  _this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                  return
                }
                _this.dataInfoForm.iconList = []
                _this.dataInfoForm.splashList = []
                for (let iItem of _this.projectIconDataList) {
                  if (iItem.picUrl) {
                    _this.dataInfoForm.iconList.push({
                      cDictIds: iItem.iDicId,
                      sDictNames: iItem.sDicName,
                      cPicType: iItem.cPicType,
                      cSource: iItem.cSource,
                      iPlatformId: iItem.iPlatformId,
                      iRefId: iItem.iRefId,
                      iPicId: iItem.iPicId,
                      resIds: iItem.resId,
                      picIds: iItem.picId,
                      picUrl: iItem.picUrl
                    })
                  }
                }
                for (let sItem of _this.projectSplashDataList) {
                  let isNull = true
                  let tempRes = {
                    resId: [],
                    picId: [],
                    picUrl: []
                  }
                  let tempItem = {
                    cDictIds: sItem.splashId + ',' + sItem.orientationId,
                    sDictNames: sItem.splashName + ',' + sItem.orientationName,
                    cPicType: sItem.cPicType,
                    cSource: sItem.cSource,
                    iPlatformId: sItem.iPlatformId,
                    iRefId: sItem.iRefId,
                    iPicId: sItem.iPicId,
                    picIds: '',
                    resIds: '',
                    picUrl: ''
                  }
                  for (let picItem of sItem.picList) {
                    if (picItem.picUrl) {
                      isNull = false
                      if (picItem.resId) {
                        tempRes.resId.push(picItem.resId)
                      }
                      if (picItem.picId) {
                        tempRes.picId.push(picItem.picId)
                      }
                      tempRes.picUrl.push(picItem.picUrl)
                    }
                  }
                  if (!isNull) {
                    tempItem.resIds = tempRes.resId.join(',')
                    tempItem.picIds = tempRes.picId.join(',')
                    tempItem.picUrl = tempRes.picUrl.join(',')
                    _this.dataInfoForm.splashList.push(tempItem)
                  }
                }
              } else {
                if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                  _this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                  return
                }
              }
              // 数据修改
              gameApi.updateVersionDataInfo(_this.$route.params.type, _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
