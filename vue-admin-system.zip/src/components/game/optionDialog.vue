<style>
  .option-dialog-game .el-dialog{
    width: 700px;
  }
  .option-dialog .el-select,.option-dialog .el-input-number{
    width: 100%;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-game">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="130px">
      <template v-if="optionData.type=='add'||optionData.type=='update'">
        <!--
        <el-form-item label="游戏ID：" prop="gameId">
          <el-input v-model.number.trim="dataInfoForm.gameId"></el-input>
        </el-form-item>
        <el-form-item label="项目名称：" prop="projectName">
          <el-input v-model.trim="dataInfoForm.projectName"></el-input>
        </el-form-item> -->
        <el-form-item label="项目名称：" prop="iItemId">
          <el-select v-model="dataInfoForm.iItemId" placeholder="请选择">
            <el-option
              v-for="item in gameProjectDataList"
              :key="item.iItemId"
              :label="item.projectName"
              :value="item.iItemId">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="游戏名称：" prop="gameName">
          <el-input v-model.trim="dataInfoForm.gameName"></el-input>
        </el-form-item>
        <el-form-item label="地区：" prop="iAreaId">
          <el-select v-model="dataInfoForm.iAreaId" placeholder="请选择" @change="judgeAreaType">
            <el-option
              v-for="item in areaList"
              :key="item.iDicId"
              :label="item.sDicName"
              :value="item.iDicId">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="语言：" prop="iLanguageId">
          <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择" @change="judgeLanguageType">
            <el-option
              v-for="item in languageList"
              :key="item.iDicId"
              :label="item.sDicName"
              :value="item.iDicId">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="平台：" prop="iPlatformId">
          <el-radio-group v-model="dataInfoForm.iPlatformId" @change="judgePlatformType">
            <el-radio v-for="item in platformList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <!--<el-form-item label="平台：" prop="iPlatformId">-->
          <!--<el-select v-model="dataInfoForm.iPlatformId" placeholder="请选择" @change="judgePlatformType">-->
            <!--<el-option-->
              <!--v-for="item in platformList"-->
              <!--:key="item.iDicId"-->
              <!--:label="item.sDicName"-->
              <!--:value="item.iDicId">-->
            <!--</el-option>-->
          <!--</el-select>-->
        <!--</el-form-item>-->
        <el-form-item label="工程code：" prop="projectCode">
          <el-input v-model.trim="dataInfoForm.projectCode"></el-input>
        </el-form-item>
        <el-form-item label="服务器版本号：" prop="serverVersion">
          <el-input v-model.trim="dataInfoForm.serverVersion"></el-input>
        </el-form-item>
        <el-form-item label="资源key：" prop="appKey">
          <el-input v-model.trim="dataInfoForm.appKey"></el-input>
        </el-form-item>
        <el-form-item label="额外拼接：">
          <el-input v-model.trim="dataInfoForm.extraSign" placeholder="若无，为空"></el-input>
        </el-form-item>
        <el-form-item label="额外资源：" prop="extraResPath">
          <el-row>
            <el-col :span="20">
              <el-upload
                class="upload-demo"
                :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
                :show-file-list="true"
                :multiple="false"
                :headers="headersFile"
                :file-list="extraResUploadList"
                :before-upload="beforeExtraResUpload"
                :on-success="handleExtraResSuccess"
                :on-remove="handleExtraResRemove"
                :on-error="handleExtraResError"
                :on-progress="handleExtraResProgress">
                <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
              </el-upload>
            </el-col>
            <el-col :span="4" style="padding-left: 10px;">
              <el-button size="mini" type="text" @click="extraResDemoUpload">实例</el-button>
              <el-button size="mini" type="text" @click="extraResUpload" v-if="dataInfoForm.extraResPath">下载</el-button>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="代理类型：" prop="cAssertType">
          <el-radio-group v-model="dataInfoForm.cAssertType" @change="judgeAssertType">
            <el-radio class="radio" :label="gameTypeList[0].iDicId">{{gameTypeList[0].sDicName}}</el-radio>
            <el-radio class="radio" :label="gameTypeList[1].iDicId">{{gameTypeList[1].sDicName}}</el-radio>
            <el-radio class="radio" :label="gameTypeList[2].iDicId">{{gameTypeList[2].sDicName}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="CDN开关：" prop="cdnFlag" v-if="areaType == '大陆' && languageType == '中文简体' && platformType == 'android'">
          <el-radio-group v-model="dataInfoForm.cdnFlag">
            <el-radio class="radio" :label="0">关闭</el-radio>
            <el-radio class="radio" :label="1">开启</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="审核服开关：" prop="reviewFlag" v-if="areaType == '大陆' && languageType == '中文简体' && platformType == 'android'">
          <el-radio-group v-model="dataInfoForm.reviewFlag">
            <el-radio class="radio" :label="0">关闭</el-radio>
            <el-radio class="radio" :label="1">开启</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="svn账户：" prop="svnUserName" v-if="platformType == 'ios'&&dataInfoForm.cAssertType == '1'">
          <el-input v-model.trim="dataInfoForm.svnUserName"></el-input>
        </el-form-item>
        <el-form-item label="svn密码：" prop="svnPassword" v-if="platformType == 'ios'&&dataInfoForm.cAssertType == '1'">
          <el-input v-model.trim="dataInfoForm.svnPassword"></el-input>
        </el-form-item>
        <el-form-item label="工程名称：" prop="svnProjectName" v-if="platformType == 'ios'&&dataInfoForm.cAssertType == '1'">
          <el-input v-model.trim="dataInfoForm.svnProjectName"></el-input>
        </el-form-item>
      </template>
      <template v-if="optionData.type=='bugly'">
        <el-form-item label="bugly ID：" label-width="120px" prop="buglyId">
          <el-input v-model.trim="dataInfoForm.buglyId"></el-input>
        </el-form-item>
        <el-form-item label="bugly KEY：" label-width="120px" prop="buglyKey">
          <el-input v-model.trim="dataInfoForm.buglyKey"></el-input>
        </el-form-item>
      </template>
      <template v-if="optionData.type=='keystore'">
        <el-form-item label="签名文件：" prop="keystorePath">
          <el-upload
            class="upload-demo"
            :action="proxyDevApi + '/uploadFile/' +fileUploadDirId"
            :show-file-list="true"
            :multiple="false"
            :headers="headersFile"
            :file-list="fileStoreUploadList"
            :before-upload="beforeAvatarUpload"
            :on-success="handleStoreFileSuccess"
            :on-remove="handleStoreFileRemove"
            :on-error="handleStoreFileError"
            :on-progress="handleStoreFileProgress">
            <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="签名密码：" prop="keyPassword">
          <el-input v-model.trim="dataInfoForm.keyPassword"></el-input>
        </el-form-item>
        <el-form-item label="注意事项：">
          <el-input type="textarea" :rows="3" v-model.trim="dataInfoForm.sDemo" placeholder="如果更换签名文件和密码请在这里填写一下更换签名所影响的范围。"></el-input>
        </el-form-item>
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false" v-if="optionData.type=='add' || optionData.type=='keystore' || dataInfoForm.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || optionData.type=='keystore' || dataInfoForm.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogVisible = false" v-if="dataInfoForm.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import equalsExtend from '../../utils/equals-extend'
  import gameProjectApi from '../../apis/game-project-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      let checkNumber = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('请输入游戏ID'))
        }
        setTimeout(() => {
          if (!Number.isInteger(value)) {
            callback(new Error('请输入数字值'))
          } else {
            if (value < 0 || value > 99999) {
              callback(new Error('游戏ID长度为1-5'))
            } else {
              callback()
            }
          }
        }, 1000)
      }
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        gameProjectDataList: [],
        gameProjectDataInfo: {
          cAssertType: '0'
        },
        platformType: 'android',
        areaType: '',
        languageType: '',
        gameAssertType: '老代理',
        fileStoreUploadList: [],
        extraResUploadList: [],
        rules: {
          iAreaId: [
            {type: 'number', required: true, message: '请选择地区', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择语言', trigger: 'change'}
          ],
          iPlatformId: [
            {type: 'number', required: true, message: '请选择平台', trigger: 'change'}
          ],
          gameId: [
            {type: 'number', required: true, message: '请输入游戏ID', trigger: 'blur'},
            {validator: checkNumber, trigger: 'blur'}
          ],
          projectName: [
            {required: true, message: '请输入项目名称', trigger: 'blur'}
          ],
          gameName: [
            {required: true, message: '请输入游戏名称', trigger: 'blur'}
//            { pattern: /^[\u4e00-\u9fa50-9a-zA-Z_]{1,15}$/, message: '中文+英文,长度在 1 到 15 个字符', trigger: 'blur' }
          ],
          projectCode: [
            {required: true, message: '请输入工程code', trigger: 'blur'}
          ],
          serverVersion: [
            {required: true, message: '请输入服务器版本号', trigger: 'blur'}
          ],
          appKey: [
            {required: true, message: '请输入资源key', trigger: 'blur'}
          ],
          extraSign: [
            {required: true, message: '请输入额外拼接', trigger: 'blur'}
          ],
          cAssertType: [
            {required: true, message: '请选择代理类型', trigger: 'change'}
          ],
          buglyId: [
            {required: true, message: '请输入buglyId', trigger: 'blur'}
          ],
          buglyKey: [
            {required: true, message: '请输入buglyKey', trigger: 'blur'}
          ],
          keystorePath: [
            {required: true, message: '请上传签名文件', trigger: 'change'}
          ],
          keyPassword: [
            {required: true, message: '请输入签名密码', trigger: 'blur'}
          ],
          svnUserName: [
            {required: true, message: '请输入svn账户', trigger: 'blur'}
          ],
          svnPassword: [
            {required: true, message: '请输入svn密码', trigger: 'blur'}
          ],
          svnProjectName: [
            {required: true, message: '请输入工程名称', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'buttonLoading',
        'proxyDevApi', 'fileUploadDirId', 'headersFile', 'extraResPath', 'gameTypeList', 'iosExtraResPath'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.optionData.type === 'keystore' && this.dataInfoForm.keystorePath) {
        this.fileStoreUploadList = []
        this.fileStoreUploadList.push({
          name: this.dataInfoForm.keystorePath
        })
      }
      if (this.optionData.type === 'update' && this.dataInfoForm.extraResPath) {
        this.extraResUploadList = []
        this.extraResUploadList.push({
          name: this.dataInfoForm.extraResPath,
          resId: this.dataInfoForm.resId
        })
      }
      if (this.dataInfoForm.resDirId) {
        this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
      } else {
        this.$store.dispatch('getFileUploadDir', null)
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
      this.judgeAreaType()
      this.judgeLanguageType()
      this.judgePlatformType()
      this.judgeAssertType()
      // 获取项目列表
      this.getGameProjectDataList()
    },
    methods: {
      getSelectProjectInfo (type) {
        for (let item of this.gameProjectDataList) {
          if (this.dataInfoForm.iItemId === item.iItemId) {
            this.gameProjectDataInfo = item
            if (!type || type !== 'init') {
              this.dataInfoForm.gameName = this.gameProjectDataInfo.projectName
            }
          }
        }
      },
      getGameProjectDataList () {
        let _this = this
        const params = {'currentPage': 1, 'number': 9999}
        // 获取数据列表
        gameProjectApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.gameProjectDataList = data.data.list
//            _this.getSelectProjectInfo('init')
          } else {
            this.gameProjectDataList = []
          }
        }, (error) => {
          this.gameProjectDataList = []
        })
      },
      judgeAreaType () {
        for (const pItem of this.areaList) {
          if (pItem.iDicId === this.dataInfoForm.iAreaId) {
            this.areaType = pItem.sDicName
          }
        }
      },
      judgeLanguageType () {
        for (const pItem of this.languageList) {
          if (pItem.iDicId === this.dataInfoForm.iLanguageId) {
            this.languageType = pItem.sDicName
          }
        }
      },
      // 判断平台类型
      judgePlatformType () {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === this.dataInfoForm.iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
      },
      judgeAssertType () {
        for (const pItem of this.gameTypeList) {
          if (pItem.iDicId === this.dataInfoForm.cAssertType) {
            this.gameAssertType = pItem.sDicName
          }
        }
      },
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegCert = /.(jks|keystore)/
        let isUpload = androidRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('签名文件格式只能为jks|keystore', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleStoreFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleStoreFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.fileStoreUploadList.length > 0 && this.fileStoreUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.fileStoreUploadList[0].resId)
          }
          this.fileStoreUploadList = []
          let fileName = response.data.url
          this.fileStoreUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.keystorePath = fileName
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.fileStoreUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleStoreFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.keystorePath = ''
        this.dataInfoForm.resId = ''
      },
      handleStoreFileError (error, file, fileList) {
        this.fileStoreUploadList = []
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      extraResDemoUpload () {
        if (this.platformType === 'ios') {
          window.location.href = this.iosExtraResPath
        } else {
          window.location.href = this.extraResPath
        }
      },
      extraResUpload () {
        let realPath = window.location.href
        let extraRP = this.dataInfoForm.extraResPath.substring(this.dataInfoForm.extraResPath.indexOf('/upload/'))
        let extraDownloadPath = ''
        if (realPath.indexOf('192.168.0.147') >= 0) {
          extraDownloadPath = 'http://192.168.0.147/cms' + extraRP
        } else {
          extraDownloadPath = 'http://192.168.0.148/cms' + extraRP
        }
        window.location.href = extraDownloadPath
      },
      beforeExtraResUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegCert = /.(zip|rar)/
        let isUpload = androidRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('渠道额外资源格式只能为zip', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleExtraResProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleExtraResSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.extraResUploadList.length > 0 && this.extraResUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.extraResUploadList[0].resId)
          }
          this.extraResUploadList = []
          let fileName = response.data.url
          this.extraResUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.extraResPath = fileName
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.extraResUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleExtraResRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.extraResPath = ''
        this.dataInfoForm.resId = ''
      },
      handleExtraResError (error, file, fileList) {
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              gameApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm)) {
                this.optionData.dialogVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              gameApi.updateDataInfo(_this.dataInfoForm, this.optionData.type).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
