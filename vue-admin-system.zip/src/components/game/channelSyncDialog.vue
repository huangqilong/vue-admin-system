<style>
  .option-dialog-join-up .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .option-dialog .el-table td, .el-table th {
    height: 40px;
  }
</style>
<style scoped>
  .warn-message{
    color: #2ebd59;
    margin-bottom: 10px;
  }
  .game-version-select{
    width: 220px;
    margin-bottom: 15px;
  }
</style>
<template>
  <el-dialog title="同步渠道"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-join-up">
    <div class="content-list">
      <div class="warn-message">提示：同步功能只能使用一次</div>
      <div class="game-version-select">
        <el-select v-model="gameVersion" value-key="gameAssetId" placeholder="请选择" @change="selectGameVersion">
          <el-option
            v-for="item in gameVersionList"
            :key="item.gameAssetId"
            :label="item.gameAssetVersion"
            :value="item">
          </el-option>
        </el-select>
      </div>
      <el-table :data="dataList" stripe>
        <el-table-column prop="gameAssetsName" label="资源名称"></el-table-column>
        <el-table-column prop="cAssertType" label="资源类型">
          <template scope="scope">
            {{scope.row.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}
          </template>
        </el-table-column>
        <el-table-column prop="channelNum" label="配置渠道"></el-table-column>
        <el-table-column label="操作（单选）">
          <template scope="scope">
            <el-radio class="radio" v-model="iProjectAssetId" :label="scope.row.iProjectAssetId">&nbsp;</el-radio>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  export default{
    components: {
    },
    props: ['optionData'],
    data () {
      return {
        iProjectAssetId: 0,
        platformType: 1,
        gameVersionList: [],
        gameVersion: null,
        dataList: []
      }
    },
    computed: {
      ...mapGetters([
        'gameAssetsTypeList', 'buttonLoading', 'gameConfigOldDate'
      ])
    },
    created: function () {
      this.platformType = this.$route.params.type === 'ios' ? 1 : 0
      this.getChannelSyncDataList()
    },
    methods: {
      getChannelSyncDataList () {
        gameApi.getChannelSyncDataList(this.optionData.gameInfo.iProjectId, this.platformType).then((data) => {
          if (data.code === 1) {
            this.gameVersionList = data.data
            if (this.gameVersionList.length > 0) {
              this.gameVersion = this.gameVersionList[0]
              this.dataList = this.gameVersion.gameProjectAssetVOS
              if (this.dataList.length > 0) {
                this.iProjectAssetId = this.dataList[0].iProjectAssetId
              }
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      selectGameVersion (selectVal) {
        this.dataList = []
        this.iProjectAssetId = 0
        if (selectVal.gameProjectAssetVOS && selectVal.gameProjectAssetVOS.length > 0) {
          this.dataList = selectVal.gameProjectAssetVOS
          if (this.dataList.length > 0) {
            this.iProjectAssetId = this.dataList[0].iProjectAssetId
          }
        }
      },
      submitForm () {
        if (this.iProjectAssetId === 0) {
          return
        }
        gameApi.postChannelSyncInfo(this.$route.params.type, this.iProjectAssetId, this.optionData.gameAssetsInfo.iProjectAssetId).then((data) => {
          if (data.code === 1) {
            this.optionData.dialogFormVisible = false
            if (new Date(this.optionData.gameAssetsInfo.dCreate) - new Date(this.gameConfigOldDate) < 0) {
              this.$router.push({path: '/home/game/list/config/' + this.$route.params.type,
                query: {iProjectId: this.$route.query.iProjectId, iAssertId: this.$route.query.iAssertId, iProjectAssetId: this.optionData.gameAssetsInfo.iProjectAssetId}})
            } else {
              this.$router.push({path: '/home/game/list/assets/channel/' + this.$route.params.type,
                query: {iProjectId: this.$route.query.iProjectId, iAssertId: this.$route.query.iAssertId}})
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
