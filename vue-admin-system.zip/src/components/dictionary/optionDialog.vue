<style>
  .option-dialog-dic .el-dialog{
    width: 700px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .dictionary-option-btn{
    padding: 10px;

  }
  .dictionary-option-btn.el-button+.el-button{
    margin-left: 0px;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增字典':'修改字典'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-dic">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="字典名称：" prop="sDicName">
        <el-input v-model.trim="dataInfoForm.sDicName"></el-input>
      </el-form-item>
      <el-form-item label="字典别名：" prop="cDicType">
        <el-input v-model.trim="dataInfoForm.cDicType" :disabled="optionData.type!='add'"></el-input>
      </el-form-item>
      <el-row>
        <el-col style="width: 88px;text-align: right;margin-bottom: 10px;">字典详情：</el-col>
      </el-row>
      <el-row v-for="(domain,index) in dataInfoForm.dictItemList" :gutter="5" style="margin-left: 15px;">
        <el-col :span="5">
          <el-form-item label-width="0px"
                        :prop="'dictItemList.' + index + '.sDicName'"
                        :rules="[{required: true, message: '请输入值', trigger: 'blur'},{validator: checkDicName, trigger: 'blur'}]">
            <el-input v-model.trim="domain.sDicName" placeholder="值"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item label-width="0px"
                        :prop="'dictItemList.' + index + '.sDicValue'"
                        :rules="[{required: true, message: '请输入编码', trigger: 'blur'},{validator: checkDicValue, trigger: 'blur'}]">
            <el-input v-model.trim="domain.sDicValue" placeholder="编码"></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="4">
          <el-form-item label-width="0px">
            <el-input type="number" min="0" v-model.trim="domain.iOrderNum" placeholder="排序"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label-width="0px">
            <el-select v-model="domain.cEnable" placeholder="请选择">
              <el-option
                v-for="item in [{'name':'启用','value':'1'},{'name':'禁用','value':'0'}]"
                :key="item.value"
                :label="item.name"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item label-width="0px">
            <el-button class="dictionary-option-btn" @click.prevent="removeItem(index,domain)" :disabled="index==0 || !!domain.iDicId">删除</el-button>
            <el-button class="dictionary-option-btn" type="primary" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.dictItemList.length-1">添加</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import dictionaryApi from '../../apis/dictionary-api'

  export default{
    components: {},
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        rules: {
          sDicName: [
            {required: true, message: '请输入字典名称', trigger: 'blur'}
          ],
          cDicType: [
            {required: true, message: '请输入字典别名', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.dictItemList.push({
              sDicName: '',
              sDicValue: '',
              iOrderNum: '1',
              cEnable: '1',
              iParentId: this.dataInfoForm.iDicId ? this.dataInfoForm.iDicId : 0
            })
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index, item) {
        this.dataInfoForm.dictItemList.splice($index, 1)
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              dictionaryApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.$store.dispatch('dictionaryUpdate', _this.dataInfoForm.cDicType)
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              dictionaryApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  // 更新字典数据
                  this.$store.dispatch('dictionaryUpdate', _this.dataInfoForm.cDicType)
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      },
      checkDicName (rule, value, callback) {
        if (!value) {
          return callback(new Error('请输入值'))
        }
        setTimeout(() => {
          let infoItemsStr = JSON.stringify(this.dataInfoForm.dictItemList)
          let valStr = JSON.stringify({sDicName: value})
          if (infoItemsStr.split(valStr.substring(1, valStr.length - 1)).length <= 2) {
            callback()
          } else {
            callback(new Error('值已存在'))
          }
        }, 1000)
      },
      checkDicValue (rule, value, callback) {
        if (!value) {
          return callback(new Error('请输入编码'))
        }
        setTimeout(() => {
          let infoItemsStr = JSON.stringify(this.dataInfoForm.dictItemList)
          let valStr = JSON.stringify({sDicValue: value})
          if (infoItemsStr.split(valStr.substring(1, valStr.length - 1)).length <= 2) {
            callback()
          } else {
            callback(new Error('编码已存在'))
          }
        }, 1000)
      }
    }
  }
</script>
