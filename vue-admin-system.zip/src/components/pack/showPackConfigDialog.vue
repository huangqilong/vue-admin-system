<style>
  .option-dialog-pack-config .el-dialog{
    width: 800px;
  }
  .option-dialog-pack-config .el-form .el-row .el-col, .popover-content-pack-config .el-row .el-col {
    line-height: 25px;
    overflow: hidden;
    text-overflow: ellipsis;
    height: 36px;
  }
  .img-content{
  }
  .img-content .img-item{
    width: 100px;
    height: 100px;
    margin: 0 auto;
    position: relative;
  }
  .img-content .img-item .img-item-icon{
    position: absolute;
    right: 2px;
    top: 2px;
    cursor: pointer;
  }
  .img-content .img-item img{
    width: 100%;
    height: 100%;
  }
</style>
<style scoped>
  .row-col{
    border: 1px solid #dfe6ec;
    padding: 5px 5px 5px 10px;
  }
  .label-title{
    background-color: #eef1f6;
    text-align: right;
  }

</style>
<template>
  <el-dialog title="查看配置" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pack-config">
    <el-form :model="dataInfoForm" label-position="top">
      <el-form-item label="游戏配置：">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">地区：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.areaName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">语言：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.languageName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">平台：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.platformName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">游戏ID：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.gameId}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">游戏名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.gameName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">工程code：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.projectCode}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">服务器版本号：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.serverVersion}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">资源key：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.appKey}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">额外拼接：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.extraSign}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">游戏版本号：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.gameAssetsVersion}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">资源类型：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">资源名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.assetsName}}</el-col>
        </el-row>
        <!--<el-row>-->
          <!--<el-col :span="colSpansSecond[0]" class="row-col label-title">上传方式：</el-col>-->
          <!--<el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.areaName}}</el-col>-->
        <!--</el-row>-->
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">游戏资源：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.gameAssetPath}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="游戏渠道信息：" v-if="platformType=='ios'">
        <el-tabs v-model="tabValue" type="card" class="tabs-content">
          <el-tab-pane label="白名单列表" name="first">
            <el-row v-for="(domain,index) in whiteListForm">
              <el-col :span="colSpansSecond[0]" class="row-col label-title">值：</el-col>
              <el-col :span="colSpansSecond[1]" class="row-col">{{domain.value}}</el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="url映射列表" name="second">
            <el-row v-for="(domain,index) in urlMapListForm">
              <el-col :span="colSpans[0]" class="row-col label-title">键名称：</el-col>
              <el-col :span="colSpans[1]" class="row-col">{{domain.value1}}</el-col>
              <el-col :span="colSpans[2]" class="row-col label-title">键值：</el-col>
              <el-col :span="colSpans[3]" class="row-col">{{domain.value2}}</el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="info额外配置列表" name="third">
            <el-row v-for="(domain,index) in infoConfigForm">
              <el-col :span="colSpans[0]" class="row-col label-title">键名称：</el-col>
              <el-col :span="colSpans[1]" class="row-col">{{domain.value1}}</el-col>
              <el-col :span="colSpans[2]" class="row-col label-title">键值：</el-col>
              <el-col :span="colSpans[3]" class="row-col">{{domain.value2}}</el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="entitments配置列表" name="fourth">
            <el-row v-for="(domain,index) in entitmentsConfigForm">
              <el-col :span="colSpans[0]" class="row-col label-title">键名称：</el-col>
              <el-col :span="colSpans[1]" class="row-col">{{domain.value1}}</el-col>
              <el-col :span="colSpans[2]" class="row-col label-title">键值：</el-col>
              <el-col :span="colSpans[3]" class="row-col">{{domain.value2}}</el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="闪屏" name="fourth1">
            <el-table :data="projectSplashDataList" stripe>
              <el-table-column prop="splashName" label="分辨率"></el-table-column>
              <el-table-column prop="orientationName" label="屏幕方向"></el-table-column>
              <el-table-column label="图片资源">
                <template scope="scope">
                  <el-popover v-if="scope.row.picList.length>0"
                              placement="bottom"
                              title="预览图片"
                              width="200"
                              trigger="hover">
                    <div class="img-content">
                      <div class="img-item" v-for="(pItem,pIndex) in scope.row.picList">
                        <img :src="pItem.picUrl">
                      </div>
                    </div>
                    <el-button slot="reference" type="text" class="table-option-button">预览</el-button>
                  </el-popover>
                  <span v-if="scope.row.picList.length<=0">----</span>
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
          <el-tab-pane label="游戏ICON" name="fourth2">
            <el-table :data="projectIconDataList" stripe>
              <el-table-column prop="sDicName" label="分辨率"></el-table-column>
              <el-table-column label="图片资源">
                <template scope="scope">
                  <el-popover v-if="scope.row.picUrl"
                              placement="bottom"
                              title="预览图片"
                              width="200"
                              trigger="hover">
                    <div class="img-content">
                      <div class="img-item">
                        <img :src="scope.row.picUrl">
                      </div>
                    </div>
                    <el-button slot="reference" type="text" class="table-option-button">预览</el-button>
                  </el-popover>
                  <span v-if="!scope.row.picUrl">----</span>
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </el-form-item>
      <el-form-item label="游戏渠道信息：" v-if="platformType=='android'">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">渠道名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iChannelName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">渠道版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.iChannelConfigName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">代理版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.cMiddleareVersion}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">版本号：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.versionCode}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">版本名字：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.versionName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">渠道包名：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.packageName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">签名文件：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.keystorePath}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">签名密码：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.keyPassword}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">最小系统版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.minVersion}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">指定系统版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.targetVersion}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">是否使用obb：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.crcValue?'是：crc值'+gameInfo.crcValue:'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">是否需要分包：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.cDex?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">bugly id：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.buglyId}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">bugly  key：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{gameInfo.buglyKey}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">操作：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">
            <el-popover
                        placement="bottom"
                        title="渠道配置信息"
                        width="600"
                        trigger="hover">
              <div class="popover-content-pack-config">
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">最小系统版本：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.minSdkVersion}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">指定系统版本：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.targetSdkVersion}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">渠道版本值：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.channelVersionValue}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">版本额外字段：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.channelVersionExtra}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">maven的名称：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.mavenChannelName}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">maven的group：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.mavenChannelGroup}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">applicationName：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.applicationName}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">特殊处理的渠道配置ID：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.specChannelConfig}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">是否分包：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.cDex==1?'是':'否'}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">是否需要生成微信jar：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.cWxjar==1?'是':'否'}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">是否需要填写metadata：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.cMetadata==1?'是':'否'}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">渠道自定义参数：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.metaData}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">是否需要特殊处理：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.cSpeHand==1?'是':'否'}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">特殊处理路径：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.spePath}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">特殊处理文件名称：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.speFileName}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">特殊处理文件内容：</el-col>
                  <el-col :span="colSpans[3]" class="row-col">{{channelConfigInfo.speContent}}</el-col>
                </el-row>
                <el-row>
                  <el-col :span="colSpans[0]" class="row-col label-title">客户端是否请求接口初始化接口：</el-col>
                  <el-col :span="colSpans[1]" class="row-col">{{channelConfigInfo.cRequestParams==1?'是':'否'}}</el-col>
                  <el-col :span="colSpans[2]" class="row-col label-title">&nbsp;</el-col>
                  <el-col :span="colSpans[3]" class="row-col">&nbsp;</el-col>
                </el-row>
              </div>
              <el-button slot="reference" type="text" class="table-option-button">渠道配置信息</el-button>
            </el-popover>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="插件信息：">
        <el-table :data="pluginsList" border>
          <el-table-column prop="areaName" label="地区">
            <template scope="scope">
              {{gameInfo.areaName}}
            </template>
          </el-table-column>
          <el-table-column prop="languageName" label="语言">
            <template scope="scope">
              {{gameInfo.languageName}}
            </template>
          </el-table-column>
          <el-table-column prop="platformName" label="平台">
            <template scope="scope">
              {{gameInfo.platformName}}
            </template>
          </el-table-column>
          <el-table-column prop="pluginType" label="插件类型"></el-table-column>
          <el-table-column prop="pluginName" label="插件名称"></el-table-column>
          <el-table-column prop="channelVersion" label="插件版本"></el-table-column>
          <el-table-column label="操作" v-if="platformType=='android'">
            <template scope="scope">
              <el-popover
                placement="bottom"
                title="插件配置信息"
                width="600"
                trigger="hover">
                <div class="popover-content-pack-config">
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">最小系统版本：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.minSdkVersion}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">指定系统版本：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.targetSdkVersion}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">渠道版本值：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.channelVersionValue}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">版本额外字段：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.channelVersionExtra}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">maven的名称：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.mavenChannelName}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">maven的group：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.mavenChannelGroup}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">applicationName：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.applicationName}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">特殊处理的渠道配置ID：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.specChannelConfig}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">是否分包：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.cDex==1?'是':'否'}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">是否需要生成微信jar：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.cWxjar==1?'是':'否'}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">是否需要填写metadata：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.cMetadata==1?'是':'否'}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">渠道自定义参数：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.metaData}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">是否需要特殊处理：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.cSpeHand==1?'是':'否'}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">特殊处理路径：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.spePath}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">特殊处理文件名称：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.speFileName}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">特殊处理文件内容：</el-col>
                    <el-col :span="colSpans[3]" class="row-col">{{scope.row.speContent}}</el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="colSpans[0]" class="row-col label-title">客户端是否请求接口初始化接口：</el-col>
                    <el-col :span="colSpans[1]" class="row-col">{{scope.row.cRequestParams==1?'是':'否'}}</el-col>
                    <el-col :span="colSpans[2]" class="row-col label-title">&nbsp;</el-col>
                    <el-col :span="colSpans[3]" class="row-col">&nbsp;</el-col>
                  </el-row>
                </div>
                <el-button slot="reference" type="text" class="table-option-button">配置信息</el-button>
              </el-popover>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="打包配置：">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">配置名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.gameConfigName}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">引擎版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.iEngineName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否更新：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUpdate==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">屏幕拉伸策略：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.iScreenstretchName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否使用plist：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUsePlist==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否使用plistbin：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUsePlistBin==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否启用崩溃日志：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseCrash==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否使用内网：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseLan==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否使用后台运行：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseBackgroundRun==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否使用调试：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseDebug==1?'是':'否'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">是否多点触控：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseMutiTouch==1?'是':'否'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">状态栏：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.iStatusbarName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">屏幕方向：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.iScreenDirectionName}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">自定义返回键：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseCustomBack==1?'使用':'不使用'}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">自动锁屏：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameConfigInfo.cUseAutoLock==1?'使用':'不使用'}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">是否启用离线模式：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameConfigInfo.cUseOffline==1?'是':'否'}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="IOS证书配置：" v-if="platformType=='ios'">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">游戏平台：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.platformName}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">签名方式：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{iOSCertConfigInfo.cCertType==signatureTypeList[0].iDicId?signatureTypeList[0].sDicName:signatureTypeList[1].sDicName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">证书名称：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{iOSCertConfigInfo.cCertName}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">安装密码：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{iOSCertConfigInfo.cCertPwd}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">证书文件：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{iOSCertConfigInfo.cCertPath}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="bugly配置：">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">bugly ID：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.buglyId}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">bugly Key：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.buglyKey}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="代理信息：" v-if="platformType=='ios'">
        <el-row>
          <el-col :span="colSpans[0]" class="row-col label-title">平台：</el-col>
          <el-col :span="colSpans[1]" class="row-col">{{gameInfo.platformName}}</el-col>
          <el-col :span="colSpans[2]" class="row-col label-title">版本：</el-col>
          <el-col :span="colSpans[3]" class="row-col">{{gameInfo.cMiddleareVersion}}</el-col>
        </el-row>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packToolApi from '../../apis/pack-tool-api'
  import channelApi from '../../apis/channel-api'

  export default{
    props: ['optionData'],
    data () {
      return {
        platformType: 'ios', // 平台类型
        tabValue: 'first',
        colSpans: [5, 7, 5, 7],
        colSpansSecond: [5, 19],
        dataInfoForm: null,
        gameInfo: {
          areaName: ''
        },
        pluginsList: [],
        gameConfigInfo: {
          gameConfigName: ''
        },
        gameProjectChannelInfo: null,
        channelConfigInfo: {
          minSdkVersion: ''
        },
        iOSCertConfigInfo: {
          cCertType: 1
        },
        // 白名单列表
        whiteListForm: [],
        // Url映射列表
        urlMapListForm: [],
        // info额外配置列表
        infoConfigForm: [],
        // entitments配置列表
        entitmentsConfigForm: []
      }
    },
    computed: {
      ...mapGetters([
        'platformList', 'gameAssetsTypeList', 'packGameInfo', 'projectSplashDataList', 'projectIconDataList', 'signatureTypeList'
      ])
    },
    created: function () {
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === this.packGameInfo.iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
        let pType = this.platformType === 'ios' ? 1 : 0
        packToolApi.getPackGameConfigDataInfo(pType, this.packGameInfo.iGamePackId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.gameInfo = this.platformType === 'ios' ? data.data.iosSettingVO : data.data.androidSettingVO
            this.pluginsList = JSON.parse(JSON.stringify(this.gameInfo.pluginsList))
            this.gameConfigInfo = this.platformType === 'ios' ? this.gameInfo.gameConfigVO : this.gameInfo.gameConfig
            if (this.platformType === 'android' && this.gameInfo.iChannelConfigId) {
              this.configDataInfo(this.gameInfo.iChannelConfigId)
            }
            if (this.platformType === 'ios') {
              this.gameProjectChannelInfo = this.gameInfo.iOSProjectChannelVO
              this.iOSCertConfigInfo = this.gameInfo.iOSCertConfig

              for (const dItem of this.gameProjectChannelInfo.iosWhiteVOList) {
                this.whiteListForm.push({
                  id: dItem.iWhitelistId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value: dItem.cQueriesScheme
                })
              }
              for (const dItem of this.gameProjectChannelInfo.iosUrlSchemeVOList) {
                this.urlMapListForm.push({
                  id: dItem.iUrlSchemeId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value1: dItem.urlSchemeName,
                  value2: dItem.urlSchemeIdentifer
                })
              }
              for (const dItem of this.gameProjectChannelInfo.iosPlistVOList) {
                this.infoConfigForm.push({
                  id: dItem.iPlistId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value2: dItem.infoValue,
                  value1: dItem.infoKey
                })
              }
              for (const dItem of this.gameProjectChannelInfo.entitlementsVOList) {
                this.entitmentsConfigForm.push({
                  id: dItem.iEntitlementsId,
                  iProjectChannelId: dItem.iProjectChannelId,
                  value2: dItem.entitlementsValue,
                  value1: dItem.entitlementsKey
                })
              }
              this.$store.dispatch('updateProjectIconDataList', this.gameProjectChannelInfo.iconList)
              this.$store.dispatch('updateProjectSplashDataList', this.gameProjectChannelInfo.splashList)
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
          this.$alert('请求失败，请重新操作', '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 配置数据
      configDataInfo (iChannelConfigId) {
        channelApi.getVersionDataInfo(this.platformType, iChannelConfigId).then((data) => {
          if (data.code === 1) {
            this.channelConfigInfo = data.data
          }
        }, (error) => {
          console.log(error)
        })
      }
    }
  }
</script>
