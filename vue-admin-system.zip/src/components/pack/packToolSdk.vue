<style>

</style>
<template>
  <div>
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="150px" class="pack-tool-form">
      <el-form-item label="打包地区：" prop="iAreaId">
        <el-select v-model="dataInfoForm.iAreaId" placeholder="请选择" @change="getGameList">
          <el-option
            v-for="item in areaList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="打包语言：" prop="iLanguageId">
        <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择" @change="getGameList">
          <el-option
            v-for="item in languageList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="打包平台：" prop="iPlatformId">
        <el-select v-model="dataInfoForm.iPlatformId" placeholder="请选择" @change="getGameList">
          <el-option
            v-for="item in platformList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="打包游戏：" prop="iProjectId">
        <el-select v-model="dataInfoForm.iProjectId" placeholder="请选择" @change="getGameVersionList">
          <el-option
            v-for="item in gameList"
            :key="item.iProjectId"
            :label="item.gameName"
            :value="item.iProjectId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="游戏版本：" prop="iGameAssetsId">
        <el-select v-model="dataInfoForm.iGameAssetsId" placeholder="请选择" @change="getGameAssetsDataList">
          <el-option
            v-for="item in gameVersionList"
            :key="item.iAssertId"
            :label="item.gameAssetsVersion"
            :value="item.iAssertId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="资源类型：" prop="cVersionType">
        <el-select v-model="cVersionType" placeholder="请选择" @change="getGameAssetsDataList">
          <el-option
            v-for="item in gameAssetsTypeList"
            :key="item.value"
            :label="item.name"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="游戏资源：" prop="iProjectAssetId">
        <el-select v-model="dataInfoForm.iProjectAssetId" placeholder="请选择" @change="getGameChannelDataList">
          <el-option
            v-for="item in gameAssetsList"
            :key="item.iProjectAssetId"
            :label="item.gameAssetsName"
            :value="item.iProjectAssetId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="打包渠道：">
        <el-table :data="channelList.length>0?[{'test':'demo'}]:[]" stripe>
          <el-table-column label="渠道名称" :width="250">
            <template scope="scope">
              <el-select v-model="dataInfoForm.iChannelId" placeholder="请选择" @change="getGameChannelVersionDataList">
                <el-option
                  v-for="item in channelList"
                  :key="item.iChannelId"
                  :label="item.channelName"
                  :value="item.iChannelId">
                </el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="渠道版本" :width="150">
            <template scope="scope">
              <el-select v-model="dataInfoForm.iChannelConfigId" placeholder="请选择">
                <el-option
                  v-for="item in channelVersionList"
                  :key="item.iChannelConfigId"
                  :label="item.channelVersion"
                  :value="item.iChannelConfigId">
                </el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="选择插件">
            <template scope="scope">
              {{selectPluginToString()}}
            </template>
          </el-table-column>
          <el-table-column
            label="操作" :width="80">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="selectPluginDialogShow">选择插件</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" class="pack-tool-form-btn" @click="submitForm('dataInfoForm')" :loading="buttonLoading">点击打包</el-button>
      </el-form-item>
    </el-form>
    <selectPluginDialog v-if="optionSelectPluginData.dialogVisible" :optionData="optionSelectPluginData" :dataInfoForm="optionSelectChannelItem"></selectPluginDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packToolApi from '../../apis/pack-tool-api'
  import selectPluginDialog from '../../components/pack/selectPluginDialog'
  export default{
    props: ['packType'],
    components: {
      selectPluginDialog
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'gameAssetsTypeList', 'fileUploadDirId',
        'buttonLoading', 'firstTabValue', 'packToolParam'
      ])
    },
    data () {
      return {
        localPackParams: null,
        platformType: 'ios', // 平台类型
        dataInfoForm: {
          iAreaId: '',
          iLanguageId: '',
          iPlatformId: '',
          iProjectId: '',
          iGameAssetsId: '',
          iProjectAssetId: '',
          iChannelId: '',
          iChannelConfigId: ''
        },
        cVersionType: 1,
        gameList: [],
        gameVersionList: [],
        gameAssetsList: [],
        channelList: [],
        channelVersionList: [],
        rules: {
          iAreaId: [
            {type: 'number', required: true, message: '请选择打包地区', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择打包语言', trigger: 'change'}
          ],
          iPlatformId: [
            {type: 'number', required: true, message: '请选择打包平台', trigger: 'change'}
          ],
          iProjectId: [
            {type: 'number', required: true, message: '请选择打包游戏', trigger: 'change'}
          ],
          iGameAssetsId: [
            {type: 'number', required: true, message: '请选择打包游戏版本', trigger: 'change'}
          ],
          iProjectAssetId: [
            {type: 'number', required: true, message: '请选择打包游戏资源', trigger: 'change'}
          ]
        },
        optionSelectPluginData: {
          platformType: 1,
          dialogVisible: false
        },
        optionSelectChannelItem: null,
        intervalTime: null
      }
    },
    watch: {
//      firstTabValue: function (newVal, oldVal) {
//        if (newVal.indexOf(this.packType) >= 0) {
//          this.dataInfoForm.iAreaId = this.areaList[0].iDicId
//          this.dataInfoForm.iLanguageId = this.languageList[0].iDicId
//          this.dataInfoForm.iPlatformId = this.platformList[0].iDicId
//          // 判断平台类型
//          this.judgePlatformType()
//          // 获取所有游戏列表
//          this.getGameList()
//        }
//      }
    },
    created: function () {
//      if (this.firstTabValue.indexOf(this.packType) >= 0) {
      this.intervalTime = setInterval(() => {
        if (this.areaList) {
          let localParam = this.packToolParam['sdkPack']
          if (localParam === '') {
            this.dataInfoForm.iAreaId = this.areaList[0].iDicId
            this.dataInfoForm.iLanguageId = this.languageList[0].iDicId
            this.dataInfoForm.iPlatformId = this.platformList[0].iDicId
            this.cVersionType = this.gameAssetsTypeList[0].value
            // 判断平台类型
            this.judgePlatformType()
            // 获取所有游戏列表
//              this.getGameList()
          } else {
            this.localPackParams = JSON.parse(localParam)
            this.dataInfoForm.iAreaId = this.localPackParams.iAreaId
            this.dataInfoForm.iLanguageId = this.localPackParams.iLanguageId
            this.dataInfoForm.iPlatformId = this.localPackParams.iPlatformId

            this.cVersionType = this.localPackParams.cVersionType
            // 判断平台类型
            this.judgePlatformType()
            // 获取所有游戏列表
//              this.getGameList('initLocal')
          }
          clearInterval(this.intervalTime)
        }
      }, 1000)
//      }
//      this.cVersionType = this.gameAssetsTypeList[0].value
//      this.$store.dispatch('getFileUploadDir', null)
    },
    methods: {
      // 判断平台类型
      judgePlatformType () {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === this.dataInfoForm.iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
      },
      // 数据清空操作
      clearDataInfo (type) {
        switch (type) {
          case 'game':
            this.dataInfoForm.iProjectId = ''
            this.gameList = []
          case 'gameVersion':
            this.dataInfoForm.iGameAssetsId  = ''
            this.gameVersionList = []
          case 'gameAssets':
            this.dataInfoForm.iProjectAssetId = ''
            this.gameAssetsList = []
          case 'gameChannel':
            this.dataInfoForm.iChannelId = ''
            this.channelList = []
          case 'gameChannelVersion':
            this.dataInfoForm.iChannelConfigId = ''
            this.channelVersionList = []
        }
      },
      // 获取游戏列表
      getGameList () {
        let _this = this
        const optionParams = {
          areaId: this.dataInfoForm.iAreaId,
          languageId: this.dataInfoForm.iLanguageId,
          platformId: this.dataInfoForm.iPlatformId
        }
        this.judgePlatformType()
        // 获得打包游戏项目表
        packToolApi.getPackGameDataList(optionParams).then((data) => {
          if (data.code === 1) {
            _this.gameList = data.data
            if (_this.gameList.length > 0) {
              _this.dataInfoForm.iProjectId = (this.localPackParams && this.localPackParams.iProjectId) ? this.localPackParams.iProjectId : _this.gameList[0].iProjectId
              // 获取游戏的版本列表
//              _this.getGameVersionList()
            } else {
              this.clearDataInfo('game')
            }
          }
        }, (error) => {
          console.log(error)
//          this.$alert(error, '请求失败', {
//            confirmButtonText: '确定'
//          })
        })
      },
      // 获得打包游戏版本列表
      getGameVersionList () {
        let _this = this
        let pType = this.platformType === 'ios' ? 1 : 0
        if (!_this.dataInfoForm.iProjectId) {
          return false
        }
        packToolApi.getPackGameVersionDataList(_this.dataInfoForm.iProjectId, pType).then((data) => {
          if (data.code === 1) {
            _this.gameVersionList = data.data
            if (_this.gameVersionList.length > 0) {
              _this.dataInfoForm.iGameAssetsId = (this.localPackParams && this.localPackParams.iGameAssetsId) ? this.localPackParams.iGameAssetsId : _this.gameVersionList[0].iAssertId
              // 获取游戏资源列表
              _this.getGameAssetsDataList()
            } else {
              this.clearDataInfo('gameVersion')
            }
          }
        }, (error) => {
          console.log(error)
//          this.$alert(error, '请求失败', {
//            confirmButtonText: '确定'
//          })
        })
      },
      // 获得打包游戏资源列表
      getGameAssetsDataList () {
        let _this = this
        let pType = this.platformType === 'ios' ? 1 : 0
        if (!_this.dataInfoForm.iGameAssetsId) {
          return false
        }
        // 获得打包游戏资源列表
        packToolApi.getPackGameAssetsDataList(_this.dataInfoForm.iGameAssetsId, pType, _this.cVersionType).then((data) => {
          if (data.code === 1) {
            _this.gameAssetsList = data.data
            if (_this.gameAssetsList.length > 0) {
              _this.dataInfoForm.iProjectAssetId = (this.localPackParams && this.localPackParams.iProjectAssetId) ? this.localPackParams.iProjectAssetId : _this.gameAssetsList[0].iProjectAssetId
              // 获取游戏打包渠道列表
//              _this.getGameChannelDataList()
            } else {
              this.clearDataInfo('gameAssets')
            }
          }
        }, (error) => {
          console.log(error)
//          this.$alert(error, '请求失败', {
//            confirmButtonText: '确定'
//          })
        })
      },
      // 获取游戏打包渠道列表
      getGameChannelDataList () {
        let _this = this
        let pType = this.platformType === 'ios' ? 1 : 0
        if (!_this.dataInfoForm.iProjectAssetId) {
          return false
        }
        packToolApi.getPackGameChannelDataList(pType, _this.dataInfoForm.iProjectAssetId).then((data) => {
          if (data.code === 1) {
            _this.channelList = data.data
            if (_this.channelList.length > 0) {
              _this.dataInfoForm.iChannelId = _this.channelList[0].iChannelId
              for (let cItem of _this.channelList) {
                cItem.selectPluginList = []
              }
              _this.channelList = JSON.parse(JSON.stringify(_this.channelList))
              _this.getGameChannelVersionDataList()
            } else {
              this.clearDataInfo('gameChannel')
            }
          }
          this.localPackParams = null
        }, (error) => {
          console.log(error)
//          this.$alert(error, '请求失败', {
//            confirmButtonText: '确定'
//          })
        })
      },
      // 获取游戏打包渠道版本列表
      getGameChannelVersionDataList () {
        for (let cItem of this.channelList) {
          if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
            this.channelVersionList = cItem.gamePackChannelVersionVOList
            if (this.channelVersionList.length > 0) {
              this.dataInfoForm.iChannelConfigId = this.channelVersionList[0].iChannelConfigId
            }
          }
        }
      },
      selectPluginDialogShow () {
        for (let cItem of this.channelList) {
          if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
            this.optionSelectChannelItem = cItem
          }
        }
        this.optionSelectPluginData.dialogVisible = true
        this.optionSelectPluginData.platformType = this.platformType === 'ios' ? 1 : 0
      },
      selectPluginToString () {
        let pluginStr = []
        for (let cItem of this.channelList) {
          if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
            for (let item of cItem.selectPluginList) {
              pluginStr.push(item.pluginName + '--' + item.pluginVersion)
            }
          }
        }
        return pluginStr.join(',')
      },
      selectPluginIdToString () {
        let pluginStr = []
        for (let cItem of this.channelList) {
          if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
            for (let item of cItem.selectPluginList) {
              pluginStr.push(item.iPluginConfigId)
            }
          }
        }
        return pluginStr.join(',')
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (!_this.dataInfoForm.iChannelId) {
              this.$alert('请选择打包渠道', '渠道选择', {
                confirmButtonText: '确定'
              })
              return
            }
            const dataInfoParam = {
//              resDirId: this.fileUploadDirId,
              ...this.dataInfoForm,
              pvoList: []
            }
            for (let cItem of this.channelList) {
              if (cItem.iChannelId === this.dataInfoForm.iChannelId) {
                let selectPluginIds = _this.selectPluginIdToString(cItem.selectPluginList)
                if (this.platformType === 'ios' && selectPluginIds === '') {
                  this.$alert('请选择打包渠道对应的插件', '打包插件', {
                    confirmButtonText: '确定'
                  })
                  return
                }
                dataInfoParam.pvoList.push({
                  iChannelId: _this.dataInfoForm.iChannelId,
                  iChannelConfigId: _this.dataInfoForm.iChannelConfigId,
                  cPluginIds: selectPluginIds
                })
                break
              }
            }
            delete dataInfoParam.iChannelId
            delete dataInfoParam.iChannelConfigId
            let pType = this.platformType === 'ios' ? 1 : 0
            packToolApi.postPackGameResource(pType, 0, dataInfoParam).then((data) => {
              if (data.code === 1) {
                this.$store.dispatch('setPackNewIds', data.data.idString.split(','))
                this.$store.dispatch('setIsFirstPackCount', true)
                let optionSearchParams = {
                  areaId: _this.dataInfoForm.iAreaId,
                  languageId: _this.dataInfoForm.iLanguageId,
                  platformId: _this.dataInfoForm.iPlatformId,
                  status: '',
                  gameId: '',
                  iGameAssetsId: _this.dataInfoForm.iGameAssetsId
                }
                for (let gItem of _this.gameList) {
                  if (gItem.iProjectId === _this.dataInfoForm.iProjectId) {
                    optionSearchParams.gameId = gItem.gameId
                    break
                  }
                }
                let optionPackParams = {
                  iAreaId: _this.dataInfoForm.iAreaId,
                  iLanguageId: _this.dataInfoForm.iLanguageId,
                  iPlatformId: _this.dataInfoForm.iPlatformId,
                  iProjectId: _this.dataInfoForm.iProjectId,
                  iGameAssetsId: _this.dataInfoForm.iGameAssetsId,
                  cVersionType: _this.cVersionType,
                  iProjectAssetId: _this.dataInfoForm.iProjectAssetId
                }
                this.$store.dispatch('setSearchPackParam', {tabType: 'sdkPack', tabSearchParam: JSON.stringify(optionSearchParams)})
                this.$store.dispatch('setPackToolParam', {tabType: 'sdkPack', tabPackParam: JSON.stringify(optionPackParams)})
                this.$router.push('/home/pack/install')
                /*
                 this.$alert('您要打包的游戏渠道包已经打过啦，在安装列表页高亮区域直接下载即可！', '友情提示', {
                 confirmButtonText: '知道了',
                 callback: action => {
                 this.$store.dispatch('setPackNewIds', data.data.idString.split(','))
                 this.$router.push('/home/pack/install')
                 }
                 }) */
              } else {
                this.$alert(data.msg, '游戏打包失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert(error, '请求失败', {
                confirmButtonText: '确定'
              })
            })
          } else {
            return false
          }
        })
      }
    }
  }

</script>
