<style>
  .option-dialog-log-file .el-dialog{
    width: 600px;
  }
  .option-dialog-log-file .el-dialog .el-dialog__body {
    padding: 10px 0px 0 20px;
  }
</style>
<style scoped>
  .content-list{
    text-align: left;
    word-wrap: break-word;
  }
</style>
<template>
  <el-dialog title="打包日志"
             :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-log-file">
    <div class="content-list">
      <template>
        <div v-html="logText" style="height: 600px;overflow: auto"></div>
      </template>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packToolApi from '../../apis/pack-tool-api'
  export default{
    components: {},
    props: ['optionData'],
    data () {
      return {
        logText: ''
      }
    },
    computed: {
      ...mapGetters([
        'packGameInfo'
      ])
    },
    created: function () {
      this.getPackFailureInfo()
    },
    methods: {
      getPackFailureInfo () {
        packToolApi.getPackFailureInfo(this.packGameInfo.iGamePackId).then((data) => {
          if (data.code === 1) {
            this.logText = data.data.logText
          }
        }, (error) => {
          console.log(error)
        })
      }
    }
  }
</script>
