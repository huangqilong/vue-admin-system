<style>
  .content-list-pack{
  }
  .content-list-pack .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .content-list-pack .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
  }
  .content-list .path{
    margin-top: 10px;
  }
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <div class="content-list-pack">
    <div class="content-list">
      <el-form :model="dataInfoForm" ref="dataInfoForm">
        <el-row v-if="0 == dataInfoForm.gamePackCPSorADModelList.length">
          <el-col :span="2">&nbsp;</el-col>
          <el-col :span="20">
            <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('dataInfoForm')">添&nbsp;&nbsp;加</el-button>
          </el-col>
          <el-col :span="2">&nbsp;</el-col>
        </el-row>
        <el-row v-if="dataInfoForm.gamePackCPSorADModelList.length > 0">
          <el-col :span="6" class="table-head">渠道码</el-col>
          <el-col :span="11" class="table-head">广告插件</el-col>
          <el-col :span="3" class="table-head">操作</el-col>
          <el-col :span="4" class="table-head">&nbsp;</el-col>
        </el-row>
        <el-row v-for="(domain,index) in dataInfoForm.gamePackCPSorADModelList" :gutter="10">
          <el-col :span="6">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.cpscode'"
              :rules="[{required: true, message: '请输入渠道码', trigger: 'blur'},{validator: checkChannelCode, trigger: 'blur'}]">
              <el-input v-model="domain.cpscode" placeholder="请输入渠道码"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="11">
            &nbsp;{{domain.selectPluginList.join(',')}}
          </el-col>
          <el-col :span="3">
            <el-popover
              placement="bottom"
              title="插件配置信息"
              width="500"
              trigger="click"
              v-model="domain.popoverVisible">
              <div class="popover-content">
                <el-table :data="pluginList" stripe ref="pluginMultipleTable" @selection-change="handleSelectionChange">
                  <el-table-column
                    type="selection"
                    width="80"
                    label="操作">
                  </el-table-column>
                  <el-table-column prop="pluginName" label="插件名称"></el-table-column>
                  <el-table-column prop="pluginVersion" label="版本号"></el-table-column>
                </el-table>
                <div style="text-align: right;margin-top: 5px;">
                  <el-button size="small" @click="domain.popoverVisible = false">关 闭</el-button>
                </div>
              </div>
              <el-button slot="reference" type="text" class="table-option-button" @click="popoverPluginClick(index)">选择插件</el-button>
            </el-popover>
          </el-col>
          <el-col :span="4" style="text-align: left;">
            <el-button type="text" class="table-option-button" @click.prevent="removeItem(index)">删除</el-button>
            <el-button type="text" class="table-option-button" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.gamePackCPSorADModelList.length-1">添加</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {
    },
    props: ['dataInfoForm', 'pluginList'],
    data () {
      return {
        popoverVisible: [],
        selectIndex: 0
      }
    },
    computed: {
      ...mapGetters([
        'packGameInfo', 'buttonLoading', 'secondTabList'
      ])
    },
    created: function () {
    },
    methods: {
      checkChannelCode (rule, value, callback) {
        if (!value) {
          return callback(new Error('请输入渠道码'))
        }
        setTimeout(() => {
          let infoItemsStr = JSON.stringify(this.dataInfoForm.gamePackCPSorADModelList)
          let valStr = JSON.stringify({cpscode: value})
          if (infoItemsStr.split(valStr.substring(1, valStr.length - 1)).length <= 2) {
            callback()
          } else {
            callback(new Error('渠道码已存在'))
          }
        }, 1000)
      },
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.gamePackCPSorADModelList.push({
              cpscode: '',
              adpluginIDs: '',
              popoverVisible: false,
              adpluginList: [],
              selectPluginList: []
            })
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        let iCpsAdId = this.dataInfoForm.gamePackCPSorADModelList[$index].iCpsAdId
        if (iCpsAdId) {
          this.dataInfoForm.deletePackedIds.push(iCpsAdId)
        }
        this.dataInfoForm.gamePackCPSorADModelList.splice($index, 1)
      },
      handleSelectionChange (selectDataList) {
        this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].selectPluginList = []
        this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginList = []
        for (let sItem of selectDataList) {
          this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].selectPluginList.push(sItem.pluginName + '--' + sItem.pluginVersion)
          this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginList.push(sItem.iPluginId)
        }
      },
      popoverPluginClick (index) {
        this.selectIndex = index
        let adpluginList = this.dataInfoForm.gamePackCPSorADModelList[this.selectIndex].adpluginList
        for (let pItem of this.pluginList) {
          if (adpluginList.indexOf(pItem.iPluginId) >= 0) {
            this.$refs['pluginMultipleTable'][this.selectIndex].toggleRowSelection(pItem, true)
          }
        }
      },
      submitForm () {
        return this
      }
    }
  }
</script>
