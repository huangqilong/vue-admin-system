<style scoped>
  .table-option-button{
    margin-top: 2px;
  }
</style>
<style>
  .el-table .info-row {
    background: #A7E0FF;
  }
  .el-table .status-line {
    background: #FFFFFF;
  }
  .el-table .status-ing {
    background: #FFFFFF;
  }
  .el-table .status-success {
    background: #FFFFFF;
  }
  .el-table .status-failure {
    background: #FFB6C1;
  }
</style>
<template>
  <div class="pack-list">
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" :row-class-name="tableRowClassName">
        <el-table-column prop="areaName" label="地区" :width="50"></el-table-column>
        <el-table-column prop="platformName" label="平台" :width="50" v-if="packType!='cpsPack' && packType!='advPack'">
          <template scope="scope">
            <el-popover v-if="scope.row.platformName=='安卓'"
              title="打包服务器"
              trigger="click">
              <div class="popover-content" style="height: 200px;overflow: auto;">
                <el-table :data="packServerList">
                  <el-table-column prop="jobName" label="服务器名称" :width="200">
                    <template scope="scope">
                      <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                      <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
                </el-table>
              </div>
              <div slot="reference" @click="getPackServerInfo(scope.$index, dataList)" style="cursor: pointer;color: #0190fe;">{{scope.row.platformName}}</div>
            </el-popover>
            <span v-if="scope.row.platformName!='安卓'">{{scope.row.platformName}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="languageName" label="语言" :width="70"></el-table-column>
        <el-table-column prop="channelName" label="渠道名称" v-if="packType=='sdkPack'"></el-table-column>
        <el-table-column prop="channelVersion" label="渠道版本" v-if="packType=='sdkPack'"  :width="60"></el-table-column>
        <el-table-column prop="gameName" label="游戏名称"></el-table-column>
        <el-table-column prop="gameAssetsVersion" label="游戏版本" :width="60"></el-table-column>
        <el-table-column label="资源类型" :width="70">
          <template scope="scope">
            {{scope.row.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}
          </template>
        </el-table-column>
        <el-table-column prop="gameAssetsName" label="资源名称"></el-table-column>
        <el-table-column prop="channelName" label="渠道名称" v-if="packType!='sdkPack'"></el-table-column>
        <el-table-column prop="channelVersion" label="渠道版本" v-if="packType!='sdkPack'"></el-table-column>
        <el-table-column prop="cAdcpsCode" label="渠道码" v-if="packType=='cpsPack'|| packType=='advPack'"></el-table-column>
        <el-table-column prop="platform" label="广告插件" v-if="packType=='advPack'">
          <template scope="scope">
            {{scope.row.pluginsLits.join(',')}}
          </template>
        </el-table-column>
        <el-table-column prop="dPackStart" label="打包开始时间" :width="200">
          <template scope="scope">
            {{scope.row.dPackStart&&scope.row.dPackStart!='1990-01-01 00:00:00'? scope.row.dPackStart : '-----'}}
          </template>
        </el-table-column>
        <el-table-column prop="dPackEnd" label="打包结束时间" :width="200">
          <template scope="scope">
            {{scope.row.dPackEnd&&scope.row.dPackEnd!='1990-01-01 00:00:00'? scope.row.dPackEnd : '-----'}}
          </template>
        </el-table-column>
        <el-table-column prop="iPackNum" label="打包次数" v-if="packType=='channelPack'" :width="70"></el-table-column>
        <el-table-column prop="cRealName" label="打包人员" :width="80"></el-table-column>
        <el-table-column label="打包状态" :width="80">
          <template scope="scope">
            {{scope.row.cStatus==packStatusList[0].iDicId?packStatusList[0].sDicName:(scope.row.cStatus==packStatusList[1].iDicId?packStatusList[1].sDicName:
            (scope.row.cStatus==packStatusList[2].iDicId?packStatusList[2].sDicName:packStatusList[3].sDicName))}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" :width="getTableWidth()">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" v-if="roleAuthority.packConfig"
                         @click="showPackConfig(scope.$index, dataList)">详情</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.downLoad && scope.row.cStatus == 1"
                         @click="downFileConfig(scope.$index, dataList)">下载</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.checkCause && (packType === 'channelPack' || packType === 'sdkPack' || packType === 'rulePack') && (scope.row.cStatus == 1 || scope.row.cStatus == 2)"
                         @click="packResultDialogShow(scope.$index, dataList)">日志</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.againPack && (packType === 'channelPack' || packType === 'sdkPack' || packType === 'rulePack') && (scope.row.cStatus == 1 || scope.row.cStatus == 2)"
                         @click="selectPluginDialogShow(scope.$index, dataList)">重新打包</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.channelPack && packType=='channelPack'&&scope.row.cStatus == 1&&scope.row.platformName=='安卓'&&scope.row.channelName=='好玩友'"
                         @click="channelPackDialogShow(scope.$index, dataList)">打渠道码包</el-button>
              <el-button type="text" class="table-option-button" v-if="packType=='channelPack'&&scope.row.platformName=='IOS'"
                         @click="buglyUpload(scope.$index, dataList)">bugly上传</el-button>
              <el-button type="text" class="table-option-button" v-if="packType=='channelPack'&&scope.row.platformName=='IOS'&&scope.row.buglyUrl"
                         @click="buglyDownload(scope.$index, dataList)">bugly下载</el-button>
              <el-button type="text" class="table-option-button" v-if="userName=='admin'|| roleAuthority.deleteBtn" @click="deleteDataInfo(scope.$index, dataList)">删除</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <showPackConfigDialog v-if="showPackConfigDataDialog.dialogFormVisible" :optionData="showPackConfigDataDialog"></showPackConfigDialog>
    <selectPluginDialog v-if="optionSelectPluginData.dialogVisible" :optionData="optionSelectPluginData" :dataInfoForm="optionSelectChannelItem"></selectPluginDialog>
    <downFileDialog v-if="optionDownFileDialog.dialogVisible" :optionData="optionDownFileDialog" :dataParams="optionDownFileItem"></downFileDialog>
    <packFailureDialog v-if="optionPackFailureDialog.dialogVisible" :optionData="optionPackFailureDialog"></packFailureDialog>
    <channelPackDialog v-if="optionChannelPackDialog.dialogVisible" :optionData="optionChannelPackDialog"></channelPackDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packToolApi from '../../apis/pack-tool-api'
  import optionForm from '../../components/manager/optionForm'
  import selectPluginDialog from '../../components/pack/selectPluginDialog'
  import showPackConfigDialog from '../../components/pack/showPackConfigDialog'
  import downFileDialog from '../../components/pack/downFileDialog'
  import packFailureDialog from '../../components/pack/packFailureDialog'
  import channelPackDialog from '../../components/pack/channelPackDialog'
  import pagination from '../../components/manager/pagination'

  export default{
    components: {
      showPackConfigDialog,
      selectPluginDialog,
      downFileDialog,
      packFailureDialog,
      channelPackDialog,
      optionForm,
      pagination
    },
    props: ['packType'],
    data () {
      return {
        platformType: 'ios',
        packRoleType: 2,
        cpacktype: 0,
        optionParams: null,
        optionData: null,
        gameVersionList: [],
        showPackConfigDataDialog: {
          iGamePackId: '',
          dialogFormVisible: false
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionSelectPluginData: {
          platformType: 1,
          dialogVisible: false
        },
        optionSelectChannelItem: null,
        optionPackFailureDialog: {
          dialogVisible: false
        },
        optionDownFileDialog: {
          dialogVisible: false
        },
        optionDownFileItem: {
          downLoadPath: '',
          resourceName: ''
        },
        optionChannelPackDialog: {
          packCpsAdvInfo: null,
          dialogVisible: false
        },
        dataList: [],
        packServerList: []
      }
    },
    computed: {
      ...mapGetters([
        'userName', 'platformList', 'pageNumber', 'gameAssetsTypeList',
        'packStatusList', 'roleAuthority', 'firstTabValue',
        'secondTabValue', 'firstTabList', 'secondTabList', 'packNewIds',
        'isFirstPackCount', 'searchPackParam'
      ])
    },
    watch: {
      firstTabValue: function (newVal, oldVal) {
        if (this.searchPackParam[this.packType]) {
          let localParam = JSON.parse(this.searchPackParam[this.packType])
          this.optionParams = localParam
        }
        if (newVal !== this.firstTabList[2] && newVal.indexOf(this.packType) >= 0) {
          this.searchDataList()
        } else if (newVal === this.firstTabList[2]) {
          if (this.secondTabValue.indexOf(this.packType) >= 0) {
            this.searchDataList()
          }
        }
      },
      secondTabValue: function (newVal, oldVal) {
        if (this.searchPackParam[this.packType]) {
          let localParam = JSON.parse(this.searchPackParam[this.packType])
          this.optionParams = localParam
        }
        if (newVal.indexOf(this.packType) >= 0) {
          this.searchDataList()
        }
      }
    },
    created: function () {
      if (this.isFirstPackCount) {
        this.$alert('系统已经收到您的打包请求，在高亮区域可以查看您的打包请求记录，已经打过的包直接下载即可，首次打包请耐心等待，打包完成后就可以下载啦！',
          '友情提示',
          {
            confirmButtonText: '知道了'
          })
        this.$store.dispatch('setIsFirstPackCount', false)
      }
      switch (this.packType) {
        case 'sdkPack':
          this.packRoleType = 0
          break
        case 'rulePack':
          this.packRoleType = 1
          break
        case 'channelPack':
          this.packRoleType = 2
          break
        case 'cpsPack':
          this.cpacktype = 1
          break
        case 'advPack':
          this.cpacktype = 0
          break
      }
      this.pageData.number = this.pageNumber
      let localParam = null
      if (this.searchPackParam[this.packType]) {
        localParam = JSON.parse(this.searchPackParam[this.packType])
      }
      if (this.packType === 'channelPack' || this.packType === 'sdkPack' || this.packType === 'rulePack') {
        this.optionParams = {
          areaId: '',
          languageId: '',
          platformId: '',
          status: '',
          gameId: '',
          iGameAssetsId: ''
        }
        this.optionData = {
          showArea: true,
          showLanguage: true,
          showPlatform: true,
          showPackStatus: true,
          showSearchBtn: true,
          showSearchGame: true,
          showSearchGameVersion: true,
          searchCallBack: this.searchDataList,
          addCallBack: null
        }
      } else {
        this.optionParams = {
          areaId: '',
          languageId: '',
          status: '',
          gameId: '',
          iGameAssetsId: ''
        }
        this.optionData = {
          showArea: true,
          showLanguage: true,
          showPackStatus: true,
          showSearchBtn: true,
          showSearchGame: true,
          showSearchGameVersion: true,
          searchCallBack: this.searchDataList,
          addCallBack: null
        }
      }
      if (localParam) {
        this.optionParams = localParam
      }
      if (this.packType === 'sdkPack' || this.packType === 'rulePack') {
        if (this.firstTabValue.indexOf(this.packType) >= 0) {
          this.searchDataList()
        }
      } else {
        if (this.firstTabValue === this.firstTabList[2]) {
          if (this.secondTabValue.indexOf(this.packType) >= 0) {
            this.searchDataList()
          }
        }
      }
    },
    methods: {
      getTableWidth () {
        if (this.packType === 'sdkPack' || this.packType === 'rulePack') {
          return 250
        } else if (this.packType === 'channelPack') {
          return 335
        } else {
          return 150
        }
        /*
        if (this.userName === 'admin') {

        } else {
          if (this.packType === 'sdkPack' || this.packType === 'rulePack') {
            return 140
          } else if (this.packType === 'channelPack') {
            return 300
          } else {
            return 80
          }
        } */
      },
      tableRowClassName (row, index) {
        if (this.packType === 'channelPack' || this.packType === 'sdkPack' || this.packType === 'rulePack') {
          if (this.packNewIds.indexOf(row.iGamePackId + '') >= 0) {
            if (parseInt(row.cStatus) === 2) {
              return 'status-failure'
            } else {
              return 'info-row'
            }
          } else {
            for (let pItem of this.packStatusList) {
              if (parseInt(row.cStatus) === pItem.iDicId) {
                return pItem.className
              }
            }
          }
        } else {
          for (let pItem of this.packStatusList) {
            if (parseInt(row.cStatus) === pItem.iDicId) {
              return pItem.className
            }
          }
        }
        return ''
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        let params = null
        let optionType = 'sdkRuleInstall'
        if (this.packType === 'channelPack' || this.packType === 'sdkPack' || this.packType === 'rulePack') {
          params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams, 'packRoleType': this.packRoleType}
          optionType = 'sdkRuleInstall'
          this.$store.dispatch('setSearchPackParam', {tabType: this.packType, tabSearchParam: JSON.stringify(this.optionParams)})
          if (this.packType === 'channelPack') {
            let tempPlatformType = 'ios'
            for (const pItem of this.platformList) {
              if (pItem.iDicId === this.optionParams.platformId) {
                tempPlatformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
              }
            }
            let optionParamsTemp = {
              areaId: this.optionParams.areaId,
              languageId: this.optionParams.languageId,
              status: this.optionParams.status,
              gameId: this.optionParams.gameId,
              iGameAssetsId: tempPlatformType === 'ios' ? '' : this.optionParams.iGameAssetsId
            }
            this.$store.dispatch('setSearchPackParam', {tabType: 'cpsPack', tabSearchParam: JSON.stringify(optionParamsTemp)})
            this.$store.dispatch('setSearchPackParam', {tabType: 'advPack', tabSearchParam: JSON.stringify(optionParamsTemp)})
          }
        } else {
          params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams, 'cpacktype': this.cpacktype}
          optionType = 'cpsDev'
          let tempPlatformId = ''
          for (const pItem of this.platformList) {
            if (pItem.sDicName === '安卓') {
              tempPlatformId = pItem.iDicId
            }
          }
          console.log(this.optionParams)
          let optionParamsTemp = {
            areaId: this.optionParams.areaId,
            languageId: this.optionParams.languageId,
            platformId: tempPlatformId,
            status: this.optionParams.status,
            gameId: this.optionParams.gameId,
            iGameAssetsId: this.optionParams.iGameAssetsId
          }
          this.$store.dispatch('setSearchPackParam', {tabType: 'channelPack', tabSearchParam: JSON.stringify(optionParamsTemp)})
          this.$store.dispatch('setSearchPackParam', {tabType: 'cpsPack', tabSearchParam: JSON.stringify(this.optionParams)})
          this.$store.dispatch('setSearchPackParam', {tabType: 'advPack', tabSearchParam: JSON.stringify(this.optionParams)})
        }
        // 获取数据列表
        _this.dataList = []
        packToolApi.getPackGameResourceDataList(optionType, params).then((data) => {
          if (data.code === 1) {
            if (this.packType === 'channelPack' || this.packType === 'sdkPack' || this.packType === 'rulePack') {
              let tempDataArray = []
              for (let dItem of data.data.list) {
                if (this.packNewIds.indexOf(dItem.iGamePackId + '') >= 0) {
                  _this.dataList.push(dItem)
                } else {
                  tempDataArray.push(dItem)
                }
              }
              _this.dataList = _this.dataList.concat(tempDataArray)
            } else {
              _this.dataList = data.data.list
            }
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 查看配置
      showPackConfig ($index, $data) {
        this.$store.dispatch('addPackGameInfo', $data[$index])
        this.showPackConfigDataDialog.iGamePackId = $data[$index].iGamePackId
        this.showPackConfigDataDialog.dialogFormVisible = true
      },
      packResultDialogShow ($index, $data) {
        window.location.href = $data[$index].resourceLogPath
        /*
        this.$store.dispatch('addPackGameInfo', $data[$index])
        this.optionPackFailureDialog.dialogVisible = true */
      },
      selectPluginDialogShow ($index, $data) {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === $data[$index].iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
        let pType = this.platformType === 'ios' ? 1 : 0
        // 获取数据列表
        packToolApi.postAgainPackGameResource($data[$index].iGamePackId, pType, this.packRoleType).then((data) => {
          if (data.code === 1) {
            this.$alert('重新打包请求成功', '重新打包', {
              confirmButtonText: '确定',
              callback: action => {
                this.searchDataList()
              }
            })
          }
        }, (error) => {
          console.log(error)
        })
        /*
        this.optionSelectChannelItem = $data[$index]
        this.optionSelectChannelItem.selectPluginList = []
        this.optionSelectPluginData.dialogVisible = true
        this.optionSelectPluginData.platformType = $data[$index].platformName === '安卓' ? 1 : 0 */
      },
      downFileConfig ($index, $data) {
        this.optionDownFileItem.downLoadPath = $data[$index].resourcePath
        this.optionDownFileItem.resourceName = $data[$index].resourceName
        this.optionDownFileDialog.dialogVisible = true
      },
      getPackServerInfo ($index, $data) {
        this.packServerList = []
        packToolApi.gamePackServerLogs({taskId: $data[$index].iGamePackId}).then((data) => {
          if (data.code === 1) {
            this.packServerList = data.data.list
          }
        }, (error) => {
          console.log(error)
        })
      },
      channelPackDialogShow ($index, $data) {
        this.$store.dispatch('addPackGameInfo', $data[$index])
        // 获取打包记录的csp或广告的历史记录
        // 获取数据列表
        packToolApi.getCpsAdvPackInfo($data[$index].iGamePackId).then((data) => {
          if (data.code === 1) {
            this.optionChannelPackDialog.packCpsAdvInfo = data.data
            this.optionChannelPackDialog.dialogVisible = true
          }
        }, (error) => {
          console.log(error)
        })
      },
      buglyUpload ($index, $data) {
        packToolApi.addBuglySymbol($data[$index].iGamePackId).then((data) => {
          if (data.code === 1) {
            this.$alert('bugly上传操作完成', '操作成功', {
              confirmButtonText: '确定'
            })
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
          this.$alert('数据操作失败，请稍后重试', '友情提醒', {
            confirmButtonText: '确定'
          })
        })
      },
      buglyDownload ($index, $data) {
        window.location.href = $data[$index].buglyUrl
      },
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该数据吗？', '删除数据', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let iId = $data[$index].iGamePackId
          let iType = 0
          if (this.packType === 'channelPack' || this.packType === 'sdkPack' || this.packType === 'rulePack') {
            iId = $data[$index].iGamePackId
            iType = 0
          } else {
            iId = $data[$index].iCpsAdId
            iType = 1
          }
          // 获取数据列表
          packToolApi.deletePackGameDataInfo(iId, iType).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            }
          }, (error) => {
            console.log(error)
          })
        }).catch(() => {
          // 取消操作
        })
      }
    }
  }
</script>
