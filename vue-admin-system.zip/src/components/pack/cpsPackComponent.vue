<style>
  .content-list-pack{
  }
  .content-list-pack .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .content-list-pack .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
  }
  .content-list .path{
    margin-top: 10px;
  }
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <div class="content-list-pack">
    <div class="content-list">
      <el-form :model="dataInfoForm" ref="dataInfoForm">
        <el-row v-if="0 == dataInfoForm.gamePackCPSorADModelList.length">
          <el-col :span="2">&nbsp;</el-col>
          <el-col :span="20">
            <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('dataInfoForm')">添&nbsp;&nbsp;加</el-button>
          </el-col>
          <el-col :span="2">&nbsp;</el-col>
        </el-row>
        <el-row v-if="dataInfoForm.gamePackCPSorADModelList.length > 0">
          <el-col :span="20" class="table-head">渠道码</el-col>
          <el-col :span="4" class="table-head">&nbsp;</el-col>
        </el-row>
        <el-row v-for="(domain,index) in dataInfoForm.gamePackCPSorADModelList" :gutter="10">
          <el-col :span="20">
            <el-form-item
              :prop="'gamePackCPSorADModelList.' + index + '.cpscode'"
              :rules="[{required: true, message: '请输入渠道码', trigger: 'blur'},{validator: checkChannelCode, trigger: 'blur'}]">
              <el-input v-model="domain.cpscode" placeholder="请输入渠道码"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="4" style="text-align: left;">
            <el-button type="text" class="table-option-button" @click.prevent="removeItem(index)">删除</el-button>
            <el-button type="text" class="table-option-button" @click.prevent="addItem('dataInfoForm')" v-if="index==dataInfoForm.gamePackCPSorADModelList.length-1">添加</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {},
    props: ['dataInfoForm'],
    data () {
      return {}
    },
    created: function () {
    },
    computed: {
      ...mapGetters([
        'packGameInfo', 'buttonLoading', 'secondTabList'
      ])
    },
    methods: {
      checkChannelCode (rule, value, callback) {
        if (!value) {
          return callback(new Error('请输入渠道码'))
        }
        setTimeout(() => {
          let infoItemsStr = JSON.stringify(this.dataInfoForm.gamePackCPSorADModelList)
          let valStr = JSON.stringify({cpscode: value})
          if (infoItemsStr.split(valStr.substring(1, valStr.length - 1)).length <= 2) {
            callback()
          } else {
            callback(new Error('渠道码已存在'))
          }
        }, 1000)
      },
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.gamePackCPSorADModelList.push({
              cpscode: ''
            })
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        let iCpsAdId = this.dataInfoForm.gamePackCPSorADModelList[$index].iCpsAdId
        if (iCpsAdId) {
          this.dataInfoForm.deletePackedIds.push(iCpsAdId)
        }
        this.dataInfoForm.gamePackCPSorADModelList.splice($index, 1)
      },
      submitForm () {
        return this
      }
    }
  }
</script>
