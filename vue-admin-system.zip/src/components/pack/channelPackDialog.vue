<style>
  .option-dialog-cps-pack .el-dialog{
    width: 800px;
  }
  .option-dialog-cps-pack .el-form .el-row .el-col.table-head{
    background-color: #eef1f6;
    text-align: center;
    line-height: 36px;
    height: 33px;
    color: #999;
    margin-bottom: 5px;
  }
  .option-dialog-cps-pack .el-form .el-row .el-col{
    line-height: 34px;
  }
</style>
<style scoped>
  .content-list{
    text-align: center;
  }
</style>
<template>
  <el-dialog title="打渠道码包"
             :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-cps-pack">
    <div class="content-list">
      <el-tabs v-model="tabValue" type="card" class="tabs-content">
        <el-tab-pane label="广告码包" name="firstTab">
          <adv-pack-component ref="advChildMethod" :dataInfoForm="advPackDataInfo" :pluginList="pluginList"></adv-pack-component>
        </el-tab-pane>
        <el-tab-pane label="cps包" name="secondTab">
          <cps-pack-component ref="cpsChildMethod" :dataInfoForm="cpsPackDataInfo"></cps-pack-component>
        </el-tab-pane>
      </el-tabs>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import advPackComponent from './advPackComponent'
  import cpsPackComponent from './cpsPackComponent'
  import packToolApi from '../../apis/pack-tool-api'
  export default{
    components: {
      advPackComponent,
      cpsPackComponent
    },
    props: ['optionData'],
    data () {
      return {
        packType: 1,
        tabValue: 'firstTab',
        advPackDataInfo: {
          deletePackedIds: [],
          gamePackCPSorADModelList: []
        },
        cpsPackDataInfo: {
          deletePackedIds: [],
          gamePackCPSorADModelList: []
        },
        pluginList: []
      }
    },
    created: function () {
      this.getPluginList()
    },
    computed: {
      ...mapGetters([
        'packGameInfo', 'buttonLoading'
      ])
    },
    methods: {
      getPluginInfo (plugins) {
        let spList = []
        for (let pItem of this.pluginList) {
          if (plugins.indexOf(pItem.iPluginId) >= 0) {
            spList.push(pItem.pluginName + '--' + pItem.pluginVersion)
          }
        }
        return spList
      },
      checkCpsAdvDataInfo () {
        for (let pItem of this.optionData.packCpsAdvInfo) {
          if (pItem.cPackType === '0') {
            this.advPackDataInfo.gamePackCPSorADModelList.push({
              iCpsAdId: pItem.iCpsAdId,
              cpscode: pItem.cAdcpsCode,
              adpluginIDs: pItem.pluginsList,
              popoverVisible: false,
              adpluginList: pItem.pluginsList.split(','),
              selectPluginList: this.getPluginInfo(pItem.pluginsList)
            })
          } else {
            this.cpsPackDataInfo.gamePackCPSorADModelList.push({
              iCpsAdId: pItem.iCpsAdId,
              cpscode: pItem.cAdcpsCode
            })
          }
        }
      },
      getPluginList () {
        let _this = this
        packToolApi.getAdvPackGamePluginDataList(this.packGameInfo.iGamePackId).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
            _this.pluginList = JSON.parse(JSON.stringify(_this.pluginList))
            this.checkCpsAdvDataInfo()
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      hideDialog () {
        let dPackIds = this.advPackDataInfo.deletePackedIds.concat(this.cpsPackDataInfo.deletePackedIds)
        let dataInfo = {
          iPackId: this.packGameInfo.iGamePackId,
          deletePackedIds: dPackIds.join(','),
          gamePackCPSorADModelList: []
        }
        for (let aItem of this.advPackDataInfo.gamePackCPSorADModelList) {
          dataInfo.gamePackCPSorADModelList.push({
            packType: '0',
            cpscode: aItem.cpscode,
            adpluginIDs: aItem.adpluginList.join(',')
          })
        }
        for (let cItem of this.cpsPackDataInfo.gamePackCPSorADModelList) {
          dataInfo.gamePackCPSorADModelList.push({
            packType: '1',
            cpscode: cItem.cpscode
          })
        }
        if (dataInfo.gamePackCPSorADModelList.length === 0) {
          return false
        }
        packToolApi.postCPSOrAdvPackGameResource(dataInfo).then((data) => {
          if (data.code === 1) {
            this.$alert('打渠道码包请求成功', '打渠道码包', {
              confirmButtonText: '确定',
              callback: action => {
                this.optionData.dialogVisible = false
              }
            })
          } else {
            this.$alert(data.msg, '打渠道码包失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
        })
      },
      submitForm () {
        let _this = this
        let advThis = this.$refs.advChildMethod.submitForm()
        let cpsThis = this.$refs.cpsChildMethod.submitForm()
        advThis.$refs['dataInfoForm'].validate((valid) => {
          if (valid) {
            cpsThis.$refs['dataInfoForm'].validate((validCps) => {
              if (validCps) {
                _this.hideDialog()
              } else {
                return false
              }
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
