<style>
  .option-dialog-cert .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
  .upload-demo .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增IOS证书':'修改IOS证书'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-cert">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="平台：" prop="iPlatformId">
        <el-radio-group v-model="dataInfoForm.iPlatformId">
          <el-radio v-for="item in platformList" class="radio" :label="item.iDicId" :disabled="item.sDicName=='IOS'?false:true">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="平台：" prop="iPlatformId">-->
        <!--<el-select v-model="dataInfoForm.iPlatformId" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in platformList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId"-->
            <!--:disabled="item.sDicName=='IOS'?false:true">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="证书签名：" prop="cCertType">
        <el-radio-group v-model="dataInfoForm.cCertType">
          <el-radio v-for="item in signatureTypeList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="证书签名：" prop="cCertType">-->
        <!--<el-select v-model="dataInfoForm.cCertType" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in signatureTypeList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="证书名称：" prop="cCertName">
        <el-input v-model.trim="dataInfoForm.cCertName"></el-input>
      </el-form-item>
      <el-form-item label="证书文件：" prop="cCertPath">
        <el-upload
          class="upload-demo"
          :action="proxyDevApi+'/uploadFile/' +fileUploadDirId"
          :headers="headersFile"
          :show-file-list="true"
          :multiple="false"
          :file-list="fileStoreUploadList"
          :before-upload="beforeAvatarUpload"
          :on-success="handleStoreFileSuccess"
          :on-remove="handleStoreFileRemove"
          :on-error="handleStoreFileError"
          :on-progress="handleStoreFileProgress">
          <el-button size="small" type="primary">点&nbsp;&nbsp;击&nbsp;&nbsp;上&nbsp;&nbsp;传</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item label="安装密码：" prop="cCertPwd">
        <el-input v-model="dataInfoForm.cCertPwd"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="dataInfoForm.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import ioscertApi from '../../apis/ioscert-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        fileStoreUploadList: [],
        rules: {
          iPlatformId: [
            {type: 'number', required: true, message: '请选择平台', trigger: 'change'}
          ],
          cCertType: [
            {type: 'string', required: true, message: '请选择证书签名', trigger: 'change'}
          ],
          cCertName: [
            {required: true, message: '请输入证书名称', trigger: 'blur'}
          ],
          cCertPath: [
            {required: true, message: '请上传证书文件', trigger: 'change'}
          ],
          cCertPwd: [
            {required: true, message: '请输入安装密码', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'headersFile', 'platformList', 'fileUploadDirId', 'buttonLoading', 'proxyDevApi', 'signatureTypeList'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.optionData.type === 'update') {
        this.fileStoreUploadList = []
        this.fileStoreUploadList.push({
          name: this.dataInfoForm.cCertPath
        })
      }
      if (this.optionData.type === 'update') {
        this.$store.dispatch('getFileUploadDir', this.dataInfoForm.resDirId)
      } else if (this.optionData.type === 'add') {
        this.$store.dispatch('getFileUploadDir', null)
      }
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let iosRegCert = /.p12/
        let isUpload = iosRegCert.test(fileType)
        if (!isUpload) {
          this.$alert('IOS证书文件格式只能为p12', '格式错误', {
            confirmButtonText: '确定'
          })
        }
        return isUpload
      },
      handleStoreFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleStoreFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          if (this.fileStoreUploadList.length > 0 && this.fileStoreUploadList[0].resId) {
            this.$store.dispatch('deleteGameConfigImage', this.fileStoreUploadList[0].resId)
          }
          this.fileStoreUploadList = []
          let fileName = response.data.url
          this.fileStoreUploadList.push({
            name: fileName,
            resId: response.data.resId
          })
          this.dataInfoForm.cCertPath = fileName
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.resDirId = this.fileUploadDirId
        } else {
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      handleStoreFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.cCertPath = ''
        this.dataInfoForm.resId = ''
      },
      handleStoreFileError (error, file, fileList) {
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              ioscertApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              ioscertApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
