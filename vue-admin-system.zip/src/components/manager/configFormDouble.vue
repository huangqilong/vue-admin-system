<style scoped>
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<template>
  <el-form :model="configDoubleForm" ref="configDoubleForm">
    <el-row v-if="0==configDoubleForm.dataList.length">
      <el-col :span="5">&nbsp;</el-col>
      <el-col :span="14">
        <el-button size="small" type="primary" class="dynamic-operator-btn" @click.prevent="addItem('configDoubleForm')">添&nbsp;&nbsp;加</el-button>
      </el-col>
      <el-col :span="5">&nbsp;</el-col>
    </el-row>
    <el-row v-for="(domain,index) in configDoubleForm.dataList" :gutter="30">
      <el-col :span="2">&nbsp;</el-col>
      <el-col :span="8">
        <el-form-item
          :prop="'dataList.' + index + '.value1'">
          <!--:rules="{required: true, message: '数据不能为空', trigger: 'blur'}">-->
          <el-input size="small" v-model="domain.value1" placeholder="键名称"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="8">
        <el-form-item
          :prop="'dataList.' + index + '.value2'">
          <!--:rules="{required: true, message: '数据不能为空', trigger: 'blur'}">-->
          <el-input size="small" v-model="domain.value2" placeholder="键值"></el-input>
        </el-form-item>
      </el-col>
      <el-col :span="6">
        <el-form-item>
          <el-button size="small" @click.prevent="removeItem(index)">删除</el-button>
          <el-button size="small" type="primary" @click.prevent="addItem('configDoubleForm')" v-if="index==configDoubleForm.dataList.length-1">添加</el-button>
        </el-form-item>
      </el-col>
    </el-row>
  </el-form>

</template>
<script>
  export default{
    props: ['configDoubleForm'],
    methods: {
      // 新增
      addItem (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.configDoubleForm.dataList.push({
              value1: '',
              value2: ''
            })
          } else {
            return false
          }
        })
      },
      // 删除
      removeItem ($index) {
        if (this.configDoubleForm.dataList[$index].id) {
          this.configDoubleForm.dataIds.push(this.configDoubleForm.dataList[$index].id)
        }
        this.configDoubleForm.dataList.splice($index, 1)
      }
    }
  }

</script>
