<style scoped>
  .option-dialog-preview .el-dialog{
    width: 600px;
  }
  .option-dialog-preview .content-list .img{
    float: left;
    width: 100px;
    height: 100px;
    margin: 5px;
  }
  .option-dialog-preview .content-list .img img{
    width: 100%;
    height: 100%;
  }
</style>
<template>
  <el-dialog title="图片预览" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-preview">
    <div class="content-list">
      <div class="img" v-for="picUrl in previewImageList">
        <img :src="picUrl"/>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  export default{
    props: ['optionData', 'previewImageList']
  }
</script>
