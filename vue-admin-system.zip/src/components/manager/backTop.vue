<style scoped>
  .page-component-up{
    background-color: #58b7ff;
    position: fixed;
    right: 10px;
    bottom: 30px;
    width: 50px;
    height: 50px;
    border-radius: 25px;
    cursor: pointer;
    opacity: .4;
    transition: .3s;
  }
  .page-component-up i {
    color: #fff;
    display: block;
    line-height: 50px;
    text-align: center;
    font-size: 22px;
  }
</style>
<template>
  <div class="page-component-up" v-show='isShow' @click='getTop'>
    <i class="el-icon-caret-top"></i>
  </div>
</template>
<script>
  export default {
    props: ['scrollMySelf'],
    data () {
      return {
        isShow: false,
        target: ''
      }
    },
    methods: {
      showIcon () {
        if (this.target.scrollTop > 100) {
          this.isShow = true
        } else if (this.target.scrollTop < 100) {
          this.isShow = false
        }
      },
      getTop () {
        let timer = setInterval(() => {
          let top = this.target.scrollTop
          let speed = Math.ceil(top / 2)
          this.target.scrollTop = top - speed
          if (top === 0) {
            clearInterval(timer)
          }
        }, 20)
      }
    },
    mounted () {
      // 通过这个target来判断当前的滚动监听对象是谁
      if (this.scrollMySelf) {
        this.target = this.$el.parentNode.childNodes[0]
      } else {
        this.target = document.body
      }
      this.target.addEventListener('scroll', this.showIcon)
    },
    beforeDestroy () {
      this.target.removeEventListener('scroll', this.showIcon)
    }
  }
</script>
