<style scoped>
  .option-form{
    margin: 10px 0 0 0;
  }
</style>
<template>
  <div class="option-form">
    <el-form :model="dataInfoForm" :inline="true" label-width="85px">
      <el-row>
        <el-col :span="(showAddBtn || showLaunchPlanBtn)?22:24" style="text-align: left;">
          <el-form-item label="项目名称：" v-if="showGameName">
            <el-input size="small" v-model="dataInfoForm.gameName" style="width:150px;"></el-input>
          </el-form-item>
          <el-form-item label="渠道名称：" v-if="showOperatorName">
            <el-input size="small" v-model="dataInfoForm.operatorName" style="width:150px;"></el-input>
          </el-form-item>
          <el-form-item label="渠道名称：" v-if="showChannelName">
            <el-input size="small" v-model="dataInfoForm.name" style="width:150px;"></el-input>
          </el-form-item>
          <el-form-item label="插件名称：" v-if="showPluginName">
            <el-input size="small" v-model="dataInfoForm.name" style="width:150px;"></el-input>
          </el-form-item>
          <el-form-item label="应用列表：" v-if="showSearchGame">
            <el-select size="small" v-model="dataInfoForm.gameId" clearable placeholder="请选择" style="width:150px;" @change="getGameVersionList" @clear="getGameVersionList">
              <el-option
                v-for="item in searchGameList"
                :key="item.gameId"
                :label="item.gameName"
                :value="item.gameId">
                <i class="ext-icon-plan-small" :class="getIconClassName(item.gameId)"></i>
                <span>{{ item.gameName }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="版本列表：" v-if="showSearchGameVersion">
            <el-select size="small" v-model="dataInfoForm.iGameAssetsId" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in gameVersionList"
                :key="item.iAssertId"
                :label="item.gameAssetsVersion"
                :value="item.iAssertId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="地区：" v-if="showArea">
            <el-select size="small" v-model="dataInfoForm.areaId" clearable placeholder="请选择" style="width:150px;" @change="getGameVersionList" @clear="getGameVersionList">
              <el-option
                v-for="item in areaList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
                <i class="ext-icon-plan-small" :class="getIconClassName(item.sDicName)"></i>
                <span>{{ item.sDicName }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="平台：" v-if="showPlatform">
            <el-select size="small" v-model="dataInfoForm.platformId" clearable placeholder="请选择" style="width:150px;" @change="getGameVersionList" @clear="getGameVersionList">
              <el-option
                v-for="item in platformList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
                <i class="ext-icon-plan-small" :class="getIconClassName(item.sDicName)"></i>
                <span>{{ item.sDicName }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="语言：" v-if="false && showLanguage">
            <el-select size="small" v-model="dataInfoForm.languageId" clearable placeholder="请选择" style="width:150px;" @change="getGameVersionList" @clear="getGameVersionList">
              <el-option
                v-for="item in languageList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="插件类型：" v-if="showPluginType">
            <el-select size="small" v-model="dataInfoForm.typeId" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in pluginTypeList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="插件：" v-if="showPlugin">
            <el-select size="small" v-model="dataInfoForm.plugin" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in pluginList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="代理类型：" v-if="showAgencyType">
            <el-select size="small" v-model="dataInfoForm.cAssertType" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in agencyTypeList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="打包状态：" v-if="showPackStatus">
            <el-select size="small" v-model="dataInfoForm.status" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in packStatusList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="状态：" v-if="showPlanStatus">
            <el-select size="small" v-model="dataInfoForm.cPlanStatus" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in planStatusList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="计划类型：" v-if="showPlanType">
            <el-select size="small" v-model="dataInfoForm.iPlanType" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in planTypeDataList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="状态：" v-if="showDataDisplay">
            <el-select size="small" v-model="dataInfoForm.cDisplay" clearable placeholder="请选择" style="width:150px;">
              <el-option
                v-for="item in dataDisplayList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item v-if="false && showSearchBtn">
            <el-button size="small" type="primary" @click="searchDataList()" v-if="roleAuthority.searchBtn">查询</el-button>
          </el-form-item>
        </el-col>
        <el-col :span="2" style="text-align: right;" v-if="showAddBtn || showLaunchPlanBtn">
          <el-form-item v-if="showAddBtn">
            <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn">新增</el-button>
          </el-form-item>
          <el-form-item v-if="showLaunchPlanBtn">
            <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.launchPlan">发起计划</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>

</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import planUtil from '../../utils/plan-util'
  export default{
    props: ['optionData', 'dataInfoForm'],
    data () {
      return {
        dataDisplayList: [
          {
            iDicId: '0',
            sDicName: '使用中'
          },
          {
            iDicId: '1',
            sDicName: '已下架'
          }
        ],
        gameVersionList: [],
        showOperatorName: false,
        showGameName: false,
        showChannelName: false,
        showPluginName: false,
        showArea: false,
        showLanguage: false,
        showPlatform: false,
        showPlugin: false,
        showAgencyType: false,
        showPackStatus: false,
        showPlanStatus: false,
        showPlanType: false,
        showDataDisplay: false,
        showSearchBtn: false,
        showLaunchPlanBtn: false,
        showAddBtn: false,
        showSearchGame: false,
        area: '',
        language: '',
        platform: '',
        pluginList: null,
        plugin: '',
        packStatus: '',
        planStatus: ''
      }
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          this.optionData.searchCallBack()
        },
        deep: true
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'packStatusList', 'roleAuthority', 'searchGameList', 'planStatusList',
        'pluginTypeList', 'agencyTypeList', 'planTypeDataList'
      ])
    },
    created () {
      this.showGameName = this.optionData.showGameName || this.showGameName
      this.showOperatorName = this.optionData.showOperatorName || this.showOperatorName
      this.showChannelName = this.optionData.showChannelName || this.showChannelName
      this.showPluginName = this.optionData.showPluginName || this.showPluginName
      this.showArea = this.optionData.showArea || this.showArea
      this.showLanguage = this.optionData.showLanguage || this.showLanguage
      this.showPlatform = this.optionData.showPlatform || this.showPlatform
      this.showPluginType = this.optionData.showPluginType || this.showPluginType
      this.showPlugin = this.optionData.showPlugin || this.showPlugin
      this.showAgencyType = this.optionData.showAgencyType || this.showAgencyType
      this.showPackStatus = this.optionData.showPackStatus || this.showPackStatus
      this.showPlanStatus = this.optionData.showPlanStatus || this.showPlanStatus
      this.showPlanType = this.optionData.showPlanType || this.showPlanType
      this.showDataDisplay = this.optionData.showDataDisplay || this.showDataDisplay
      this.showLaunchPlanBtn = this.optionData.showLaunchPlanBtn || this.showLaunchPlanBtn
      this.showSearchGame = this.optionData.showSearchGame || this.showSearchGame
      this.showSearchGameVersion = this.optionData.showSearchGameVersion || this.showSearchGameVersion
      this.showSearchBtn = this.optionData.showSearchBtn || this.showSearchBtn
      this.showAddBtn = this.optionData.showAddBtn || this.showAddBtn
      if (this.showSearchGameVersion) {
        this.getGameVersionList(false)
      }
    },
    methods: {
      getGameVersionList (initFlag) {
        if (!this.showSearchGameVersion) {
          return false
        }
        let platformId = 0
        if (this.showPlatform) {
          if (!this.dataInfoForm.areaId || !this.dataInfoForm.languageId || !this.dataInfoForm.platformId || !this.dataInfoForm.gameId) {
            this.dataInfoForm.iGameAssetsId = ''
            return
          }
          platformId = this.dataInfoForm.platformId
          for (let pItem of this.platformList) {
            if (pItem.iDicId === this.dataInfoForm.platformId) {
              platformId = pItem.sDicName === '安卓' ? 0 : 1
            }
          }
        } else {
          if (!this.dataInfoForm.areaId || !this.dataInfoForm.languageId || !this.dataInfoForm.gameId) {
            this.dataInfoForm.iGameAssetsId = ''
            return
          }
          platformId = 0
        }
        gameApi.getSearchVersionDataList(this.dataInfoForm.gameId, this.dataInfoForm.areaId, this.dataInfoForm.languageId, platformId).then((data) => {
          if (data.code === 1) {
            this.gameVersionList = data.data ? data.data : []
            if (initFlag) {
              this.dataInfoForm.iGameAssetsId = ''
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      searchDataList () {
        this.optionData.searchCallBack()
      },
      addDataItem () {
        this.optionData.addCallBack()
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }
</script>
