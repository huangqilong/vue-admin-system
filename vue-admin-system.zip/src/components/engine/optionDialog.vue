<style>
  .option-dialog-engine .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增引擎':'修改引擎'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-engine">
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="平台：" prop="iPlatformId">
        <el-radio-group v-model="dataInfoForm.iPlatformId">
          <el-radio v-for="item in platformList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="平台：" prop="iPlatformId">-->
        <!--<el-select v-model="dataInfoForm.iPlatformId" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in platformList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="引擎版本：" prop="engineVersion">
        <el-input v-model.trim="dataInfoForm.engineVersion"></el-input>
      </el-form-item>
      <el-form-item label="引擎描述：">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.engineName"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('dataInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="dataInfoForm.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import engineApi from '../../apis/engine-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    components: {
    },
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        content: '',
        ueDefaultMsg: '这里是UE测试',
        ueConfig: {
          initialFrameWidth: null,
          initialFrameHeight: 350
        },
        rules: {
          iPlatformId: [
            {type: 'number', required: true, message: '请选择平台', trigger: 'change'}
          ],
          engineVersion: [
            {required: true, message: '请输入引擎版本', trigger: 'blur'}
          ],
          engineName: [
            {required: true, message: '请输入引擎描述', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              engineApi.addDataInfo(_this.dataInfoForm).then((data) => {
                console.log(data)
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              engineApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
