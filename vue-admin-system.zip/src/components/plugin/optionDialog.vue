<style>
  .option-dialog-plug .el-dialog{
    width: 600px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增插件':'修改插件('+optionData.title+ '）'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-plug">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="120px">
      <el-form-item label="地区：" prop="iAreaId">
        <el-select v-model="dataInfoForm.iAreaId" placeholder="请选择">
          <el-option
            v-for="item in areaList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="语言：" prop="iLanguageId">
        <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择">
          <el-option
            v-for="item in languageList"
            :key="item.iDicId"
            :label="item.sDicName"
            :value="item.iDicId">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="平台：" prop="iPlatformId">
        <el-radio-group v-model="dataInfoForm.iPlatformId">
          <el-radio v-for="item in platformList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="平台：" prop="iPlatformId">-->
        <!--<el-select v-model="dataInfoForm.iPlatformId" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in platformList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="插件名称：" prop="channelName">
        <el-input v-model.trim="dataInfoForm.channelName"></el-input>
      </el-form-item>
      <el-form-item label="标识符：" prop="channelSign">
        <el-input v-model.trim="dataInfoForm.channelSign"></el-input>
      </el-form-item>
      <el-form-item label="特殊标识符：" prop="channelExtraSign">
        <el-input v-model.trim="dataInfoForm.channelExtraSign"></el-input>
      </el-form-item>
      <el-form-item label="额外标识符：" prop="channelOtherSign">
        <el-input v-model.trim="dataInfoForm.channelOtherSign"></el-input>
      </el-form-item>
      <el-form-item label="插件关联入口：" prop="relateType">
        <el-radio class="radio" v-model="dataInfoForm.relateType" :label="'0'">渠道关联</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.relateType" :label="'1'">游戏关联</el-radio>
      </el-form-item>
      <el-form-item label="插件类型：" prop="typeId">
        <el-radio-group v-model="dataInfoForm.typeId">
          <el-radio v-for="item in pluginTypeList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <!--<el-form-item label="插件类型：" prop="typeId">-->
        <!--<el-select v-model="dataInfoForm.typeId" placeholder="请选择">-->
          <!--<el-option-->
            <!--v-for="item in pluginTypeList"-->
            <!--:key="item.iDicId"-->
            <!--:label="item.sDicName"-->
            <!--:value="item.iDicId">-->
          <!--</el-option>-->
        <!--</el-select>-->
      <!--</el-form-item>-->
      <el-form-item label="插件描述：" prop="sDesc">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.sDesc"></el-input>
      </el-form-item>
      <el-form-item label="是否请求参数：" prop="cReqParam">
        <el-radio class="radio" v-model="dataInfoForm.cReqParam" :label="'1'">是</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.cReqParam" :label="'0'">否</el-radio>
      </el-form-item>
      <el-form-item label="参数值：" prop="paramKey" v-if="dataInfoForm.cReqParam=='1'">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.paramKey"></el-input>
      </el-form-item>
      <el-form-item label="参数说明：" prop="paramDetail" v-if="dataInfoForm.cReqParam=='1'">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.paramDetail"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading" v-if="optionData.type=='add' || dataInfoForm.cDisplay=='0'">确 定</el-button>
      <el-button size="small" @click="optionData.dialogFormVisible = false" v-if="dataInfoForm.cDisplay=='1'">关 闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import channelApi from '../../apis/channel-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        rules: {
          iAreaId: [
            {type: 'number', required: true, message: '请选择地区', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择语言', trigger: 'change'}
          ],
          iPlatformId: [
            {type: 'number', required: true, message: '请选择平台', trigger: 'change'}
          ],
          channelName: [
            {required: true, message: '请输入渠道名称', trigger: 'blur'}
          ],
          channelSign: [
            {required: true, message: '请输入标识符', trigger: 'blur'}
          ],
          channelExtraSign: [
            {required: true, message: '请输入特殊标识符', trigger: 'blur'}
          ],
          channelOtherSign: [
            {required: true, message: '请输入额外标识符', trigger: 'blur'}
          ],
          relateType: [
            {required: true, message: '请选择插件关联入口', trigger: 'change'}
          ],
          typeId: [
            {type: 'number', required: true, message: '请选择插件类型', trigger: 'change'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'pluginTypeList', 'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              channelApi.addDataInfo(1, _this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(this.oldDataInfoForm, this.dataInfoForm)) {
                this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              channelApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
