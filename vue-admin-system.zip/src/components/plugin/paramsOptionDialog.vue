<style scoped>
  .dynamic-operator-btn{
    width: 100%;
  }
</style>
<style>
  .option-dialog-params .el-dialog{
    width: 600px;
  }
</style>
<template>
  <el-dialog title="参数查看" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-params">
    <el-table :data="paramsDataList" stripe>
      <el-table-column prop="paramsKey" label="参数名"></el-table-column>
      <el-table-column prop="paramsValue" label="参数值"></el-table-column>
    </el-table>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  export default{
    props: ['optionData', 'dataInfoForm'],
    computed: {
    },
    data () {
      return {
        paramsDataList: []
      }
    },
    created: function () {
      let resKey = this.dataInfoForm.paramsKey.split(',')
      let resValue = this.dataInfoForm.paramsValue ? this.dataInfoForm.paramsValue.split(',') : []
      for (let rIndex in resKey) {
        this.paramsDataList.push({
          paramsKey: resKey[rIndex],
          paramsValue: resValue.length > 0 ? resValue[rIndex] : ''
        })
      }
    },
    methods: {
    }
  }
</script>
