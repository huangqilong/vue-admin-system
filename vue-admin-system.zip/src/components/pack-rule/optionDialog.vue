<style>
  .option-dialog-agec .el-dialog--tiny{
    min-width: 400px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type=='add'?'新增打包规则':'修改打包规则'" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-agec">
    <el-form :model="dataInfoForm" ref="gameInfoForm" :rules="rules" label-width="100px">
      <el-form-item label="配置名称：" prop="sysConfigName">
        <el-input v-model.trim="dataInfoForm.sysConfigName"></el-input>
      </el-form-item>
      <el-form-item label="配置参数：" prop="sysConfigParam">
        <el-input v-model.trim="dataInfoForm.sysConfigParam"></el-input>
      </el-form-item>
      <el-form-item label="参数值：" prop="sysConfigValue">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.sysConfigValue"></el-input>
      </el-form-item>
      <el-form-item label="规则说明：" prop="sysConfigRule">
        <el-input type="textarea" :rows="3" v-model="dataInfoForm.sysConfigRule"></el-input>
      </el-form-item>
      <el-form-item label="开启状态：" prop="sysConfigStatus">
        <el-radio class="radio" v-model="dataInfoForm.sysConfigStatus" :label="1">开启</el-radio>
        <el-radio class="radio" v-model="dataInfoForm.sysConfigStatus" :label="0">关闭</el-radio>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">取 消</el-button>
      <el-button size="small" type="primary" :disabled="isEqualsOption" @click="submitForm('gameInfoForm')" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import packRuleApi from '../../apis/pack-rule-api'

  export default{
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        rules: {
          sysConfigName: [
            {required: true, message: '请输入配置名称', trigger: 'blur'}
          ],
          sysConfigParam: [
            {required: true, message: '请输入配置参数', trigger: 'blur'}
          ],
          sysConfigValue: [
            {required: true, message: '请输入参数值', trigger: 'blur'}
          ],
          sysConfigRule: [
            {required: true, message: '请输入规则说明', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'platformList', 'buttonLoading'
      ])
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
    },
    methods: {
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.optionData.type === 'add') {
              // 数据新增
              packRuleApi.addDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '新增失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            } else {
              if (equalsExtend.objectEqual(_this.oldDataInfoForm, _this.dataInfoForm)) {
                _this.optionData.dialogFormVisible = false
                _this.optionCallBack()
                return
              }
              // 数据修改
              packRuleApi.updateDataInfo(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                  _this.optionCallBack()
                } else {
                  this.$alert(data.msg, '修改失败', {
                    confirmButtonText: '确定'
                  })
                }
              }, (error) => {
                console.log(error)
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
