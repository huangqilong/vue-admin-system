<style>
  .option-dialog-sys-config .el-dialog{
    width: 600px;
  }
  .option-dialog-sys-config .el-dialog .el-dialog__body{
    padding: 20px 0px 0 20px;
  }
  .option-dialog .el-select{
    width: 100%;
  }
</style>
<template>
  <el-dialog title="配置参数值" :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-sys-config">
    <div style="max-height: 600px;overflow: auto;">
      {{optionData.sysConfig.sysConfigValue}}
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogFormVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  export default{
    props: ['optionData'],
    data () {
      return {}
    },
    computed: {},
    created: function () {

    },
    methods: {
    }
  }
</script>
