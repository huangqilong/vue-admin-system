<style>
  .option-dialog-upload-package .el-dialog{
    width: 600px;
  }
  .option-dialog-upload-package .el-select{
    width: 100%;
  }
  .option-dialog-upload-package .el-table td, .el-table th {
    height: 40px;
  }
  .option-dialog-upload-package .upload-demo-table{
    width: 80px;
  }
  .option-dialog-upload-package .el-upload, .upload-demo .el-upload .el-button--small{
    width: 100%;
  }
  .option-dialog-upload-package .el-upload-list .el-upload-list__item .el-upload-list__item-status-label{
    top: 4px;
    display: none;
  }
  .option-dialog-upload-package .el-upload-list .el-upload-list__item .el-icon-close{
    top: 9px;
    display: none;
  }
</style>
<!--<style scoped>-->
<!--/*.uploadBarePackage .upload-demo {width:100px;}*/-->
<!--</style>-->
<template>
  <el-dialog title="SDK测试资源上传" :visible.sync="optionData.dialogFormVisible"
             :close-on-click-modal="false"
             class="option-dialog option-dialog-upload-package">
    <el-form :model="dataInfoForm" ref="dataInfoForm" label-width="100px" :rules="rules">
      <el-form-item label="游戏资源：" prop="gameAssetPath"  class="uploadBarePackage" v-if="planInfo.iUseSvn!=1">
        <el-upload
          class="upload-demo"
          :action="proxyDevApi+'/uploadFile/' +fileUploadDirId"
          :show-file-list="true"
          :multiple="false"
          :headers="headersFile"
          :file-list="fileAssetUploadList"
          :before-upload="beforeAvatarUpload"
          :on-success="handleAssetFileSuccess"
          :on-remove="handleAssetFileRemove"
          :on-error="handleAssetFileError"
          :on-progress="handleAssetFileProgress">
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </el-form-item>
      <el-form-item label="svn路径：" prop="svnResourcePath" v-if="planInfo.iUseSvn==1">
        <el-input v-model.trim="dataInfoForm.svnResourcePath"></el-input>
      </el-form-item>
      <div style="color: #ef5350;">提示：当前系统支持最高2000M的资源包，如有特殊需求请联系系统组葛卫强！</div>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="optionData.dialogFormVisible = false" >取 消</el-button>
        <el-button size="small" type="primary" @click="submitForm('dataInfoForm')" :loading="buttonLoading || startFileUpload" >确 定</el-button>
      </div>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import planApi from '../../apis/plan-api'

  export default{
    components: {
    },
    props: ['optionData'],
    data () {
      return {
        startFileUpload: false,
        fileAssetUploadList: [],
        dataInfoForm: {
          cPlatformType: '',
          gameAssetPath: '',
          iGameAssertId: '',
          iProjectAssetId: '',
          uploadType: '0',
          resDirId: '',
          resId: '',
          cMd5: ''
        },
        rules: {
          gameAssetPath: [
            {required: true, message: '请输入游戏资源', trigger: 'change'}
          ],
          svnResourcePath: [
            {required: true, message: '请输入svn路径', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'headersFile', 'fileUploadDirId', 'buttonLoading', 'proxyDevApi'
      ])
    },
    created: function () {
      if (this.planInfo.iUseSvn === 1) {
        this.dataInfoForm = {
          svnResourcePath: '',
          iGameAssertId: '',
          iProjectAssetId: ''
        }
      }
      this.getSdkTestPack()
    },
    methods: {
      beforeAvatarUpload (file) {
        let fileType = file.name.substring(file.name.lastIndexOf('.')).toLocaleLowerCase()
        let androidRegAsset = /.(pkg|apk)/
        let iosRegAsset = /.pkg/
        let isUpload = false
        if (this.planInfo.iPlatformName === '安卓') {
          isUpload = androidRegAsset.test(fileType)
          if (!isUpload) {
            this.$alert('资源类型只能为pkg或apk', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        } else {
          isUpload = iosRegAsset.test(fileType)
          if (!isUpload) {
            this.$alert('资源类型只能为pkg', '格式错误', {
              confirmButtonText: '确定'
            })
          }
        }
        if (isUpload) {
          this.startFileUpload = true
        }
        return isUpload
      },
      handleAssetFileProgress (event, file, fileList) {
        if (event.percent >= 99) {
          event.percent = 99
        }
      },
      handleAssetFileSuccess (response, file, fileList) {
        if (response.code === 1) {
          this.fileAssetUploadList = []
          this.fileAssetUploadList.push({
            name: response.data.url,
            resId: response.data.resId
          })
          this.dataInfoForm.gameAssetPath = response.data.url
          this.dataInfoForm.resId = response.data.resId
          this.dataInfoForm.cMd5 = response.data.md5
        } else {
          this.fileAssetUploadList = []
          this.$alert('文件上传失败', '提示', {
            confirmButtonText: '确定'
          })
        }
        this.startFileUpload = false
      },
      handleAssetFileRemove (file, fileList) {
        if (file && file.resId) {
          this.$store.dispatch('deleteGameConfigImage', file.resId)
        }
        this.dataInfoForm.gameAssetPath = ''
        this.dataInfoForm.resId = ''
        this.dataInfoForm.cMd5 = ''
        this.startFileUpload = false
      },
      handleAssetFileError (error, file, fileList) {
        this.fileAssetUploadList = []
        this.startFileUpload = false
        this.$alert(error, '文件上传失败', {
          confirmButtonText: '确定'
        })
      },
      getSdkTestPack () {
        gameApi.getAssetsDataInfo(this.planInfo.iProjectSdkAssetId).then((data) => {
          if (data.code === 1) {
            if (this.planInfo.iUseSvn === 1) {
              this.dataInfoForm.svnResourcePath = data.data.svnResourcePath
            } else {
              if (data.data.resDirId) {
                this.$store.dispatch('getFileUploadDir', data.data.resDirId)
              } else {
                this.$store.dispatch('getFileUploadDir', null)
              }
              this.fileAssetUploadList = []
              if (data.data.gameAssetPath) {
                this.fileAssetUploadList.push({
                  name: data.data.gameAssetPath,
                  resId: data.data.resId
                })
                this.dataInfoForm.gameAssetPath = data.data.gameAssetPath
                this.dataInfoForm.resId = data.data.resId
                this.dataInfoForm.cMd5 = data.data.cMd5
              }
            }
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      submitForm (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            this.dataInfoForm.iGameAssertId = this.planInfo.iGameAssetsId
            this.dataInfoForm.iProjectAssetId = this.planInfo.iProjectSdkAssetId
            if (this.planInfo.iUseSvn === 1) {
              planApi.uploadGameSdkTestPackageSvn(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                } else {
                  this.$alert(data.msg, '提示', {
                    confirmButtonText: '确定'
                  })
                }
                this.startFileUpload = false
              }, (error) => {
                this.$alert('请求失败，请稍后重试', '提示', {
                  confirmButtonText: '确定'
                })
                this.startFileUpload = false
              })
            } else {
              this.dataInfoForm.cPlatformType = this.planInfo.iPlatformName === '安卓' ? 0 : 1
              this.dataInfoForm.resDirId = _this.fileUploadDirId
              // 数据新增
              planApi.uploadGameSdkTestPackage(_this.dataInfoForm).then((data) => {
                if (data.code === 1) {
                  this.optionData.dialogFormVisible = false
                } else {
                  this.$alert(data.msg, '提示', {
                    confirmButtonText: '确定'
                  })
                }
                this.startFileUpload = false
              }, (error) => {
                this.$alert('请求失败，请稍后重试', '提示', {
                  confirmButtonText: '确定'
                })
                this.startFileUpload = false
              })
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
