<style>
  .option-dialog-anew-package .el-dialog{
    width: 600px;
  }
  .option-dialog-anew-package .el-form-item__label{
    width:100%;
    text-align:left;
  }
  .option-dialog-anew-package .el-checkbox-group .el-checkbox{
    margin-right:5px;
    margin-left:0;
  }
</style>
<template>
  <el-dialog :title="optionData.title" :visible.sync="optionData.dialogFormVisible" class="option-dialog option-dialog-anew-package">
    <div class="content-list">
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules" >
        <!--<el-row class="tip-wraning-message-item">-->
          <!--<el-col><i class="el-icon-warning" ></i><span >提示：在渠道驳回的情况下,点击重新打包，整包状态变为待打包,渠道重走接入流程</span ></el-col>-->
        <!--</el-row>-->
        <el-row >
          <el-col :span="5">重新打包渠道：</el-col>
          <el-col :span="19">{{planChannelInfo.iChannelName}}</el-col>
        </el-row>
        <el-form-item label="选择哪些广告码需要重新打包:" prop="channelArrayIds" v-if="channelDataList.length>0">
          <el-row>
            <el-col :span="24"><el-checkbox label="广告码" v-model="advCheckedAll" @change="advCheckAllChange"></el-checkbox></el-col>
            <el-checkbox-group v-model="dataInfoForm.advChannelArrayIds">
              <template>
                <el-col v-for="(item,index) in advChannelDataList" :span="8">
                  <el-checkbox :label="item.cAdcpsCode" @change="advCheckOneChange($event,item)">{{item.cAdcpsCode+'('+item.sDemo+')'}}</el-checkbox>
                </el-col>
              </template>
            </el-checkbox-group>
            <el-col :span="24"><el-checkbox label="CPS码" v-model="cpsCheckedAll" @change="cpsCheckAllChange"></el-checkbox></el-col>
            <el-checkbox-group v-model="dataInfoForm.cpsChannelArrayIds">
              <template>
                <el-col v-for="(item,index) in cpsChannelDataList" :span="8">
                  <el-checkbox :label="item.cAdcpsCode" @change="cpsCheckOneChange($event,item)">{{item.cAdcpsCode+'('+item.sDemo+')'}}</el-checkbox>
                </el-col>
              </template>
            </el-checkbox-group>
          </el-row>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary" @click="submitFormData('dataInfoForm')" >确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {},
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
//          channelArrayIds: [
//            { type: 'array', required: true, message: '请至少选择一个广告码', trigger: 'change' }
//          ]
        },
        advCheckedAll: false,
        cpsCheckedAll: false,
        channelDataList: [],
        advChannelDataList: [],
        cpsChannelDataList: []
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planChannelInfo'
      ])
    },
    created: function () {
      // 获取广告吗
      this.getAdvOrCpsList()
    },
    methods: {
      getAdvOrCpsList () {
        planApi.getPackAdvCpsDataList(this.planChannelInfo.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            if (data.data) {
              this.channelDataList = data.data
              for (let item of data.data) {
                if (item.cPackType === '0') {
                  this.advChannelDataList.push(item)
                } else {
                  this.cpsChannelDataList.push(item)
                }
              }
            } else {
              this.channelDataList = []
              this.advChannelDataList = []
              this.cpsChannelDataList = []
            }
          }
        })
      },
      advCheckAllChange (event) {
        const _this = this
        this.dataInfoForm.advChannelArrayIds = []
        if (event) {
          for (let item of _this.advChannelDataList) {
            this.dataInfoForm.advChannelArrayIds.push(item.cAdcpsCode)
          }
        }
      },
      cpsCheckAllChange (event) {
        const _this = this
        this.dataInfoForm.cpsChannelArrayIds = []
        if (event) {
          for (let item of _this.cpsChannelDataList) {
            this.dataInfoForm.cpsChannelArrayIds.push(item.cAdcpsCode)
          }
        }
      },
      // 单个选中
      advCheckOneChange (event, item) {
        const _this = this
        if (_this.advChannelDataList.length === _this.dataInfoForm.advChannelArrayIds.length) {
          _this.advCheckedAll = true
        } else {
          _this.advCheckedAll = false
        }
      },
      cpsCheckOneChange (event, item) {
        const _this = this
        if (_this.cpsChannelDataList.length === _this.dataInfoForm.cpsChannelArrayIds.length) {
          _this.cpsCheckedAll = true
        } else {
          _this.cpsCheckedAll = false
        }
      },
      submitFormData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let submitData = JSON.parse(JSON.stringify(this.dataInfoForm))
            submitData.channelIds = submitData.advChannelArrayIds.concat(submitData.cpsChannelArrayIds).join(',')
            delete submitData.advChannelArrayIds
            delete submitData.cpsChannelArrayIds
//            delete submitData.hasAdvCpsCode
            planApi.againPackGamePackage(this.planChannelInfo.iPlanChannelId, 2, this.planChannelInfo.cStatus, submitData).then((data) => {
              if (data.code === 1) {
                _this.optionCallBack()
                this.optionData.dialogFormVisible = false
              } else {
                _this.$alert(data.msg, '请求失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert('请求失败，请稍后重试！', '提示', {
                confirmButtonText: '确定'
              })
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
