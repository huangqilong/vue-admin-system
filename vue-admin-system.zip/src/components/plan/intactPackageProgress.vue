<style scoped>
  .warning-text{
    margin-bottom: 10px;
    color: #008000;
    letter-spacing: 1px;
  }
  .review-text{
    margin-bottom: 10px;
    color: #999;
    letter-spacing: 1px;
  }
</style>
<template>
  <div>
    <div class="warning-text" v-if="planProgressTabStatus.packPlanNoticeVO && planProgressTabStatus.packPlanNoticeVO.packNotice">
      <i class="el-icon-warning"></i>&nbsp;&nbsp;温馨提示：{{planProgressTabStatus.packPlanNoticeVO.packNotice}}
    </div>
    <div class="review-text" v-if="planInfo.iAreaName=='大陆'&&planInfo.iPlatformName=='安卓'">
      <i class="el-icon-warning"></i>&nbsp;&nbsp;温馨提示：<span v-if="planInfo.gameReviewFlag == 1">当前项目已支持自动开启和关闭审核服状态！</span>
      <span v-else>当前项目暂未支持自动开启和关闭审核服，请走原有的OA流程！</span>
    </div>
    <el-table :data="dataList" stripe>
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="iChannelName" label="渠道名称" >
        <template scope="scope">
          <span v-if="!(roleAuthority.planChannelSummary && scope.row.iChannelName)">{{scope.row.iChannelName ? scope.row.iChannelName : '--'}}</span>
          <a v-if="roleAuthority.planChannelSummary && scope.row.iChannelName" @click="planChannelSummaryFun(scope.$index,scope.row,dataList)">{{scope.row.iChannelName}}</a>
        </template>
      </el-table-column>
      <el-table-column prop="iChannelVersion" label="接入渠道版本" >
        <template scope="scope">
          {{scope.row.iChannelVersion? scope.row.iChannelVersion : '--'}}
        </template>
      </el-table-column>
      <el-table-column  label="整包状态" prop="cStatus">
        <template scope="scope" >
          <span v-html="getStatusCharacter(scope.row.cStatus)"></span>
        </template>
      </el-table-column>
      <el-table-column prop="userName" label="处理人">
        <template scope="scope">
          <span :style="scope.row.userName=='系统'?'color: #aaa;':''">{{scope.row.cStatus !=0 &&　scope.row.userName　? scope.row.userName : '--'}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="reviewFlag" label="审核服状态" v-if="planInfo.iPlanType == 1 && planInfo.gameReviewFlag == 1">
        <template scope="scope">
          <span v-if="scope.row.iIsOffical == 1 || scope.row.iEject == 0 || scope.row.cStatus ==0 || scope.row.cStatus == 6 || scope.row.cStatus == 10">--</span>
          <span v-if="!(scope.row.iIsOffical == 1 || scope.row.iEject == 0 || scope.row.cStatus ==0 || scope.row.cStatus == 6 || scope.row.cStatus == 10)"
                :style="(scope.row.reviewFlag == 0 || scope.row.reviewFlag == 2)?'color: #ef5350':(scope.row.reviewFlag == 1?'color: #13ce66':(scope.row.reviewFlag == 3?'color: #999':''))">{{getReviewFlagName(scope.row.reviewFlag)}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="packNum" label="驳回次数"  sortable>
        <template scope="scope">
          <a v-if="scope.row.packNum>0" @click="checkTimeDialogShow(scope.$index,scope.row,dataList)">{{scope.row.packNum}}</a>
          <span v-if="scope.row.packNum<=0">{{scope.row.packNum}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="dPackEnd" label="打包时间" sortable>
        <template scope="scope">
          {{scope.row.cStatus !='0' &&　scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10' && scope.row.dPackEnd　? scope.row.dPackEnd : '--'}}
        </template>
      </el-table-column>
      <el-table-column  label="操作"  width="430" v-if="planInfo.cPlanStatus!=planStatusList[1].iDicId && planInfo.iPlanType == 1 && planInfo.gameReviewFlag == 1">
        <template scope="scope">
          <el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.configDetails &&　scope.row.cStatus != '0'">配置详情</el-button>
          <el-button type="text" class="table-option-button" @click="anewPack(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.againPack && (scope.row.cStatus == '5' || scope.row.cStatus == '20' || scope.row.cStatus == '40')">重新打包</el-button>
          <el-button type="text" class="table-option-button" @click="openEjectReview(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.openEjectReview &&　scope.row.cStatus == '15' && scope.row.iIsOffical != 1 && scope.row.iEject == 0">开启审核服</el-button>
          <el-button type="text" class="table-option-button" @click="workOrderOpenFun(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.workOrderOpen && scope.row.cStatus == '15' && scope.row.iEject == 1 && (scope.row.iIsOffical != 1 && scope.row.reviewFlag == 0)">走工单开启</el-button>
          <el-button type="text" class="table-option-button" @click="workOrderCloseFun(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.workOrderClose && scope.row.cStatus == '35'&& (scope.row.iIsOffical != 1 && scope.row.reviewFlag == 2)">走工单关闭</el-button>
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoad && (scope.row.iIsOffical == 1 || scope.row.iEject == 1) && scope.row.cStatus != '0' && scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">下载</el-button>
          <el-button type="text" class="table-option-button" @click="checkPass(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.QAPass &&　scope.row.cStatus == '15' && (scope.row.iIsOffical == 1 || (scope.row.reviewFlag == 1 && scope.row.iEject == 1))">通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList,'质检')"
                     v-if="roleAuthority.rejectBtn &&　scope.row.cStatus == '15' && (scope.row.iIsOffical == 1 || (scope.row.reviewFlag == 1 && scope.row.iEject == 1))">驳回</el-button>
          <el-button type="text" class="table-option-button" @click="viewReason(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.checkCause && (scope.row.cStatus == '20' || scope.row.cStatus == '40')">查看原因</el-button>
          <el-button type="text" class="table-option-button" @click="revocationReject(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.revocationRejectBtn && (scope.row.cStatus == '20' || scope.row.cStatus == '40')">撤销</el-button>
          <el-button type="text" class="table-option-button" @click="channelSendCheck(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelSendCheck &&　scope.row.cStatus == '25'">渠道送审</el-button>
          <el-button type="text" class="table-option-button" @click="channelPass(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelPass &&　scope.row.cStatus == '30'">渠道通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList,'渠道')"
                     v-if="roleAuthority.channelReject &&　scope.row.cStatus == '30'">渠道驳回</el-button>
          <el-button type="text" class="table-option-button" @click="buglyUpload(scope.$index,scope.row,dataList)"
                     v-if="false&&roleAuthority.buglyConfig&&planInfo.iPlatformName=='IOS'&& scope.row.cStatus == '35' && (scope.row.iIsOffical == 1 || scope.row.reviewFlag == 3)">bugly上传</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.buglyConfig&&planInfo.iPlatformName=='IOS'&& (scope.row.iIsOffical == 1 || scope.row.iEject == 1) && scope.row.cStatus != '0' && scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">bugly下载</el-button>
          <el-button type="text" class="table-option-button" @click="enterChannelAddress(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.enterChannelUrl && scope.row.cStatus == '35'&& (scope.row.iIsOffical == 1 || scope.row.reviewFlag == 3)">录入渠道地址</el-button>
          <el-button type="text" class="table-option-button" @click="channelDownloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelDownloadUrl &&　scope.row.cStatus == '35' && (scope.row.iIsOffical == 1 || scope.row.reviewFlag == 3) && scope.row.channelAppUrl">渠道下载地址</el-button>
          <el-popover :title="'打包服务器（' + scope.row.iChannelName+ '）'" trigger="click" @show="packResultLogDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button" v-if="roleAuthority.checkLog && (scope.row.iIsOffical == 1 || scope.row.iEject == 1) && scope.row.cStatus != '0'">日志</el-button>
          </el-popover>
          <span v-if="scope.row.cStatus == '0'">--</span>
        </template>
      </el-table-column>
      <el-table-column  label="操作"  width="430" v-if="planInfo.cPlanStatus!=planStatusList[1].iDicId && !(planInfo.iPlanType == 1 && planInfo.gameReviewFlag == 1)">
        <template scope="scope">
          <el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList) && planInfo.iPlanType == 1 && planInfo.gameReviewFlag == 1"
                     v-if="roleAuthority.configDetails &&　scope.row.cStatus != '0'">配置详情</el-button>
          <el-button type="text" class="table-option-button" @click="anewPack(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.againPack && (scope.row.cStatus == '5' || scope.row.cStatus == '20' || scope.row.cStatus == '40')">重新打包</el-button>
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoad &&　scope.row.cStatus != '0' && scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">下载</el-button>
          <el-button type="text" class="table-option-button" @click="checkPass(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.QAPass &&　scope.row.cStatus == '15'">通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList,'质检')"
                     v-if="roleAuthority.rejectBtn &&　scope.row.cStatus == '15'">驳回</el-button>
          <el-button type="text" class="table-option-button" @click="viewReason(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.checkCause && (scope.row.cStatus == '20' || scope.row.cStatus == '40')">查看原因</el-button>
          <el-button type="text" class="table-option-button" @click="revocationReject(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.revocationRejectBtn && (scope.row.cStatus == '20' || scope.row.cStatus == '40')">撤销</el-button>
          <el-button type="text" class="table-option-button" @click="channelSendCheck(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelSendCheck &&　scope.row.cStatus == '25'">渠道送审</el-button>
          <el-button type="text" class="table-option-button" @click="channelPass(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelPass &&　scope.row.cStatus == '30'">渠道通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList,'渠道')"
                     v-if="roleAuthority.channelReject &&　scope.row.cStatus == '30'">渠道驳回</el-button>
          <el-button type="text" class="table-option-button" @click="buglyUpload(scope.$index,scope.row,dataList)"
                     v-if="false&&roleAuthority.buglyConfig&&planInfo.iPlatformName=='IOS'&& scope.row.cStatus == '35'">bugly上传</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.buglyConfig&&planInfo.iPlatformName=='IOS'&& scope.row.cStatus != '0' && scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">bugly下载</el-button>
          <el-button type="text" class="table-option-button" @click="enterChannelAddress(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.enterChannelUrl && scope.row.cStatus == '35'">录入渠道地址</el-button>
          <el-button type="text" class="table-option-button" @click="channelDownloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelDownloadUrl &&　scope.row.cStatus == '35' && scope.row.channelAppUrl">渠道下载地址</el-button>
          <el-popover :title="'打包服务器（' + scope.row.iChannelName+ '）'" trigger="click" @show="packResultLogDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button" v-if="roleAuthority.checkLog && scope.row.cStatus != '0'">日志</el-button>
          </el-popover>
          <span v-if="scope.row.cStatus == '0'">--</span>
        </template>
      </el-table-column>
      <el-table-column  label="操作"  width="350" v-if="planInfo.cPlanStatus==planStatusList[1].iDicId">
        <template scope="scope">
          <el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList)" v-if="scope.row.cStatus != '0'">配置详情</el-button>
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="scope.row.cStatus != '0' && scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">下载</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="planInfo.iPlatformName=='IOS'&& scope.row.cStatus != '0' && scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">bugly下载</el-button>
          <el-button type="text" class="table-option-button" @click="channelDownloadPackage(scope.$index,scope.row,dataList)" v-if="scope.row.cStatus == '35'">渠道下载地址</el-button>
          <el-popover :title="'打包服务器（' + scope.row.iChannelName+ '）'" trigger="click" @show="packResultLogDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button" v-if="scope.row.cStatus != '0'">日志</el-button>
          </el-popover>
        </template>
      </el-table-column>
    </el-table>
    <planPackConfigDialog v-if="showPackConfigDataDialogSet.dialogFormVisible" :optionData="showPackConfigDataDialogSet"></planPackConfigDialog>
    <downFileDialog v-if="optionDownFileDialog.dialogVisible" :optionData="optionDownFileDialog" :dataParams="optionDownFileItem"></downFileDialog>
    <down-file-dialog-v1 v-if="optionDownFileDialogV1.dialogVisible" :optionData="optionDownFileDialogV1" :dataParams="optionDownFileItemV1"></down-file-dialog-v1>
    <plan-down-file-dialog v-if="optionPlanDownFileDialog.dialogVisible" :optionData="optionPlanDownFileDialog" :dataParams="optionDownFileItem"></plan-down-file-dialog>
    <viewReasonDialog v-if="viewRejectReasonDialogSet.dialogFormVisible" :optionData="viewRejectReasonDialogSet" :dataInfoForm="viewRejectReasonContent"></viewReasonDialog>
    <checkTimeDialog  v-if="checkTimeDialogSet.dialogFormVisible" :optionData="checkTimeDialogSet"  ></checkTimeDialog>
    <submit-explain-dialog v-if="submitExplainDialogSet.dialogFormVisible" :optionData="submitExplainDialogSet"></submit-explain-dialog>
    <anew-package-dialog v-if="anewPackageDialogSet.dialogFormVisible" :optionData="anewPackageDialogSet" :dataInfoForm="anewPackageFormData" :optionCallBack="searchDataList"></anew-package-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planUtil from '../../utils/plan-util'
  import planApi from '../../apis/plan-api'
  import packToolApi from '../../apis/pack-tool-api'
  import downFileDialog from '../../components/pack/downFileDialog'
  import downFileDialogV1 from '../../components/plan/downFileDialogV1'
  import planDownFileDialog from '../../components/plan/downFileDialog'
  import planPackConfigDialog from '../../components/plan/planPackConfigDialog'
  import viewReasonDialog from './viewRejectReasonDialog'
  import checkTimeDialog from '../../components/plan/checkTimeDialog'
  import submitExplainDialog from '../../components/plan/submitExplainDialog'
  import anewPackageDialog from '../../components/plan/anewPackageDialog'
  export default{
    components: {
      planPackConfigDialog,
      downFileDialog,
      downFileDialogV1,
      viewReasonDialog,
      checkTimeDialog,
      submitExplainDialog,
      planDownFileDialog,
      anewPackageDialog
    },
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {
        dataList: [],
        currentStatus: ' ',
        showPackConfigDataDialogSet: {
          iGamePackId: '',
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        optionDownFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileDialogV1: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionPlanDownFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileItemV1: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        optionDownFileItem: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        anewUploadDialogSet: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
//        anewUploadReasonContent: {},
//        rejectDialogSet: {
//          dialogFormVisible: false,
//          dialogFlag: '',
//          dialogCurrentTitle: ''
//        },
//        rejectReasonContent: {},
//        addChannelUrlDialogSet: {
//          dialogFormVisible: false,
//          dialogFlag: '',
//          currentStatus: '',
//          dialogCurrentTitle: ''
//        },
//        addChannelUrlContent: {},
        packServerList: [],
        checkTimeDialogSet: {
          type: '驳回',
          dialogFormVisible: false,
          currentStatus: '',
          dialogCurrentTitle: ''
        },
        viewRejectReasonDialogSet: {
          dialogFormVisible: false,
          dialogFlag: 'intact',
          dialogCurrentTitle: ''
        },
        viewRejectReasonContent: '',
        submitExplainDialogSet: {
          dialogFormVisible: false,
          type: '',
          title: '',
          isNeedProblemAttribution: false,
          formData: [],
          submitCallbackFun: null
        },
        anewPackageDialogSet: {
          dialogFormVisible: false,
          title: ''
        },
        anewPackageFormData: null
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planProgressSelectedTab', 'roleAuthority', 'planChannelInfo', 'planStatusList', 'planProgressTabStatus'
      ])
    },
    created: function () {
      if (this.planProgressSelectedTab === '2') {
        this.searchDataList()
      }
    },
    watch: {
      planProgressSelectedTab: function (newVal, oldVal) {
        if (newVal === '2') {
          this.searchDataList()
        }
      }
    },
    methods: {
      orderDataList (data) {
        let backData = []
        let backData2 = []
        let backData3 = []
        let backData4 = []
        let backData5 = []
        this.dataList = []
        for (let item of data) {
          if (item.cStatus === '40') {
            backData.unshift(item)
          } else if (item.cStatus === '20') {
            backData.push(item)
          } else if (item.cStatus === '5') {
            backData2.unshift(item)
          } else if (item.cStatus === '15') {
            backData2.push(item)
          } else if (item.cStatus === '25') {
            backData3.unshift(item)
          } else if (item.cStatus === '30') {
            backData3.push(item)
          } else if (item.cStatus === '0') {
            backData4.unshift(item)
          } else if (item.cStatus === '6') {
            backData4.push(item)
          } else if (item.cStatus === '10') {
            backData5.unshift(item)
          } else {
            backData5.push(item)
          }
        }
        this.dataList = backData.concat(backData2).concat(backData3).concat(backData4).concat(backData5)
      },
      searchDataList () {
        let _this = this
        const id = this.planInfo.iPlanId
        const packType = 2
        planApi.getPackageProgressDataList(id, packType).then((data) => {
          if (data.code === 1) {
            _this.orderDataList(data.data)
//            _this.dataList = data.data
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.dataList = null
        })
      },
      //  查看配置详情
      showPackConfig ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.showPackConfigDataDialogSet.iGamePackId = $item.iGamePackId
        this.showPackConfigDataDialogSet.dialogFormVisible = true
        this.showPackConfigDataDialogSet.dialogCurrentTitle = $item.iChannelName
      },
      // 日志下载
      packResultLogDialogShow ($index, $item, $data) {
        this.packServerList = []
        planApi.gamePackServerLogs({taskId: $item.iGamePackId}).then((data) => {
          if (data.code === 1) {
            this.packServerList = data.data.list
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 游戏下载
      downloadPackage ($index, $item, $data) {
        let noDownLoadStatus = ['0', '5', '6', '10']
        planApi.getPackRecordInfo($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            if ($item.appstore) {
              this.optionDownFileItemV1.isChannelDownload = false
              this.optionDownFileItemV1.downLoadPath = data.data.cUrl
              this.optionDownFileItemV1.resourceName = data.data.resourceName || ''
              this.optionDownFileItemV1.appstoreName = data.data.appstoreName || ''
              if (noDownLoadStatus.indexOf(data.data.cStatus) < 0 && data.data.cUrl) {
                this.optionDownFileDialogV1.dialogVisible = true
                this.optionDownFileDialogV1.dialogCurrentTitle = $item.iChannelName
              } else {
                this.$alert('暂无下载的游戏包', '提示', {
                  confirmButtonText: '确定'
                })
              }
            } else {
              this.optionDownFileItem.isChannelDownload = false
              this.optionDownFileItem.downLoadPath = data.data.cUrl
              this.optionDownFileItem.resourceName = data.data.resourceName || ''
              this.optionDownFileItem.appstoreName = data.data.appstoreName || ''
              if (noDownLoadStatus.indexOf(data.data.cStatus) < 0 && data.data.cUrl) {
                this.optionDownFileDialog.dialogVisible = true
                this.optionDownFileDialog.dialogCurrentTitle = $item.iChannelName
              } else {
                this.$alert('暂无下载的游戏包', '提示', {
                  confirmButtonText: '确定'
                })
              }
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
          this.searchDataList()
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
          this.searchDataList()
        })
      },
      // 渠道下载地址
      channelDownloadPackage ($index, $item, $data) {
        let downLoadStatus = ['35']
        planApi.getPackRecordInfo($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.optionDownFileItem.isChannelDownload = true
            this.optionDownFileItem.downLoadPath = data.data.channelAppUrl
            this.optionDownFileItem.resourceName = ''
            this.optionDownFileItem.appstoreName = ''
            if (downLoadStatus.indexOf(data.data.cStatus) >= 0 && data.data.channelAppUrl) {
              this.optionPlanDownFileDialog.dialogVisible = true
              this.optionPlanDownFileDialog.dialogCurrentTitle = $item.iChannelName
            } else {
              this.$alert('暂无渠道下载地址', '提示', {
                confirmButtonText: '确定'
              })
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
          this.searchDataList()
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
          this.searchDataList()
        })
      },
      // 通过、渠道送审，切至下一个状态
      nextStatus () {
        planApi.updateDataStatus(this.planChannelInfo.iPlanChannelId, 1, this.planChannelInfo.cStatus).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 通过
      checkPassCallback () {
        this.submitExplainDialogSet.dialogFormVisible = false
        this.nextStatus(this.planChannelInfo)
      },
      checkPass ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '质检通过'
        this.submitExplainDialogSet.title = '质检通过（' + $item.iChannelName + '）'
        this.submitExplainDialogSet.isNeedProblemAttribution = false
        this.submitExplainDialogSet.formData = [
          {
            label: '渠道名称：',
            isText: true,
            value: $item.iChannelName
          }
        ]
        this.submitExplainDialogSet.submitCallbackFun = this.checkPassCallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      // 渠道送审
      channelSendCheck ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '渠道送审'
        this.submitExplainDialogSet.title = '渠道送审（' + $item.iChannelName + '）'
        this.submitExplainDialogSet.isNeedProblemAttribution = false
        this.submitExplainDialogSet.formData = [
          {
            label: '质检人员：',
            isText: true,
            value: $item.userName
          },
          {
            label: '送审渠道：',
            isText: true,
            value: $item.iChannelName
          }
        ]
        this.submitExplainDialogSet.submitCallbackFun = this.checkPassCallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      // 驳回、渠道驳回
      rejectDialogShow ($index, $item, $data, type) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = type + '驳回'
        this.submitExplainDialogSet.title = type + '驳回（' + $item.iChannelName + '）'
        this.submitExplainDialogSet.isNeedProblemAttribution = true
        if (type === '质检') {
          this.submitExplainDialogSet.formData = [
            {
              label: '渠道名称：',
              isText: true,
              value: $item.iChannelName
            },
            {
              label: '驳回理由：',
              isText: false,
              value: '',
              placeholderText: '提示：驳回前，请联系SDK人员，确认无误后再填写简要驳回原因！'
            }
          ]
        } else {
          this.submitExplainDialogSet.formData = [
            {
              label: '送审人员：',
              isText: true,
              value: $item.userName
            },
            {
              label: '送审渠道：',
              isText: true,
              value: $item.iChannelName
            },
            {
              label: '驳回理由：',
              isText: false,
              value: '',
              placeholderText: '提示：驳回前，请联系SDK人员，确认无误后再填写简要驳回原因！'
            }
          ]
        }
        this.submitExplainDialogSet.submitCallbackFun = this.rejectCallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      rejectCallback (explainData) {
        this.submitExplainDialogSet.dialogFormVisible = false
        let params = {
          channelIds: '',
          iPlanChannelId: this.planChannelInfo.iPlanChannelId,
          iProblemType: explainData.iProblemType,
          sDesc: explainData.reason
        }
        planApi.rejectPlanReason(this.planChannelInfo.iPlanChannelId, 2, params, this.planChannelInfo.cStatus).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 渠道通过
      channelPass ($index, $item, $data) {
        this.$confirm('渠道是否确定审核通过？', '提示（' + $item.iChannelName + '）', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const params = {
            channelIds: '',
            iPlanChannelId: 0,
            sDesc: ''
          }
          planApi.channelPass($item.iPlanChannelId, params, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
              this.$store.dispatch('planChannelInfo', $item)
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      enterChannelAddress ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '录入渠道地址'
        this.submitExplainDialogSet.title = '录入渠道地址（' + $item.iChannelName + '）'
        this.submitExplainDialogSet.isNeedProblemAttribution = false
        this.submitExplainDialogSet.formData = [
          {
            label: '送审人员：',
            isText: true,
            value: $item.userName
          },
          {
            label: '送审渠道：',
            isText: true,
            value: $item.iChannelName
          },
          {
            label: '渠道下载地址：',
            isText: false,
            value: $item.channelAppUrl
          }
        ]
        this.submitExplainDialogSet.submitCallbackFun = this.channelPassCallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      // 重新打包
      anewPack ($index, $item, $data) {
        if ($item.cStatus === '40') {
          this.$store.dispatch('planChannelInfo', $item)
          this.anewPackageDialogSet.dialogFormVisible = true
          this.anewPackageDialogSet.title = '重新打包（' + $item.iChannelName + '）'
          this.anewPackageFormData = {
            iPlanChannelId: $item.iPlanChannelId,
            advChannelArrayIds: [],
            cpsChannelArrayIds: [],
            channelIds: '',
            sDesc: ''
          }
        } else {
          const title = '提示（' + $item.iChannelName + '）'
          this.$confirm('是否确定重新打包?', title, {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            // 重新打包请求
            planApi.againPackGamePackage($item.iPlanChannelId, 2, $item.cStatus).then((data) => {
              if (data.code === 1) {
                this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                  confirmButtonText: '确定'
                })
                this.searchDataList()
              } else if (data.code === 1100) {
                this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
                  confirmButtonText: '确定'
                })
              } else {
                this.$alert(data.msg, '操作失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert('请求失败，请稍后重试！', '提示', {
                confirmButtonText: '确定'
              })
            })
          }).catch(() => {
          })
        }
      },
      channelPassCallback (explainData) {
        const params = {
          iPlanChannelId: this.planChannelInfo.iPlanChannelId,
          channelAppUrl: explainData.reason
        }
        planApi.addChannelPassUrl(params).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
            this.submitExplainDialogSet.dialogFormVisible = false
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 下载渠道整包
      channelDownloadAddress ($index, $item, $data) {
        this.optionDownFileItem.downLoadPath = $item.cUrl
        if ($item.cUrl) {
          this.optionDownFileDialog.dialogVisible = true
          this.optionDownFileDialog.dialogCurrentTitle = $item.iChannelName
        } else {
          this.$alert('暂无上传的游戏包', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      // 查看原因
      viewReason ($index, $item, $data) {
        planApi.getRejectReason($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.viewRejectReasonContent = {
              userName: data.data.userName,
              bugUrl: $item.bugUrl,
              sDesc: data.data.sDesc
            }
            this.viewRejectReasonDialogSet.dialogFormVisible = true
            this.viewRejectReasonDialogSet.dialogCurrentTitle = $item.iChannelName
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      revocationReject ($index, $item, $data) {
        const title = '提示（' + $item.iChannelName + '）'
        this.$confirm('是否确定执行撤销操作?', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.putPlanRevocationReject($item.iPlanChannelId, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      //  送检次数
      checkTimeDialogShow ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.checkTimeDialogSet.dialogFormVisible = true
        this.checkTimeDialogSet.dialogCurrentTitle = $item.iChannelName
      },
      buglyDownload ($index, $item, $data) {
        window.location.href = $item.buglyUrl
      },
      buglyUpload ($index, $item, $data) {
        packToolApi.addBuglySymbol($item.iGamePackId).then((data) => {
          if (data.code === 1) {
            this.$alert('bugly上传操作完成', '操作成功', {
              confirmButtonText: '确定'
            })
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          console.log(error)
          this.$alert('数据操作失败，请稍后重试', '友情提醒', {
            confirmButtonText: '确定'
          })
        })
      },
      openEjectReview ($index, $item, $data) {
        const title = '开启审核服（' + $item.iChannelName + '）'
        this.$confirm('您确定为当前渠道开启审核服？', title, {
          confirmButtonText: '确认',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.putOpenEjectReview($item.iPlanChannelId).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      workOrderOpenFun ($index, $item, $data) {
        const title = '走工单开启（' + $item.iChannelName + '）'
        this.$confirm('系统自动开启审核服失败，请在OA流程走工单人工在gois系统开启审核服状态！', title, {
          confirmButtonText: '确认已开启',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.putWorkOrderOption($item.iPlanChannelId, 1).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      workOrderCloseFun ($index, $item, $data) {
        const title = '走工单关闭（' + $item.iChannelName + '）'
        this.$confirm('系统自动关闭审核服失败，请在OA流程走工单人工在gois系统关闭审核服状态！', title, {
          confirmButtonText: '确认已关闭',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.putWorkOrderOption($item.iPlanChannelId, 0).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      planChannelSummaryFun ($index, $item, $data) {
        this.$router.push({path: '/home/plan/channel/summary', query: {iPlanId: this.$route.query.iPlanId}})
      },
      getStatusCharacter (status) {
        return planUtil.getPlanStatus(status, 2)
      },
      getReviewFlagName (flag) {
        let reviewFlagName = '开启成功'
        switch (parseInt(flag)) {
          case 0:
            reviewFlagName = '开启失败'
            break
          case 1:
            reviewFlagName = '开启成功'
            break
          case 2:
            reviewFlagName = '关闭失败'
            break
          case 3:
            reviewFlagName = '关闭成功'
            break
          case 4:
            reviewFlagName = '关闭中'
            break
          case 5:
            reviewFlagName = '开启中'
            break
        }
        return reviewFlagName
      }
    }
  }
</script>
