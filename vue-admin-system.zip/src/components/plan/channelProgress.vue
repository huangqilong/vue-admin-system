<style>
  .test-game-upload{
    line-height: 40px;
    font-size: 14px;
    color: #666;
  }
  .test-upload-demo .el-button{
    width: 200px;
  }
  .test-upload-demo .el-upload,.test-upload-demo .el-upload-list{
    float: left;
  }
  .test-upload-demo .el-upload-list .el-upload-list__item:first-child{
    margin-top: 6px;
  }
  .test-upload-demo .el-upload-list .el-upload-list__item .el-upload-list__item-status-label{
    top: 4px;
    display: none;
  }
  .test-upload-demo .el-upload-list .el-upload-list__item .el-icon-close{
    top: 9px;
    display: none;
  }
  .doc-url-a{
    text-decoration: underline;
    color: #20a0ff;
  }
</style>
<template>
  <div>
    <el-form ref="gameInfoForm" label-width="0" v-if="roleAuthority.sdkTestAssets">
      <el-form-item label="">
        <el-button size="small" type="success" style="width: 300px;letter-spacing: 5px;" @click="sdkTestAssets()">上传SDK测试资源</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="dataList" stripe>
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="iChannelName" label="渠道名称" >
        <template scope="scope">
          <span v-if="!(roleAuthority.planChannelSummary && scope.row.iChannelName)">{{scope.row.iChannelName ? scope.row.iChannelName : '--'}}</span>
          <a v-if="roleAuthority.planChannelSummary && scope.row.iChannelName" @click="planChannelSummaryFun(scope.$index,scope.row,dataList)">{{scope.row.iChannelName}}</a>
        </template>
      </el-table-column>
      <el-table-column prop="iFirstUse" label="是否首次接入">
        <template scope="scope">
          {{scope.row.cStatus == '1' || scope.row.cStatus == '0' ? '--' : scope.row.iFirstUse == 0 ? '否' : '是'}}
        </template>
      </el-table-column>
      <el-table-column prop="iNeedUpdate" label="是否需要更新" >
        <template scope="scope">
          {{scope.row.cStatus == '1' ? '--' : scope.row.iNeedUpdate == 0 ? '否':'是'}}
        </template>
      </el-table-column>
      <el-table-column prop="iPriority" label="是否优先接入" >
        <template scope="scope">
          <span :style="scope.row.iPriority ? 'color: #0190fe;' : ''">{{scope.row.iPriority ? '优先接入' : '--'}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="iChannelVersion" label="接入版本" >
        <template scope="scope">
          <div v-if="scope.row.docUrl && scope.row.iChannelVersion &&　scope.row.cStatus != 0">
            <a class="doc-url-a" :href="scope.row.docUrl" target="_blank">{{scope.row.iChannelVersion}}</a>
          </div>
          <div v-else>
            {{scope.row.iChannelVersion &&　scope.row.cStatus != 0 ? scope.row.iChannelVersion : '--'}}
          </div>
        </template>
      </el-table-column>
      <el-table-column label="渠道状态" prop="cStatus">
        <template scope="scope">
          <span v-html="getStatusCharacter(scope.row.cStatus)"></span>
        </template>
      </el-table-column>
      <el-table-column prop="userName" label="处理人">
        <template scope="scope">
          <span :style="scope.row.userName=='系统'?'color: #aaa;':''">{{scope.row.cStatus !=0 && scope.row.cStatus !=5 && scope.row.userName　? scope.row.userName : '--'}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="packNum" label="送检次数" sortable>
        <template scope="scope">
          <a v-if="scope.row.packNum>0" @click="checkTimeDialogShow(scope.$index,scope.row,dataList)">{{scope.row.packNum}}</a>
          <span v-if="scope.row.packNum<=0">{{scope.row.packNum}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="dPackEnd" label="打包时间" min-width="150" sortable>
        <template scope="scope">
          {{scope.row.cStatus !='0' &&　scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10' && scope.row.cStatus != '15' && scope.row.dPackEnd　? scope.row.dPackEnd : '--'}}
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="450" v-if="planInfo.cPlanStatus!=planStatusList[1].iDicId">
        <template scope="scope">
          <el-button type="text" class="table-option-button" @click="channelCheck(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelCheckBtn && scope.row.cStatus == '1'">渠道检测</el-button>
          <el-button type="text" class="table-option-button" @click="checkExplain(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelCheckExplain && scope.row.cStatus == '0'">检测说明</el-button>
          <el-button type="text" class="table-option-button" @click="joinUpCompleteFun(scope.$index,scope.row,dataList)" v-if="roleAuthority.joinUpComplete && scope.row.cStatus == '0'">接入完成</el-button>
          <el-button type="text" class="table-option-button" @click="sdkTestPackFun(scope.$index,scope.row,dataList)" v-if="roleAuthority.clickPack && scope.row.cStatus == '5'">打SDK测试包</el-button>
          <el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.configDetails && scope.row.cStatus != '0' && scope.row.cStatus != '1' && scope.row.cStatus != '5' && scope.row.cStatus != '31'">配置详情</el-button>
          <el-popover :title="'打包服务器（' + scope.row.iChannelName+ '）'" trigger="click" @show="packResultDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button"
                       v-if="roleAuthority.checkLog && scope.row.cStatus != '0' && scope.row.cStatus != '1' && scope.row.cStatus != '5'  && scope.row.cStatus != '31'">日志</el-button>
          </el-popover>
          <el-button type="text" class="table-option-button" @click="anewPack(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.againPack && (scope.row.cStatus == '15' || scope.row.cStatus == '20' || scope.row.cStatus == '26')">重新打包</el-button>
          <el-button type="text" class="table-option-button"  @click="lineAnewPack(scope.$index,scope.row,dataList)"  v-if="roleAuthority.lineAgainPack && scope.row.cStatus == '6'">重新打包</el-button>
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoad && (( roleName.indexOf('质检')==-1 && scope.row.cStatus == '20') || scope.row.cStatus == '25'|| scope.row.cStatus == '26' || scope.row.cStatus == '30')">下载</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.buglyConfig&&planInfo.iPlatformName=='IOS'&& (scope.row.cStatus == '20' || scope.row.cStatus == '25'|| scope.row.cStatus == '26' || scope.row.cStatus == '30')">bugly下载</el-button>
          <el-button type="text" class="table-option-button" @click="commitQA(scope.$index,scope.row,dataList)" v-if="roleAuthority.commitQA && scope.row.cStatus == '20'">提交质检</el-button>
          <el-button type="text" class="table-option-button" @click="checkPass(scope.$index,scope.row,dataList)" v-if="roleAuthority.QAPass && scope.row.cStatus == '25'">通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.rejectBtn && scope.row.cStatus == '25'">驳回</el-button>
          <el-button type="text" class="table-option-button" @click="anewJoinUpDialogShow(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.againJoinUp && (scope.row.cStatus == '15' || scope.row.cStatus == '20' || scope.row.cStatus == '26' || scope.row.cStatus == '30' || scope.row.cStatus == '31')">重新接入</el-button>
          <el-button type="text" class="table-option-button" @click="viewReason(scope.$index,scope.row,dataList)" v-if="roleAuthority.checkCause && scope.row.cStatus == '26'">查看原因</el-button>
          <el-button type="text" class="table-option-button" @click="revocationReject(scope.$index,scope.row,dataList)" v-if="roleAuthority.revocationRejectBtn && scope.row.cStatus == '26'">撤销</el-button>
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="250" v-if="planInfo.cPlanStatus==planStatusList[1].iDicId">
        <template scope="scope">
          <el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList)"
                     v-if="scope.row.cStatus != '0' && scope.row.cStatus != '1' && scope.row.cStatus != '5' && scope.row.cStatus != '31'">配置详情</el-button>
          <el-popover :title="'打包服务器（' + scope.row.iChannelName+ '）'" trigger="click" @show="packResultDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button"
                       v-if="scope.row.cStatus != '0' && scope.row.cStatus != '1' && scope.row.cStatus != '5'  && scope.row.cStatus != '31'">日志</el-button>
          </el-popover>
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="scope.row.cStatus == '20' || scope.row.cStatus == '25'|| scope.row.cStatus == '26' || scope.row.cStatus == '30'">下载</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="planInfo.iPlatformName=='IOS'&& (scope.row.cStatus == '20' || scope.row.cStatus == '25'|| scope.row.cStatus == '26' || scope.row.cStatus == '30')">bugly下载</el-button>
        </template>
      </el-table-column>
    </el-table>
    <planPackConfigDialog v-if="showPackConfigDataDialogSet.dialogFormVisible" :optionData="showPackConfigDataDialogSet"></planPackConfigDialog>
    <anewJoinUpDialog  v-if="anewJoinUpDialogSet.dialogFormVisible" :optionData="anewJoinUpDialogSet"  :dataInfoForm="anewJoinUpFormData" :optionCallBack="searchDataList"></anewJoinUpDialog>
    <downFileDialog v-if="optionDownFileDialog.dialogVisible" :optionData="optionDownFileDialog" :dataParams="optionDownFileItem"></downFileDialog>
    <down-file-dialog-v1 v-if="optionDownFileDialogV1.dialogVisible" :optionData="optionDownFileDialogV1" :dataParams="optionDownFileItemV1"></down-file-dialog-v1>
    <checkTimeDialog  v-if="checkTimeDialogSet.dialogFormVisible" :optionData="checkTimeDialogSet"  ></checkTimeDialog>
    <viewReasonDialog v-if="viewRejectReasonDialogSet.dialogFormVisible" :optionData="viewRejectReasonDialogSet" :dataInfoForm="viewRejectReasonContent"></viewReasonDialog>
    <submit-explain-dialog v-if="submitExplainDialogSet.dialogFormVisible" :optionData="submitExplainDialogSet"></submit-explain-dialog>
    <channel-check-dialog v-if="channelCheckDialogSet.dialogFormVisible" :optionData="channelCheckDialogSet" :dataInfoForm="channelCheckFormInfo" :optionCallBack="searchDataList"></channel-check-dialog>
    <sdk-test-assets-upload-dialog v-if="sdkTestAssetsUpload.dialogFormVisible" :optionData="sdkTestAssetsUpload"></sdk-test-assets-upload-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planUtil from '../../utils/plan-util'
  import planApi from '../../apis/plan-api'
  import sdkTestAssetsUploadDialog from './sdkTestAssetsUploadDialog'
  import planPackConfigDialog from '../../components/plan/planPackConfigDialog'
  import anewJoinUpDialog from '../../components/plan/anewJoinUpDialog'
  import downFileDialog from '../../components/pack/downFileDialog'
  import downFileDialogV1 from '../../components/plan/downFileDialogV1'
  import checkTimeDialog from '../../components/plan/checkTimeDialog'
  import viewReasonDialog from './viewRejectReasonDialog'
  import submitExplainDialog from '../../components/plan/submitExplainDialog'
  import channelCheckDialog from '../../components/plan/channelCheckDialog'
  export default{
    components: {
      planPackConfigDialog,
      anewJoinUpDialog,
      downFileDialog,
      downFileDialogV1,
      checkTimeDialog,
      viewReasonDialog,
      submitExplainDialog,
      channelCheckDialog,
      sdkTestAssetsUploadDialog
    },
    props: [],
    data () {
      return {
        dataList: [],
        anewJoinUpDialogSet: {
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        showPackConfigDataDialogSet: {
          iGamePackId: '',
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        optionDownFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileDialogV1: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileItem: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        optionDownFileItemV1: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        anewJoinUpFormData: null,
        packServerList: [],
        checkTimeDialogSet: {
          type: '送检',
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        viewRejectReasonDialogSet: {
          dialogFormVisible: false,
          dialogFlag: 'channel',
          dialogCurrentTitle: ''
        },
        viewRejectReasonContent: {
          userName: '',
          bugUrl: '',
          sDesc: ''
        },
        submitExplainDialogSet: {
          dialogFormVisible: false,
          type: '',
          title: '',
          isNeedProblemAttribution: false,
          formData: [],
          submitCallbackFun: null
        },
        channelCheckDialogSet: {
          dialogFormVisible: false,
          currentStatus: '',
          dialogCurrentTitle: ''
        },
        channelCheckFormInfo: {
          isCheck: '0',
          reason: '',
          iPlanChannelId: ''
        },
        sdkTestAssetsUpload: {
          dialogFormVisible: false
        }
      }
    },
    computed: {
      ...mapGetters([
        'userId', 'planInfo', 'planProgressSelectedTab', 'roleAuthority', 'planChannelInfo', 'planStatusList', 'roleName'
      ])
    },
    created: function () {
      if (this.planProgressSelectedTab === '0') {
        this.searchDataList()
      }
    },
    watch: {
      planProgressSelectedTab: function (newVal) {
        if (newVal === '0') {
          this.searchDataList()
        }
      }
    },
    methods: {
      sdkTestAssets () {
        this.sdkTestAssetsUpload.dialogFormVisible = true
      },
      orderDataList (data) {
        let backData = []
        let backData2 = []
        let backData3 = []
        let backData4 = []
        let backData5 = []
        let backData6 = []
        this.dataList = []
        for (let item of data) {
          if (item.cStatus === '26') {
            backData.unshift(item)
          } else if (item.cStatus === '15') {
            backData.push(item)
          } else if (item.cStatus === '1') {
            backData2.unshift(item)
          } else if (item.cStatus === '0') {
            backData2.push(item)
          } else if (item.cStatus === '5') {
            backData3.unshift(item)
          } else if (item.cStatus === '20') {
            backData3.push(item)
          } else if (item.cStatus === '25') {
            backData4.unshift(item)
          } else if (item.cStatus === '6') {
            backData4.push(item)
          } else if (item.cStatus === '10') {
            backData5.unshift(item)
          } else if (item.cStatus === '30') {
            backData5.push(item)
          } else {
            backData6.push(item)
          }
        }
        this.dataList = backData.concat(backData2).concat(backData3).concat(backData4).concat(backData5).concat(backData6)
      },
      searchDataList () {
        const _this = this
        const id = this.planInfo.iPlanId
        const packType = 0
        planApi.getPackageProgressDataList(id, packType).then((data) => {
          if (data.code === 1) {
            _this.orderDataList(data.data)
//            _this.dataList = data.data
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.dataList = null
        })
      },
      // 打SDK测试包、通过，切至下一个状态
      nextStatus (planInfo, type) {
        planApi.updateDataStatus(planInfo.iPlanChannelId, 1, planInfo.cStatus).then((data) => {
          if (data.code === 1) {
            if (type === 'sdkPack') {
              this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                confirmButtonText: '确定'
              })
            }
            this.searchDataList()
          } else if (data.code === 1100) {
            this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
              confirmButtonText: '确定'
            })
          } else if (data.code === 1052) {
            this.$alert('请配置游戏资源后再打包!', '提示', {
              confirmButtonText: '确定'
            })
          } else if (data.code === 1053) {
            this.$alert('请刷新页面', '提示', {
              confirmButtonText: '确定'
            })
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 渠道检测
      channelCheck ($index, $item, $data) {
        this.channelCheckDialogSet.dialogFormVisible = true
        this.channelCheckDialogSet.currentStatus = $item.cStatus
        this.channelCheckDialogSet.dialogCurrentTitle = $item.iChannelName
        this.channelCheckFormInfo = {
          isCheck: '0',
          iPlanChannelId: $item.iPlanChannelId,
          reason: '无'
        }
      },
      // 接入完成
      joinUpCompleteFun ($index, $item, $data) {
        const _this = this
        const title = '提示（' + $item.iChannelName + '）'
        this.$confirm('是否确定渠道已接入完成', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.channelJoinUpComplete($item.cStatus, $item.iPlanChannelId).then((data) => {
            if (data.code === 1) {
              _this.searchDataList()
            } else {
              this.$alert(data.msg, '提示', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 打SDK测试包
      sdkTestPackFun ($index, $item, $data) {
        const title = '提示（' + $item.iChannelName + '）'
        this.$confirm('是否确定打SDK测试包', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.nextStatus($item, 'sdkPack')
        }).catch(() => {
        })
      },
      //  查看配置详情
      showPackConfig ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.showPackConfigDataDialogSet.iGamePackId = $item.iGamePackId
        this.showPackConfigDataDialogSet.dialogCurrentTitle = $item.iChannelName
        this.showPackConfigDataDialogSet.dialogFormVisible = true
      },
      // 日志下载
      packResultDialogShow ($index, $item, $data) {
        this.packServerList = []
        planApi.gamePackServerLogs({taskId: $item.iGamePackId}).then((data) => {
          if (data.code === 1) {
            this.packServerList = data.data.list
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 重新打包
      anewPack ($index, $item, $data) {
        const title = '提示（' + $item.iChannelName + '）'
        this.$confirm('是否确定重新打包', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 发送打包请求
          planApi.againPackGamePackage($item.iPlanChannelId, 0, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                confirmButtonText: '确定'
              })
              this.searchDataList()
            } else if (data.code === 1100) {
              this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
                confirmButtonText: '确定'
              })
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 排队中的重新打包
      lineAnewPack ($index, $item, $data) {
        const title = '提示（' + $item.iChannelName + '）'
        this.$confirm('是否确定重新打包', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 重新打包请求
          planApi.lineAgainPackGamePackage($item.iPlanChannelId, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                confirmButtonText: '确定'
              })
              this.searchDataList()
            } else if (data.code === 1100) {
              this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
                confirmButtonText: '确定'
              })
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 游戏下载
      downloadPackage ($index, $item, $data) {
        let downLoadStatus = ['20', '25', '26', '30']
        planApi.getPackRecordInfo($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            if ($item.appstore) {
              this.optionDownFileItemV1.isChannelDownload = false
              this.optionDownFileItemV1.downLoadPath = data.data.cUrl
              this.optionDownFileItemV1.resourceName = data.data.resourceName || ''
              this.optionDownFileItemV1.appstoreName = data.data.appstoreName || ''
              if (downLoadStatus.indexOf(data.data.cStatus) >= 0 && data.data.cUrl) {
                this.optionDownFileDialogV1.dialogCurrentTitle = $item.iChannelName
                this.optionDownFileDialogV1.dialogVisible = true
              } else {
                this.$alert('暂无下载的游戏包', '提示', {
                  confirmButtonText: '确定'
                })
              }
            } else {
              this.optionDownFileItem.isChannelDownload = false
              this.optionDownFileItem.downLoadPath = data.data.cUrl
              this.optionDownFileItem.resourceName = data.data.resourceName || ''
              this.optionDownFileItem.appstoreName = data.data.appstoreName || ''
              if (downLoadStatus.indexOf(data.data.cStatus) >= 0 && data.data.cUrl) {
                this.optionDownFileDialog.dialogCurrentTitle = $item.iChannelName
                this.optionDownFileDialog.dialogVisible = true
              } else {
                this.$alert('暂无下载的游戏包', '提示', {
                  confirmButtonText: '确定'
                })
              }
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
          this.searchDataList()
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
          this.searchDataList()
        })
      },
      buglyDownload ($index, $item, $data) {
        window.location.href = $item.buglyUrl
      },
      // 提交质检
      commitQA ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '提交质检'
        this.submitExplainDialogSet.title = '提交说明（' + $item.iChannelName + '）'
        if ($item.packNum > 0) {
          this.submitExplainDialogSet.isNeedProblemAttribution = true
        } else {
          this.submitExplainDialogSet.isNeedProblemAttribution = false
        }
        this.submitExplainDialogSet.formData = [
          {
            label: '打包人员：',
            isText: true,
            value: $item.userName
          },
          {
            label: '渠道名称：',
            isText: true,
            value: $item.iChannelName
          }
        ]
        if ($item.iUserId !== this.userId) {
          this.submitExplainDialogSet.formData.push(
            {
              label: '操作提醒：',
              isText: true,
              value: '<span style="color:red;">提交质检人员与打包人员不一致</span>'
            }
          )
        }
        this.submitExplainDialogSet.formData.push(
          {
            label: '更新说明：',
            isText: false,
            value: '',
            placeholderText: '提示：提交质检时，请输入修复bugid以及简单说明！'
          }
        )
        this.submitExplainDialogSet.submitCallbackFun = this.commitQACallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      // 提交质检回调提交
      commitQACallback (explainData) {
        this.submitExplainDialogSet.dialogFormVisible = false
        let params = {
          channelIds: '',
          iPlanChannelId: this.planChannelInfo.iPlanChannelId,
          iProblemType: explainData.iProblemType,
          sDesc: explainData.reason
        }
        planApi.commitQualityTest(this.planChannelInfo.cStatus, this.planChannelInfo.iPlanChannelId, params).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 通过
      checkPass ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '质检通过'
        this.submitExplainDialogSet.title = '质检通过（' + $item.iChannelName + '）'
        this.submitExplainDialogSet.isNeedProblemAttribution = false
        this.submitExplainDialogSet.formData = [
          {
            label: '送检人员：',
            isText: true,
            value: $item.userName
          },
          {
            label: '送检渠道：',
            isText: true,
            value: $item.iChannelName
          },
          {
            label: '',
            isText: true,
            value: '<span style="color:#c29068;font-size:16px;margin-left:30%;">是否确认质检通过？</span>'
          }
        ]
        this.submitExplainDialogSet.submitCallbackFun = this.checkPassCallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      checkPassCallback () {
        this.submitExplainDialogSet.dialogFormVisible = false
        this.nextStatus(this.planChannelInfo)
      },
      // 驳回
      rejectDialogShow ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '质检驳回'
        this.submitExplainDialogSet.title = '质检驳回（' + $item.iChannelName + '）'
        this.submitExplainDialogSet.isNeedProblemAttribution = true
        this.submitExplainDialogSet.formData = [
          {
            label: '送检人员：',
            isText: true,
            value: $item.userName
          },
          {
            label: '送检渠道：',
            isText: true,
            value: $item.iChannelName
          },
          {
            label: '驳回理由：',
            isText: false,
            value: '',
            placeholderText: '提示：驳回时，请输入bugid及简单问题描述！'
          }
        ]
        this.submitExplainDialogSet.submitCallbackFun = this.rejectCallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      rejectCallback (explainData) {
        this.submitExplainDialogSet.dialogFormVisible = false
        let params = {
          channelIds: '',
          iPlanChannelId: this.planChannelInfo.iPlanChannelId,
          iProblemType: explainData.iProblemType,
          sDesc: explainData.reason
        }
        planApi.rejectPlanReason(this.planChannelInfo.iPlanChannelId, 0, params, this.planChannelInfo.cStatus).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 重新接入渠道
      anewJoinUpDialogShow ($index, $item, $data) {
        if ($item.cStatus === '30' || $item.cStatus === '31') {
          this.anewJoinUpDialogSet.dialogFormVisible = true
          this.anewJoinUpDialogSet.dialogCurrentTitle = $item.iChannelName
          this.$store.dispatch('planChannelInfo', $item)
          this.anewJoinUpFormData = {
            iPlanChannelId: $item.iPlanChannelId,
            advChannelArrayIds: [],
            cpsChannelArrayIds: [],
            channelIds: '',
            sDesc: ''
          }
        } else {
          this.$confirm('是否确定重新接入该渠道', '提示（' + $item.iChannelName + '）', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            planApi.justAgainJoinUpPackage($item.cStatus, $item.iPlanChannelId).then((data) => {
              if (data.code === 1) {
                this.searchDataList()
              } else {
                this.$alert(data.msg, '操作失败', {
                  confirmButtonText: '确定'
                })
              }
            })
          }).catch(() => {
          })
        }
      },
      revocationReject ($index, $item, $data) {
        const title = '提示（' + $item.iChannelName + '）'
        this.$confirm('是否确定执行撤销操作?', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.putPlanRevocationReject($item.iPlanChannelId, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 查看原因
      viewReason ($index, $item, $data) {
        planApi.getRejectReason($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.viewRejectReasonContent = {
              userName: data.data.userName,
              bugUrl: $item.bugUrl,
              sDesc: data.data.sDesc
            }
            this.viewRejectReasonDialogSet.dialogFormVisible = true
            this.viewRejectReasonDialogSet.dialogCurrentTitle = $item.iChannelName
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 检测说明
      checkExplain ($index, $item, $data) {
        planApi.channelCheckExplain($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.$alert(data.data.sDesc, '检测说明（' + $item.iChannelName + '）', {
              confirmButtonText: '关闭'
            })
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      //  送检次数
      checkTimeDialogShow ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.checkTimeDialogSet.dialogFormVisible = true
        this.checkTimeDialogSet.dialogCurrentTitle = $item.iChannelName
      },
      planChannelSummaryFun ($index, $item, $data) {
        this.$router.push({path: '/home/plan/channel/summary', query: {iPlanId: this.$route.query.iPlanId}})
      },
      getStatusCharacter (status) {
        return planUtil.getPlanStatus(status, 0)
      }
    }
  }
</script>
