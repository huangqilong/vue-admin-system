<style scoped>
  .warning-text{
    margin-bottom: 10px;
    color: #008000;
    letter-spacing: 1px;
  }
</style>
<template>
  <div>
    <div class="warning-text" v-if="planProgressTabStatus.packPlanNoticeVO && planProgressTabStatus.packPlanNoticeVO.adNotice">
      <i class="el-icon-warning"></i>&nbsp;&nbsp;温馨提示：{{planProgressTabStatus.packPlanNoticeVO.adNotice}}
    </div>
    <el-table :data="dataList" stripe>
      <el-table-column type="index" label="序号" width="50"></el-table-column>
      <el-table-column prop="cAdcpsCode" label="广告码" ></el-table-column>
      <el-table-column prop="sDemo" label="备注" ></el-table-column>
      <el-table-column  label="广告插件" >
        <template scope="scope">
          {{scope.row.cAdPluginIds ? getPluginInfo(scope.row.cAdPluginIds, scope.row.cAdPluginConfigIds).join(',') : '--'}}
        </template>
      </el-table-column>
      <el-table-column prop="cStatus" label="状态">
        <template scope="scope">
          <span v-html="getStatusCharacter(scope.row.cStatus)"></span>
        </template>
      </el-table-column>
      <el-table-column prop="cRealName" label="处理人">
        <template scope="scope">
          <span :style="scope.row.cRealName=='系统'?'color: #aaa;':''">{{scope.row.cStatus !=0 && scope.row.cRealName　? scope.row.cRealName : '--'}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="dPackEnd" label="打包时间">
        <template scope="scope">
          {{scope.row.cStatus !='0' && scope.row.cStatus != '6' && scope.row.cStatus != '10' && scope.row.dPackEnd　? scope.row.dPackEnd : '--'}}
        </template>
      </el-table-column>
      <el-table-column prop="cdnStatus" label="CDN状态" v-if="planInfo.gameCdnFlag == 1">
        <template scope="scope">
          <span v-if="scope.row.cdnStatus == 0">{{planInfo.cdnFlag == 1? '运营已开启cdn': '运营未开启cdn'}}</span>
          <span v-if="scope.row.cdnStatus != 0" :style="scope.row.cdnStatus == 1?'color: #ef5350':(scope.row.cdnStatus == 2?'color: #13ce66':'')">{{getCdnStatusValue(scope.row.cdnStatus)}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="cdnUploadNum" label="CDN自动上传次数" v-if="false && planInfo.gameCdnFlag == 1">
        <template scope="scope">
          <a @click="showCDNUploadDataList(scope.$index,scope.row,dataList)" v-if="scope.row.cdnUploadNum>0">{{scope.row.cdnUploadNum}}</a>
          <span v-if="scope.row.cdnUploadNum<=0">0</span>
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="400" v-if="planInfo.cPlanStatus!=planStatusList[1].iDicId && planInfo.gameCdnFlag == 1">
        <template scope="scope">
          <!--<el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList)" v-if="roleAuthority.configDetails && scope.row.cStatus != '0'">配置详情</el-button>-->
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoad && scope.row.cStatus != '0' && scope.row.cStatus != '6' && scope.row.cStatus != '10' && scope.row.cdnStatus != 5">下载</el-button>
          <el-button type="text" class="table-option-button" @click="checkPass(scope.$index,scope.row,dataList)" v-if="roleAuthority.QAPass && scope.row.cStatus == '15'">通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.rejectBtn && scope.row.cStatus == '15'">驳回</el-button>
          <el-button type="text" class="table-option-button" @click="viewReason(scope.$index,scope.row,dataList)" v-if="roleAuthority.checkCause && (scope.row.cStatus == '20' || scope.row.cStatus == '40')">查看原因</el-button>
          <el-button type="text" class="table-option-button" @click="channelSendCheck(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.channelSendCheck && scope.row.cStatus == '25' && planInfo.cdnFlag == 1 && scope.row.cdnStatus == 2">渠道送审</el-button>
          <el-button type="text" class="table-option-button" @click="channelPass(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelPass && scope.row.cStatus == '30'">渠道通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelReject && scope.row.cStatus == '30'">渠道驳回</el-button>
          <!--<el-button type="text" class="table-option-button" @click="enterChannelAddress(scope.$index,scope.row,dataList)"-->
                     <!--v-if="roleAuthority.enterChannelUrl && scope.row.cStatus == '35' && scope.row.cdnStatus != 5">录入渠道地址</el-button>-->
          <!--<el-button type="text" class="table-option-button" @click="channelDownloadPackage(scope.$index,scope.row,dataList)"-->
                     <!--v-if="roleAuthority.channelDownloadUrl && scope.row.cStatus == '35' && scope.row.cdnStatus != 5 && scope.row.channelAppUrl">渠道下载地址</el-button>-->
          <el-button type="text" class="table-option-button" @click="cdnManualUploadFun(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.cdnManualUpload && planInfo.cdnFlag == 1 && scope.row.cdnStatus == 1 && scope.row.cStatus == '25'">手动上传</el-button>
          <el-button type="text" class="table-option-button" @click="cdnDownloadUrlFun(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.cdnDownloadUrl && planInfo.cdnFlag == 1 && scope.row.cdnStatus == 2 && (scope.row.cStatus == '25' || scope.row.cStatus == '30' || scope.row.cStatus == '35' || scope.row.cStatus == '40')">CDN地址下载</el-button>
          <span v-if="scope.row.cStatus == '0' || scope.row.cdnStatus == 5">--</span>
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="400" v-if="planInfo.cPlanStatus!=planStatusList[1].iDicId && planInfo.gameCdnFlag != 1">
        <template scope="scope">
          <!--<el-button type="text" class="table-option-button" @click="showPackConfig(scope.$index,scope.row,dataList)" v-if="roleAuthority.configDetails && scope.row.cStatus != '0'">配置详情</el-button>-->
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoad && scope.row.cStatus != '0' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">下载</el-button>
          <el-button type="text" class="table-option-button" @click="checkPass(scope.$index,scope.row,dataList)" v-if="roleAuthority.QAPass && scope.row.cStatus == '15'">通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.rejectBtn && scope.row.cStatus == '15'">驳回</el-button>
          <el-button type="text" class="table-option-button" @click="viewReason(scope.$index,scope.row,dataList)" v-if="roleAuthority.checkCause && (scope.row.cStatus == '20' || scope.row.cStatus == '40')">查看原因</el-button>
          <el-button type="text" class="table-option-button" @click="channelSendCheck(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelSendCheck && scope.row.cStatus == '25'">渠道送审</el-button>
          <el-button type="text" class="table-option-button" @click="channelPass(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelPass && scope.row.cStatus == '30'">渠道通过</el-button>
          <el-button type="text" class="table-option-button" @click="rejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelReject && scope.row.cStatus == '30'">渠道驳回</el-button>
          <!--<el-button type="text" class="table-option-button" @click="enterChannelAddress(scope.$index,scope.row,dataList)" v-if="roleAuthority.enterChannelUrl && scope.row.cStatus == '35'">录入渠道地址</el-button>-->
          <!--<el-button type="text" class="table-option-button" @click="channelDownloadPackage(scope.$index,scope.row,dataList)" v-if="roleAuthority.channelDownloadUrl && scope.row.cStatus == '35' && scope.row.channelAppUrl">渠道下载地址</el-button>-->
          <span v-if="scope.row.cStatus == '0'">--</span>
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="250" v-if="planInfo.cPlanStatus==planStatusList[1].iDicId">
        <template scope="scope">
          <el-button type="text" class="table-option-button" @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="scope.row.cStatus != '0' && scope.row.cStatus != '6' && scope.row.cStatus != '10'">下载</el-button>
          <!--<el-button type="text" class="table-option-button" @click="channelDownloadPackage(scope.$index,scope.row,dataList)" v-if="planInfo.gameCdnFlag != 1 && scope.row.cStatus == '35'">渠道下载地址</el-button>-->
          <el-button type="text" class="table-option-button" @click="cdnDownloadUrlFun(scope.$index,scope.row,dataList)"
                     v-if="planInfo.gameCdnFlag == 1 && planInfo.cdnFlag == 1 && (scope.row.cStatus == '25' || scope.row.cStatus == '30' || scope.row.cStatus == '35' || scope.row.cStatus == '40')">CDN地址下载</el-button>
        </template>
      </el-table-column>
    </el-table>
    <planPackConfigDialog v-if="showPackConfigDataDialogSet.dialogFormVisible" :optionData="showPackConfigDataDialogSet"></planPackConfigDialog>
    <downFileDialog v-if="optionDownFileDialog.dialogVisible" :optionData="optionDownFileDialog" :dataParams="optionDownFileItem"></downFileDialog>
    <down-cdn-file-dialog v-if="optionDownCdnFileDialog.dialogVisible" :optionData="optionDownCdnFileDialog" :dataParams="optionDownFileItem"></down-cdn-file-dialog>
    <plan-down-file-dialog v-if="optionPlanDownFileDialog.dialogVisible" :optionData="optionPlanDownFileDialog" :dataParams="optionDownFileItem"></plan-down-file-dialog>
    <rejectDialog  v-if="rejectDialogSet.dialogFormVisible" :optionData="rejectDialogSet"  :dataInfoForm="rejectReasonContent" :optionCallBack="searchDataList"></rejectDialog>
    <addChannelUrlDialog v-if="addChannelUrlDialogSet.dialogFormVisible" :optionData="addChannelUrlDialogSet"  :dataInfoForm="addChannelUrlContent" :optionCallBack="searchDataList"></addChannelUrlDialog>
    <viewReasonDialog v-if="viewRejectReasonDialogSet.dialogFormVisible" :optionData="viewRejectReasonDialogSet" :dataInfoForm="viewRejectReasonContent"></viewReasonDialog>
    <cdn-manual-upload-dialog v-if="cdnManualUploadDataDialog.dialogFormVisible" :optionData="cdnManualUploadDataDialog" :optionCallBack="searchDataList"></cdn-manual-upload-dialog>
    <show-data-info-dialog v-if="showInfoDataDialog.dialogShowVisible" :optionData="showInfoDataDialog"></show-data-info-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planUtil from '../../utils/plan-util'
  import planApi from '../../apis/plan-api'
  import pluginApi from '../../apis/plugin-api'
  import planPackConfigDialog from '../../components/plan/planPackConfigDialog'
  import downFileDialog from '../../components/pack/downFileDialog'
  import downCdnFileDialog from '../../components/plan/downCdnFileDialog'
  import planDownFileDialog from '../../components/plan/downFileDialog'
  import rejectDialog from '../../components/plan/rejectDialog'
  import addChannelUrlDialog from '../../components/plan/addChannelUrlDialog'
  import cdnManualUploadDialog from '../../components/plan/cdnManualUploadDialog'
  import showDataInfoDialog from '../../components/manager/showDataInfo'
  import viewReasonDialog from './viewRejectReasonDialog'
  export default{
    components: {
      planPackConfigDialog,
      downFileDialog,
      rejectDialog,
      addChannelUrlDialog,
      viewReasonDialog,
      cdnManualUploadDialog,
      showDataInfoDialog,
      planDownFileDialog,
      downCdnFileDialog
    },
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {
        dataList: [],
        pluginList: [],
        showPackConfigDataDialogSet: {
          iGamePackId: '',
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        optionDownFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          appstoreName: ''
        },
        optionDownCdnFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          appstoreName: ''
        },
        optionPlanDownFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileItem: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        rejectDialogSet: {
          dialogFormVisible: false,
          dialogFlag: '',
          currentStatus: '',
          dialogCurrentTitle: ''
        },
        rejectReasonContent: {},
        addChannelUrlDialogSet: {
          title: '',
          dialogFormVisible: false,
          dialogFlag: '',
          currentStatus: '',
          dialogCurrentTitle: ''
        },
        cdnManualUploadDataDialog: {
          title: '',
          iPlanAdId: '',
          dialogFormVisible: false
        },
        addChannelUrlContent: {},
        viewRejectReasonDialogSet: {
          dialogFormVisible: false,
          dialogFlag: '',
          dialogCurrentTitle: ''
        },
        viewRejectReasonContent: '',
        showInfoDataDialog: {
          dialogShowVisible: false,
          title: '',
          tableHeader: [],
          tableDataList: []
        }
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planProgressSelectedTab', 'roleAuthority', 'planStatusList', 'planProgressTabStatus'
      ])
    },
    created: function () {
      if (this.planProgressSelectedTab === '3') {
        this.getPluginList()
        this.searchDataList()
      }
    },
    watch: {
      planProgressSelectedTab: function (newVal) {
        if (newVal === '3') {
          this.getPluginList()
          this.searchDataList()
        }
      }
    },
    methods: {
      orderDataList (data) {
        let backData = []
        let backData2 = []
        let backData3 = []
        let backData4 = []
        let backData5 = []
        this.dataList = []
        for (let item of data) {
          if (item.cStatus === '40') {
            backData.unshift(item)
          } else if (item.cStatus === '20') {
            backData.push(item)
          } else if (item.cStatus === '15') {
            backData2.push(item)
          } else if (item.cStatus === '25') {
            backData3.unshift(item)
          } else if (item.cStatus === '30') {
            backData3.push(item)
          } else if (item.cStatus === '0') {
            backData4.unshift(item)
          } else if (item.cStatus === '6') {
            backData4.push(item)
          } else if (item.cStatus === '10') {
            backData5.unshift(item)
          } else {
            backData5.push(item)
          }
        }
        this.dataList = backData.concat(backData2).concat(backData3).concat(backData4).concat(backData5)
      },
      searchDataList () {
        planApi.getCpsOrAdvProgressDataList(this.planInfo.iPlanId, 0).then((data) => {
          if (data.code === 1) {
            this.orderDataList(data.data)
//            this.dataList = data.data
          } else {
            this.$alert(data.msg, '数据获取失败', {
              confirmButtonText: '确定'
            })
          }
        })
      },
      getPluginList () {
        let _this = this
        let params = {
          platformId: this.planInfo.iPlatformId,
          languageId: this.planInfo.iLanguageId,
          areaId: this.planInfo.iAreaId
        }
        pluginApi.getPluginDataList(2, params).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      getPluginInfo (plugins, pluginConfigIds) {
        let spList = []
        for (let pItem of this.pluginList) {
          if (plugins.indexOf(pItem.iPluginId) >= 0) {
            for (let spItem of pItem.pluginVersionList) {
              if (pluginConfigIds.indexOf(spItem.iPluginConfigId) >= 0) {
                pItem.iPluginConfigId = spItem.iPluginConfigId
                spList.push(pItem.pluginName + '--' + spItem.pluginVersion)
              }
            }
          }
        }
        return spList
      },
      //  查看配置详情
      showPackConfig ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.showPackConfigDataDialogSet.iGamePackId = $item.iGamePackId
        this.showPackConfigDataDialogSet.dialogFormVisible = true
        this.showPackConfigDataDialogSet.dialogCurrentTitle = $item.cAdcpsCode
      },
      // 广告包下载
      downloadPackage ($index, $item, $data) {
        let noDownLoadStatus = ['0', '6', '10']
        planApi.getAdCpsPackRecordInfo($item.iPlanAdId).then((data) => {
          if (data.code === 1) {
            this.optionDownFileItem.downLoadPath = data.data.cUrl
            this.optionDownFileItem.isChannelDownload = false
            this.optionDownFileItem.resourceName = ''
            this.optionDownFileItem.appstoreName = ''
            if (noDownLoadStatus.indexOf(data.data.cStatus) < 0 && data.data.cUrl) {
              this.optionDownFileDialog.dialogVisible = true
              this.optionDownFileDialog.dialogCurrentTitle = $item.cAdcpsCode
            } else {
              this.$alert('暂无下载的游戏包', '提示', {
                confirmButtonText: '确定'
              })
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
          this.searchDataList()
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
          this.searchDataList()
        })
      },
      // 通过、渠道送审，切至下一个状态
      nextStatus ($index, $item, $data) {
        planApi.updateAdProgressStatus($item.iPlanAdId, 1, $item.cStatus).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 通过
      checkPass ($index, $item, $data) {
        this.$confirm('是否确定通过', '提示（' + $item.cAdcpsCode + '）', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.nextStatus($index, $item, $data)
        }).catch(() => {
        })
      },
      // 渠道送审
      channelSendCheck ($index, $item, $data) {
        this.$confirm('是否确定执行渠道送审操作', '提示（' + $item.cAdcpsCode + '）', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.nextStatus($index, $item, $data)
        }).catch(() => {
        })
      },
      // 驳回、渠道驳回
      rejectDialogShow ($index, $item, $data) {
        this.rejectDialogSet.dialogFormVisible = true
        this.rejectDialogSet.dialogFlag = 'ad'
        this.rejectDialogSet.currentStatus = $item.cStatus
        this.rejectDialogSet.dialogCurrentTitle = $item.cAdcpsCode
        this.rejectReasonContent = {
          iPlanAdId: $item.iPlanAdId,
          reason: ''
        }
      },
      // 查看原因
      viewReason ($index, $item, $data) {
        planApi.getAdRejectReason($item.iPlanAdId).then((data) => {
          if (data.code === 1) {
            this.viewRejectReasonDialogSet.dialogFormVisible = true
            this.viewRejectReasonDialogSet.dialogCurrentTitle = $item.cAdcpsCode
            this.viewRejectReasonContent = data.data
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 渠道通过
      channelPass ($index, $item, $data) {
        this.$confirm('渠道是否确定审核通过？', '提示（' + $item.cAdcpsCode + '）', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const params = {
            channelIds: '',
            iPlanChannelId: 0,
            sDesc: ''
          }
          planApi.adChannelPass($item.iPlanAdId, params, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      enterChannelAddress ($index, $item, $data) {
        this.addChannelUrlDialogSet.dialogFormVisible = true
        this.addChannelUrlDialogSet.dialogFlag = 'ad'
        this.addChannelUrlDialogSet.currentStatus = $item.cStatus
        this.addChannelUrlDialogSet.dialogCurrentTitle = $item.cAdcpsCode
        this.addChannelUrlContent = {
          iPlanAdId: $item.iPlanAdId,
          url: $item.channelAppUrl
        }
      },
      // 渠道下载地址
      channelDownloadPackage ($index, $item, $data) {
        let downLoadStatus = ['35']
        planApi.getAdCpsPackRecordInfo($item.iPlanAdId).then((data) => {
          if (data.code === 1) {
            this.optionDownFileItem.downLoadPath = data.data.channelAppUrl
            this.optionDownFileItem.isChannelDownload = true
            this.optionDownFileItem.resourceName = ''
            this.optionDownFileItem.appstoreName = ''
            if (downLoadStatus.indexOf(data.data.cStatus) >= 0 && data.data.channelAppUrl) {
              this.optionPlanDownFileDialog.dialogVisible = true
              this.optionPlanDownFileDialog.dialogCurrentTitle = $item.cAdcpsCode
            } else {
              this.$alert('暂无渠道下载地址', '提示', {
                confirmButtonText: '确定'
              })
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
          this.searchDataList()
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
          this.searchDataList()
        })
      },
      cdnManualUploadFun ($index, $item, $data) {
        this.cdnManualUploadDataDialog.title = '手动上传（' + $item.cAdcpsCode + '）'
        this.cdnManualUploadDataDialog.iPlanAdId = $item.iPlanAdId
        this.cdnManualUploadDataDialog.dialogFormVisible = true
      },
      cdnDownloadUrlFun ($index, $item, $data) {
        if ($item.cdnUrl) {
          this.optionDownFileItem.downLoadPath = $item.cdnUrl
          this.optionDownFileItem.isChannelDownload = true
          this.optionDownFileItem.resourceName = ''
          this.optionDownFileItem.appstoreName = ''
          this.optionDownCdnFileDialog.dialogVisible = true
          this.optionDownCdnFileDialog.dialogCurrentTitle = $item.cAdcpsCode
        } else {
          this.$alert('暂无CDN下载地址', '提示', {
            confirmButtonText: '确定'
          })
        }
      },
      showCDNUploadDataList ($index, $item, $data) {
        this.showInfoDataDialog.dialogShowVisible = true
        this.showInfoDataDialog.title = 'CDN自动上传次数（' + $item.cAdcpsCode + '）'
        this.showInfoDataDialog.tableHeader = [
          {
            label: '上传时间',
            prop: 'uploadCreate'
          },
          {
            label: '状态',
            prop: 'uploadStatus'
          }
        ]
        this.showInfoDataDialog.tableDataList = [
          {
            uploadCreate: '2017-05-25 11:23',
            uploadStatus: '上传成功'
          },
          {
            uploadCreate: '2017-05-25 11:23',
            uploadStatus: '上传成功'
          }
        ]
      },
      getStatusCharacter (status) {
        return planUtil.getPlanStatus(status, 3)
      },
      getCdnStatusValue (cdnStatus) {
        let cdnStatusValue = '上传中'
        switch (parseInt(cdnStatus)) {
          case 1:
            cdnStatusValue = '上传失败'
            break
          case 2:
            cdnStatusValue = '上传成功'
            break
          case 5:
            cdnStatusValue = '上传中'
            break
        }
        return cdnStatusValue
      }
    }
  }
</script>
