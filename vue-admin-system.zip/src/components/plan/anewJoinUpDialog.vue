<style>
  .option-dialog-anew-Join-up .el-dialog{
    width: 600px;
  }
  .option-dialog-anew-Join-up .el-form-item__label{
    width:100%;
    text-align:left;
  }
  .option-dialog-anew-Join-up .el-checkbox-group .el-checkbox{
    /*width:25%;*/
    margin-right:5px;
    margin-left:0;
  }
  .tip-wraning-message-item{
    color:#c29068;
    font-size:13px;
    font-weight:200;
    margin-bottom:5px;
  }
  .tip-wraning-message-item .el-icon-warning{
    margin-right:5px;
  }
</style>
<template>
  <el-dialog :title="'重新接入（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-anew-Join-up">
    <div class="content-list">
      <el-row class="tip-wraning-message-item">
        <el-col><i class="el-icon-warning" ></i><span >提示：接入渠道在质检通过的情况下,点击重新接入，整包状态变为待打包,渠道重走接入流程</span ></el-col>
      </el-row>
      <el-row >
        <el-col :span="3">重接渠道：</el-col>
        <el-col :span="21">{{planChannelInfo.iChannelName}}</el-col>
      </el-row>
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules" >
        <el-form-item label="选择哪些广告码需要重新打包:" prop="channelArrayIds" v-if="channelDataList.length>0">
          <el-row>
            <el-col :span="24" v-if="advChannelDataList && advChannelDataList.length > 0">
              <el-checkbox v-model="advCheckedAll" @change="advCheckAllChange"><strong style="font-size: 15px;">广告码</strong></el-checkbox>
            </el-col>
            <el-checkbox-group v-model="dataInfoForm.advChannelArrayIds">
              <template>
                <el-col v-for="(item,index) in advChannelDataList" :span="8">
                  <el-checkbox :label="item.cAdcpsCode" @change="advCheckOneChange($event,item)">{{item.cAdcpsCode+'('+item.sDemo+')'}}</el-checkbox>
                </el-col>
              </template>
            </el-checkbox-group>
            <el-col :span="24" v-if="cpsChannelArrayIds && cpsChannelArrayIds.length > 0">
              <el-checkbox v-model="cpsCheckedAll" @change="cpsCheckAllChange"><strong style="font-size: 15px;">CPS码</strong></el-checkbox>
            </el-col>
            <el-checkbox-group v-model="dataInfoForm.cpsChannelArrayIds">
              <template>
                <el-col v-for="(item,index) in cpsChannelDataList" :span="8">
                  <el-checkbox :label="item.cAdcpsCode" @change="cpsCheckOneChange($event,item)">{{item.cAdcpsCode+'('+item.sDemo+')'}}</el-checkbox>
                </el-col>
              </template>
            </el-checkbox-group>
          </el-row>
        </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary" @click="submitFormData('dataInfoForm')" >确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planApi from '../../apis/plan-api'
  export default{
    components: {},
    props: ['optionData', 'dataInfoForm', 'optionCallBack'],
    data () {
      return {
        rules: {
//          sDesc: [
//            {required: true, message: '请输入更新说明', trigger: 'blur'}
//          ],
//          channelArrayIds: [
//            { type: 'array', required: true, message: '请至少选择一个广告码', trigger: 'change' }
//          ]
        },
        advCheckedAll: false,
        cpsCheckedAll: false,
        channelDataList: [],
        advChannelDataList: [],
        cpsChannelDataList: []
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'planChannelInfo'
      ])
    },
    created: function () {
      // 获取广告吗
      this.getAdvOrCpsList()
    },
    methods: {
      getAdvOrCpsList () {
        planApi.getPackAdvCpsDataList(this.planChannelInfo.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            if (data.data) {
              this.channelDataList = data.data
              for (let item of data.data) {
                if (item.cPackType === '0') {
                  this.advChannelDataList.push(item)
                } else {
                  this.cpsChannelDataList.push(item)
                }
              }
            } else {
              this.channelDataList = []
              this.advChannelDataList = []
              this.cpsChannelDataList = []
            }
          }
        })
      },
      advCheckAllChange (event) {
        const _this = this
        this.dataInfoForm.advChannelArrayIds = []
        if (event) {
          for (let item of _this.advChannelDataList) {
            this.dataInfoForm.advChannelArrayIds.push(item.cAdcpsCode)
          }
        }
      },
      cpsCheckAllChange (event) {
        const _this = this
        this.dataInfoForm.cpsChannelArrayIds = []
        if (event) {
          for (let item of _this.cpsChannelDataList) {
            this.dataInfoForm.cpsChannelArrayIds.push(item.cAdcpsCode)
          }
        }
      },
      // 单个选中
      advCheckOneChange (event, item) {
        const _this = this
        if (_this.advChannelDataList.length === _this.dataInfoForm.advChannelArrayIds.length) {
          _this.advCheckedAll = true
        } else {
          _this.advCheckedAll = false
        }
      },
      cpsCheckOneChange (event, item) {
        const _this = this
        if (_this.cpsChannelDataList.length === _this.dataInfoForm.cpsChannelArrayIds.length) {
          _this.cpsCheckedAll = true
        } else {
          _this.cpsCheckedAll = false
        }
      },
      submitFormData (formName) {
        let _this = this
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let submitData = JSON.parse(JSON.stringify(this.dataInfoForm))
            submitData.channelIds = submitData.advChannelArrayIds.concat(submitData.cpsChannelArrayIds).join(',')
            delete submitData.advChannelArrayIds
            delete submitData.cpsChannelArrayIds
            planApi.againJoinUpPackage(submitData, this.planChannelInfo.cStatus).then((data) => {
              if (data.code === 1) {
                _this.optionCallBack()
                this.optionData.dialogFormVisible = false
              } else {
                _this.$alert(data.msg, '请求失败', {
                  confirmButtonText: '确定'
                })
              }
            }, (error) => {
              this.$alert('请求失败，请稍后重试！', '提示', {
                confirmButtonText: '确定'
              })
            })
          } else {
            return false
          }
        })
      }
    }
  }
</script>
