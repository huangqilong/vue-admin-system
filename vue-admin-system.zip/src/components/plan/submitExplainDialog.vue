<style>
  .option-submit-explain .el-dialog{
    width: 500px;
  }
  .option-submit-explain .el-dialog .el-form-item-text{
    margin-bottom: 0px;
  }
</style>
<template>
  <el-dialog  :title="optionData.title" :close-on-click-modal="false"
              :visible.sync="optionData.dialogFormVisible"
              class="option-dialog option-submit-explain">
    <div class="content-list">
      <el-form  :model="dataInfoForm" ref="dataInfoForm" :rules="rules">
          <el-form-item v-for="item in optionData.formData" :prop="item.isText?'':'reason'" :class="item.isText?'el-form-item-text':''"  :label="item.label">
            <span v-if="item.isText">
              <template v-if="item.value" >
                <span v-html="item.value.split('::')[1] ? item.value.split('::')[1] : item.value"></span>
              </template>
            </span>
            <el-input v-if="!item.isText" type="textarea"  v-model="dataInfoForm.reason" :placeholder="item.placeholderText?item.placeholderText:''"></el-input>
          </el-form-item>
          <el-form-item label="问题归属（支持多选）：" v-if="optionData.isNeedProblemAttribution" prop="iProblemType" >
            <el-select v-model="dataInfoForm.iProblemType" multiple placeholder="请选择" style="width:100%;">
            <el-option
              v-for="item2 in problemAttributionList"
              :key="item2.iDicId"
              :label="item2.sDicName"
              :value="item2.iDicId">
            </el-option>
            </el-select>
          </el-form-item>
      </el-form>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="default" @click="optionData.dialogFormVisible = false">取消</el-button>
      <el-button size="small" type="primary"  @click="submitData('dataInfoForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {
    },
    props: ['optionData'],
    data () {
      return {
        dataInfoForm: {
          reason: '',
          iProblemType: []
        },
        rules: {
          reason: [
            {required: true, message: '数据不可为空', trigger: 'blur'}
          ],
          iProblemType: [
            {type: 'array', required: true, message: '请选择问题归属类型', trigger: 'change'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'problemAttributionList'
      ])
    },
    created: function () {
      for (var item of this.optionData.formData) {
        if (!item.isText && item.value) {
          this.dataInfoForm.reason = item.value
        }
      }
    },
    methods: {
      submitData (formName) {
        let _this = this
        if (_this.optionData.submitCallbackFun) {
          this.$refs[formName].validate((valid) => {
            if (valid) {
              let submitData = JSON.parse(JSON.stringify(this.dataInfoForm))
              if (this.optionData.isNeedProblemAttribution) {
                submitData.iProblemType = submitData.iProblemType.join(',')
              } else {
                submitData.iProblemType = ''
              }
              _this.optionData.submitCallbackFun(submitData)
            }
          })
        } else {
          _this.optionData.dialogFormVisible = false
        }
      }
    }
  }
</script>
