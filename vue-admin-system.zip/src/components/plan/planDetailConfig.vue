<style>
  .option-dialog-plan-detail .el-dialog{
    width: 700px;
  }
  .option-dialog-plan-detail .el-form .el-row .el-col, .popover-content-pack-config .el-row .el-col {
    line-height: 25px;
    overflow: hidden;
    text-overflow: ellipsis;
    height: 36px;
  }
  .option-dialog-plan-detail.el-dialog__wrapper{
    overflow:hidden;
  }
  .option-dialog-plan-detail  .detail-form-content{padding-right: 5px; height:600px;overflow-Y:auto;}
  .option-dialog-plan-detail .detail-form-content .el-form-item__label {
    font-size: 15px;
    font-weight: bold;
  }
</style>
<style scoped>
  .row-col{
    border: 1px solid #dfe6ec;
    padding: 5px 5px 5px 10px;
  }
  .label-title{
    background-color: #eef1f6;
    text-align: right;
  }
</style>
<template>
  <el-dialog :title="'查看详情（' + optionData.dialogCurrentTitle+ '）'"
             :visible.sync="optionData.dialogFormVisible"
             class="option-dialog option-dialog-pack-config option-dialog-plan-detail">
    <el-form :model="planInfo" label-position="top" class="detail-form-content">
      <el-form-item label="计划基本信息：">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">计划名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.sPackPlanName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">起止时间：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.planTime}}</el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="计划游戏信息：">
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">地区：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.iAreaName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">语言：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.iLanguageName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">平台：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.iPlatformName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">项目名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.projectName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">游戏名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.gameName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">游戏版本：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.gameVersion}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">资源类型：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.cVersionType==gameAssetsTypeList[0].value?gameAssetsTypeList[0].name:gameAssetsTypeList[1].name}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">资源名称：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">{{planInfo.assertName}}</el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title" style="padding:5px 0px;">游戏母包截止上传时间：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">
            <template>
            {{planInfo.dUploadEnd.split(' ')[0]}}
          </template></el-col>
        </el-row>
        <el-row>
          <el-col :span="colSpansSecond[0]" class="row-col label-title">备注：</el-col>
          <el-col :span="colSpansSecond[1]" class="row-col">
            {{planInfo.sDemo ? planInfo.sDemo : '--'}}
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="打包渠道信息：">
        <el-table :data="planInfo.packPlanChannelRecordVOList" border>
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="iChannelName" label="渠道名称"></el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="广告包信息：" v-if="planInfo.packPlanAdRecordList.length>0">
        <el-table :data="advCpsDataFilter('0')" border>
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="adcpsCode" label="广告码"></el-table-column>
          <el-table-column prop="sDemo" label="备注"></el-table-column>
          <el-table-column label="广告插件">
            <template scope="scope">
              {{scope.row.cAdPluginConfigIds ? getPluginInfo(scope.row.pluginIds, scope.row.cAdPluginConfigIds).join(',') : '--'}}
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="cps包信息：" v-if="planInfo.packPlanAdRecordList.length>0">
        <el-table :data="advCpsDataFilter('1')" border>
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="adcpsCode" label="广告码"></el-table-column>
          <el-table-column prop="sDemo" label="备注">
            <template scope="scope">
              {{scope.row.sDemo ? scope.row.sDemo : '--'}}
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="计划订阅人员：">
        <el-table :data="planInfo.packPlanSubcribeVOList" border>
          <el-table-column type="index" label="序号" width="50"></el-table-column>
          <el-table-column prop="cRoleName" label="角色"></el-table-column>
          <el-table-column prop="cRealName" label="真实姓名"></el-table-column>
        </el-table>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" type="success"  v-if="roleAuthority.updateBtn && planInfo.cPlanStatus!=planStatusList[1].iDicId" @click="updateDataInfo" style="float:left;">编辑计划</el-button>
      <el-button size="small" type="success" v-if="roleAuthority.deleteBtn"  @click="deleteDataInfo" style="float:left;">删除计划</el-button>
      <el-button size="small" type="success" v-if="roleAuthority.openOrClosePlan"  @click="changePlanStatus" style="float:left;">{{planInfo.cPlanStatus!=planStatusList[1].iDicId?'结束计划':'开启计划'}}</el-button>
      <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关闭</el-button>
    </div>
  </el-dialog>
</template>
<script>
  import {mapGetters} from 'vuex'
  import pluginApi from '../../apis/plugin-api'

  export default{
    props: ['optionData', 'changeStatusCallbackFun', 'updateCallbackFun', 'deleteCallbackFun'],
    data () {
      return {
        pluginList: [],
        colSpans: [5, 7, 5, 7],
        colSpansSecond: [6, 18]
      }
    },
    computed: {
      ...mapGetters([
        'planInfo', 'gameAssetsTypeList', 'planStatusList', 'roleAuthority'
      ])
    },
    created: function () {
      this.getPluginList()
    },
    methods: {
      getPluginList () {
        let _this = this
        let params = {
          platformId: this.planInfo.iPlatformId,
          languageId: this.planInfo.iLanguageId,
          areaId: this.planInfo.iAreaId
        }
        pluginApi.getPluginDataList(2, params).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      getPluginInfo (plugins, pluginConfigIds) {
        let spList = []
        for (let pItem of this.pluginList) {
          if (plugins.indexOf(pItem.iPluginId) >= 0) {
            for (let spItem of pItem.pluginVersionList) {
              if (pluginConfigIds.indexOf(spItem.iPluginConfigId) >= 0) {
                pItem.iPluginConfigId = spItem.iPluginConfigId
                spList.push(pItem.pluginName + '--' + spItem.pluginVersion)
              }
            }
          }
        }
        return spList
      },
      advCpsDataFilter (cPackType) {
        return this.planInfo.packPlanAdRecordList.filter(function (item) {
          return item.cPackType === cPackType
        })
      },
      updateDataInfo () {
        this.optionData.dialogFormVisible = false
        this.updateCallbackFun()
      },
      deleteDataInfo () {
        this.optionData.dialogFormVisible = false
        this.deleteCallbackFun()
      },
      changePlanStatus () {
        if (this.planInfo.cPlanStatus === this.planStatusList[0].iDicId) {
          this.$confirm('是否确定结束该计划', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.optionData.dialogFormVisible = false
            this.changeStatusCallbackFun()
          }).catch(() => {
          })
        } else {
          this.$confirm('是否确定开始该计划', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.optionData.dialogFormVisible = false
            this.changeStatusCallbackFun()
          }).catch(() => {
          })
        }
      }
    }
  }
</script>
