<style>
  .option-dialog-adv-cps .el-dialog{
    width: 600px;
  }
</style>
<style scoped>
  .option-dialog-adv-cps .plugin-item{
    padding-left: 10px;
    padding-right: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 5px;
  }
  .option-dialog-adv-cps .plugin-item .plugin-item-checkbox{
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
  }
</style>
<template>
  <el-dialog :title="optionData.type==0?'选择广告码':'选择CPS码'" :visible.sync="optionData.dialogVisible"
             class="option-dialog option-dialog-adv-cps">
    <div style="margin: 0 0 15px 0;">
      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
      <el-checkbox-group v-model="selectAdvCpsDataList" @change="handleCheckedChange" style="margin-top: 5px">
        <el-row :gutter="10">
          <el-col :span="8" v-for="item in advCpsDataList" class="plugin-item">
            <el-checkbox :label="item" :key="item.iAdcodeId" class="plugin-item-checkbox">
              <span v-if="(item.cAdcpsCode+'('+item.sDemo+')').replace(/[\u0391-\uFFE5]/g,'aa').length<=21">{{item.cAdcpsCode+'('+item.sDemo+')'}}</span>
              <el-tooltip :content="(item.cAdcpsCode+'('+item.sDemo+')')" placement="bottom" effect="light" v-if="(item.cAdcpsCode+'('+item.sDemo+')').replace(/[\u0391-\uFFE5]/g,'aa').length>21">
                <span>{{item.cAdcpsCode+'('+item.sDemo+')'}}</span>
              </el-tooltip>
            </el-checkbox>
          </el-col>
        </el-row>
      </el-checkbox-group>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button size="small" @click="optionData.dialogVisible = false">取 消</el-button>
      <el-button size="small" type="primary" @click="submitForm()" :loading="buttonLoading">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  export default{
    components: {},
    props: ['optionData', 'dataInfoForm', 'optionCallBack', 'packAdvCpsIdsList'],
    data () {
      return {
        selectAdvCpsDataList: [],
        checkAll: true,
        isIndeterminate: true,
        advCpsDataList: []
      }
    },
    created () {
      // 获取渠道列表
      this.getCpsAdvPackList()
    },
    computed: {
      ...mapGetters([
        'buttonLoading'
      ])
    },
    methods: {
      getCpsAdvPackList () {
        let _this = this
        // 获取数据列表
        gameApi.getCpsAdvPackInfo(this.dataInfoForm.iProjectId).then((data) => {
          if (data.code === 1) {
            for (let pItem of data.data) {
              if (pItem.cPackType === _this.optionData.type) {
                _this.advCpsDataList.push(pItem)
                if (_this.packAdvCpsIdsList[this.optionData.type].indexOf(pItem.iAdcodeId) >= 0) {
                  _this.selectAdvCpsDataList.push(pItem)
                }
              }
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      handleCheckAllChange (event) {
        this.selectAdvCpsDataList = event ? this.advCpsDataList : []
        this.isIndeterminate = false
      },
      handleCheckedChange (value) {
        let checkedCount = value.length
        this.checkAll = checkedCount === this.advCpsDataList.length
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.advCpsDataList.length
      },
      submitForm () {
        this.optionData.dialogVisible = false
        this.optionCallBack(this.selectAdvCpsDataList, this.optionData.type)
      }
    }
  }

</script>
