<style>
</style>
<template>
  <div>
    <el-table :data="dataList" stripe>
      <el-table-column prop="assertName" label="资源名称" >
        <template scope="scope" >
          {{scope.row.assertName ? scope.row.assertName : '--'}}
        </template>
      </el-table-column>
      <el-table-column label="资源状态" >
        <template scope="scope" >
          <span v-html="getStatusCharacter(scope.row.cStatus)"></span>
        </template>
      </el-table-column>
      <el-table-column prop="userName" label="处理人" >
        <template scope="scope">
          <span :style="scope.row.userName=='系统'?'color: #aaa;':''">{{scope.row.cStatus !=0 && scope.row.cStatus !=5 &&　scope.row.userName　? scope.row.userName : '--'}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="packNum" label="送检次数" >
        <template scope="scope">
          <a v-if="scope.row.packNum>0" @click="checkTimeDialogShow(scope.$index,scope.row,dataList)">{{scope.row.packNum}}</a>
          <span v-if="scope.row.packNum<=0">{{scope.row.packNum}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="dPackEnd" label="打包时间" >
        <template scope="scope">
          {{scope.row.cStatus !='0' &&　scope.row.cStatus != '5' && scope.row.cStatus != '6' && scope.row.cStatus != '10' && scope.row.cStatus != '15' && scope.row.dPackEnd　? scope.row.dPackEnd : '--'}}
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="520" v-if="planInfo.cPlanStatus!=planStatusList[1].iDicId">
        <template scope="scope">
          <el-button type="text" class="table-option-button"  @click="uploadBarePackageDialogShow(scope.$index,scope.row, dataList)" v-if="roleAuthority.uploadBtn && scope.row.cStatus == '0'">上传</el-button>
          <el-button type="text" class="table-option-button"  @click="downloadBarePackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoadBareFile && planInfo.iUseSvn != 1 && scope.row.cStatus != '0'">下载母包</el-button>
          <el-button type="text" class="table-option-button"  @click="packGameTestPackage(scope.$index,scope.row, dataList)"  v-if="roleAuthority.clickPack && scope.row.cStatus == '5'">打游戏测试包</el-button>
          <el-button type="text" class="table-option-button"  @click="showPackConfig(scope.$index,scope.row, dataList)"  v-if="roleAuthority.configDetails && scope.row.cStatus !== '5' && scope.row.cStatus !== '0'">配置详情</el-button>
          <el-button type="text" class="table-option-button"  @click="lineAnewPack(scope.$index,scope.row,dataList)"  v-if="roleAuthority.lineAgainPack && scope.row.cStatus == '6'">重新打包</el-button>
          <el-button type="text" class="table-option-button"  @click="anewPack(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.againPack && (scope.row.cStatus == '15'|| scope.row.cStatus == '20' || scope.row.cStatus == '26' || scope.row.cStatus == '40')">重新打包</el-button>
          <el-button type="text" class="table-option-button"  @click="anewUploadDialogShow(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.againUpload && (scope.row.cStatus == '5' || scope.row.cStatus == '15' || scope.row.cStatus == '30' || scope.row.cStatus == '20' || scope.row.cStatus == '26' || scope.row.cStatus == '40')">更换母包</el-button>
          <el-button type="text" class="table-option-button"  @click="chooseChannel(scope.$index,scope.row, dataList)" v-if="roleAuthority.againChooseChannel && scope.row.cStatus == '31'">选择渠道</el-button>
          <el-popover  :title="'打包服务器（' + scope.row.assertName+'）'"  trigger="click" @show="packResultLogDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button" v-if="roleAuthority.checkLog && scope.row.cStatus !== '5' && scope.row.cStatus !== '0'">日志</el-button>
          </el-popover>
          <el-button type="text" class="table-option-button"  @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.downLoad && (scope.row.cStatus == '25'  || scope.row.cStatus == '26' || scope.row.cStatus == '30' || ( roleName.indexOf('质检')==-1 && (scope.row.cStatus == '20' || scope.row.cStatus == '31' || scope.row.cStatus == '35' || scope.row.cStatus == '40')))">下载</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="roleAuthority.buglyConfig&&planInfo.iPlatformName=='IOS'&& (scope.row.cStatus == '20' || scope.row.cStatus == '25'  || scope.row.cStatus == '26' || scope.row.cStatus == '30' || scope.row.cStatus == '31' || scope.row.cStatus == '35' || scope.row.cStatus == '40')">bugly下载</el-button>
          <el-button type="text" class="table-option-button"  @click="commitQA(scope.$index,scope.row,dataList)" v-if="roleAuthority.commitQA && scope.row.cStatus == '20'">提交质检</el-button>
          <el-button type="text" class="table-option-button"  @click="checkPass(scope.$index,scope.row,dataList)"  v-if="roleAuthority.QAPass && scope.row.cStatus == '25'">通过</el-button>
          <el-button type="text" class="table-option-button"  @click="rejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.rejectBtn && scope.row.cStatus == '25'">驳回</el-button>
          <el-button type="text" class="table-option-button"  @click="managerCheckPass(scope.$index,scope.row,dataList)"  v-if="roleAuthority.managerPass && scope.row.cStatus == '35'">通过</el-button>
          <el-button type="text" class="table-option-button"  @click="managerRejectDialogShow(scope.$index,scope.row,dataList)" v-if="roleAuthority.managerReject && scope.row.cStatus == '35'">驳回</el-button>
          <el-button type="text" class="table-option-button" @click="viewReason(scope.$index,scope.row,dataList)" v-if="roleAuthority.checkCause && (scope.row.cStatus == '26'|| scope.row.cStatus == '40')">查看原因</el-button>
          <el-button type="text" class="table-option-button" @click="revocationReject(scope.$index,scope.row,dataList)" v-if="roleAuthority.revocationRejectBtn && (scope.row.cStatus == '26'|| scope.row.cStatus == '40')">撤销</el-button>
        </template>
      </el-table-column>
      <el-table-column  label="操作" width="320" v-if="planInfo.cPlanStatus==planStatusList[1].iDicId">
        <template scope="scope">
          <el-button type="text" class="table-option-button"  @click="showPackConfig(scope.$index,scope.row, dataList)"  v-if="scope.row.cStatus !== '5' && scope.row.cStatus !== '0'">配置详情</el-button>
          <el-popover  :title="'打包服务器（' + scope.row.assertName+'）'"  trigger="click" @show="packResultLogDialogShow(scope.$index,scope.row,dataList)">
            <div class="popover-content" style="height: 200px;overflow: auto;">
              <el-table :data="packServerList">
                <el-table-column prop="jobName" label="服务器名称" :width="200">
                  <template scope="scope">
                    <a target="_blank" :href="scope.row.console" v-if="!!scope.row.console">{{scope.row.jobName}}</a>
                    <span v-if="scope.row.console==null||scope.row.console ==''">{{scope.row.jobName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="dCreate" label="日期" :width="200"></el-table-column>
              </el-table>
            </div>
            <el-button slot="reference" type="text" class="table-option-button" v-if="scope.row.cStatus !== '5' && scope.row.cStatus !== '0'">日志</el-button>
          </el-popover>
          <el-button type="text" class="table-option-button"  @click="downloadBarePackage(scope.$index,scope.row,dataList)"
                     v-if="planInfo.iUseSvn != 1 && scope.row.cStatus != '0'">下载母包</el-button>
          <el-button type="text" class="table-option-button"  @click="downloadPackage(scope.$index,scope.row,dataList)"
                     v-if="scope.row.cStatus == '20' || scope.row.cStatus == '25'  || scope.row.cStatus == '26' || scope.row.cStatus == '30' || scope.row.cStatus == '31' || scope.row.cStatus == '35' || scope.row.cStatus == '40'">下载</el-button>
          <el-button type="text" class="table-option-button" @click="buglyDownload(scope.$index,scope.row,dataList)"
                     v-if="planInfo.iPlatformName=='IOS'&& (scope.row.cStatus == '20' || scope.row.cStatus == '25'  || scope.row.cStatus == '26' || scope.row.cStatus == '30' || scope.row.cStatus == '31' || scope.row.cStatus == '35' || scope.row.cStatus == '40')">bugly下载</el-button>
        </template>
      </el-table-column>
    </el-table>
    <uploadBarePackageDialog v-if="uploadBarePackageDialogSet.dialogFormVisible" :optionData="uploadBarePackageDialogSet"  :dataInfoForm="uploadFileInfo" :optionCallBack="searchDataList"></uploadBarePackageDialog>
    <downFileDialog v-if="optionDownFileDialog.dialogVisible" :optionData="optionDownFileDialog" :dataParams="optionDownFileItem"></downFileDialog>
    <down-file-dialog-v1 v-if="optionDownFileDialogV1.dialogVisible" :optionData="optionDownFileDialogV1" :dataParams="optionDownFileItemV1"></down-file-dialog-v1>
    <checkTimeDialog  v-if="checkTimeDialogSet.dialogFormVisible" :optionData="checkTimeDialogSet" ></checkTimeDialog>
    <planPackConfigDialog v-if="showPackConfigDataDialogSet.dialogFormVisible" :optionData="showPackConfigDataDialogSet"></planPackConfigDialog>
    <viewReasonDialog v-if="viewRejectReasonDialogSet.dialogFormVisible" :optionData="viewRejectReasonDialogSet" :dataInfoForm="viewRejectReasonContent"></viewReasonDialog>
    <anewChooseChannelDialog v-if="anewChooseChannelDialogSet.dialogFormVisible" :optionData="anewChooseChannelDialogSet"  :dataInfoForm="anewChooseChannelContent" :optionCallBack="searchDataList"></anewChooseChannelDialog>
    <submit-explain-dialog v-if="submitExplainDialogSet.dialogFormVisible" :optionData="submitExplainDialogSet"></submit-explain-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import planApi from '../../apis/plan-api'
  import planUtil from '../../utils/plan-util'
  import uploadBarePackageDialog from '../../components/plan/uploadBarePackageDialog'
  import downFileDialog from '../../components/pack/downFileDialog'
  import downFileDialogV1 from '../../components/plan/downFileDialogV1'
  import checkTimeDialog from '../../components/plan/checkTimeDialog'
  import planPackConfigDialog from '../../components/plan/planPackConfigDialog'
  import viewReasonDialog from './viewRejectReasonDialog'
  import anewChooseChannelDialog from '../../components/plan/anewChooseChannelDialog'
  import submitExplainDialog from '../../components/plan/submitExplainDialog'
  export default{
    components: {
      planPackConfigDialog,
      uploadBarePackageDialog,
      downFileDialog,
      downFileDialogV1,
      checkTimeDialog,
      viewReasonDialog,
      anewChooseChannelDialog,
      submitExplainDialog
    },
    props: ['optionConfigData', 'dataInfoForm'],
    data () {
      return {
        dataList: [],
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        uploadBarePackageDialogSet: {
          dialogFormVisible: false,
          currentStatus: '',
          dialogCurrentTitle: ''
        },
        uploadFileInfo: {},
        optionDownFileDialog: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileDialogV1: {
          dialogVisible: false,
          dialogTypeFlag: '',
          dialogCurrentTitle: ''
        },
        optionDownFileItem: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        optionDownFileItemV1: {
          isChannelDownload: false,
          downLoadPath: '',
          resourceName: '',
          appstoreName: ''
        },
        anewChooseChannelDialogSet: {
          dialogFormVisible: false,
          currentStatus: '',
          dialogCurrentTitle: ''
        },
        anewChooseChannelContent: {},
        checkTimeDialogSet: {
          type: '送检',
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        showPackConfigDataDialogSet: {
          iGamePackId: '',
          dialogFormVisible: false,
          dialogCurrentTitle: ''
        },
        packServerList: [],
        viewRejectReasonDialogSet: {
          dialogFormVisible: false,
          dialogFlag: 'channel',
          dialogCurrentTitle: ''
        },
        viewRejectReasonContent: '',
        submitExplainDialogSet: {
          dialogFormVisible: false,
          type: '',
          title: '',
          isNeedProblemAttribution: false,
          formData: [],
          submitCallbackFun: null
        }
      }
    },
    computed: {
      ...mapGetters([
        'userId', 'planInfo', 'gameInfo', 'gameVersionInfo', 'pageNumber', 'roleAuthority',
        'planProgressSelectedTab', 'planChannelInfo', 'planStatusList', 'roleName'
      ])
    },
    created: function () {
      if (this.planProgressSelectedTab === '1') {
        this.searchDataList()
      }
    },
    watch: {
      planProgressSelectedTab: function (newVal) {
        if (newVal === '1') {
          this.searchDataList()
        }
      }
    },
    methods: {
      searchDataList () {
        let _this = this
        const id = this.planInfo.iPlanId
        const packType = 1
        planApi.getPackageProgressDataList(id, packType).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
            confirmButtonText: '确定'
          })
          this.dataList = null
        })
      },
      // 上传裸包
      uploadBarePackageDialogShow ($index, $item, $data) {
        let platformId = this.planInfo.iPlatformName === '安卓' ? 0 : 1
        this.$store.dispatch('planChannelInfo', $item)
        this.uploadBarePackageDialogSet.dialogCurrentTitle = $item.assertName
        this.uploadBarePackageDialogSet.dialogFormVisible = true
        this.uploadBarePackageDialogSet.currentStatus = $item.cStatus
        if (this.planInfo.iUseSvn === 1) {
          this.uploadFileInfo = {
            svnResourcePath: '',
            iGameAssertId: $item.iGameAssetsId,
            iProjectAssetId: $item.iProjectAssetId
          }
        } else {
          this.uploadFileInfo = {
            cPlatformType: platformId,
            gameAssetPath: '',
            iGameAssertId: $item.iGameAssetsId,
            iProjectAssetId: $item.iProjectAssetId,
            uploadType: '0',
            resDirId: '',
            resId: '',
            cMd5: ''
          }
        }
      },
      downloadBarePackage ($index, $item, $data) {
        gameApi.getAssetsDataInfo(this.planInfo.iProjectAssetId).then((data) => {
          if (data.code === 1) {
            let realPath = window.location.href
            let extraRP = data.data.gameAssetPath.substring(data.data.gameAssetPath.indexOf('/upload/'))
            let extraDownloadPath = ''
            if (realPath.indexOf('192.168.0.147') >= 0) {
              extraDownloadPath = 'http://192.168.0.147/cms' + extraRP
            } else {
              extraDownloadPath = 'http://192.168.0.148/cms' + extraRP
            }
            const title = '提示（' + $item.assertName + '）'
            this.$confirm('是否确定下载母包？', title, {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              window.location.href = extraDownloadPath
            }).catch(() => {
            })
            /*
            this.optionDownFileItem.isChannelDownload = true
            this.optionDownFileItem.downLoadPath = extraDownloadPath
            this.optionDownFileItem.resourceName = data.data.resourceName || ''
            this.optionDownFileItem.appstoreName = data.data.appstoreName || ''
            this.optionDownFileDialog.dialogCurrentTitle = $item.assertName
            this.optionDownFileDialog.dialogVisible = true */
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      //  打游戏测试包
      packGameTestPackage ($index, $item, $data) {
        const title = '提示（' + $item.assertName + '）'
        this.$confirm('是否确定打包？', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.packGameTestPackage($item.iPlanChannelId, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                confirmButtonText: '确定'
              })
              this.searchDataList()
            } else if (data.code === 1100) {
              this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
                confirmButtonText: '确定'
              })
            } else if (data.code === 1052) {
              this.$alert('请配置游戏资源后再打包!', '提示', {
                confirmButtonText: '确定'
              })
            } else if (data.code === 1053) {
              this.$alert('请刷新页面', '提示', {
                confirmButtonText: '确定'
              })
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 更换母包
      anewUploadDialogShow ($index, $item, $data) {
        let _this = this
        let title = '提示（' + $item.assertName + '）'
        let content = '是否确定更换母包？'
        if ($item.cStatus === '30') {
          content = '点击该按钮所有渠道整包将使用新的母包打包，请务必和相关负责人确认后在点击！'
        }
        this.$confirm(content, title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let submitData = {
            iPlanChannelId: $item.iPlanChannelId,
            channelIds: '',
            sDesc: ''
          }
          planApi.againUploadgamePackage(submitData, $item.cStatus).then((data) => {
            if (data.code === 1) {
              _this.searchDataList()
            } else {
              _this.$alert(data.msg, '提示', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 日志
      packResultLogDialogShow ($index, $item, $data) {
        this.packServerList = []
        planApi.gamePackServerLogs({taskId: $item.iGamePackId}).then((data) => {
          if (data.code === 1) {
            this.packServerList = data.data.list
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 驳回
      rejectDialogShow ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.isNeedProblemAttribution = true
        this.submitExplainDialogSet.type = '质检驳回'
        this.submitExplainDialogSet.title = '驳回（' + $item.assertName + '）'
        this.submitExplainDialogSet.formData = [
          {
            label: '驳回原因：',
            isText: false,
            value: '',
            placeholderText: '提示：驳回时，请输入修复bugid以及简单说明！'
          }
        ]
        this.submitExplainDialogSet.submitCallbackFun = this.rejectCallback
      },
      // 项目经理驳回回调
      rejectCallback (explainData) {
        this.submitExplainDialogSet.dialogFormVisible = false
        let _this = this
        let id = this.planChannelInfo.iPlanChannelId
        let roleType = 1
        let params = {
          channelIds: '',
          iPlanChannelId: this.planChannelInfo.iPlanChannelId,
          iProblemType: explainData.iProblemType,
          sDesc: explainData.reason
        }
        // 母包、渠道包、整包驳回
        planApi.rejectPlanReason(id, roleType, params, _this.planChannelInfo.cStatus).then((data) => {
          if (data.code === 1) {
            _this.searchDataList()
          } else {
            _this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      //  项目经理驳回
      managerRejectDialogShow ($index, $item, $data) {
        planApi.getQualityDescChannels($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('planChannelInfo', $item)
            this.submitExplainDialogSet.dialogFormVisible = true
            this.submitExplainDialogSet.type = '项目经理驳回'
            this.submitExplainDialogSet.title = '驳回（' + $item.assertName + '）'
            this.submitExplainDialogSet.isNeedProblemAttribution = false
            this.submitExplainDialogSet.formData = [
              {
                label: '提交审核说明：',
                isText: true,
                value: data.data.reason
              },
              {
                label: '重打整包渠道：',
                isText: true,
                value: this.getChannelNameConfig(data.data.gameChannelConfigs)
              },
              {
                label: '问题归属：',
                isText: true,
                value: data.data.problemType ? data.data.problemType : '--'
              },
              {
                label: '驳回原因：',
                isText: false,
                value: ''
              }
            ]
            this.submitExplainDialogSet.submitCallbackFun = this.rejectCallback
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      //  送检次数
      checkTimeDialogShow ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.checkTimeDialogSet.dialogCurrentTitle = $item.assertName
        this.checkTimeDialogSet.dialogFormVisible = true
      },
      // 游戏下载
      downloadPackage ($index, $item, $data) {
        let downLoadStatus = ['20', '25', '26', '30', '31', '35', '40']
        planApi.getPackRecordInfo($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            if ($item.appstore) {
              this.optionDownFileItemV1.isChannelDownload = false
              this.optionDownFileItemV1.downLoadPath = data.data.cUrl
              this.optionDownFileItemV1.resourceName = data.data.resourceName || ''
              this.optionDownFileItemV1.appstoreName = data.data.appstoreName || ''
              if (downLoadStatus.indexOf(data.data.cStatus) >= 0 && data.data.cUrl) {
                this.optionDownFileDialogV1.dialogCurrentTitle = $item.assertName
                this.optionDownFileDialogV1.dialogVisible = true
              } else {
                this.$alert('暂无下载的游戏包', '提示', {
                  confirmButtonText: '确定'
                })
              }
            } else {
              this.optionDownFileItem.isChannelDownload = false
              this.optionDownFileItem.downLoadPath = data.data.cUrl
              this.optionDownFileItem.resourceName = data.data.resourceName || ''
              this.optionDownFileItem.appstoreName = data.data.appstoreName || ''
              if (downLoadStatus.indexOf(data.data.cStatus) >= 0 && data.data.cUrl) {
                this.optionDownFileDialog.dialogCurrentTitle = $item.assertName
                this.optionDownFileDialog.dialogVisible = true
              } else {
                this.$alert('暂无下载的游戏包', '提示', {
                  confirmButtonText: '确定'
                })
              }
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
          this.searchDataList()
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
          this.searchDataList()
        })
      },
      buglyDownload ($index, $item, $data) {
        window.location.href = $item.buglyUrl
      },
      // 通过，切至下一个状态
      nextStatus (iPlanChannelId, cStatus) {
        planApi.updateDataStatus(iPlanChannelId, 1, cStatus).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 提交质检回调
      commitQACallback (explainData) {
        this.submitExplainDialogSet.dialogFormVisible = false
        let params = {
          channelIds: '',
          iPlanChannelId: this.planChannelInfo.iPlanChannelId,
          iProblemType: explainData.iProblemType,
          sDesc: explainData.reason
        }
        planApi.commitQualityTest(this.planChannelInfo.cStatus, this.planChannelInfo.iPlanChannelId, params).then((data) => {
          if (data.code === 1) {
            this.searchDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 提交质检
      commitQA ($index, $item, $data) {
        this.submitExplainDialogSet.dialogFormVisible = true
        this.submitExplainDialogSet.type = '提交质检'
        this.submitExplainDialogSet.title = '提交质检（' + $item.assertName + '）'
        if ($item.packNum > 0) {
          this.submitExplainDialogSet.isNeedProblemAttribution = true
        } else {
          this.submitExplainDialogSet.isNeedProblemAttribution = false
        }
        this.submitExplainDialogSet.formData = []
        if ($item.iUserId !== this.userId) {
          this.submitExplainDialogSet.formData.push(
            {
              label: '操作提醒：',
              isText: true,
              value: '<span style="color:red;">提交质检人员与打包人员不一致</span>'
            }
          )
        }
        this.submitExplainDialogSet.formData.push(
          {
            label: '更新说明：',
            isText: false,
            value: '',
            placeholderText: '提示：提交质检时，请输入修复bugid以及简单说明！'
          }
        )
        this.submitExplainDialogSet.submitCallbackFun = this.commitQACallback
        this.$store.dispatch('planChannelInfo', $item)
      },
      // 查看配置详情
      showPackConfig ($index, $item, $data) {
        this.$store.dispatch('planChannelInfo', $item)
        this.showPackConfigDataDialogSet.dialogCurrentTitle = $item.assertName
        this.showPackConfigDataDialogSet.iGamePackId = $item.iGamePackId
        this.showPackConfigDataDialogSet.dialogFormVisible = true
      },
      // 通过
      checkPass ($index, $item, $data) {
        const title = '提示（' + $item.assertName + '）'
        this.$confirm('是否确定通过?', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.nextStatus($item.iPlanChannelId, $item.cStatus)
        }).catch(() => {
        })
      },
      // 项目经理通过
      managerCheckPassCallback () {
        this.nextStatus(this.planChannelInfo.iPlanChannelId, this.planChannelInfo.cStatus)
        this.submitExplainDialogSet.dialogFormVisible = false
      },
      managerCheckPass ($index, $item, $data) {
        planApi.getQualityDescChannels($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.$store.dispatch('planChannelInfo', $item)
            this.submitExplainDialogSet.dialogFormVisible = true
            this.submitExplainDialogSet.type = '项目经理通过'
            this.submitExplainDialogSet.title = '通过（' + $item.assertName + '）'
            this.submitExplainDialogSet.isNeedProblemAttribution = false
            this.submitExplainDialogSet.formData = [
              {
                label: '提交审核说明：',
                isText: true,
                value: data.data.reason
              },
              {
                label: '重打整包渠道：',
                isText: true,
                value: this.getChannelNameConfig(data.data.gameChannelConfigs)
              },
              {
                label: '问题归属：',
                isText: true,
                value: data.data.problemType ? data.data.problemType : '--'
              }
            ]
            this.submitExplainDialogSet.submitCallbackFun = this.managerCheckPassCallback
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      // 排队中的重新打包
      lineAnewPack ($index, $item, $data) {
        const title = '提示（' + $item.assertName + '）'
        this.$confirm('是否确定重新打包?', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 重新打包请求
          planApi.lineAgainPackGamePackage($item.iPlanChannelId, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                confirmButtonText: '确定'
              })
              this.searchDataList()
            } else if (data.code === 1100) {
              this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
                confirmButtonText: '确定'
              })
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 重新打包
      anewPack ($index, $item, $data) {
//        提示
        const title = '提示（' + $item.assertName + '）'
        this.$confirm('是否确定重新打包?', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 重新打包请求
          planApi.againPackGamePackage($item.iPlanChannelId, 1, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.$alert('系统已收到您的打包请求，请耐心等待!', '提示', {
                confirmButtonText: '确定'
              })
              this.searchDataList()
            } else if (data.code === 1100) {
              this.$alert('该资源还没有配置打包渠道，请联系sdk部门接入后再打包!', '提示', {
                confirmButtonText: '确定'
              })
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      revocationReject ($index, $item, $data) {
        const title = '提示（' + $item.assertName + '）'
        this.$confirm('是否确定执行撤销操作?', title, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          planApi.putPlanRevocationReject($item.iPlanChannelId, $item.cStatus).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '操作失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert('请求失败，请稍后重试！', '提示', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
        })
      },
      // 查看原因
      viewReason ($index, $item, $data) {
        planApi.getRejectReason($item.iPlanChannelId).then((data) => {
          if (data.code === 1) {
            this.viewRejectReasonDialogSet.dialogFormVisible = true
            this.viewRejectReasonDialogSet.dialogCurrentTitle = $item.assertName
            this.viewRejectReasonContent = data.data
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
//      选择渠道
      chooseChannel ($index, $item, $data) {
        this.anewChooseChannelDialogSet.dialogFormVisible = true
        this.anewChooseChannelDialogSet.dialogCurrentTitle = $item.assertName
        this.anewChooseChannelDialogSet.currentStatus = $item.cStatus
        this.anewChooseChannelContent = {
          iPlanChannelId: $item.iPlanChannelId,
          channelArrayIds: [],
          channelIds: '',
          sDesc: ''
        }
      },
      getChannelNameConfig (gameChannelConfigs) {
        if (gameChannelConfigs && gameChannelConfigs.length > 0) {
          let channelNames = []
          for (let cItem of gameChannelConfigs) {
            channelNames.push(cItem.channelName)
          }
          return channelNames.join(',')
        } else {
          return '无'
        }
      },
      // 状态汉字显示
      getStatusCharacter (status) {
        return planUtil.getPlanStatus(status, 1)
      }
    }
  }
</script>
