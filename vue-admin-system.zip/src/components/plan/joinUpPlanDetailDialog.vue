<style>
  .option-dialog-plan-detail .el-dialog{
    width: 700px;
  }
</style>
<template>
  <div>
    <el-dialog :title="optionData.title"
               :visible.sync="optionData.dialogFormVisible"
               class="option-dialog option-dialog-plan-detail">
      <div class="content-list">
        <el-table :data="optionData.planDataList" stripe>
          <el-table-column prop="pluginName" label="游项目名称"></el-table-column>
          <el-table-column prop="channelVersion" label="游戏版本"></el-table-column>
          <el-table-column prop="pluginType" label="计划名称"></el-table-column>
          <el-table-column label="操作" width="100">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="planDetailFun(scope.$index, scope.row)">计划详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" type="primary" @click="optionData.dialogFormVisible = false">关  闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default{
    components: {
    },
    props: ['optionData'],
    data () {
      return {
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {
    },
    methods: {
      planDetailFun ($index, $item) {
      }
    }
  }
</script>
