/**
 * Created by huangjinbiao on 2017/7/5.
 */
// pageInfo
export const PAGE_NUMBER = 50

// 数据字典别名列表
export const DICTS_TYPE_LIST = {
  area: 'area', // 地区
  plugintype: 'plugintype', // 插件类型
  language: 'language', // 语言
  platform: 'platform', // 平台
  packStatus: 'packstatus', // 安装包打包状态
  orientation: 'orientation', // 屏幕方向（用于分辨率）
  androidIconResolution: 'androidIconResolution', // 安卓icon分辨率
  iosIconResolution: 'iosIconResolution', // 苹果icon分辨率
  androidSplashResolution: 'androidSplashResolution', // 安卓闪屏分辨率
  iosSplashResolution: 'iosSplashResolution', // 苹果闪屏分辨率
  screenStretching: 'screenStretching', // 屏幕拉伸策略
  statusBar: 'statusBar', // 状态栏
  orientationForPack: 'orientationForPack', // 屏幕方向（用于游戏打包配置）
  iosSystemVersion: 'iosSystemVersion', // IOS系统版本
  shareSwitch: 'share_switch', // '分享开关',
  problemAttribution: 'problemAttribution' // '问题归属'
}

// 地区列表
export const ARER_LIST = [
  {
    name: '大陆地区',
    value: '大陆地区'
  },
  {
    name: '北美地区',
    value: '北美地区'
  },
  {
    name: '台湾地区',
    value: '台湾地区'
  },
  {
    name: '新马地区',
    value: '新马地区'
  }
]

// 平台列表
export const PLATFORM_LIST = [
  {
    name: '安卓',
    value: 1
  },
  {
    name: 'IOS',
    value: 0
  }
]

// 语言
export const LANGUAGR_LIST = [
  {
    name: '中文简体',
    value: '中文简体'
  },
  {
    name: '中文繁体',
    value: '中文繁体'
  },
  {
    name: '英文',
    value: '英文'
  }
]

// ICON数据列表
export const ICON_DPI_LIST = [
  {
    dpi: '36*36',
    url: ''
  },
  {
    dpi: '48*48',
    url: ''
  },
  {
    dpi: '72*72',
    url: ''
  },
  {
    dpi: '96*96',
    url: ''
  },
  {
    dpi: '144*144',
    url: ''
  }
]

  // 图片数据列表
export const IMAGES_DPI_LIST = [
  {
    dpi: '480*480',
    screen: '竖屏',
    url: ''
  },
  {
    dpi: '640*960',
    screen: '竖屏',
    url: ''
  },
  {
    dpi: '768*1024',
    screen: '竖屏',
    url: ''
  },
  {
    dpi: '640*1136',
    screen: '竖屏',
    url: ''
  },
  {
    dpi: '1536*1136',
    screen: '竖屏',
    url: ''
  },
  {
    dpi: '480*480',
    screen: '横屏',
    url: ''
  },
  {
    dpi: '640*960',
    screen: '横屏',
    url: ''
  },
  {
    dpi: '768*1024',
    screen: '横屏',
    url: ''
  },
  {
    dpi: '640*1136',
    screen: '横屏',
    url: ''
  },
  {
    dpi: '1536*1136',
    screen: '横屏',
    url: ''
  }
]

