/**
 * auth true登录才能访问，false不需要登录，默认true
 */
export default [
  { path: '*', component: resolve => require(['../modules/login/'], resolve) },
  {
    path: '/login',
    meta: {auth: false},
    component: resolve => require(['../modules/login/'], resolve)
  },
  {
    path: '/',
    meta: {auth: false},
    redirect: '/login'
  },
  {
    path: '/home',
    meta: {auth: true},
    component: resolve => require(['../modules/home/'], resolve),
    children: [
      {
        path: 'pack/tool',
        meta: {auth: true},
        component: resolve => require(['../modules/pack/tool'], resolve)
      },
      {
        path: 'pack/install',
        meta: {auth: true},
        component: resolve => require(['../modules/pack/install'], resolve)
      },
      {
        path: 'project/list',
        meta: {auth: true},
        component: resolve => require(['../modules/game/project-list'], resolve)
      },
      {
        path: 'project/list/operator',
        meta: {auth: true},
        component: resolve => require(['../modules/game/project-operator'], resolve)
      },
      {
        path: 'game/list',
        meta: {auth: true},
        component: resolve => require(['../modules/game/list'], resolve)
      },
      {
        path: 'game/subcribe/list',
        meta: {auth: true},
        component: resolve => require(['../modules/game/game-subcribe'], resolve)
      },
      {
        path: 'game/list/config/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/game/config-list'], resolve)
      },
      {
        path: 'game/list/assets/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/game/assets-list'], resolve)
      },
      {
        path: 'game/list/assets/channel/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/game/assets-channel-list'], resolve)
      },
      {
        path: 'game/list/version/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/game/version-list'], resolve)
      },
      {
        path: 'channel/list',
        meta: {auth: true},
        component: resolve => require(['../modules/channel/list'], resolve)
      },
      {
        path: 'channel/list/version/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/channel/version-list'], resolve)
      },
      {
        path: 'plugin/list',
        meta: {auth: true},
        component: resolve => require(['../modules/plugin/list'], resolve)
      },
      {
        path: 'plugin/list/version/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/plugin/version-list'], resolve)
      },
      {
        path: 'agency/list',
        meta: {auth: true},
        component: resolve => require(['../modules/agency/list'], resolve)
      },
      {
        path: 'engine/list',
        meta: {auth: true},
        component: resolve => require(['../modules/engine/list'], resolve)
      },
      {
        path: 'ioscert/list',
        meta: {auth: true},
        component: resolve => require(['../modules/ioscert/list'], resolve)
      },
      {
        path: 'project/list',
        meta: {auth: true},
        component: resolve => require(['../modules/project/list'], resolve)
      },
      {
        path: 'project/list/channel',
        meta: {auth: true},
        component: resolve => require(['../modules/project/channel-list'], resolve)
      },
      {
        path: 'user/account/list',
        meta: {auth: true},
        component: resolve => require(['../modules/user/user-account'], resolve)
      },
      {
        path: 'user/account/setting',
        meta: {auth: true},
        component: resolve => require(['../modules/user/account-setting'], resolve)
      },
      {
        path: 'user/role/list',
        meta: {auth: true},
        component: resolve => require(['../modules/user/user-role'], resolve)
      },
      {
        path: 'user/role/setting',
        meta: {auth: true},
        component: resolve => require(['../modules/user/role-setting'], resolve)
      },
      {
        path: 'user/role/inform',
        meta: {auth: true},
        component: resolve => require(['../modules/user/role-rtx-inform'], resolve)
      },
      {
        path: 'user/menu/list',
        meta: {auth: true},
        component: resolve => require(['../modules/user/user-menu'], resolve)
      },
      {
        path: 'user/menu/operation/list',
        meta: {auth: true},
        component: resolve => require(['../modules/user/menu-operation'], resolve)
      },
      {
        path: 'dictionary/list',
        meta: {auth: true},
        component: resolve => require(['../modules/dictionary/list'], resolve)
      },
      {
        path: 'pack/rule/list',
        meta: {auth: true},
        component: resolve => require(['../modules/pack-rule/list'], resolve)
      },
      {
        path: 'plugin/config/list',
        meta: {auth: true},
        component: resolve => require(['../modules/plugin/config-list'], resolve)
      },
      {
        path: 'plan/list',
        meta: {auth: true},
        component: resolve => require(['../modules/plan/list'], resolve)
      },
      {
        path: 'plan/list/progress',
        meta: {auth: true},
        component: resolve => require(['../modules/plan/progress-list'], resolve)
      },
      {
        path: 'plan/option/:type',
        meta: {auth: true},
        component: resolve => require(['../modules/plan/plan-option'], resolve)
      },
      {
        path: 'plan/channel/summary',
        meta: {auth: true},
        component: resolve => require(['../modules/plan/channel-summary'], resolve)
      },
      {
        path: 'pack/machine/list',
        meta: {auth: true},
        component: resolve => require(['../modules/pack/machine'], resolve)
      },
      {
        path: 'manager/system/log',
        meta: {auth: true},
        component: resolve => require(['../modules/manager/system-log'], resolve)
      },
      {
        path: 'manager/file/log',
        meta: {auth: true},
        component: resolve => require(['../modules/manager/file-log'], resolve)
      }
    ]
  }
]
