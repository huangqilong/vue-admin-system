/**
 * Created by huangjinbiao on 2017/7/10.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/sysDicts/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/sysDicts', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/sysDicts', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/sysDicts', params)
  },
  // 根据字典类别获取系统数据字典列表
  getDictsByType (dictType) {
    return request.get(PROXY_DEV_API + '/sysDicts/dictType/' + dictType)
  },
  // 获取游戏图片资源
  getGamePicRess (platformType, source) {
    return request.get(PROXY_DEV_API + '/gamePicRess/platform/' + platformType + '/source/' + source)
  },
  // 获取插件配置参数, 逗号分割
  getPluginDictIdList (pluginDictId) {
    return request.get(PROXY_DEV_API + '/productChannelPlugins/params/' + pluginDictId)
  }
}
