/**
 * Created by huangjinbiao on 2017/7/13.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/sdkMiddleareConfigs/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/sdkMiddleareConfigs', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/sdkMiddleareConfigs', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/sdkMiddleareConfigs', params)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/sdkMiddleareConfigs/' + id + '/status/' + status)
  },
  // 平台分类数据列表
  getPlatDataList (platformType, platform, assertType) {
    if (platformType === 'ios') {
      return request.get(PROXY_DEV_API + '/sdkMiddleareConfigs/platform/' + platform)
    } else {
      return request.get(PROXY_DEV_API + '/sdkMiddleareConfigs/platform/' + platform + '/' + assertType)
    }
  },
  // 获取关联游戏信息接口
  getRelevanceGameDataList (middleareId) {
    return request.get(PROXY_DEV_API + '/sdkMiddleareGameConfigs/middleareId/' + middleareId)
  },
  // 提交关联游戏信息接口
  addRelevanceGameDataList (params) {
    return request.post(PROXY_DEV_API + '/sdkMiddleareGameConfigs', params)
  },
  // 获取渠道游戏介入数
  getAgencyGameDataList (platfrom, imiddleaid) {
    return request.get(PROXY_DEV_API + '/sdkMiddleareConfigs/platfrom/' + platfrom + '/imiddleaid/' + imiddleaid)
  }
}
