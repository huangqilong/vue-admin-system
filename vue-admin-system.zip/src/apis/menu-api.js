/**
 * Created by huangjinbiao on 2017/8/7.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/sysMenus/' + id)
  },
  // 数据列表
  getDataList () {
    return request.get(PROXY_DEV_API + '/sysMenus')
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/sysMenus', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/sysMenus', params)
  },
  // 数据删除
  deleteDataInfo (id) {
    return request.delete(PROXY_DEV_API + '/sysMenus/' + id)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/sysMenus/' + id + '/status/' + status)
  },
  // 获取父节点下面所有自子节点
  getChildrenDataList (id) {
    return request.get(PROXY_DEV_API + '/sysMenus/children/' + id)
  },
  // 所有数据列表
  getAllDataList () {
    return request.get(PROXY_DEV_API + '/sysMenus/all')
  },
  // 设置menu权限
  setRoleMenu (params) {
    return request.post(PROXY_DEV_API + '/SysRoleMenu/menus', params)
  },
  // 获取选中的菜单数据
  getSelectMenuDataList (id) {
    return request.get(PROXY_DEV_API + '/SysRoleMenu/' + id + '/access')
  },
  // 获取选中的左栏菜单列表
  getSelectLeftMenuDataList (id) {
    return request.get(PROXY_DEV_API + '/SysRoleMenu/' + id + '/menus')
  }
}
