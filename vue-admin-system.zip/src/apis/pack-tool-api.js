/**
 * Created by huangjinbiao on 2017/8/4.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 获取打包游戏项目列表
  getPackGameDataList (params) {
    return request.get(PROXY_DEV_API + '/gameProjects/list', params)
  },
  // 获得打包游戏版本列表
  getPackGameVersionDataList (projectId, platformType) {
    return request.get(PROXY_DEV_API + '/gameProjects/version/project/' + projectId + '/platform/' + platformType + '/list')
  },
  // 获得打包游戏资源列表
  getPackGameAssetsDataList (gameAssertId, platformType, versionType) {
    return request.get(PROXY_DEV_API + '/gameProjectAssets/' + gameAssertId + '/platform/' + platformType + '/assert/' + versionType + '/list')
  },
  // 获取打包渠道列表
  getPackGameChannelDataList (platformType, iProjectAssetId) {
    return request.get(PROXY_DEV_API + '/gameChannels/platform/' + platformType + '/project/assert/' + iProjectAssetId + '/list')
  },
  // 获取渠道下打包插件列表
  getPackGamePluginDataList (channelId, platformType) {
    return request.get(PROXY_DEV_API + '/gamePlugins/channel/' + channelId + '/platform/' + platformType + '/list')
  },
  // 获取打包游戏项目信息
  getPackGameDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gamePackResources/' + id)
  },
  // 分页查询游戏打包安装表
  getPackGameResourceDataList (optionType, params) {
    if (optionType === 'sdkRuleInstall') {
      return request.get(PROXY_DEV_API + '/gamePackResources', params)
    } else {
      return request.get(PROXY_DEV_API + '/gamePackCpsAdResources', params)
    }
  },
  // Cps Dev打包接口
  postCPSOrAdvPackGameResource (params) {
    return request.post(PROXY_DEV_API + '/gamePackCpsAdResources', params)
  },
  // 获取广告打包插件列表
  getAdvPackGamePluginDataList (ipackid) {
    return request.get(PROXY_DEV_API + '/gamePackCpsAdResources/' + ipackid + '/gamePlugins')
  },
  // 添加游戏打包安装表
  postPackGameResource (platformType, packroletype, params) {
    return request.post(PROXY_DEV_API + '/gamePackResources/platform/' + platformType + '/packroletype/' + packroletype, params)
  },
  // 重新打包
  postAgainPackGameResource (gamePackId, platformType, packroletype) {
    return request.put(PROXY_DEV_API + '/gamePackResources/' + gamePackId + '/platform/' + platformType + '/packroletype/' + packroletype)
  },
  // SDK打包获取渠道列表
  getSDKPackGameChannelDataList (platform, language, area) {
    return request.get(PROXY_DEV_API + '/gameChannels/sdkpack/platform/' + platform + '/language/' + language + '/area/' + area)
  },
  // 根据渠道获取游戏列表
  getSDKPackGameDataList (platform, channelid) {
    return request.get(PROXY_DEV_API + '/gameChannels/sdkpack/platform/' + platform + '/channelid/' + channelid)
  },
  // 获取打包游戏配置信息
  getPackGameConfigDataInfo (platform, ipackid) {
    return request.get(PROXY_DEV_API + '/gameChannels/platform/' + platform + '/configuration/' + ipackid)
  },
  // 获取打包失败的原因
  getPackFailureInfo (id) {
    return request.get(PROXY_DEV_API + '/gamePackResources/log/' + id)
  },
  // 删除打包记录
  deletePackGameDataInfo (id, type) {
    if (type === 0) {
      return request.delete(PROXY_DEV_API + '/gamePackResources/' + id)
    } else {
      return request.delete(PROXY_DEV_API + '/gamePackCpsAdResources/' + id)
    }
  },
  // 获取cps adv 的记录
  getCpsAdvPackInfo (id) {
    return request.get(PROXY_DEV_API + '/gamePackCpsAdResources/ipackedid/' + id)
  },
  // 获取打包服务器记录
  gamePackServerLogs (params) {
    return request.get(PROXY_DEV_API + '/gamePackServerLogs', params)
  },
  // bugly上传操作
  addBuglySymbol (id) {
    return request.post(PROXY_DEV_API + '/gamePackResources/buglySymbol/' + id)
  }
}
