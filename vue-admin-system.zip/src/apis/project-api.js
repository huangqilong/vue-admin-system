/**
 * Created by huangjinbiao on 2017/7/13.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/gameAssetsConfigs/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/gameAssetsConfigs', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/gameAssetsConfigs', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/gameAssetsConfigs', params)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/gameAssetsConfigs/' + id + '/status/' + status)
  },
  // 游戏工程的渠道数据信息
  getChannelDataInfo (id) {
    return request.get(PROXY_DEV_API + '/androidGamePackages/' + id)
  },
  // 获取游戏工程的渠道列表
  getChannelDataList (projectCode, params) {
    return request.get(PROXY_DEV_API + '/androidGamePackages/projectCode/' + projectCode, params)
  },
  // 新增游戏工程的渠道数据
  addChannelDataInfo (params) {
    return request.post(PROXY_DEV_API + '/androidGamePackages', params)
  },
  // 修改游戏工程的渠道数据
  updateChannelDataInfo (params) {
    return request.put(PROXY_DEV_API + '/androidGamePackages', params)
  },
  // 游戏工程的渠道数据状态修改
  updateChannelDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/androidGamePackages/' + id + '/status/' + status)
  }
}
