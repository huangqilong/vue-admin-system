import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default{
  // 获取列表数据
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/sysUsers', params)
  },
  getAllDataList () {
    return request.get(PROXY_DEV_API + '/sysUsers/all')
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/sysUser', params)
  },
  // 修改数据
  updateDataInfo (id, params) {
    return request.put(PROXY_DEV_API + '/sysUser/' + id, params)
  },
  // 删除数据
  deleteDataInfo (id) {
    return request.delete(PROXY_DEV_API + '/sysUser/' + id)
  },
  // 用户状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/sysUser/' + id + '/status/' + status)
  },
  getAllAccessData (id, params) {
    return request.get(PROXY_DEV_API + '/sysAccess/' + id, params)
  },
  addAccountSetData (id, params) {
    return request.put(PROXY_DEV_API + '/sysAccess/' + id, params)
  },
   // 角色查询条件
  getRoleDataList (params) {
    return request.get(PROXY_DEV_API + '/sysRoles', params)
  },
  getRtxUserDataList () {
    return request.get(PROXY_DEV_API + '/user/org/list')
  }
}
