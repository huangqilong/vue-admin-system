/**
 * Created by huangjinbiao on 2017/7/13.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/iosCertConfigs/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/iosCertConfigs', params)
  },
  // 数据下拉框列表
  getDropDownDataList () {
    return request.get(PROXY_DEV_API + '/iosCertConfigs/list')
  },
  // 数据分类下拉框列表
  getTypeDropDownDataList (type) {
    return request.get(PROXY_DEV_API + '/iosCertConfigs/type/' + type)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/iosCertConfigs', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/iosCertConfigs', params)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/iosCertConfigs/' + id + '/status/' + status)
  }
}
