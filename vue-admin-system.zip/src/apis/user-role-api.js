/**
 * Created by huangjinbiao on 2017/8/3.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/sysRoles/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/sysRoles', params)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/sysRoles', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/sysRoles', params)
  },
  // 删除数据信息
  deleteDataInfo (id) {
    return request.delete(PROXY_DEV_API + '/sysRoles/' + id)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/sysRoles/' + id + '/status/' + status)
  },
  // 获取角色信息列表
  getRoleRtxInformDataList (id) {
    return request.get(PROXY_DEV_API + '/sysRoleMessages/roleid/' + id)
  },
  // 获取计划订阅人员信息列表
  getSubcribeRtxInformDataList (id) {
    return request.get(PROXY_DEV_API + '/sysRoleMessages/iplansubcribeid/' + id)
  },
  // 提交角色信息
  putRoleRtxInformData (params) {
    return request.put(PROXY_DEV_API + '/sysRoleMessages', params)
  }
}
