/**
 * Created by huangjinbiao on 2018/1/11.
 */
import request from '../utils/request'
import {PROXY_DEV_API} from './api-type'

export default {
  // 数据信息
  getDataInfo (id) {
    return request.get(PROXY_DEV_API + '/packMachines/' + id)
  },
  // 数据列表
  getDataList (params) {
    return request.get(PROXY_DEV_API + '/packMachines', params)
  },
  getDataListForPlatform (id) {
    return request.get(PROXY_DEV_API + '/packMachines/platformid/' + id)
  },
  // 新增数据
  addDataInfo (params) {
    return request.post(PROXY_DEV_API + '/packMachines', params)
  },
  // 修改数据
  updateDataInfo (params) {
    return request.put(PROXY_DEV_API + '/packMachines', params)
  },
  // 数据状态修改
  updateDataStatus (id, status) {
    return request.put(PROXY_DEV_API + '/packMachines/' + id + '/status/' + status)
  }
}
