
import {LOGIN_IN, LOGIN_OUT} from '../mutation-types'

// initial state
const state = {
  cookie: {
    userName: '',
    userId: '',
    tokens: '',
    cRealName: '',
    roleName: '',
    userLoginInfo: {
      userName: '',
      password: ''
    }
  },
  local: {
    headersFile: null
  }
}

// getters
const getters = {
  userName: state => state.cookie.userName,
  tokens: state => state.cookie.tokens,
  userId: state => state.cookie.userId,
  cRealName: state => state.cookie.cRealName,
  roleName: state => state.cookie.roleName,
  userLoginInfo: state => state.cookie.userLoginInfo,
  headersFile: state => state.local.headersFile
}

// actions
const actions = {
  login ({commit, state}, data) {
    commit(LOGIN_IN, data)
  },
  logout ({commit}) {
    commit(LOGIN_OUT)
  }
}

// mutations
const mutations = {
  [LOGIN_IN] (state, data) {
    state.cookie.userName = data.cUserName
    state.cookie.tokens = data.jwtToken
    state.cookie.userId = data.iUserId
    state.cookie.cRealName = data.cRealName
    state.cookie.roleName = data.roleName
    state.cookie.userLoginInfo = {
      userName: data.cUserName,
      password: data.password
    }
    state.local.headersFile = {
      jwtToken: data.jwtToken,
      userId: data.iUserId
    }
  },
  [LOGIN_OUT] (state) {
    state.cookie.userName = ''
    state.cookie.tokens = ''
    state.cookie.userId = ''
    state.cookie.cRealName = ''
    state.cookie.roleName = ''
    state.local.headersFile = null
  }
}
// export
export default {
  state,
  getters,
  actions,
  mutations
}
