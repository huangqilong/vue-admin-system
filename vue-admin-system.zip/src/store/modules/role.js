/**
 * Created by huangjinbiao on 2018/1/11.
 */

import {ROLE} from '../mutation-types'

// initial state
const state = {
  local: {
    roleOptionParams: null
  }
}

// getters
const getters = {
  roleOptionParams: state => state.local.roleOptionParams
}

// actions
const actions = {
  setRoleOptionParams ({commit, state}, data) {
    commit(ROLE.ROLE_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [ROLE.ROLE_OPTION_PARAMS] (state, data) {
    state.local.roleOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
