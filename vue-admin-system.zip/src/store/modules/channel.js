/**
 * Created by huangjinbiao on 2018/1/11.
 */

import {CHANNEL} from '../mutation-types'

// initial state
const state = {
  local: {
    channelOptionParams: null
  }
}

// getters
const getters = {
  channelOptionParams: state => state.local.channelOptionParams
}

// actions
const actions = {
  setChannelOptionParams ({commit, state}, data) {
    commit(CHANNEL.CHANNEL_CHANNEL_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [CHANNEL.CHANNEL_CHANNEL_OPTION_PARAMS] (state, data) {
    state.local.channelOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
