/**
 * Created by huangjinbiao on 2018/1/11.
 */

import {ENGINE} from '../mutation-types'

// initial state
const state = {
  local: {
    engineOptionParams: null
  }
}

// getters
const getters = {
  engineOptionParams: state => state.local.engineOptionParams
}

// actions
const actions = {
  setEngineOptionParams ({commit, state}, data) {
    commit(ENGINE.ENGINE_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [ENGINE.ENGINE_OPTION_PARAMS] (state, data) {
    state.local.engineOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
