import {PAGE_NUMBER} from '../../config/common'
import {PROXY_DEV_API} from '../../apis/api-type'
import {COMMON} from '../mutation-types'
import menuApi from '../../apis/menu-api'
import gameApi from '../../apis/game-api'
// initial state
const state = {
  local: {
    menuConfig: [],
    menuChildrenList: [],
    menuAccessList: [],
    breadCrumbDataList: null,
    activeMenuIndex: '',
    searchGameList: [],
    packSystemVersion: '1.0.0'
  },
  pageNumber: PAGE_NUMBER,
  optionParams: null,
  buttonLoading: false,
  proxyDevApi: PROXY_DEV_API,
  currentOptionRoleAuth: '',
  roleAuthority: {
    searchBtn: true, // 查询按钮
    insertBtn: true, // 新增按钮
    statusBtn: true, // 状态按钮
    updateBtn: true, // 编辑按钮
    deleteBtn: true, // 删除按钮
    clickPack: true, // 点击打包按钮
    downLoad: true, // 下载按钮
    downLoadBareFile: true, // 下载母包按钮
    againPack: true, // 重新打包按钮
    revocationRejectBtn: true, // 撤销驳回按钮
    lineAgainPack: true, // 排队中重新打包按钮
    checkCause: true, // 查看原因按钮
    checkLog: true, // 日志按钮
    channelPack: true, // 打渠道码包按钮
    cpsAdvCodeConfig: true, // 广告码配置按钮
    sdkTestPack: true, // SDK测试
    relevanceOperatorConfig: true, // 关联渠道/运营商按钮
    gameTestPack: true, // 游戏测试
    gameInstallPack: true, // 打整包
    // cpsPack: true, // 打cps包按钮
    // advPack: true, // 打广告包按钮
    cdnControlOptionBtn: true, // CDN开启控制按钮
    gameSubcribeConfig: true, // 游戏人员配置按钮
    buglyConfig: true, // bugly配置按钮,上传bugly
    svnSecretKeyConfig: true, // svn密钥配置
    keystoreConfig: true, // 签名配置按钮
    packNameConfig: true, // 包名配置按钮
    iOSPermissionConfig: true, // 权限配置
    packConfig: true, // 打包配置按钮
    versionPage: true, // 版本列表按钮
    assetsPage: true, // 游戏资源配置按钮
    channelPage: true, // 游戏资源渠道配置按钮
    channelSync: true, // 游戏渠道同步按钮
    shareSwitch: true, // 分享开关按钮
    relevancePluginConfig: true, // 关联插件按钮
    channelConfig: true, // 渠道OR插件配置按钮
    showChannelConfig: true, // 查看渠道OR插件配置按钮
    pluginConfig: true, // 插件配置按钮
    relevanceGameConfig: true, // 关联游戏按钮
    insertChildrenBtn: true, // 添加子菜单按钮
    relevanceFunctionConfig: true, // 关联功能按钮
    permissionsBindingConfig: true, // 权限绑定
    rtxInformConfigBtn: true, // 消息配置按钮
    dataListPage: true, // 数据列表界面
    defineParams: true, // 定义参数按钮
    enteringParams: true, // 录入参数按钮
    showParams: true, // 参数查看按钮
    progressBtn: true,   // 进度按钮
    sdkTestAssets: true, // SDK测试资源
    openOrClosePlan: true, // 开启或者关闭计划
    launchPlan: true, // 发起计划按钮
    configDetails: true, // 配置详情按钮
    openEjectReview: true, // 开启审核服按钮
    workOrderOpen: true, // 走工单开启按钮
    workOrderClose: true, // 走工单关闭按钮
    uploadBtn: true, // 上传按钮
    updateSubcribeList: true, // 计划订阅人员修改
    joinUpComplete: true, // 接入完成按钮
    againUpload: true, // 重新上传按钮
    againJoinUp: true, // 重新接入按钮
    againChooseChannel: true, // 母包进度-选择渠道
    commitQA: true, // 提交质检
    QAPass: true, //  质检通过按钮
    channelPass: true, // 渠道通过按钮
    managerPass: true, //  项目经理通过按钮
    rejectBtn: true, // 质检驳回按钮
    channelReject: true, // 渠道驳回按钮
    managerReject: true, // 项目经理驳回按钮
    channelSendCheck: true, // 渠道送审
    channelDownloadUrl: true, // 渠道下载地址
    enterChannelUrl: true, // 录入渠道下载地址
    cdnManualUpload: true, // 手动上传按钮
    gameShortcutConfig: true, // 游戏快捷配置按钮
    cdnDownloadUrl: true, // CDN地址下载按钮
    channelCheckBtn: true, // 渠道检测按钮
    channelCheckExplain: true, // 渠道检测说明按钮
    planBarePackageProgressTab: true, // 计划管理-母包进度Tab
    planChannelPackageProgressTab: true, // 计划管理-渠道进度Tab
    planIntactPackageProgressTab: true, // 计划管理-整包进度Tab
    planAdPackageProgressTab: true, // 计划管理-广告码进度Tab
    planCpsPackageProgressTab: true, // 计划管理-CPS包进度Tab
    planChannelSummary: true, // 计划渠道汇总
    planEventTab: true // 计划事件Tab页
  },
  gameConfigOldDate: '2018-01-31 00:00:00'
}

// getters
const getters = {
  menuConfig: state => state.local.menuConfig,
  activeMenuIndex: state => state.local.activeMenuIndex,
  menuChildrenList: state => state.local.menuChildrenList,
  menuAccessList: state => state.local.menuAccessList,
  breadCrumbDataList: state => state.local.breadCrumbDataList,
  searchGameList: state => state.local.searchGameList,
  packSystemVersion: state => state.local.packSystemVersion,
  pageNumber: state => state.pageNumber,
  optionParams: state => state.optionParams,
  buttonLoading: state => state.buttonLoading,
  proxyDevApi: state => state.proxyDevApi,
  roleAuthority: state => state.roleAuthority,
  currentOptionRoleAuth: state => state.currentOptionRoleAuth,
  gameConfigOldDate: state => state.gameConfigOldDate
}

// actions
const actions = {
  clearCommonLocalData ({commit, state}) {
    commit(COMMON.COM_CLEAR_LOCAL_DATA)
  },
  setPackSystemVersion ({commit, state}, data) {
    commit(COMMON.COM_PACK_SYSTEM_VERSION, data)
  },
  getSearchGameList ({dispatch, commit, state}) {
    gameApi.getSearchDataList().then((data) => {
      if (data.code === 1) {
        commit(COMMON.COM_SEARCH_DATA_LIST, data.data)
      }
    }, (error) => {
      console.log(error)
    })
  },
  getMenusAll ({dispatch, commit, state}) {
    menuApi.getAllDataList().then((data) => {
      if (data.code === 1) {
        commit(COMMON.COM_MENU_CHILDREN_LIST, null)
        dispatch('setMenuChildrenList', data.data)
        commit(COMMON.COM_BREAD_CRUMB_LIST)
        // dispatch('setRoleAuthorityRouter', {routerUrl: '/home/plan/list', tabVal: ''})
      }
    }, (error) => {
      console.log(error)
    })
  },
  getRoleMenusList ({dispatch, commit, state}, roleId) {
    menuApi.getSelectMenuDataList(roleId).then((data) => {
      if (data.code === 1) {
        commit(COMMON.COM_ROLE_DATA_LIST, data.data)
        if (roleId === -1) {
          dispatch('setRoleAuthorityRouter', null)
        } else {
          dispatch('getMenusAll')
        }
      }
    }, (error) => {
      console.log(error)
    })
  },
  getRoleMenus ({dispatch, commit, state}, roleId) {
    menuApi.getSelectLeftMenuDataList(roleId).then((data) => {
      if (data.code === 1) {
        commit(COMMON.COM_MENU_CONFIG_LIST, data.data)
        dispatch('getRoleMenusList', roleId)
      }
    }, (error) => {
      console.log(error)
    })
  },
  setRoleAuthorityRouter ({dispatch, commit, state}, data) {
    if (!data) {
      commit(COMMON.COM_CURRENT_ROUTER_ROLE_AUTH, null)
    } else {
      let curMenuId = 0
      let nextMenuIdArray = []
      let nextClassIdArray = []
      for (let item of state.local.menuChildrenList) {
        if (data.routerUrl === item.cUrl || data.routerUrl === item.cUrl + 'ios' || data.routerUrl === item.cUrl + 'android') {
          curMenuId = item.iMenuId
          if (item.children) {
            for (let mItem of item.children) {
              if (mItem.iParentId === curMenuId) {
                if (mItem.cMenuType === 1) {
                  nextMenuIdArray.push(mItem.iMenuId)
                } else if (mItem.cMenuType === 3) {
                  // 确认当前的分类
                  if (data.tabVal === mItem.cUrl) {
                    nextClassIdArray.push(mItem.iMenuId)
                  }
                }
              }
            }
          }
          break
        }
      }
      commit(COMMON.COM_CURRENT_ROUTER_ROLE_AUTH, {curMenuId: curMenuId, nextMenuIdArray: nextMenuIdArray, nextClassIdArray: nextClassIdArray})
      if (data.routerUrl.indexOf('/home/pack/install') >= 0 || data.routerUrl.indexOf('/home/pack/tool') >= 0) {
        dispatch('setFirstTabValueInit', state.roleAuthority)
      }
    }
  },
  setOptionParams ({commit, state}, params) {
    commit(COMMON.COM_OPTION_PARAMS, params)
  },
  setButtonLoading ({commit, state}, params) {
    commit(COMMON.COM_BUTTON_LOADING, params)
  },
  setMenuChildrenList ({dispatch, commit, state}, dataList) {
    for (let item of dataList) {
      if (item.cMenuType === 0) {
        dispatch('setMenuChildrenList', item.children)
      } else if (item.cMenuType === 1) {
        commit(COMMON.COM_MENU_CHILDREN_LIST, item)
        if (item.children) {
          dispatch('setMenuChildrenList', item.children)
        }
      } else if (item.cMenuType === 3) {
        commit(COMMON.COM_MENU_CHILDREN_LIST, item)
        if (item.children) {
          dispatch('setMenuChildrenList', item.children)
        }
      }
    }
  },
  setCurOptRoleAuth ({commit, state}, params) {
    commit(COMMON.COM_CURR_OPT_ROLE_AUTH, params)
  },
  getMenuActiveIndex ({dispatch, commit, state}, {menus, path}) {
    for (var i = 0; i < menus.length; i++) {
      let menu = menus[i]
      if (menu.children && menu.children.length > 0) {
        dispatch('getMenuActiveIndex', {menus: menu.children, path: path})
      } else {
        if (path.indexOf(menu.cUrl) > -1) {
          commit(COMMON.COM_MENU_ACTIVE_INDEX, menu.iMenuId + '')
        }
      }
    }
  }
}

// mutations
const mutations = {
  [COMMON.COM_CLEAR_LOCAL_DATA] (state) {
    state.local.menuConfig = []
    state.local.menuChildrenList = []
    state.local.menuAccessList = []
    state.local.breadCrumbDataList = null
    state.local.activeMenuIndex = ''
    state.local.searchGameList = []
  },
  [COMMON.COM_PACK_SYSTEM_VERSION] (state, data) {
    state.local.packSystemVersion = data
  },
  [COMMON.COM_SEARCH_DATA_LIST] (state, data) {
    let gameList = []
    for (let item of data) {
      gameList.push({
        gameId: item.gameId,
        gameName: item.gameName
      })
    }
    state.local.searchGameList = gameList
  },
  [COMMON.COM_CURR_OPT_ROLE_AUTH] (state, data) {
    if (data) {
      state.currentOptionRoleAuth = data
    } else {
      state.currentOptionRoleAuth = ''
    }
  },
  [COMMON.COM_MENU_CONFIG_LIST] (state, data) {
    for (let item of data) {
      delete item.cBackMethod
      delete item.cBackUrl
      delete item.cIdentifier
      delete item.cPerms
      delete item.iOrderNum
      delete item.iParentId
      delete item.parentName
      delete item.typeName
      delete item.cMenuName
      delete item.cMenuType
      if (item.children && item.children.length > 0) {
        for (let cItem of item.children) {
          delete cItem.cBackMethod
          delete cItem.cBackUrl
          delete cItem.cIdentifier
          delete cItem.cPerms
          delete cItem.iOrderNum
          delete cItem.iParentId
          delete cItem.parentName
          delete cItem.typeName
          delete cItem.cMenuName
          delete cItem.cMenuType
        }
      }
    }
    state.local.menuConfig = data
  },
  [COMMON.COM_MENU_ACTIVE_INDEX] (state, data) {
    state.local.activeMenuIndex = data
  },
  [COMMON.COM_MENU_CHILDREN_LIST] (state, data) {
    if (data) {
      let item = {
        iParentId: data.iParentId,
        iMenuId: data.iMenuId,
        cUrl: data.cUrl,
        cMenuType: data.cMenuType,
        cMenuName: data.cMenuName,
        children: null
      }
      if (data.children && data.children.length > 0) {
        item.children = []
        for (let cItem of data.children) {
          if (cItem.cMenuType !== 2) {
            item.children.push({
              iParentId: cItem.iParentId,
              iMenuId: cItem.iMenuId,
              cUrl: cItem.cUrl,
              cMenuName: cItem.cMenuName,
              cMenuType: cItem.cMenuType
            })
          }
        }
      }
      state.local.menuChildrenList.push(item)
    } else {
      state.local.menuChildrenList = []
    }
  },
  [COMMON.COM_CURRENT_ROUTER_ROLE_AUTH] (state, data) {
    if (data) {
      for (let rItem in state.roleAuthority) {
        state.roleAuthority[rItem] = false
      }
      for (let item of state.local.menuAccessList) {
        if (item.iParentId === data.curMenuId) {
          if (item.cIdentifier) {
            state.roleAuthority[item.cIdentifier] = true
          }
        }
        if (data.nextMenuIdArray.indexOf(item.iParentId) >= 0) {
          if (item.cMenuName === '数据列表') {
            state.roleAuthority[item.cIdentifier] = true
          }
        }
        if (data.nextClassIdArray.indexOf(item.iParentId) >= 0) {
          state.roleAuthority[item.cIdentifier] = true
        }
      }
    } else {
      for (let rItem in state.roleAuthority) {
        state.roleAuthority[rItem] = true
      }
    }
  },
  [COMMON.COM_ROLE_DATA_LIST] (state, data) {
    for (let item of data) {
      delete item.cBackMethod
      delete item.cBackUrl
      delete item.cIcon
      delete item.cPerms
      delete item.iOrderNum
      delete item.parentName
      delete item.typeName
      if (item.children && item.children.length > 0) {
        for (let cItem of item.children) {
          delete cItem.cBackMethod
          delete cItem.cBackUrl
          delete cItem.cIcon
          delete cItem.cPerms
          delete cItem.iOrderNum
          delete cItem.parentName
          delete cItem.typeName
          delete cItem.children
        }
      }
    }
    state.local.menuAccessList = data
  },
  [COMMON.COM_BREAD_CRUMB_LIST] (state) {
    let breadCrumbPageList = state.local.menuChildrenList
    state.local.breadCrumbDataList = {}
    for (let bItem of breadCrumbPageList) {
      let hasParentMenu = false
      for (let bcItem of breadCrumbPageList) {
        if (bItem.iParentId === bcItem.iMenuId) {
          state.local.breadCrumbDataList[bItem.cUrl] = state.local.breadCrumbDataList[bcItem.cUrl] + ',' + bItem.cMenuName
          hasParentMenu = true
        }
      }
      if (!hasParentMenu) {
        state.local.breadCrumbDataList[bItem.cUrl] = bItem.cMenuName
      }
    }
  },
  [COMMON.COM_OPTION_PARAMS] (state, data) {
    state.optionParams = data
  },
  [COMMON.COM_BUTTON_LOADING] (state, data) {
    if (data) {
      state.buttonLoading = true
    } else {
      state.buttonLoading = false
    }
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
