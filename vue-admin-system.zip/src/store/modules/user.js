/**
 * Created by huangjinbiao on 2018/1/11.
 */

import {USER} from '../mutation-types'

// initial state
const state = {
  local: {
    userOptionParams: null
  }
}

// getters
const getters = {
  userOptionParams: state => state.local.userOptionParams
}

// actions
const actions = {
  setUserOptionParams ({commit, state}, data) {
    commit(USER.USER_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [USER.USER_OPTION_PARAMS] (state, data) {
    state.local.userOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
