/**
 * Created by huangjinbiao on 2018/1/11.
 */

import {AGENCY} from '../mutation-types'

// initial state
const state = {
  local: {
    agencyOptionParams: null
  }
}

// getters
const getters = {
  agencyOptionParams: state => state.local.agencyOptionParams
}

// actions
const actions = {
  setAgencyOptionParams ({commit, state}, data) {
    commit(AGENCY.AGENCY_OPTION_PARAMS, data)
  }
}

// mutations
const mutations = {
  [AGENCY.AGENCY_OPTION_PARAMS] (state, data) {
    state.local.agencyOptionParams = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
