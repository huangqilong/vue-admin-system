/**
 * Created by huangjinbiao on 2017/7/17.
 */

import {PACK} from '../mutation-types'

// initial state
const state = {
  local: {
    packGameInfo: null,
    firstTabValue: 'sdkPackFirst',
    secondTabValue: 'channelPackSecond',
    packNewIds: [],
    isFirstPackCount: false,
    searchPackParam: {
      sdkPack: '',
      rulePack: '',
      channelPack: '',
      cpsPack: '',
      advPack: ''
    },
    packToolParam: {
      sdkPack: '',
      rulePack: '',
      channelPack: ''
    },
    machineOptionParams: null
  },
  firstTabList: ['sdkPackFirst', 'rulePackFirst', 'channelPackFirst'],
  secondTabList: ['channelPackSecond', 'cpsPackSecond', 'advPackSecond']
}

// getters
const getters = {
  packGameInfo: state => state.local.packGameInfo,
  firstTabValue: state => state.local.firstTabValue,
  firstTabList: state => state.firstTabList,
  secondTabValue: state => state.local.secondTabValue,
  secondTabList: state => state.secondTabList,
  packNewIds: state => state.local.packNewIds,
  isFirstPackCount: state => state.local.isFirstPackCount,
  searchPackParam: state => state.local.searchPackParam,
  packToolParam: state => state.local.packToolParam,
  machineOptionParams: state => state.local.machineOptionParams
}

// actions
const actions = {
  setMachineOptionParams ({commit, state}, data) {
    commit(PACK.PACK_MACHINE_OPTION_PARAMS, data)
  },
  setSearchPackParam ({commit, state}, data) {
    commit(PACK.PACK_SEARCH_PARAM, data)
  },
  setPackToolParam ({commit, state}, data) {
    commit(PACK.PACK_TOOL_PARAM, data)
  },
  addPackGameInfo ({commit, state}, data) {
    commit(PACK.PACK_GAME_INFO, data)
  },
  setFirstTabValueInit ({commit, state}, data) {
    let testPack = ['sdkTestPack', 'gameTestPack', 'gameInstallPack']
    for (let fIndex in state.firstTabList) {
      if (state.firstTabList[fIndex] === state.local.firstTabValue && !data[testPack[fIndex]]) {
        let tabType = data.sdkTestPack ? state.firstTabList[0] : (data.gameTestPack ? state.firstTabList[1] : state.firstTabList[2])
        commit(PACK.PACK_TAB_TYPE, tabType)
      }
    }
  },
  setFirstTabValue ({commit, state}, data) {
    commit(PACK.PACK_TAB_TYPE, data)
  },
  setSecondTabValue ({commit, state}, data) {
    commit(PACK.PACK_TAB_TYPE_SECOND, data)
  },
  setPackNewIds ({commit, state}, data) {
    commit(PACK.PACK_NEW_IDS, data)
  },
  setIsFirstPackCount ({commit, state}, data) {
    commit(PACK.PACK_IS_FIRST_PACK, data)
  }
}

// mutations
const mutations = {
  [PACK.PACK_MACHINE_OPTION_PARAMS] (state, data) {
    state.local.machineOptionParams = data
  },
  [PACK.PACK_SEARCH_PARAM] (state, data) {
    state.local.searchPackParam[data.tabType] = data.tabSearchParam
  },
  [PACK.PACK_TOOL_PARAM] (state, data) {
    state.local.packToolParam[data.tabType] = data.tabPackParam
  },
  [PACK.PACK_IS_FIRST_PACK] (state, data) {
    state.local.isFirstPackCount = data
  },
  [PACK.PACK_GAME_INFO] (state, data) {
    state.local.packGameInfo = data
  },
  [PACK.PACK_NEW_IDS] (state, data) {
    state.local.packNewIds = data
  },
  [PACK.PACK_TAB_TYPE] (state, data) {
    state.local.firstTabValue = data
    if (state.local.firstTabValue === 'installFirst') {
      state.local.secondTabValue = 'installSecond'
    }
  },
  [PACK.PACK_TAB_TYPE_SECOND] (state, data) {
    state.local.secondTabValue = data
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
