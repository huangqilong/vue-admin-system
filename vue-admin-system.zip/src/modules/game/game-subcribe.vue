<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn && gameInfo.cDisplay=='0'">配 置</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="selectDataList" border :span-method="subscribeSpanMethod" :default-sort = "{prop: 'cRoleName', order: 'descending'}">
        <el-table-column type="index" label="序号" width="60"></el-table-column>
        <el-table-column prop="cRoleName" label="角色"></el-table-column>
        <el-table-column prop="cRealName" label="真实姓名"></el-table-column>
      </el-table>
    </div>
    <subcribe-list-dialog v-if="optionSubcribeListDataDialog.dialogVisible" :optionData="optionSubcribeListDataDialog"
                          :packSubcribeIdsList="packSubcribeIdsList" :packSubcribeList="packSubcribeList" :optionCallBack="submitSubcribeList"></subcribe-list-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import subcribeListDialog from '../../components/plan/subcribeListDialog'
  let subcribeSpanCount = 0
  export default{
    components: {
      breadCrumbConfig,
      subcribeListDialog
    },
    data () {
      return {
        routerPathList: ['/home/game/list', ''],
        dataList: [],
        selectDataList: [],
        subcribeRoleList: {},
        gameInfo: {
          gameName: '',
          cDisplay: 0
        },
        optionDataDialog: {
          gameInfo: null,
          dialogFormVisible: false
        },
        optionSubcribeListDataDialog: {
          dialogVisible: false
        },
        packSubcribeIdsList: [],
        packSubcribeList: []
      }
    },
    computed: {
      ...mapGetters([
        'roleAuthority'
      ])
    },
    created: function () {
      this.getGameInfo()
      this.getSubcribeDataList()
    },
    methods: {
      getGameInfo () {
        gameApi.getDataInfo(this.$route.query.iProjectId).then((data) => {
          if (data.code === 1) {
            this.gameInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      addDataItem () {
        this.packSubcribeIdsList = []
        this.packSubcribeList = []
        for (let packItem of this.dataList) {
          this.packSubcribeIdsList.push(packItem.iUserId)
          this.packSubcribeList.push({
            name: packItem.cRealName,
            pinyinName: packItem.cUserName,
            type: 1
          })
        }
        this.optionSubcribeListDataDialog.dialogVisible = true
      },
      subscribeSpanMethod ({ row, column, rowIndex, columnIndex }) {
        if (columnIndex === 1) {
          if (rowIndex === 0) {
            subcribeSpanCount = 0
          }
          if ((rowIndex - subcribeSpanCount) % this.subcribeRoleList[row.cRoleName] === 0) {
            if ((rowIndex - subcribeSpanCount) === this.subcribeRoleList[row.cRoleName] - 1) {
              subcribeSpanCount += this.subcribeRoleList[row.cRoleName]
            }
            return {
              rowspan: this.subcribeRoleList[row.cRoleName],
              colspan: 1
            }
          } else {
            if ((rowIndex - subcribeSpanCount) === this.subcribeRoleList[row.cRoleName] - 1) {
              subcribeSpanCount += this.subcribeRoleList[row.cRoleName]
            }
            return {
              rowspan: 0,
              colspan: 0
            }
          }
        }
      },
      getSubcribeDataList () {
        gameApi.getGameSubcribesDataList(this.$route.query.iProjectId).then((data) => {
          if (data.code === 1) {
            this.dataList = data.data
            this.selectDataList = data.data
            this.subcribeRoleList = {}
            for (let item of data.data) {
              if (typeof this.subcribeRoleList[item.cRoleName] === 'undefined') {
                this.$set(this.subcribeRoleList, item.cRoleName, 0)
              }
              this.subcribeRoleList[item.cRoleName]++
            }
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      },
      submitSubcribeList (selectSubcribeDataList) {
        let subParams = {
          dels: '',
          userOrgList: selectSubcribeDataList.userOrgList
        }
        let userNames = selectSubcribeDataList.userNames.join(',')
        let deleteNames = []
        for (let item of this.packSubcribeList) {
          if (userNames.indexOf(item.name) === -1) {
            deleteNames.push(item.pinyinName)
          }
        }
        subParams.dels = deleteNames.join(',')
        gameApi.postGameSubcribesDataList(this.$route.query.iProjectId, subParams).then((data) => {
          if (data.code === 1) {
            this.optionSubcribeListDataDialog.dialogVisible = false
            this.getSubcribeDataList()
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert('请求失败，请稍后重试！', '提示', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
