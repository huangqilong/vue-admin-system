<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>

</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn && gameInfo.cDisplay=='0'">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column label="游戏名称">
          <template scope="scope">
            {{gameInfo.gameName}}
          </template>
        </el-table-column>
        <el-table-column label="游戏版本">
          <template scope="scope">
            {{gameVersionInfo.gameAssetsVersion}}
          </template>
        </el-table-column>
        <el-table-column label="游戏资源">
          <template scope="scope">
            {{gameAssetsInfo.gameAssetsName}}
          </template>
        </el-table-column>
        <el-table-column prop="channelName" label="渠道名称"></el-table-column>
        <el-table-column prop="channelVersion" label="渠道版本"></el-table-column>
        <el-table-column prop="proxyVersion" label="代理版本"></el-table-column>
        <el-table-column
          label="操作" width="220">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.relevancePluginConfig" @click="relevancePlugin(scope.$index, dataList)">关联插件</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.shareSwitch" @click="shareSwitchConfig(scope.$index, dataList)">分享开关</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <configIOSDialog v-if="optionType=='ios'&& optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="iosDataInfoForm" :optionCallBack="searchDataList"></configIOSDialog>
    <configAndroidDialog v-if="optionType!='ios'&& optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="androidDataInfoForm" :optionCallBack="searchDataList"></configAndroidDialog>
    <shareSwitchDialog v-if="shareSwitchDataDialog.dialogVisible" :optionData="shareSwitchDataDialog" :shareSwitchData="shareSwitchData" :selectShareSwitch="selectShareSwitch"></shareSwitchDialog>
    <relevance-plugin-game-channel v-if="relevancePluginDataDialog.dialogFormVisible" :optionData="relevancePluginDataDialog"></relevance-plugin-game-channel>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import configIOSDialog from '../../components/game/configIOSDialog'
  import configAndroidDialog from '../../components/game/configAndroidDialog'
  import shareSwitchDialog from '../../components/game/shareSwitchDialog'
  import relevancePluginGameChannel from '../../components/game/relevancePluginGameChannel'
  export default{
    components: {
      breadCrumbConfig,
      pagination,
      configIOSDialog,
      configAndroidDialog,
      shareSwitchDialog,
      relevancePluginGameChannel
    },
    data () {
      return {
        routerPathList: [],
        optionType: '',
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          gameInfo: null,
          dialogFormVisible: false
        },
        iosDataInfoForm: {
          channelName: ''
        },
        shareSwitchData: '',
        shareSwitchDataDialog: {
          title: '',
          dialogVisible: false
        },
        androidDataInfoForm: null,
        dataList: null,
        gameInfo: {
          gameName: '',
          cDisplay: 0
        },
        gameVersionInfo: {
          gameAssetsVersion: ''
        },
        gameAssetsInfo: {
          gameAssetsName: ''
        },
        relevancePluginDataDialog: {
          title: '',
          type: 'gameChannel',
          gameInfo: null,
          projectChannelInfo: null,
          dialogFormVisible: false
        }
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'signatureTypeList', 'iosSystemVersionList', 'roleAuthority', 'gameConfigOldDate'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.optionType = this.$route.params.type || 'android'
      this.routerPathList = [
        '/home/game/list',
        '/home/game/list/version/' + this.optionType + '?iProjectId=' + this.$route.query.iProjectId,
        '/home/game/list/assets/' + this.optionType + '?iProjectId=' + this.$route.query.iProjectId + '&iAssertId=' + this.$route.query.iAssertId,
        ''
      ]
      this.getGameInfo()
      this.getGameVersionInfo()
      this.getGameAssetsInfo()
      this.searchDataList()
    },
    methods: {
      getGameInfo () {
        gameApi.getDataInfo(this.$route.query.iProjectId).then((data) => {
          if (data.code === 1) {
            this.gameInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getGameVersionInfo () {
        gameApi.getVersionDataInfo(this.optionType, this.$route.query.iAssertId).then((data) => {
          if (data.code === 1) {
            this.gameVersionInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getGameAssetsInfo () {
        gameApi.getAssetsDataInfo(this.$route.query.iProjectAssetId).then((data) => {
          if (data.code === 1) {
            this.gameAssetsInfo = data.data
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        gameApi.getConfigDataList(this.optionType, this.$route.query.iProjectAssetId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          }
        }, (error) => {
          console.log(error)
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.gameInfo = this.gameInfo
        this.optionDataDialog.dialogFormVisible = true
        // 初始化游戏ICON和渠道闪屏
        this.$store.dispatch('projectIconListInit', {'platformType': this.optionType === 'ios' ? 1 : 0, 'source': 1})
        if (this.optionType === 'ios') {
          this.iosDataInfoForm = {
            iProjectAssetId: this.gameAssetsInfo.iProjectAssetId,
            iChannelId: '',
            iChannelConfigId: '',
            iMiddleareId: '',
            iCertId: '',
            buglyId: '',
            buglyKey: '',
            bundleId: '',
            cCertType: this.signatureTypeList[0].iDicId,
            minIosVersion: this.iosSystemVersionList[0].iDicId,
            resDirId: '',
            resId: '',
            keystorePath: '',
            extraResPath: '',
            extraResId: '',
            cProjectName: 'BJMPublish',
            buildVersion: '',
//            getiUseAppstore: 0,
            iUseImessage: 0,
            imessageCertId: '',
            imessageBundleId: '',
            imessageResId_pp1: '',
            imessageResId_ppim: '',
            imessageResId_ppim1: '',
            imessageResDirId: '',
            imessagePathPp1: '',
            imessagePathPpim: '',
            imessagePathPpim1: '',
            iosWhiteVOList: [],
            iosUrlSchemeVOList: [],
            iosPlistVOList: [],
            entitlementsVOList: [],
            iconList: [],
            splashList: []
          }
        } else {
          this.androidDataInfoForm = {
            iProjectAssetId: this.gameAssetsInfo.iProjectAssetId,
            iChannelId: '',
            iChannelConfigId: '',
            iMiddleareId: '',
            versionCode: '',
            versionName: '',
            packageName: '',
            keystorePath: '',
            resId: '',
            resDirId: '',
            extraResPath: '',
            extraResId: '',
            keyPassword: '',
            minVersion: '',
            targetVersion: '',
            cDex: '0',
            crcValue: '',
            publicKey: '',
            buglyId: '',
            buglyKey: '',
            iRate: '',
            cMetadata: '0',
            metaData: '0',
            iconList: [],
            splashList: []
          }
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        gameApi.getConfigDataInfo(this.optionType, data[$index].iProjectChannelId).then((data) => {
          if (data.code === 1) {
            const dataInfo = this.optionType === 'ios' ? data.data[0] : data.data
            this.$store.dispatch('updateProjectIconDataList', dataInfo.iconList || [])
            this.$store.dispatch('updateProjectSplashDataList', dataInfo.splashList || [])
            if (this.optionType === 'ios') {
              this.iosDataInfoForm = dataInfo
              this.$set(this.iosDataInfoForm, 'imessagePathPp1', '')
              this.$set(this.iosDataInfoForm, 'imessagePathPpim', '')
              this.$set(this.iosDataInfoForm, 'imessagePathPpim1', '')
            } else {
              this.androidDataInfoForm = dataInfo
            }
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.gameInfo = this.gameInfo
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 关联插件
      relevancePlugin ($index, data) {
        this.relevancePluginDataDialog.title = '关联插件（' + this.dataList[$index].channelName + '）'
        this.relevancePluginDataDialog.projectChannelInfo = this.dataList[$index]
        this.relevancePluginDataDialog.gameInfo = this.gameInfo
        this.relevancePluginDataDialog.dialogFormVisible = true
      },
      shareSwitchConfig ($index, $data) {
        this.$store.dispatch('addGameChannelInfo', this.dataList[$index])
        gameApi.getShareSwitchDataInfo(this.optionType, $data[$index].iProjectChannelId).then((data) => {
          if (data.code === 1) {
            this.shareSwitchData = data.data
            this.shareSwitchDataDialog.title = '分享开关(' + this.dataList[$index].channelName + ')'
            this.shareSwitchDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      selectShareSwitch (params) {
        gameApi.postShareSwitchDataInfo(this.optionType, params).then((data) => {
          if (data.code === 1) {
            this.shareSwitchDataDialog.dialogVisible = false
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }

</script>
