<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="areaName" label="地区" width="100">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.areaName)"></i>{{scope.row.areaName}}
          </template>
        </el-table-column>
        <el-table-column prop="platformName" label="平台" width="80">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.platformName)"></i>{{scope.row.platformName}}
          </template>
        </el-table-column>
        <el-table-column prop="projectName" label="项目名称">
          <template scope="scope">
            <i class="ext-icon-plan-big" :class="getIconClassName(scope.row.projectName)"></i>{{scope.row.projectName ? scope.row.projectName : '--'}}
          </template>
        </el-table-column>
        <el-table-column prop="gameName" label="游戏名称"></el-table-column>
        <el-table-column prop="languageName" label="语言" width="100"></el-table-column>
        <el-table-column prop="cAssertType" label="代理类型" width="80">
          <template scope="scope">
            {{scope.row.cAssertType==gameTypeList[0].iDicId?gameTypeList[0].sDicName:(scope.row.cAssertType==gameTypeList[1].iDicId?gameTypeList[1].sDicName:gameTypeList[2].sDicName)}}
          </template>
        </el-table-column>
        <el-table-column prop="cDisplay" label="状态" :width="80">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="350">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].cDisplay==0?'下架':'上架'}}</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.relevancePluginConfig" @click="relevancePlugin(scope.$index, dataList)">关联插件</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.versionPage" @click="gameVersion(scope.$index, dataList)">版本列表</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.gameSubcribeConfig" @click="gameSubcribeConfig(scope.$index, dataList)">人员配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.buglyConfig" @click="buglyConfig(scope.$index, dataList)">bugly配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.packConfig" @click="gameConfig(scope.$index, dataList)">打包配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.cpsAdvCodeConfig && scope.row.platformName=='安卓'" @click="cpsAdvCodeConfig(scope.$index, dataList)">广告码配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.keystoreConfig && scope.row.platformName=='安卓'" @click="keystoreConfig(scope.$index, dataList)">签名配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.packNameConfig && scope.row.platformName=='安卓'" @click="packNameConfig(scope.$index, dataList)">包名配置</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.iOSPermissionConfig && scope.row.platformName!='安卓'" @click="iOSPermissionConfig(scope.$index, dataList)">权限配置</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
    <configDialog v-if="configDataDialog.dialogVisible" :optionData="configDataDialog"></configDialog>
    <channelPackDialog v-if="optionChannelPackDialog.dialogVisible" :optionData="optionChannelPackDialog"></channelPackDialog>
    <packNameConfigDialog v-if="packNameConfigDataDialog.dialogVisible" :optionData="packNameConfigDataDialog"></packNameConfigDialog>
    <relevancePluginDialog v-if="relevancePluginDataDialog.dialogFormVisible" :optionData="relevancePluginDataDialog"></relevancePluginDialog>
    <ios-permission-dialog v-if="iosPermissionDataDialog.dialogFormVisible" :optionData="iosPermissionDataDialog"></ios-permission-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameApi from '../../apis/game-api'
  import planUtil from '../../utils/plan-util'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import optionForm from '../../components/manager/optionForm'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/game/optionDialog'
  import configDialog from '../../components/game/configDialog'
  import channelPackDialog from '../../components/game/channelPackDialog'
  import packNameConfigDialog from '../../components/game/packNameConfigDialog'
  import relevancePluginDialog from '../../components/game/relevancePlugin'
  import iosPermissionDialog from '../../components/game/iosPermissionDialog'

  export default{
    components: {
      breadCrumbConfig,
      optionForm,
      pagination,
      optionDialog,
      configDialog,
      channelPackDialog,
      packNameConfigDialog,
      relevancePluginDialog,
      iosPermissionDialog
    },
    data () {
      return {
        optionParams: {
          gameName: '',
          areaId: '',
          languageId: '',
          platformId: '',
          gameId: '',
          cDisplay: '0'
        },
        optionData: {
          showGameName: false,
          showArea: true,
          showLanguage: true,
          showPlatform: true,
          showSearchGame: true,
          showDataDisplay: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          title: '',
          type: 'add',
          dialogVisible: false
        },
        configDataDialog: {
          title: '',
          type: 'game',
          gameInfo: null,
          iProjectAssetId: '',
          dialogVisible: false
        },
        packNameConfigDataDialog: {
          title: '',
          gameInfo: null,
          dialogVisible: false
        },
        optionChannelPackDialog: {
          title: '',
          gameInfo: null,
          packCpsAdvInfo: null,
          dialogVisible: false
        },
        relevancePluginDataDialog: {
          title: '',
          gameInfo: null,
          dialogFormVisible: false
        },
        iosPermissionDataDialog: {
          iProjectId: '',
          iProjectAssetId: '',
          title: '',
          type: 'game',
          gameInfo: null,
          dialogFormVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo', 'gameTypeList', 'gameOptionParams'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.gameOptionParams) {
        this.optionParams.gameName = this.gameOptionParams.gameName
        this.optionParams.areaId = this.gameOptionParams.areaId
        this.optionParams.languageId = this.gameOptionParams.languageId
        this.optionParams.platformId = this.gameOptionParams.platformId
        this.optionParams.cDisplay = this.gameOptionParams.cDisplay
      }
      if (this.$route.query.iEngineId) {
        this.searchDataList(this.$route.query.iEngineId)
      } else {
        this.searchDataList()
      }
    },
    methods: {
      // 查询数据列表回调
      searchDataList (iEngineId) {
        let _this = this
        let params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        if (iEngineId) {
          params = {'currentPage': 1, 'number': 9999, iEngineId: iEngineId}
        }
        // 获取数据列表
        gameApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setGameOptionParams', JSON.parse(JSON.stringify(this.optionParams)))
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.title = '新增游戏'
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogVisible = true
        this.dataInfoForm = {
          iItemId: '',
          iAreaId: this.defaultAreaPlatLanInfo.iAreaId,
          iLanguageId: this.defaultAreaPlatLanInfo.iLanguageId,
          iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
          gameName: '',
//          projectName: '',
//          gameId: '',
          projectCode: '',
          serverVersion: '',
          extraSign: '',
          appKey: '',
          resDirId: '',
          extraResPath: '',
          resId: '',
          cAssertType: '0',
          svnUserName: '',
          svnPassword: '',
          svnProjectName: '',
          reviewFlag: 0,
          cdnFlag: 0
        }
      },
      // 编辑数据
      updateDataInfo ($index, $data) {
        gameApi.getDataInfo($data[$index].iProjectId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.title = '编辑游戏（' + $data[$index].gameName + '）'
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $data[$index].iProjectId
          let status = $data[$index].cDisplay === '0' ? '1' : '0'
          gameApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $data[$index].cDisplay = status
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            console.log(error)
          })
        }).catch(() => {
          // 取消操作
        })
      },
      // bugly配置
      buglyConfig ($index, $data) {
        gameApi.getDataInfo($data[$index].iProjectId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.title = 'bugly配置（' + $data[$index].gameName + '）'
            this.optionDataDialog.dialogVisible = true
            this.optionDataDialog.type = 'bugly'
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 签名配置
      keystoreConfig ($index, $data) {
        // 获取签名配置信息
        gameApi.getKeystoreConfigDataInfo($data[$index].iProjectId).then((data) => {
          if (data.code === 1) {
            this.optionDataDialog.title = '签名配置（' + $data[$index].gameName + '）'
            this.optionDataDialog.dialogVisible = true
            this.optionDataDialog.type = 'keystore'
            if (data.data) {
              this.dataInfoForm = data.data
            } else {
              this.dataInfoForm = {
                projectId: $data[$index].iProjectId,
                keystorePath: '',
                resId: '',
                resDirId: '',
                keyPassword: '',
                sDemo: ''
              }
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 打包配置
      gameConfig ($index, $data) {
        this.configDataDialog.dialogVisible = true
        this.configDataDialog.title = '打包配置（' + $data[$index].gameName + '）'
        this.configDataDialog.gameInfo = $data[$index]
      },
      // 包名配置
      packNameConfig ($index, $data) {
        this.packNameConfigDataDialog.title = '包名配置（' + $data[$index].gameName + '）'
        this.packNameConfigDataDialog.gameInfo = $data[$index]
        this.packNameConfigDataDialog.dialogVisible = true
      },
      // 广告码配置
      cpsAdvCodeConfig ($index, $data) {
        // 获取打包记录的csp或广告的历史记录
        // 获取数据列表
        gameApi.getCpsAdvPackInfo($data[$index].iProjectId).then((data) => {
          if (data.code === 1) {
            this.optionChannelPackDialog.title = '广告码配置（' + $data[$index].gameName + '）'
            this.optionChannelPackDialog.gameInfo = $data[$index]
            this.optionChannelPackDialog.packCpsAdvInfo = data.data
            this.optionChannelPackDialog.dialogVisible = true
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 游戏版本
      gameVersion ($index, data) {
        if (this.dataList[$index].platformName === '安卓') {
          this.$router.push({path: '/home/game/list/version/android', query: {iProjectId: this.dataList[$index].iProjectId}})
        } else {
          this.$router.push({path: '/home/game/list/version/ios', query: {iProjectId: this.dataList[$index].iProjectId}})
        }
      },
      gameSubcribeConfig ($index, data) {
        this.$router.push({path: '/home/game/subcribe/list', query: {iProjectId: this.dataList[$index].iProjectId}})
      },
      // 关联插件
      relevancePlugin ($index, $data) {
        this.relevancePluginDataDialog.title = '关联插件（' + $data[$index].gameName + '）'
        this.relevancePluginDataDialog.gameInfo = $data[$index]
        this.relevancePluginDataDialog.dialogFormVisible = true
      },
      // 权限配置
      iOSPermissionConfig ($index, $data) {
        this.iosPermissionDataDialog.iProjectId = $data[$index].iProjectId
        this.iosPermissionDataDialog.title = '权限配置（' + $data[$index].gameName + '）'
        this.iosPermissionDataDialog.dialogFormVisible = true
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>

