<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="projectName" label="项目名称">
          <template scope="scope">
            {{projectDataInfo.projectName}}
          </template>
        </el-table-column>
        <el-table-column prop="areaName" label="地区"></el-table-column>
        <el-table-column prop="languageName" label="语言"></el-table-column>
        <el-table-column prop="platformName" label="平台"></el-table-column>
        <el-table-column prop="operatorName" label="渠道名称"></el-table-column>
        <el-table-column prop="operatorAlias" label="渠道别名"></el-table-column>
        <el-table-column prop="sChannelCode" label="应用ID"></el-table-column>
        <el-table-column
          label="操作" width="100">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <project-operator-insert-dialog v-if="optionInsertDataDialog.dialogVisible" :optionData="optionInsertDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></project-operator-insert-dialog>
    <project-operator-update-dialog v-if="optionUpdateDataDialog.dialogVisible" :optionData="optionUpdateDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></project-operator-update-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import gameProjectApi from '../../apis/game-project-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import optionForm from '../../components/manager/optionForm'
  import pagination from '../../components/manager/pagination'
  import projectOperatorInsertDialog from '../../components/game/projectOperatorInsertDialog'
  import projectOperatorUpdateDialog from '../../components/game/projectOperatorUpdateDialog'

  export default{
    components: {
      breadCrumbConfig,
      optionForm,
      pagination,
      projectOperatorInsertDialog,
      projectOperatorUpdateDialog
    },
    data () {
      return {
        routerPathList: ['/home/project/list', ''],
        optionParams: {
          operatorName: '',
          areaId: '',
          languageId: '',
          platformId: ''
        },
        optionData: {
          showOperatorName: true,
          showArea: true,
          showLanguage: true,
          showPlatform: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionInsertDataDialog: {
          title: '新增',
          projectName: '',
          channelIds: [],
          projectDataInfo: null,
          dialogVisible: false
        },
        optionUpdateDataDialog: {
          title: '修改',
          projectName: '',
          projectDataInfo: null,
          dialogVisible: false
        },
        dataInfoForm: null,
        dataList: null,
        projectDataInfo: {
          projectName: ''
        }
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.getProjectDataInfo()
      this.searchDataList()
    },
    methods: {
      getProjectDataInfo () {
        gameProjectApi.getDataInfo(this.$route.query.iItemId).then((data) => {
          if (data.code === 1) {
            this.projectDataInfo = data.data
          } else {
            this.projectDataInfo = null
          }
        }, (error) => {
          this.projectDataInfo = null
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        // 获取数据列表
        gameProjectApi.getOperatorDataList(this.$route.query.iItemId, params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        gameProjectApi.getOperatorDataListAll(this.$route.query.iItemId).then((data) => {
          if (data.code === 1) {
            this.optionInsertDataDialog.channelIds = []
            for (let item of data.data) {
              this.optionInsertDataDialog.channelIds.push(item.iChannelId)
            }
            this.optionInsertDataDialog.type = 'add'
            this.optionInsertDataDialog.projectDataInfo = this.projectDataInfo
            this.optionInsertDataDialog.dialogVisible = true
            this.dataInfoForm = {
              iAreaId: this.defaultAreaPlatLanInfo.iAreaId,
              iLanguageId: this.defaultAreaPlatLanInfo.iLanguageId,
              iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
              projectName: ''
            }
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        gameProjectApi.getOperatorDataInfo(data[$index].iOperatorId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionUpdateDataDialog.type = 'update'
            this.optionUpdateDataDialog.projectDataInfo = this.projectDataInfo
            this.optionUpdateDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }

</script>
