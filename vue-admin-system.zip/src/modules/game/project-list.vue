<style scoped>
  .content-list{
    margin-top: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <el-row>
      <el-col :span="20" style="text-align: left;">
        <bread-crumb-config></bread-crumb-config>
      </el-col>
      <el-col :span="4" style="text-align: right;">
        <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn">新增</el-button>
      </el-col>
    </el-row>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="gameId" label="项目ID" width="80"></el-table-column>
        <el-table-column prop="projectName" label="项目名称">
          <template scope="scope">
            <i class="ext-icon-plan-big" :class="getIconClassName(scope.row.projectName)"></i>{{scope.row.projectName ? scope.row.projectName : '--'}}
          </template>
        </el-table-column>
        <!--
        <el-table-column prop="projectCode" label="工程Code"></el-table-column>
        <el-table-column prop="serverVersion" label="服务器版本号"></el-table-column>
        <el-table-column prop="cAssertType" label="代理类型" width="80">
          <template scope="scope">
            {{scope.row.cAssertType==gameTypeList[0].iDicId?gameTypeList[0].sDicName:(scope.row.cAssertType==gameTypeList[1].iDicId?gameTypeList[1].sDicName:gameTypeList[2].sDicName)}}
          </template>
        </el-table-column> -->
        <el-table-column prop="cDisplay" label="状态" :width="80">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="130">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.relevanceOperatorConfig" @click="relevanceOperator(scope.$index, dataList)">关联渠道</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <project-insert-or-update-dialog v-if="optionDataDialog.dialogVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></project-insert-or-update-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import planUtil from '../../utils/plan-util'
  import gameProjectApi from '../../apis/game-project-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import projectInsertOrUpdateDialog from '../../components/game/projectInsertOrUpdateDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      projectInsertOrUpdateDialog
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          title: '新增项目',
          type: 'add',
          dialogVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'gameTypeList'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        gameProjectApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.title = '新增项目'
        this.optionDataDialog.dialogVisible = true
        this.dataInfoForm = {
          projectName: '',
          gameId: ''
//          projectCode: '',
//          serverVersion: '',
//          cAssertType: '0'
        }
      },
      // 编辑数据
      updateDataInfo ($index, $data) {
        gameProjectApi.getDataInfo($data[$index].iItemId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.title = '修改项目（' + $data[$index].projectName + '）'
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      relevanceOperator ($index, data) {
        this.$router.push({path: '/home/project/list/operator', query: {iItemId: this.dataList[$index].iItemId}})
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }
</script>
