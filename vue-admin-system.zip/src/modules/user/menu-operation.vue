<style scoped>
  .top-crumb .nav-font{
    font-size: 16px;
  }
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="20" style="text-align: left;">
          <el-breadcrumb separator=">>">
            <el-breadcrumb-item :to="{ path: '/home/user/menu/list' }"><span class="nav-font">菜单列表</span></el-breadcrumb-item>
            <el-breadcrumb-item v-for="(iParentId, index) in iParentIds">
              <span class="nav-font" @click="toOperationListPage(index)">功能列表</span>
            </el-breadcrumb-item>
          </el-breadcrumb>
        </el-col>
        <el-col :span="4" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="cMenuName" label="功能名称" :width="150"></el-table-column>
        <el-table-column prop="parentName" label="父菜单" :width="150"></el-table-column>
        <el-table-column prop="typeName" label="功能类型" :width="100"></el-table-column>
        <el-table-column prop="cBackUrl" label="访问地址"></el-table-column>
        <el-table-column prop="cBackMethod" label="提交方式" :width="100"></el-table-column>
        <el-table-column prop="iOrderNum" label="排序" :width="100"></el-table-column>
        <el-table-column
          label="操作" :width="200">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
              <el-button type="text" class="table-option-button" @click="deleteDataInfo(scope.$index, dataList)">删除</el-button>
              <el-button type="text" class="table-option-button" v-if="scope.row.cMenuType == 1||scope.row.cMenuType == 3" @click="relevanceConfig(scope.$index, dataList)">关联功能</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import menuApi from '../../apis/menu-api'
  import optionDialog from '../../components/user/optionMenuDialog'
  export default{
    components: {
      optionDialog
    },
    data () {
      return {
        iParentId: '',
        iParentIds: [],
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          optionType: 'menuOperation',
          dialogFormVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority'
      ])
    },
    created: function () {
      // 获取操作类型
      this.pageData.number = this.pageNumber
      this.iParentIds = this.$route.query.iParentIds.split(',')
      this.iParentId = this.iParentIds[this.iParentIds.length - 1]
      // 查询数据列表回调
      this.searchDataList()
    },
    methods: {
      getParamsStr ($index) {
        let tempArray = []
        for (let i = 0; i <= $index; i++) {
          tempArray.push(this.iParentIds[i])
        }
        return tempArray.join(',')
      },
      // 查询数据列表回调
      searchDataList () {
        // 获取数据列表
        menuApi.getChildrenDataList(this.iParentId).then((data) => {
          if (data.code === 1) {
            this.dataList = data.data
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          cMenuName: '',
          cMenuType: '',
          cIdentifier: '',
          cUrl: '',
          cBackMethod: '',
          cBackUrl: '',
          iParentId: this.iParentId,
          iOrderNum: 0
        }
      },
      // 编辑数据
      updateDataInfo ($index, $data) {
        menuApi.getDataInfo($data[$index].iMenuId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      deleteDataInfo ($index, $data) {
        this.$confirm('是否确定删除该菜单？', '删除菜单', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 确定操作
          menuApi.deleteDataInfo($data[$index].iMenuId).then((data) => {
            if (data.code === 1) {
              this.searchDataList()
            } else {
              this.$alert(data.msg, '菜单删除失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      toOperationListPage (index) {
        console.log(index)
        this.$router.push({path: '/home/user/menu/operation/list', query: {iParentIds: this.getParamsStr(index)}})
        this.iParentIds = this.$route.query.iParentIds.split(',')
        this.iParentId = this.iParentIds[this.iParentIds.length - 1]
        this.dataList = null
        // 查询数据列表回调
        this.searchDataList()
      },
      // 关联功能
      relevanceConfig ($index, $data) {
        this.$router.push({path: '/home/user/menu/operation/list', query: {iParentIds: this.$route.query.iParentIds + ',' + $data[$index].iMenuId}})
        this.iParentIds = this.$route.query.iParentIds.split(',')
        this.iParentId = this.iParentIds[this.iParentIds.length - 1]
        this.dataList = null
        // 查询数据列表回调
        this.searchDataList()
      }
    }
  }

</script>
