<style scoped>
  .content-list{
    background-color:#fff;
    padding:10px;
  }
  .account-setting-table{
    border:1px solid #e0e0e0;
    position:relative;
  }
  .el-row{
    border-bottom:1px solid #e7e7e7;
  }
 .el-col{
    text-align:center;
    font-size:14px;
    line-height:40px;
  }
  .border-line{
    border-left:1px solid #e7e7e7;
  }
  .detail-list{
    text-align:left;
    min-height:40px;
  }
  .detail-list label{
    width:16%;
  }
  .el-checkbox{
    padding-left:10px;
  }
  .el-checkbox+.el-checkbox{
    margin:0;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config :routerPathList="routerPathList"></bread-crumb-config>
    <div class="content-list">
        <template>
            <div class="account-setting-table">
                <el-row class="table-header" >
                  <el-col :span="4" >
                    <el-col :span="12" >
                      <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="checkAllChange"> 全选</el-checkbox>
                    </el-col>
                    <el-col :span="12" >
                      类型
                    </el-col>
                  </el-col>
                  <el-col :span="20" class="border-line">
                    明细
                  </el-col>
                </el-row>
                <el-row class="table-body">
                  <template v-for="(cMenu,index) in checkboxMenu">
                    <el-row>
                       <el-col :span="4" style="height:100%;" >
                        <el-col :span="12" >
                          <el-checkbox :indeterminate="isIndeterminate" v-model="cMenu.selectedRow"    @change="checkItemAllChange($event,cMenu)" key="全选"  label="index"> 全选</el-checkbox>
                        </el-col>
                        <el-col :span="12" >
                          {{cMenu.menuType | valChange}}
                        </el-col>
                      </el-col>
                      <el-col :span="20" class="detail-list border-line">
                         <template v-if="cMenu.menuDetailList.length > 0">
                         <el-checkbox-group v-model="checkedListVal" >
                         <template v-for="(dMenu,index2) in cMenu.menuDetailList">
                             <template v-if="dMenu.name.length > 10">
                              <el-tooltip :content="dMenu.name" placement="top" effect="light" >
                                 <el-checkbox  :key="dMenu.name"  :label="dMenu.name" @change="checkOneChange($event,dMenu,cMenu)" > {{dMenu.name  | sliceStr}}</el-checkbox>
                              </el-tooltip>
                             </template>
                             <el-checkbox  :key="dMenu.name"  :label="dMenu.name" @change="checkOneChange($event,dMenu,cMenu)" v-if="dMenu.name.length <= 10">
                              {{dMenu.name}}
                             </el-checkbox>
                         </template>
                         </el-checkbox-group>
                         </template>
                      </el-col>
                     </el-row>
                  </template>
                </el-row>
            </div>
        </template>
        <div style="padding:20px 0;">
          <el-button type="primary" @click="submitAccountSetData" v-if="userAccountInfo && userAccountInfo.cStatus==1">确定并返回列表</el-button>
          <el-button type="primary" @click="submitAccountToList" v-if="userAccountInfo && userAccountInfo.cStatus==0">返回列表</el-button>
        </div>
    </div>
  </div>
</template>
<script>
  import Vue from 'vue'
  import {mapGetters} from 'vuex'
  import userAccountApi from '../../apis/user-account-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionChannelDialog from '../../components/project/optionChannelDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      optionChannelDialog
    },
    data () {
      return {
        routerPathList: ['/home/user/account/list', ''],
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        dataInfoForm: null,
        dataList: null,
        checkAll: false,
        checkedListVal: [],
        isIndeterminate: false,
        checkboxMenu: [],
        accountSetData: [],
        cAllValue: [],
        userAccountInfo: null
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.getUserAccountInfo()
      this.searchDataList()
    },
    methods: {
      getUserAccountInfo () {
        var params = {'iUserId': this.$route.query.iUserId}
        userAccountApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            this.userAccountInfo = data.data.list[0]
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        // 获取数据列表
        let iUserid = this.$route.query.iUserId
        userAccountApi.getAllAccessData(iUserid).then((data) => {
          if (data.code === 1) {
            for (let i in data.data) {
              let rData = data.data[i]
              _this.checkboxMenu.push(
                {
                  menuType: rData[0].type,
                  selectedRow: false,
                  selectedList: [],
                  menuDetailList: data.data[i]
                }
              )
              for (let dItem of rData) {
                _this.cAllValue.push(dItem.name)
                if (dItem.isSelected === 1) {
                  _this.checkedListVal.push(dItem.name)
                }
              }
              if (_this.checkedListVal.length === _this.cAllValue.length) {
                _this.checkAll = true
              } else {
                _this.checkAll = false
              }
            }
            // 全选和单行选中判断
            for (let i = 0; i < _this.checkboxMenu.length; i++) {
              for (let j = 0; j < _this.checkboxMenu[i].menuDetailList.length; j++) {
                for (let p = 0; p < _this.checkedListVal.length; p++) {
                  const cName = _this.checkboxMenu[i].menuDetailList[j].name
                  if (cName === _this.checkedListVal[p]) {
                    _this.checkboxMenu[i].selectedList.push(cName)
                  }
                }
              }
              if (_this.checkboxMenu[i].selectedList.length === _this.checkboxMenu[i].menuDetailList.length) {
                _this.checkboxMenu[i].selectedRow = true
              } else {
                _this.checkboxMenu[i].selectedRow = false
              }
            }

          } else {
            this.$alert(data.msg, '信息绑定失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      submitAccountToList () {
        this.$router.push({path: '/home/user/account/list'})
      },
      // 提交用户资源
      submitAccountSetData (){
        const _this = this
        for(let i=0;i<_this.checkedListVal.length;i++){
          for(let j=0;j<_this.checkboxMenu.length;j++){
            let cMenu = _this.checkboxMenu[j].menuDetailList
            for(let item of cMenu){
              if(_this.checkedListVal[i] === item.name){
                _this.accountSetData.push({
                  cDataAccessId:item.id,
                  cDataType:item.type,
                  iUserId:_this.userAccountInfo.iUserId
                })
              }
            }
          }
        }
        const iUserId = _this.userAccountInfo.iUserId
        userAccountApi.addAccountSetData(iUserId, _this.accountSetData).then((resData) => {
          if (resData.code === 1) {
            this.$router.push({path: '/home/user/account/list'})
          } else {
            this.$alert(resData.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 全选
      checkAllChange(event){
          const _this = this
          const cValue = []
          for(let i=0;i<this.checkboxMenu.length;i++){
              this.checkboxMenu[i].selectedRow = event
              let cMenu = this.checkboxMenu[i].menuDetailList
              if(event){
                for(let item of cMenu){
                    cValue.push(item.name)
                    //防止重复
                    _this.removeEleByValue(this.checkboxMenu[i].selectedList,item.name)
                    this.checkboxMenu[i].selectedList.push(item.name)
                }
                this.checkedListVal = cValue
              }else{
                this.checkedListVal = []
                this.checkboxMenu[i].selectedList = []
              }
          }
      },
      // 单行全选
      checkItemAllChange(event,cMenu){
          var _this = this
          if(event){
              for(let j=0;j<cMenu.menuDetailList.length;j++){
               // 剔除重复
                _this.removeEleByValue(_this.checkedListVal,cMenu.menuDetailList[j].name)
                _this.removeEleByValue(cMenu.selectedList,cMenu.menuDetailList[j].name)
                // 添加元素
                _this.checkedListVal.push(cMenu.menuDetailList[j].name)
                cMenu.selectedList.push(cMenu.menuDetailList[j].name)
                _this.removeEleByValue(cMenu.selectedList,cMenu.menuDetailList[j].name)
              }

          }else{
              cMenu.menuDetailList.forEach(function(ele,index){
                _this.removeEleByValue(_this.checkedListVal,ele.name)
              })
              cMenu.selectedList = []
          }
          if(_this.checkedListVal.length == _this.cAllValue.length){
              _this.checkAll = true
          }else{
             _this.checkAll = false
          }
      },
      // checkbox单个选中
      checkOneChange(event,dMenu,cMenu){
          const _this = this
          if(event){
              _this.removeEleByValue(cMenu.selectedList,dMenu.name)
              cMenu.selectedList.push(dMenu.name)
          }else{
              _this.removeEleByValue(cMenu.selectedList,dMenu.name)
          }
          if(cMenu.selectedList.length === cMenu.menuDetailList.length ){
              cMenu.selectedRow = true
          }else{
              cMenu.selectedRow = false
          }

          if(_this.checkedListVal.length == _this.cAllValue.length){
              _this.checkAll = true
          }else{
              _this.checkAll = false
          }
      },
      removeEleByValue(arr,val){
        for(var i=0; i<arr.length; i++) {
            if(arr[i] == val) {
              arr.splice(i, 1);
              continue;
            }
          }
      },

    }
  }
  Vue.filter("sliceStr", function(value) {   //全局方法 Vue.filter() 注册一个自定义过滤器,必须放在Vue实例化前面
        return value.slice(0,10)+'...'
  })
  Vue.filter ('valChange',function(value){
     switch (value){
      case 'area' :
          return '地区'
          break;
      case 'platform' :
          return '平台'
          break;
      case 'language' :
          return '语言'
          break;
      case 'game' :
          return '游戏'
          break;
     }
  })
</script>
