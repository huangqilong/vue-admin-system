<style scoped>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="areaName" label="地区" width="150">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.areaName)"></i>{{scope.row.areaName}}
          </template>
        </el-table-column>
        <el-table-column prop="platformName" label="平台" width="150">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.platformName)"></i>{{scope.row.platformName}}
          </template>
        </el-table-column>
        <el-table-column prop="languageName" label="语言" width="200"></el-table-column>
        <el-table-column prop="channelName" label="渠道名称"></el-table-column>
        <!--<el-table-column prop="channelSign" label="运营商ID(友财)"></el-table-column>-->
        <!--<el-table-column prop="channelSign" label="运营商别名(友财)"></el-table-column>-->
        <!--<el-table-column prop="channelExtraSign" label="运营商别名(老代理)"></el-table-column>-->
        <!--<el-table-column prop="channelOtherSign" label="额外标识符"></el-table-column>-->
        <el-table-column prop="cDisplay" label="渠道状态" width="100">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="240">
          <template scope="scope">
            <div style="text-align: left;">
              <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].cDisplay==0?'下架':'上架'}}</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.versionPage" @click="dataVersion(scope.$index, dataList)">版本列表</el-button>
              <el-button type="text" class="table-option-button" v-if="roleAuthority.relevancePluginConfig && scope.row.platformName == 'IOS'" @click="relevancePlugin(scope.$index, dataList)">关联插件</el-button>
              <el-button type="text" class="table-option-button" v-if="scope.row.platformName=='安卓'&&roleAuthority.shareSwitch" @click="shareSwitchConfig(scope.$index, dataList)">分享开关</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
    <relevancePluginDialog v-if="relevancePluginDataDialog.dialogFormVisible" :optionData="relevancePluginDataDialog"></relevancePluginDialog>
    <shareSwitchDialog v-if="shareSwitchDataDialog.dialogVisible" :optionData="shareSwitchDataDialog" :shareSwitchData="shareSwitchData" :selectShareSwitch="selectShareSwitch"></shareSwitchDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import channelApi from '../../apis/channel-api'
  import planUtil from '../../utils/plan-util'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import optionForm from '../../components/manager/optionForm'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/channel/optionDialog'
  import relevancePluginDialog from '../../components/channel/relevancePlugin'
  import shareSwitchDialog from '../../components/game/shareSwitchDialog'

  export default{
    components: {
      breadCrumbConfig,
      optionForm,
      pagination,
      optionDialog,
      relevancePluginDialog,
      shareSwitchDialog
    },
    data () {
      return {
        optionParams: {
          name: '',
          areaId: '',
          languageId: '',
          platformId: '',
          cDisplay: '0'
        },
        optionData: {
          showChannelName: true,
          showArea: true,
          showLanguage: true,
          showPlatform: true,
          showDataDisplay: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          title: '',
          dialogFormVisible: false
        },
        relevancePluginDataDialog: {
          title: '',
          channelInfo: null,
          dialogFormVisible: false
        },
        shareSwitchData: '',
        shareSwitchDataDialog: {
          title: '',
          dialogVisible: false
        },
        dataInfoForm: null,
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo', 'channelOptionParams'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.channelOptionParams) {
        this.optionParams.name = this.channelOptionParams.name
        this.optionParams.areaId = this.channelOptionParams.areaId
        this.optionParams.languageId = this.channelOptionParams.languageId
        this.optionParams.platformId = this.channelOptionParams.platformId
        this.optionParams.cDisplay = this.channelOptionParams.cDisplay
      }
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        // 获取数据列表
        channelApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setChannelOptionParams', JSON.parse(JSON.stringify(this.optionParams)))
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.title = '渠道新增'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          iAreaId: this.defaultAreaPlatLanInfo.iAreaId,
          iLanguageId: this.defaultAreaPlatLanInfo.iLanguageId,
          iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
          channelName: '',
          iIsOffical: 0,
          channelSign: '',
          channelExtraSign: '',
          channelOtherSign: '',
          iRate: 0,
          linkUrl: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        channelApi.getDataInfo(data[$index].iChannelId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.title = '渠道修改（' + data.data.channelName + '）'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $data[$index].iChannelId
          let status = $data[$index].cDisplay === '0' ? '1' : '0'
          channelApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $data[$index].cDisplay = status
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            console.log(error)
          })
        }).catch(() => {
          // 取消操作
        })
      },
      // 游戏版本
      dataVersion ($index, data) {
        if (this.dataList[$index].platformName === '安卓') {
          this.$router.push({path: '/home/channel/list/version/android', query: {iChannelId: this.dataList[$index].iChannelId}})
        } else {
          this.$router.push({path: '/home/channel/list/version/ios', query: {iChannelId: this.dataList[$index].iChannelId}})
        }
      },
      // 关联插件
      relevancePlugin ($index, data) {
        this.relevancePluginDataDialog.title = '关联插件（' + this.dataList[$index].channelName + '）'
        this.relevancePluginDataDialog.channelInfo = this.dataList[$index]
        this.relevancePluginDataDialog.dialogFormVisible = true
      },
      shareSwitchConfig ($index, $data) {
        channelApi.getShareSwitchDataInfo($data[$index].iChannelId).then((data) => {
          if (data.code === 1) {
            this.shareSwitchData = data.data
            this.shareSwitchDataDialog.title = '分享开关(' + this.dataList[$index].channelName + ')'
            this.shareSwitchDataDialog.dialogVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      selectShareSwitch (params) {
        channelApi.postShareSwitchDataInfo(params).then((data) => {
          if (data.code === 1) {
            this.shareSwitchDataDialog.dialogVisible = false
          } else {
            this.$alert(data.msg, '操作失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>

