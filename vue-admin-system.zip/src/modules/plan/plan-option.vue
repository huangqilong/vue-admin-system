<style scoped>
  .top-crumb .nav-font{
    font-size: 16px;
  }
  .pack-tool-form{
    width: 1000px;
  }
  .pack-tool-form .el-select{
    width: 100%;
  }
  .pack-tool-form .pack-tool-form-btn{
    width: 100%;
    font-size: 16px;
    letter-spacing: 1em;
  }
  .pack-tool-form .plan-option-form-btn{
    width: 40%;
    font-size: 14px;
    letter-spacing: 1em;
    padding: 6px 15px;
  }
  .pack-tool-form .title{
    font-size: 16px;
    margin: 20px 0 7px 20px;
    font-weight: 600;
    color: #333;
  }
  .pack-tool-form .plan-label{
    line-height: 36px;
    font-size: 18px;
    color: #333;
  }
</style>
<style>
  .pack-tool-form .el-date-editor.el-input{
    width: 100%;
  }
  .el-date-picker{
    max-width: 320px;
  }
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-breadcrumb separator=">>">
        <el-breadcrumb-item to="/home/plan/list"><span class="nav-font">计划管理</span></el-breadcrumb-item>
        <el-breadcrumb-item><span class="nav-font">{{$route.path.indexOf('/add') >= 0?'发起计划':'编辑计划'}}</span></el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <el-form :model="dataInfoForm" ref="dataInfoForm" :rules="rules" label-width="130px" class="pack-tool-form">
      <div class="title">计划基本信息</div>
      <el-form-item label="计划名称：" prop="sPackPlanName">
        <el-input v-model.trim="dataInfoForm.sPackPlanName"></el-input>
      </el-form-item>
      <el-row>
        <el-col :span="12"></el-col>
      </el-row>
      <el-form-item label="起止时间：" prop="startEndDate">
        <el-row>
          <el-col :span="10">
            <el-date-picker
              v-model="dPlanStart"
              type="date"
              :editable="false"
              format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss"
              @change="dPlanStartChange"
              placeholder="选择开始日期"
              :picker-options="pickerOptions0">
            </el-date-picker>
          </el-col>
          <el-col :span="4" style="text-align: center;"><span class="plan-label">至</span></el-col>
          <el-col :span="10">
            <el-date-picker
              v-model="dPlanEnd"
              type="date"
              :editable="false"
              format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss"
              @change="dPlanEndChange"
              placeholder="选择结束日期"
              :picker-options="pickerOptions0">
            </el-date-picker>
          </el-col>
        </el-row>
      </el-form-item>
      <el-form-item label="计划类型：" prop="cAssertType">
        <el-radio-group v-model="dataInfoForm.iPlanType" @change="getGameSubcribesList">
          <el-radio class="radio" :label="planTypeDataList[0].iDicId">{{planTypeDataList[0].sDicName}}</el-radio>
          <el-radio class="radio" :label="planTypeDataList[1].iDicId">{{planTypeDataList[1].sDicName}}</el-radio>
        </el-radio-group>
      </el-form-item>
      <div class="split" style="border-bottom: 1px solid #666;margin-left: 20px;"></div>
      <div class="title">打包游戏信息</div>
      <el-row>
        <el-col :span="8">
          <el-form-item label="打包地区：" prop="iAreaId">
            <el-select v-model="dataInfoForm.iAreaId" placeholder="请选择" @change="getGameList" :disabled="isUpdateOption==true">
              <el-option
                v-for="item in areaList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="打包语言：" prop="iLanguageId">
            <el-select v-model="dataInfoForm.iLanguageId" placeholder="请选择" @change="getGameList" :disabled="isUpdateOption==true">
              <el-option
                v-for="item in languageList"
                :key="item.iDicId"
                :label="item.sDicName"
                :value="item.iDicId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="打包平台：" prop="iPlatformId">
            <el-radio-group v-model="dataInfoForm.iPlatformId" @change="getGameList" :disabled="isUpdateOption==true">
              <el-radio v-for="item in platformList" class="radio" :label="item.iDicId">{{item.sDicName}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="打包游戏：" prop="iProjectId">
            <el-select v-model="dataInfoForm.iProjectId" placeholder="请选择" @change="getGameVersionList" :disabled="isUpdateOption==true">
              <el-option
                v-for="item in gameList"
                :key="item.iProjectId"
                :label="item.gameName"
                :value="item.iProjectId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="游戏版本：" prop="iGameAssetsId">
            <el-select v-model="dataInfoForm.iGameAssetsId" placeholder="请选择" @change="getGameAssetsDataList" :disabled="isUpdateOption==true">
              <el-option
                v-for="item in gameVersionList"
                :key="item.iAssertId"
                :label="item.gameAssetsVersion"
                :value="item.iAssertId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="资源类型：" prop="cVersionType">
            <el-radio-group v-model="dataInfoForm.cVersionType" @change="getGameAssetsDataList" :disabled="isUpdateOption==true">
              <el-radio v-for="item in gameAssetsTypeList" class="radio" :label="item.value">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="游戏资源：" prop="iProjectAssetId">
            <el-select v-model="dataInfoForm.iProjectAssetId" placeholder="请选择" :disabled="isUpdateOption==true">
              <el-option
                v-for="item in gameAssetsList"
                :key="item.iProjectAssetId"
                :label="item.gameAssetsName"
                :value="item.iProjectAssetId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="母包截止时间：" prop="dUploadEnd">
            <el-date-picker
              v-model="dUploadEnd"
              type="date"
              :editable="false"
              format="yyyy-MM-dd HH:mm:ss"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="选择日期"
              @change="dUploadEndChange"
              :picker-options="pickerOptions0">
            </el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="8">
          &nbsp;
        </el-col>
      </el-row>
      <!--<div style="color: #999;margin-left: 133px;">提示：选择的版本务必和相关人员确认后再提交计划，计划一旦开始，无法修改游戏版本！</div>-->
      <el-form-item label="打包渠道信息：">
        <el-button type="primary" class="plan-option-form-btn" @click="showChannelListDialog()">选择打包渠道</el-button>
        <el-table :data="packChannelList" stripe style="margin-top: 10px;">
          <el-table-column label="优先接入" width="120">
            <template scope="scope">
              <el-checkbox v-model="scope.row.iPriority" :true-label="1" :false-label="0">&nbsp;</el-checkbox>
            </template>
          </el-table-column>
          <el-table-column prop="iChannelName" label="渠道名称"></el-table-column>
          <el-table-column label="操作" width="80">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="deletePackChannelData(scope.$index)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="广告包信息：" v-if="hasHwyChannel">
        <el-button type="primary" class="plan-option-form-btn" @click="showAdvCodeDialog()">选择广告码</el-button>
        <el-table :data="advCpsDataFilter('0')" stripe style="margin-top: 10px;">
          <el-table-column prop="adcpsCode" label="广告码"></el-table-column>
          <el-table-column prop="sDemo" label="备注"></el-table-column>
          <el-table-column label="广告插件">
            <template scope="scope">
              {{getPluginInfo(scope.row.pluginIds, scope.row.cAdPluginConfigIds).join(',')}}
            </template>
          </el-table-column>
          <el-table-column
            label="操作" width="80">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="deleteAdvCpsData(scope.$index, '0')">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="cps包信息：" v-if="hasHwyChannel">
        <el-button type="primary" class="plan-option-form-btn" @click="showCpsCodeDialog()">选择CPS码</el-button>
        <el-table :data="advCpsDataFilter('1')" stripe style="margin-top: 10px;">
          <el-table-column prop="adcpsCode" label="广告码"></el-table-column>
          <el-table-column prop="sDemo" label="备注"></el-table-column>
          <el-table-column
            label="操作" width="80">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="deleteAdvCpsData(scope.$index, '1')">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="计划订阅人员：" v-if="!isUpdateOption && dataInfoForm.iPlanType == planTypeDataList[0].iDicId">
        <el-button v-if="false" type="primary" class="plan-option-form-btn" @click="showUserSubcribe()">选择订阅人员</el-button>
        <div style="color: #999;">提示：这里显示了默认的计划订阅人员，可以到计划进度页进行修改！</div>
        <el-table :data="packSubcribeList" stripe style="margin-top: 10px;" :default-sort = "{prop: 'cRoleName', order: 'descending'}">
          <el-table-column prop="cRoleName" label="角色"></el-table-column>
          <el-table-column prop="cRealName" label="真实姓名"></el-table-column>
          <el-table-column
            label="操作" width="80" v-if="false">
            <template scope="scope">
              <el-button type="text" class="table-option-button" @click="deleteSubcribeData(scope.$index)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form-item>
      <el-form-item label="备注：">
        <el-input type="textarea" :rows="3" v-model.trim="dataInfoForm.sDemo" placeholder="正常版本更新外的额外打包计划请详细描述一下原因！"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" :disabled="isEqualsOption" class="pack-tool-form-btn" @click="submitForm('dataInfoForm')" :loading="buttonLoading">提交计划并返回列表</el-button>
      </el-form-item>
    </el-form>
    <channel-list-dialog v-if="optionChannelListDataDialog.dialogVisible" :optionData="optionChannelListDataDialog"
                         :dataInfoForm="dataInfoForm" :packChannelIdsList="packChannelIdsList" :optionCallBack="selectChannelList"></channel-list-dialog>
    <adv-or-cps-code-dialog v-if="optionAdvOrCpsDataDialog.dialogVisible" :optionData="optionAdvOrCpsDataDialog"
                            :dataInfoForm="dataInfoForm" :packAdvCpsIdsList="packAdvCpsIdsList" :optionCallBack="selectAdvCpsDataList"></adv-or-cps-code-dialog>
    <subcribe-list-dialog v-if="optionSubcribeListDataDialog.dialogVisible" :optionData="optionSubcribeListDataDialog"
                          :packSubcribeList="packSubcribeList" :optionCallBack="selectSubcribeList"></subcribe-list-dialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import equalsExtend from '../../utils/equals-extend'
  import gameApi from '../../apis/game-api'
  import packToolApi from '../../apis/pack-tool-api'
  import planApi from '../../apis/plan-api'
  import pluginApi from '../../apis/plugin-api'
  import channelListDialog from '../../components/plan/channelListDialog'
  import advOrCpsCodeDialog from '../../components/plan/advOrCpsCodeDialog'
  import subcribeListDialog from '../../components/plan/subcribeListDialog'
  export default{
    components: {
      channelListDialog,
      advOrCpsCodeDialog,
      subcribeListDialog
    },
    computed: {
      ...mapGetters([
        'areaList', 'platformList', 'languageList', 'gameAssetsTypeList',
        'buttonLoading', 'planInfo', 'planTypeDataList'
      ])
    },
    data () {
      let checkStartEndDate = (rule, value, callback) => {
        if (!this.dPlanStart || !this.dPlanEnd) {
          return callback(new Error('请输入起止时间'))
        }
        setTimeout(() => {
          let startDate = new Date(this.dPlanStart).getTime()
          let endEnd = new Date(this.dPlanEnd).getTime()
          if (startDate > endEnd) {
            callback(new Error('起始时间必须小于截止时间'))
          } else {
            callback()
          }
        }, 1000)
      }
      let checkUploadEndDate = (rule, value, callback) => {
        if (!this.dUploadEnd) {
          return callback(new Error('请输入游戏母包截止上传时间'))
        }
        setTimeout(() => {
          let startDate = new Date(this.dPlanStart).getTime()
          let endEnd = new Date(this.dPlanEnd).getTime()
          let uploadEnd = new Date(this.dUploadEnd).getTime()
          if (startDate > uploadEnd || uploadEnd > endEnd) {
            callback(new Error('游戏母包截止上传时间必须大于起始时间且小于截止时间'))
          } else {
            callback()
          }
        }, 1000)
      }
      return {
        isEqualsOption: true,
        oldDataInfoForm: null,
        oldPackChannelList: null,
        oldPackAdvCpsList: null,
        hasHwyChannel: false,
        isUpdateOption: false,
        platformType: 'ios',
        dPlanStart: '',
        dPlanEnd: '',
        dUploadEnd: '',
        dataInfoForm: {
          sPackPlanName: '',
          dPlanStart: '',
          dPlanEnd: '',
          iPlanType: 1,
          iAreaId: '',
          iLanguageId: '',
          iPlatformId: '',
          iProjectId: '',
          iGameAssetsId: '',
          cVersionType: '1',
          iProjectAssetId: '',
          dUploadEnd: '',
          sDemo: '',
          cPlanStatus: '0',
          deleteChannelIDs: [],
          deleteAdIDs: [],
          deleteUserIDs: [],
          packPlanChannelRecordVOList: [],
          packPlanAdRecordList: [],
          packPlanSubcribeVOList: []
        },
        gameList: [],
        gameVersionList: [],
        gameAssetsList: [],
        packChannelIdsList: [],
        packChannelList: [],
        packAdvCpsIdsList: {
          '0': [],
          '1': []
        },
        packAdvCpsList: {
          '0': [],
          '1': []
        },
        packSubcribeIdsList: [],
        packSubcribeList: [],
        pluginList: [],
        optionChannelListDataDialog: {
          dialogVisible: false
        },
        optionAdvOrCpsDataDialog: {
          type: '0',
          dialogVisible: false
        },
        optionSubcribeListDataDialog: {
          dialogVisible: false
        },
        rules: {
          sPackPlanName: [
            {required: true, message: '请输入计划名称', trigger: 'blur'}
          ],
          startEndDate: [
            {validator: checkStartEndDate, trigger: 'blur'}
          ],
          iAreaId: [
            {type: 'number', required: true, message: '请选择打包地区', trigger: 'change'}
          ],
          iLanguageId: [
            {type: 'number', required: true, message: '请选择打包语言', trigger: 'change'}
          ],
          iPlatformId: [
            {type: 'number', required: true, message: '请选择打包平台', trigger: 'change'}
          ],
          iProjectId: [
            {type: 'number', required: true, message: '请选择打包游戏', trigger: 'change'}
          ],
          iGameAssetsId: [
            {type: 'number', required: true, message: '请选择打包游戏版本', trigger: 'change'}
          ],
          iProjectAssetId: [
            {type: 'number', required: true, message: '请选择打包游戏资源', trigger: 'change'}
          ],
          dUploadEnd: [
            {validator: checkUploadEndDate, trigger: 'blur'}
//            {required: true, message: '请输入游戏母包截止上传时间', trigger: 'blur'}
          ]
        },
        pickerOptions0: {
          disabledDate (time) {
            return time.getTime() < Date.now() - 8.64e7
          }
        }
      }
    },
    watch: {
      dataInfoForm: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldDataInfoForm, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      packChannelList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldPackChannelList, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      },
      packAdvCpsList: {
        handler: function (newVal) {
          if (equalsExtend.objectEqual(this.oldPackAdvCpsList, newVal)) {
            this.isEqualsOption = true
          } else {
            this.isEqualsOption = false
          }
        },
        deep: true
      }
    },
    created: function () {
      if (this.$route.path === '/home/plan/option/update') {
        this.isUpdateOption = true
        // 获取计划进度信息
        this.getPackPlanDataInfo()
      } else {
        this.isUpdateOption = false
        this.dataInfoForm.iAreaId = this.areaList[0].iDicId
        this.dataInfoForm.iLanguageId = this.languageList[0].iDicId
        this.dataInfoForm.iPlatformId = this.platformList[0].iDicId
        this.dataInfoForm.cVersionType = this.gameAssetsTypeList[0].value
        let startDate = new Date()
        let endDate = new Date(new Date().setDate(new Date().getDate() + 15))
        this.dPlanStart = startDate.getFullYear() + '-' + (startDate.getMonth() + 1) + '-' + startDate.getDate() + ' 00:00:00'
        this.dPlanEnd = endDate.getFullYear() + '-' + (endDate.getMonth() + 1) + '-' + endDate.getDate() + ' 00:00:00'
        this.dataInfoForm.dPlanStart = startDate.getFullYear() + '-' + (startDate.getMonth() + 1) + '-' + startDate.getDate() + ' 00:00:00'
        this.dataInfoForm.dPlanEnd = endDate.getFullYear() + '-' + (endDate.getMonth() + 1) + '-' + endDate.getDate() + ' 00:00:00'
        this.getGameList()
      }
    },
    methods: {
      advCpsDataFilter (cPackType) {
        return this.packAdvCpsList[cPackType]
      },
      dPlanStartChange (val) {
        this.dataInfoForm.dPlanStart = val
      },
      dPlanEndChange (val) {
        this.dataInfoForm.dPlanEnd = val
      },
      dUploadEndChange (val) {
        this.dataInfoForm.dUploadEnd = val
      },
      // 判断平台类型
      judgePlatformType () {
        for (const pItem of this.platformList) {
          if (pItem.iDicId === this.dataInfoForm.iPlatformId) {
            this.platformType = pItem.sDicName === '安卓' ? 'android' : 'ios'
          }
        }
      },
      // 判断用户是否选择了好玩又渠道
      judgeHwyChannel () {
        let isExit = false
        if (this.packChannelList.length > 0) {
          for (let tempChannel of this.packChannelList) {
            if ((tempChannel.iIsOffical === 1 || tempChannel.iIsOffical === '1') && this.platformType === 'android') {
              isExit = true
            }
          }
        }
        if (isExit) {
          this.hasHwyChannel = true
        } else {
          this.hasHwyChannel = false
        }
      },
      // 数据清空操作
      clearDataInfo (type) {
        switch (type) {
          case 'game':
            this.dataInfoForm.iProjectId = ''
            this.gameList = []
          case 'gameVersion':
            this.dataInfoForm.iGameAssetsId = ''
            this.gameVersionList = []
          case 'gameAssets':
            this.dataInfoForm.iProjectAssetId = ''
            this.gameAssetsList = []
          case 'gameChannel':
            this.channelList = []
          case 'channelList':
            this.packChannelList = []
            this.packChannelIdsList = []
            this.judgeHwyChannel()
          case 'advCpsList':
            this.packAdvCpsList = {
              '0': [],
              '1': []
            }
            this.packAdvCpsIdsList = {
              '0': [],
              '1': []
            }
          case 'subcribeList':
            this.packSubcribeList = []
        }
      },
      getPackPlanDataInfo () {
        planApi.getPackPlanDataInfo(this.$route.query.iPlanId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            /*
            this.dataInfoForm.iPlanId = data.data.iPlanId
            this.dataInfoForm.sPackPlanName = data.data.sPackPlanName
            this.dataInfoForm.dPlanStart = data.data.dPlanStart
            this.dataInfoForm.dPlanEnd = data.data.dPlanEnd
            this.dataInfoForm.iAreaId = data.data.iAreaId
            this.dataInfoForm.iLanguageId = data.data.iLanguageId
            this.dataInfoForm.iPlatformId = data.data.iPlatformId
            this.dataInfoForm.cVersionType = data.data.cVersionType
            this.dataInfoForm.iProjectId = data.data.iProjectId
            this.dataInfoForm.iGameAssetsId = data.data.iGameAssetsId
            this.dataInfoForm.iProjectAssetId = data.data.iProjectAssetId
            this.dataInfoForm.dUploadEnd = data.data.dUploadEnd
            this.dataInfoForm.sDemo = data.data.sDemo
            this.dataInfoForm.cPlanStatus = data.data.cPlanStatus
            this.dataInfoForm.packPlanChannelRecordVOList = data.data.packPlanChannelRecordVOList
            this.dataInfoForm.packPlanAdRecordList = data.data.packPlanAdRecordList
            this.dataInfoForm.packPlanSubcribeVOList = data.data.packPlanSubcribeVOList */
            this.dataInfoForm.deleteAdIDs = []
            this.dataInfoForm.deleteChannelIDs = []
            this.dataInfoForm.deleteUserIDs = []

            this.dPlanStart = this.dataInfoForm.dPlanStart
            this.dPlanEnd = this.dataInfoForm.dPlanEnd
            this.dUploadEnd = this.dataInfoForm.dUploadEnd
            if (this.dataInfoForm.packPlanChannelRecordVOList && this.dataInfoForm.packPlanChannelRecordVOList.length > 0) {
              for (let packItem of this.dataInfoForm.packPlanChannelRecordVOList) {
                this.packChannelIdsList.push(packItem.iChannelId)
                this.packChannelList.push(packItem)
              }
            }
            if (this.dataInfoForm.packPlanAdRecordList && this.dataInfoForm.packPlanAdRecordList.length > 0) {
              for (let packItem of this.dataInfoForm.packPlanAdRecordList) {
                this.packAdvCpsIdsList[packItem.cPackType].push(packItem.iAdcodeId)
                this.packAdvCpsList[packItem.cPackType].push(packItem)
              }
            }
            if (this.dataInfoForm.packPlanSubcribeVOList && this.dataInfoForm.packPlanSubcribeVOList.length > 0) {
              for (let packItem of this.dataInfoForm.packPlanSubcribeVOList) {
//                this.packSubcribeIdsList.push(packItem.iUserId)
                this.packSubcribeList.push(packItem)
              }
            }
            this.oldDataInfoForm = JSON.parse(JSON.stringify(this.dataInfoForm))
            this.oldPackAdvCpsList = JSON.parse(JSON.stringify(this.packChannelList))
            this.oldPackAdvCpsList = JSON.parse(JSON.stringify(this.packAdvCpsList))
            this.getGameList()
            this.judgePlatformType()
            this.judgeHwyChannel()
            this.getPluginList()
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 获取游戏列表
      getGameList () {
        if (!this.dataInfoForm.iAreaId || !this.dataInfoForm.iLanguageId || !this.dataInfoForm.iPlatformId) {
          return
        }
        let _this = this
        const optionParams = {
          areaId: this.dataInfoForm.iAreaId,
          languageId: this.dataInfoForm.iLanguageId,
          platformId: this.dataInfoForm.iPlatformId
        }
        this.judgePlatformType()
        // 获得打包游戏项目表
        packToolApi.getPackGameDataList(optionParams).then((data) => {
          if (data.code === 1) {
            _this.gameList = data.data
            if (_this.gameList.length > 0) {
              if (!this.isUpdateOption) {
                _this.dataInfoForm.iProjectId = _this.gameList[0].iProjectId
              }
              // 获取游戏的版本列表
              _this.getGameVersionList()
            } else {
              this.clearDataInfo('game')
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 获得打包游戏版本列表
      getGameVersionList () {
        let _this = this
        let pType = this.platformType === 'ios' ? 1 : 0
        if (!_this.dataInfoForm.iProjectId) {
          return false
        }
        packToolApi.getPackGameVersionDataList(_this.dataInfoForm.iProjectId, pType).then((data) => {
          if (data.code === 1) {
            _this.gameVersionList = data.data
            if (_this.gameVersionList.length > 0) {
              if (!this.isUpdateOption) {
                _this.dataInfoForm.iGameAssetsId = _this.gameVersionList[0].iAssertId
//                if (_this.dataInfoForm.iGameAssetsId === _this.gameVersionList[0].iAssertId) {
//                  // 获取游戏资源列表
//                  _this.getGameAssetsDataList()
//                } else {
//                  _this.dataInfoForm.iGameAssetsId = _this.gameVersionList[0].iAssertId
//                }
              }
              _this.getGameAssetsDataList()
            } else {
              this.clearDataInfo('gameVersion')
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 获得打包游戏资源列表
      getGameAssetsDataList () {
        let _this = this
        let pType = this.platformType === 'ios' ? 1 : 0
        if (!_this.dataInfoForm.iGameAssetsId) {
          return false
        }
        // 获得打包游戏资源列表
        packToolApi.getPackGameAssetsDataList(_this.dataInfoForm.iGameAssetsId, pType, this.dataInfoForm.cVersionType).then((data) => {
          if (data.code === 1) {
            _this.gameAssetsList = data.data
            if (_this.gameAssetsList.length > 0) {
              if (!this.isUpdateOption) {
                _this.dataInfoForm.iProjectAssetId = _this.gameAssetsList[0].iProjectAssetId
                // 获取当前资源下的渠道列表
                _this.getGameAssetsChannelDataList()
                // 新增游戏时，获取游戏默认人员列表
                this.getGameSubcribesList()
              }
            } else {
              this.clearDataInfo('gameAssets')
            }
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 获取当前资源下的渠道列表
      getGameAssetsChannelDataList () {
        let _this = this
        const params = {'currentPage': 1, 'number': 9999}
        // 获取数据列表
        gameApi.getConfigDataList(_this.platformType, _this.dataInfoForm.iProjectAssetId, params).then((data) => {
          if (data.code === 1) {
            this.packChannelList = []
            this.packChannelIdsList = []
            for (let item of data.data.list) {
              let selectItem = {
                iPlanChannelId: '',
                iChannelId: item.iChannelId,
                iChannelName: item.channelName,
                iIsOffical: item.iIsOffical,
                iPriority: 0
              }
              this.packChannelIdsList.push(item.iChannelId)
              this.packChannelList.push(selectItem)
            }
            this.judgeHwyChannel()
            if (this.hasHwyChannel) {
              this.getCpsAdvPackList()
            }
          } else {
            this.clearDataInfo('channelList')
          }
        }, (error) => {
          console.log(error)
        })
      },
      // 获取CPS码和广告码的列表
      getCpsAdvPackList () {
        let _this = this
        // 获取数据列表
        gameApi.getCpsAdvPackInfo(_this.dataInfoForm.iProjectId).then((data) => {
          if (data.code === 1) {
            this.packAdvCpsIdsList['0'] = []
            this.packAdvCpsList['0'] = []
            this.packAdvCpsIdsList['1'] = []
            this.packAdvCpsList['1'] = []
            for (let item of data.data) {
              let selectItem = {
                iPlanAdId: '',
                iAdcodeId: item.iAdcodeId,
                adcpsCode: item.cAdcpsCode,
                cPackType: item.cPackType,
                sDemo: item.sDemo,
                offical: item.cOfficial,
                pluginIds: item.cAdPluginIds,
                cAdPluginConfigIds: item.cAdPluginConfigIds
              }
              this.packAdvCpsIdsList[item.cPackType].push(selectItem.iAdcodeId)
              this.packAdvCpsList[item.cPackType].push(selectItem)
            }
          } else {
            this.clearDataInfo('advCpsList')
          }
        }, (error) => {
        })
      },
      // 新增游戏时，获取游戏默认人员列表
      getGameSubcribesList () {
        let _this = this
        if (this.isUpdateOption || this.dataInfoForm.iPlanType !== this.planTypeDataList[0].iDicId) {
          this.packSubcribeIdsList = []
          this.packSubcribeList = []
          return
        }
        gameApi.getGameSubcribesDataList(_this.dataInfoForm.iProjectId).then((data) => {
          if (data.code === 1) {
            this.packSubcribeIdsList = []
            this.packSubcribeList = []
            for (let item of data.data) {
//              this.packSubcribeList.push({
//                iUserId: item.iUserId,
//                cRoleName: item.cRoleName,
//                name: item.cRealName,
//                pinyinName: item.cUserName,
//                type: 1
//              })
              let selectItem = {
                iUserId: item.iUserId,
                cRoleName: item.cRoleName,
                cRealName: item.cRealName,
                cUserName: item.cUserName
              }
              this.packSubcribeIdsList.push(item.iUserId)
              this.packSubcribeList.push(selectItem)
            }
          } else {
            this.clearDataInfo('subcribeList')
          }
        }, (error) => {
          console.log(error)
        })
      },
      showChannelListDialog () {
        this.optionChannelListDataDialog.dialogVisible = true
      },
      deletePackChannelData ($index) {
        this.packChannelList.splice($index, 1)
        this.packChannelIdsList.splice($index, 1)
        this.judgeHwyChannel()
      },
      selectChannelList (selectChannelList) {
        this.packChannelList = []
        this.packChannelIdsList = []
        for (let item of selectChannelList) {
          let selectItem = {
            iPlanChannelId: '',
            iChannelId: item.iChannelId,
            iChannelName: item.channelName,
            iIsOffical: item.iIsOffical,
            iPriority: 0
          }
          this.packChannelIdsList.push(item.iChannelId)
          this.packChannelList.push(selectItem)
        }
        this.judgeHwyChannel()
      },
      showAdvCodeDialog () {
        this.optionAdvOrCpsDataDialog.dialogVisible = true
        this.optionAdvOrCpsDataDialog.type = '0'
        this.getPluginList()
      },
      showCpsCodeDialog () {
        this.optionAdvOrCpsDataDialog.dialogVisible = true
        this.optionAdvOrCpsDataDialog.type = '1'
      },
      deleteAdvCpsData ($index, cPackType) {
        this.packAdvCpsIdsList[cPackType].splice($index, 1)
        this.packAdvCpsList[cPackType].splice($index, 1)
      },
      selectAdvCpsDataList (selectAdvCpsDataList, packType) {
        this.packAdvCpsIdsList[packType] = []
        this.packAdvCpsList[packType] = []
        for (let item of selectAdvCpsDataList) {
          let selectItem = {
            iPlanAdId: '',
            iAdcodeId: item.iAdcodeId,
            adcpsCode: item.cAdcpsCode,
            cPackType: item.cPackType,
            sDemo: item.sDemo,
            offical: item.cOfficial,
            pluginIds: item.cAdPluginIds,
            cAdPluginConfigIds: item.cAdPluginConfigIds
          }
          this.packAdvCpsIdsList[packType].push(selectItem.iAdcodeId)
          this.packAdvCpsList[packType].push(selectItem)
        }
      },
      getPluginList () {
        let _this = this
        let params = {
          platformId: this.dataInfoForm.iPlatformId,
          languageId: this.dataInfoForm.iLanguageId,
          areaId: this.dataInfoForm.iAreaId
        }
        pluginApi.getPluginDataList(2, params).then((data) => {
          if (data.code === 1) {
            _this.pluginList = data.data
          }
        }, (error) => {
          console.log(error)
          _this.pluginList = null
        })
      },
      getPluginInfo (plugins, pluginConfigIds) {
        let spList = []
        for (let pItem of this.pluginList) {
          if (plugins.indexOf(pItem.iPluginId) >= 0) {
            for (let spItem of pItem.pluginVersionList) {
              if (pluginConfigIds.indexOf(spItem.iPluginConfigId) >= 0) {
                pItem.iPluginConfigId = spItem.iPluginConfigId
                spList.push(pItem.pluginName + '--' + spItem.pluginVersion)
              }
            }
          }
        }
        return spList
      },
      showUserSubcribe () {
        this.optionSubcribeListDataDialog.dialogVisible = true
      },
      deleteSubcribeData ($index) {
        this.packSubcribeList.splice($index, 1)
//        this.packSubcribeIdsList.splice($index, 1)
      },
      selectSubcribeList (selectSubcribeDataList) {
//        console.log(selectSubcribeDataList)
//        this.packSubcribeIdsList = []
        this.packSubcribeList = []
        for (let item of selectSubcribeDataList.userOrgList) {
          let selectItem = {
            name: item.cRealName,
            pinyinName: item.cUserName,
            type: 1
//            iUserId: item.iUserId,
//            cRoleName: item.cRoleName,
//            cRealName: item.cRealName,
//            cUserName: item.cUserName
          }
//          this.packSubcribeIdsList.push(selectItem.iUserId)
          this.packSubcribeList.push(selectItem)
        }
        this.optionSubcribeListDataDialog.dialogVisible = false
      },
      submitForm (formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            if (this.packChannelList.length <= 0) {
              this.$alert('打包渠道信息不可为空', '提醒', {
                type: 'warning',
                confirmButtonText: '确定'
              })
              return false
            }
            this.$confirm('是否确定提交计划', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.submitFormData()
            }).catch(() => {
            })
          } else {
            return false
          }
        })
      },
      submitFormData () {
        let _this = this
        let submitDataInfo = JSON.parse(JSON.stringify(_this.dataInfoForm))
        submitDataInfo.packPlanChannelRecordVOList = []
        submitDataInfo.deleteChannelIDs = []
        let tempChannel = []
        if (this.dataInfoForm.packPlanChannelRecordVOList && this.dataInfoForm.packPlanChannelRecordVOList.length > 0) {
          for (let packItem of this.dataInfoForm.packPlanChannelRecordVOList) {
            if (this.packChannelIdsList.indexOf(packItem.iChannelId) < 0) {
              submitDataInfo.deleteChannelIDs.push(packItem.iChannelId)
            } else {
              submitDataInfo.packPlanChannelRecordVOList.push(packItem)
              tempChannel.push(packItem.iChannelId)
            }
          }
        }
        for (let packItem of this.packChannelList) {
          if (tempChannel.indexOf(packItem.iChannelId) < 0) {
            submitDataInfo.packPlanChannelRecordVOList.push(packItem)
          }
        }

        submitDataInfo.packPlanAdRecordList = []
        submitDataInfo.deleteAdIDs = []
        if (this.hasHwyChannel) {
          let tempAdvCps = []
          if (this.dataInfoForm.packPlanAdRecordList && this.dataInfoForm.packPlanAdRecordList.length > 0) {
            for (let advItem of _this.dataInfoForm.packPlanAdRecordList) {
              if (this.packAdvCpsIdsList['0'].indexOf(advItem.iAdcodeId) < 0 && this.packAdvCpsIdsList['1'].indexOf(advItem.iAdcodeId) < 0) {
                submitDataInfo.deleteAdIDs.push(advItem.iPlanAdId)
              } else {
                submitDataInfo.packPlanAdRecordList.push({
                  iPlanAdId: advItem.iPlanAdId,
                  iAdcodeId: advItem.iAdcodeId
                })
                tempAdvCps.push(advItem.iAdcodeId)
              }
            }
          }
          for (let advItem of this.packAdvCpsList['0']) {
            if (tempAdvCps.indexOf(advItem.iAdcodeId) < 0) {
              submitDataInfo.packPlanAdRecordList.push({
                iPlanAdId: advItem.iPlanAdId,
                iAdcodeId: advItem.iAdcodeId
              })
            }
          }
          for (let advItem of this.packAdvCpsList['1']) {
            if (tempAdvCps.indexOf(advItem.iAdcodeId) < 0) {
              submitDataInfo.packPlanAdRecordList.push({
                iPlanAdId: advItem.iPlanAdId,
                iAdcodeId: advItem.iAdcodeId
              })
            }
          }
        }

        submitDataInfo.packPlanSubcribeVOList = []
        submitDataInfo.deleteUserIDs = []
//        let tempUser = []
//        if (this.dataInfoForm.packPlanSubcribeVOList && this.dataInfoForm.packPlanSubcribeVOList.length > 0) {
//          for (let packItem of this.dataInfoForm.packPlanSubcribeVOList) {
//            if (this.packSubcribeIdsList.indexOf(packItem.iUserId) < 0) {
//              submitDataInfo.deleteUserIDs.push(packItem.iPlanSubcribeId)
//            } else {
//              submitDataInfo.packPlanSubcribeVOList.push(packItem)
//              tempUser.push(packItem.iUserId)
//            }
//          }
//        }
//        for (let packItem of this.packSubcribeList) {
//          if (tempUser.indexOf(packItem.iUserId) < 0) {
//            submitDataInfo.packPlanSubcribeVOList.push(packItem)
//          }
//        }
        planApi.postPackPlanRecord(submitDataInfo).then((data) => {
          if (data.code === 1) {
            this.$router.push('/home/plan/list')
//            if (this.$route.path === '/home/plan/option/update') {
//              this.$router.push('/home/plan/list/progress')
//            } else {
//              this.$router.push('/home/plan/list')
//            }
          } else {
            this.$alert(data.msg, '打包计划失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      }
    }
  }
</script>
