<style scoped>
  .top-crumb{
    margin-bottom: 10px;
  }
</style>
<style>
</style>
<template>
  <div class="content">
    <div class="top-crumb">
      <el-row>
        <el-col :span="16">
          <bread-crumb-config></bread-crumb-config>
        </el-col>
        <el-col :span="8" style="text-align: right;">
          <el-button size="small" type="success" @click="addDataItem()" v-if="roleAuthority.insertBtn">新增</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="sDicName" label="字典名称" width="300"></el-table-column>
        <el-table-column prop="cDicType" label="字典别名" width="300"></el-table-column>
        <el-table-column prop="sDicDetail" label="字典详情"></el-table-column>
        <el-table-column
          label="操作" width="80">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.updateBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData" ></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import dictionaryApi from '../../apis/dictionary-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/dictionary/optionDialog'

  export default{
    components: {
      breadCrumbConfig,
      pagination,
      optionDialog
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        dataInfoForm: {
          sDicName: '',
          cDicType: '',
          dictItemList: [
            {
              sDicName: '',
              sDicValue: '',
              iOrderNum: '1',
              cEnable: '1'
            }
          ]
        },
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        dictionaryApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          sDicName: '',
          cDicType: '',
          dictItemList: [
            {
              sDicName: '',
              sDicValue: '',
              iOrderNum: '1',
              cEnable: '1'
            }
          ]
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        /*
        dictionaryApi.getDataInfo(data[$index].iDicId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        }) */
        this.optionDataDialog.type = 'update'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = JSON.parse(JSON.stringify(data[$index]))
      }
    }
  }

</script>

