<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="platformName" label="平台" width="150">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.platformName)"></i>{{scope.row.platformName}}
          </template>
        </el-table-column>
        <el-table-column prop="sVersion" label="版本" width="200"></el-table-column>
        <el-table-column prop="sDesc" label="描述"></el-table-column>
        <el-table-column prop="dCreate" label="创建时间" width="200"></el-table-column>
        <el-table-column prop="cDisplay" label="状态" width="100">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column
          label="操作" width="120">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index,scope.row, dataList)">{{scope.row.cDisplay==0?'下架':'上架'}}</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="updateDataInfo(scope.$index,scope.row, dataList)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import packMachineApi from '../../apis/pack-machine-api'
  import planUtil from '../../utils/plan-util'
  import optionForm from '../../components/manager/optionForm'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/pack/machineOptionDialog'

  export default{
    components: {
      optionForm,
      breadCrumbConfig,
      pagination,
      optionDialog
    },
    data () {
      return {
        optionParams: {
          platformId: '',
          cDisplay: '0'
        },
        optionData: {
          showPlatform: true,
          showDataDisplay: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        joinUpGameList: [],
        joinUpGameData: {
          dialogFormVisible: false
        },
        dataInfoForm: {
          iPlatformId: '',
          engineVersion: '',
          engineName: ''
        },
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo', 'machineOptionParams'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.machineOptionParams) {
        this.optionParams.platformId = this.machineOptionParams.platformId
        this.optionParams.cDisplay = this.machineOptionParams.cDisplay
      }
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        // 获取数据列表
        packMachineApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setMachineOptionParams', JSON.parse(JSON.stringify(this.optionParams)))
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
          sVersion: '',
          sDesc: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, $item, data) {
        packMachineApi.getDataInfo($item.iPackMachineId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $item, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $item.iPackMachineId
          let status = $item.cDisplay === 0 ? '1' : '0'
          packMachineApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $item.cDisplay = status
              this.searchDataList()
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>
