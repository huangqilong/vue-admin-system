<style scoped>
</style>
<style>
  .pack-tool-form{
    width: 70%;
  }
  .pack-tool-form .el-select{
    width: 100%;
  }
  .pack-tool-form .pack-tool-form-btn{
    width: 100%;
    font-size: 18px;
    letter-spacing: 1em;
  }
</style>

<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <el-tabs v-model="firstTabValue" type="card" class="tabs-content" @tab-click="selectTabFirst">
      <el-tab-pane label="SDK测试" :name="firstTabList[0]" v-if="roleAuthority.sdkTestPack">
        <installPackList packType="sdkPack"></installPackList>
      </el-tab-pane>
      <el-tab-pane label="游戏测试" :name="firstTabList[1]" v-if="roleAuthority.gameTestPack">
        <installPackList packType="rulePack"></installPackList>
      </el-tab-pane>
      <el-tab-pane label="打整包" :name="firstTabList[2]" v-if="roleAuthority.gameInstallPack">
        <el-tabs v-model="secondTabValue" type="card" @tab-click="selectTabSecond">
          <el-tab-pane label="渠道整包" :name="secondTabList[0]">
            <installPackList packType="channelPack"></installPackList>
          </el-tab-pane>
          <el-tab-pane label="CPS包" :name="secondTabList[1]">
            <installPackList packType="cpsPack"></installPackList>
          </el-tab-pane>
          <el-tab-pane label="广告包" :name="secondTabList[2]">
            <installPackList packType="advPack"></installPackList>
          </el-tab-pane>
        </el-tabs>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import installPackList from '../../components/pack/installPackList'
  export default{
    components: {
      breadCrumbConfig,
      installPackList
    },
    computed: {
      ...mapGetters([
        'firstTabValue', 'secondTabValue', 'firstTabList', 'secondTabList', 'roleAuthority'
      ])
    },
    data () {
      return {
      }
    },
    created: function () {
    },
    methods: {
      selectTabFirst (data) {
        this.$store.dispatch('setFirstTabValue', data.name)
      },
      selectTabSecond (data) {
        this.$store.dispatch('setSecondTabValue', data.name)
      }
    }
  }

</script>
