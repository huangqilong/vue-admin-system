<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <div class="option-form">
      <el-form :inline="true" label-width="80px" :model="searchForm" ref="searchForm">
        <el-row>
          <el-col :span="24" style="text-align: left;">
            <el-form-item label="姓名：" >
              <el-input size="small" v-model="searchForm.cUserName" auto-complete="off" style="width:150px;"></el-input>
            </el-form-item>
            <el-form-item label="时间：">
              <el-date-picker
                size="small"
                v-model="searchForm.searchDate"
                type="daterange"
                align="right"
                unlink-panels
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :picker-options="pickerOptions">
              </el-date-picker>
            </el-form-item>
            <el-form-item v-if="false">
              <el-button size="small" type="primary" @click="searchDataList()" v-if="roleAuthority.searchBtn">查询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="platformName" label="姓名"></el-table-column>
        <el-table-column prop="engineVersion" label="操作类型"></el-table-column>
        <el-table-column prop="engineName" label="路径"></el-table-column>
        <el-table-column prop="engineName" label="操作内容"></el-table-column>
        <el-table-column prop="userName" label="IP地址"></el-table-column>
        <el-table-column prop="dCreate" label="创建时间"></el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import engineApi from '../../apis/engine-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'

  export default{
    components: {
      breadCrumbConfig,
      pagination
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        searchForm: {
          cUserName: '',
          searchDate: ''
        },
        pickerOptions: {
          shortcuts: [{
            text: '最近一周',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近一个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          }, {
            text: '最近三个月',
            onClick (picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }]
        },
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'engineOptionParams'
      ])
    },
    watch: {
      searchForm: {
        handler: function (newVal) {
          this.searchDataList()
        },
        deep: true
      }
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        engineApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      }
    }
  }

</script>

