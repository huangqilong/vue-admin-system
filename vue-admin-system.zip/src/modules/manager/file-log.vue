<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <div class="option-form">
      <el-form :inline="true" label-width="85px" :model="searchForm" ref="searchForm">
        <el-row>
          <el-col :span="22" style="text-align: left;">
            <el-form-item label="计划类型：">
              <el-select size="small" v-model="searchForm.iPlanType" clearable placeholder="请选择" style="width:150px;">
                <el-option
                  v-for="item in planTypeDataList"
                  :key="item.iDicId"
                  :label="item.sDicName"
                  :value="item.iDicId">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="计划状态：">
              <el-select size="small" v-model="searchForm.cPlanStatus" clearable placeholder="请选择" style="width:150px;">
                <el-option
                  v-for="item in planStatusList"
                  :key="item.iDicId"
                  :label="item.sDicName"
                  :value="item.iDicId">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="计划平台：">
              <el-select size="small" v-model="searchForm.platformId" clearable placeholder="请选择" style="width:150px;">
                <el-option
                  v-for="item in platformList"
                  :key="item.iDicId"
                  :label="item.sDicName"
                  :value="item.iDicId">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="文件来源：">
              <el-select size="small" v-model="searchForm.fileResource" clearable placeholder="请选择" style="width:150px;">
                <el-option
                  v-for="item in fileResourceTypeList"
                  :key="item.iDicId"
                  :label="item.sDicName"
                  :value="item.iDicId">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="计划编号：" >
              <el-input size="small" v-model="searchForm.iPlanId" style="width:150px;"></el-input>
            </el-form-item>
            <el-form-item label="持续时间：" >
              <span>大于</span>&nbsp;&nbsp;<el-input size="small" v-model="searchForm.continueDate"  style="width:110px;"></el-input>
            </el-form-item>
            <el-form-item v-if="false">
              <el-button size="small" type="primary" @click="searchDataList()" v-if="roleAuthority.searchBtn">查询</el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2" style="text-align: right;">
            <el-form-item>
              <el-button size="small" type="success" @click="deleteDataInfo()" v-if="roleAuthority.deleteBtn">批量删除</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="content-list">
      <el-table :data="dataList" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55">
        </el-table-column>
        <el-table-column prop="platformName" label="计划编号"></el-table-column>
        <el-table-column prop="engineVersion" label="计划类型"></el-table-column>
        <el-table-column prop="engineName" label="计划状态"></el-table-column>
        <el-table-column prop="engineName" label="计划名称"></el-table-column>
        <el-table-column prop="userName" label="计划平台"></el-table-column>
        <el-table-column prop="userName" label="文件来源"></el-table-column>
        <el-table-column prop="userName" label="文件状态"></el-table-column>
        <el-table-column prop="userName" label="文件路径"></el-table-column>
        <el-table-column prop="userName" label="文件名称"></el-table-column>
        <el-table-column prop="dCreate" label="文件生成时间"></el-table-column>
        <el-table-column prop="dCreate" label="已持续时间"></el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import engineApi from '../../apis/engine-api'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'

  export default{
    components: {
      breadCrumbConfig,
      pagination
    },
    data () {
      return {
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        searchForm: {
          iPlanType: '',
          cPlanStatus: '',
          platformId: '',
          fileResource: '',
          iPlanId: '',
          continueDate: ''
        },
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'planTypeDataList', 'planStatusList', 'platformList', 'fileResourceTypeList'
      ])
    },
    watch: {
      searchForm: {
        handler: function (newVal) {
          this.searchDataList()
        },
        deep: true
      }
    },
    created: function () {
      this.pageData.number = this.pageNumber
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number}
        // 获取数据列表
        engineApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      handleSelectionChange (val) {
        console.log(val)
      },
      deleteDataInfo () {

      }
    }
  }

</script>
