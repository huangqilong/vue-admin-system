<style scoped>
</style>
<style>
</style>
<template>
  <div class="content">
    <bread-crumb-config></bread-crumb-config>
    <optionForm :optionData="optionData" :dataInfoForm="optionParams"></optionForm>
    <div class="content-list">
      <el-table :data="dataList" stripe>
        <el-table-column prop="platformName" label="平台" width="150">
          <template scope="scope">
            <i class="ext-icon-plan-small" :class="getIconClassName(scope.row.platformName)"></i>{{scope.row.platformName}}
          </template>
        </el-table-column>
        <el-table-column prop="engineVersion" label="引擎版本" width="200">
          <template scope="scope">
            <a v-if="scope.row.iGameNum>0" @click="toEngineGameList(scope.$index, dataList)">{{scope.row.engineVersion}}</a>
            <span v-if="scope.row.iGameNum<=0">{{scope.row.engineVersion}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="engineName" label="引擎描述"></el-table-column>
        <el-table-column label="接入游戏资源数" width="200">
          <template scope="scope">
            <a v-if="scope.row.iGameNum>0" @click="showJoinUpDialog(scope.$index, dataList)">{{scope.row.iGameNum}}</a>
            <span v-if="scope.row.iGameNum<=0">{{scope.row.iGameNum}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="cDisplay" label="状态" width="100">
          <template scope="scope">
            {{scope.row.cDisplay==1?'已下架':'使用中'}}
          </template>
        </el-table-column>
        <el-table-column prop="userName" label="操作人" width="120"></el-table-column>
        <el-table-column prop="dCreate" label="创建时间" width="200"></el-table-column>
        <el-table-column
          label="操作" width="150">
          <template scope="scope">
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="dataUpOrDown(scope.$index, dataList)">{{dataList[scope.$index].cDisplay==0?'下架':'上架'}}</el-button>
            <el-button type="text" class="table-option-button" v-if="roleAuthority.statusBtn" @click="updateDataInfo(scope.$index, dataList)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <pagination :pageData="pageData"></pagination>
    <optionDialog v-if="optionDataDialog.dialogFormVisible" :optionData="optionDataDialog" :dataInfoForm="dataInfoForm" :optionCallBack="searchDataList"></optionDialog>
    <joinUpGameDialog v-if="joinUpGameData.dialogFormVisible" :optionConfigData="joinUpGameData" :dataInfoForm="joinUpGameList"></joinUpGameDialog>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import engineApi from '../../apis/engine-api'
  import planUtil from '../../utils/plan-util'
  import optionForm from '../../components/manager/optionForm'
  import breadCrumbConfig from '../../components/manager/breadCrumbConfig'
  import pagination from '../../components/manager/pagination'
  import optionDialog from '../../components/engine/optionDialog'
  import joinUpGameDialog from '../../components/game/joinUpDialog'

  export default{
    components: {
      optionForm,
      breadCrumbConfig,
      pagination,
      optionDialog,
      joinUpGameDialog
    },
    data () {
      return {
        optionParams: {
          platformId: '',
          cDisplay: '0'
        },
        optionData: {
          showPlatform: true,
          showDataDisplay: true,
          showSearchBtn: true,
          showAddBtn: true,
          searchCallBack: this.searchDataList,
          addCallBack: this.addDataItem
        },
        pageData: {
          currentPage: 1,
          number: 10,
          totalCount: 0,
          callPageChange: this.pageChange
        },
        optionDataDialog: {
          type: 'add',
          dialogFormVisible: false
        },
        joinUpGameList: [],
        joinUpGameData: {
          dialogFormVisible: false
        },
        dataInfoForm: {
          iPlatformId: '',
          engineVersion: '',
          engineName: ''
        },
        dataList: null
      }
    },
    computed: {
      ...mapGetters([
        'pageNumber', 'roleAuthority', 'defaultAreaPlatLanInfo', 'engineOptionParams'
      ])
    },
    created: function () {
      this.pageData.number = this.pageNumber
      if (this.engineOptionParams) {
        this.optionParams.platformId = this.engineOptionParams.platformId
        this.optionParams.cDisplay = this.engineOptionParams.cDisplay
      }
      this.searchDataList()
    },
    methods: {
      // 查询数据列表回调
      searchDataList () {
        let _this = this
        const params = {'currentPage': this.pageData.currentPage, 'number': this.pageData.number, ...this.optionParams}
        // 获取数据列表
        engineApi.getDataList(params).then((data) => {
          if (data.code === 1) {
            _this.dataList = data.data.list
            _this.pageData.totalCount = data.data.pageVO.iTotalRowCount
            this.$store.dispatch('setEngineOptionParams', JSON.parse(JSON.stringify(this.optionParams)))
          } else {
            this.$alert(data.msg, '数据列表获取失败', {
              confirmButtonText: '确定'
            })
            this.dataList = null
          }
        }, (error) => {
//          this.$alert('数据列表获取失败，请稍后重试！', '友情提醒', {
//            confirmButtonText: '确定'
//          })
          this.dataList = null
        })
      },
      // 分页回调
      pageChange (currentPage, number) {
        this.pageData.currentPage = currentPage || this.pageData.currentPage
        this.pageData.number = number || this.pageData.number
        this.searchDataList()
      },
      // 新增数据窗口回调
      addDataItem () {
        this.optionDataDialog.type = 'add'
        this.optionDataDialog.dialogFormVisible = true
        this.dataInfoForm = {
          iPlatformId: this.defaultAreaPlatLanInfo.iPlatformId,
          engineVersion: '',
          engineName: ''
        }
      },
      // 编辑数据
      updateDataInfo ($index, data) {
        engineApi.getDataInfo(data[$index].iEngineId).then((data) => {
          if (data.code === 1) {
            this.dataInfoForm = data.data
            this.optionDataDialog.type = 'update'
            this.optionDataDialog.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '信息获取失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      // 数据上架或下架
      dataUpOrDown ($index, $data) {
        this.$confirm('是否确定修改该条数据的状态？', '操作', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let id = $data[$index].iEngineId
          let status = $data[$index].cDisplay === '0' ? '1' : '0'
          engineApi.updateDataStatus(id, status).then((data) => {
            if (data.code === 1) {
              $data[$index].cDisplay = status
            } else {
              this.$alert(data.msg, '修改失败', {
                confirmButtonText: '确定'
              })
            }
          }, (error) => {
            this.$alert(error, '请求失败', {
              confirmButtonText: '确定'
            })
          })
        }).catch(() => {
          // 取消操作
        })
      },
      showJoinUpDialog ($index, $data) {
        // 获取引擎接入游戏列表
        engineApi.getEnginGameDataList($data[$index].iEngineId).then((data) => {
          if (data.code === 1) {
            this.joinUpGameList = data.data.list
            this.joinUpGameData.dialogFormVisible = true
          } else {
            this.$alert(data.msg, '请求失败', {
              confirmButtonText: '确定'
            })
          }
        }, (error) => {
          this.$alert(error, '请求失败', {
            confirmButtonText: '确定'
          })
        })
      },
      toEngineGameList ($index, $data) {
        this.$router.push({path: '/home/game/list', query: {iEngineId: $data[$index].iEngineId}})
      },
      getIconClassName (iconName) {
        return planUtil.getPlanIconClass(iconName)
      }
    }
  }

</script>

